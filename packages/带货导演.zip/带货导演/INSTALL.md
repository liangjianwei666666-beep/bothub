# 安装说明 · 带货导演

## 装法一：交给主 Bot 装（推荐）
把压缩包整个发给主 Bot（DeepSeekHarness + DSBOT 插件），它会读完包内文件并建出 Bot。不用解压。

## 装法二：手动建
1. 解压本包。
2. 复制 `BOT.md` 全文，贴进新 Bot（名字「带货导演」）的指令。
3. 建三个空目录：`脚本/` `成片/` `素材/`，再建一份 `台账.md`（照 `参考/台账模板.md` 抄）。

## 这个包不含出片能力
它是一份**导演指令 + 三份作业规程**，本身不会渲染视频。真正出片要用本机的这些技能：

- `trend-proof-piece`（选梗方法论，最核心）
- `mg-storyboard`（A 路：纯代码动效，不烧生图钱）
- `ai-video-pipeline` + `telangpuai-imagegen`（B 路：需要生图 / 生视频 Key）
- `cover-publish`、`five-platform-publish`、`sensitive-check`

装法：把对应技能目录放进你的技能目录（通常 `~/.agents/skills/`），或在主 Bot 里让它装。**没装技能就出不了片，这一点先确认。**

## 装完之后
第一次跑，挑一个你熟悉的商品，走完整条链（选梗 → 脚本 → 出片 → 封面 → 发布作战卡），别一上来就批量。
