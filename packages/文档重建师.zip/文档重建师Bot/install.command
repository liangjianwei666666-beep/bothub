#!/usr/bin/env bash
# macOS 双击入口：双击本文件即可安装（首次可能需右键 → 打开）
HERE="$(cd "$(dirname "$0")" && pwd)"
exec /bin/bash "$HERE/install.sh" "$@"
