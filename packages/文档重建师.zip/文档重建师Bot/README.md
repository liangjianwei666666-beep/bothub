# 文档重建师 Bot · 一键安装包 v1.0.0

把 PDF 重建成**按页对齐、可逐页核对**的 Markdown + 单文件 HTML。这个包给其他 DS Bot 用户安装用。

底座是开源技能 [KY Markdown Rebuilder](https://github.com/KyrieCheungYep/ky-markdown-rebuilder)（作者 KyrieCheungYep，115★），已内置在 `tools/ky-markdown-rebuilder/`。

## 装完是什么样

- 一个「文档重建师」Bot，默认输出 `<源文件名>.calibrated.md` + `<源文件名>.calibrated.html`
- 一份自动生成的工作台 `工作台/index.html`：能力体检 + 交付记录 + 收件交办
- 三种硬能力：逐页原图核对、`check_output.py` 验收闸门（退出码 0 才许交付）、图抽取与 HTML 输出

## macOS 安装（三步）

1. 解压本包
2. **双击 `install.command`**，或在终端执行：
   ```bash
   bash install.sh
   ```
   默认装到 `~/文档重建师`；换位置：
   ```bash
   bash install.sh "/你选的目录/文档重建师"
   ```
3. 把 `1-发给主Bot一键创建.md` 里的指令发给 DS Bot 主 Bot，由它创建 Bot（工作目录填安装目录）

安装脚本会：铺工具链 → 建独立 venv 并装 PDF 依赖 → 探测 pdftoppm/pdfinfo/soffice → 生成工作台 → 跑端到端自检（在临时目录造 2 页 PDF 走完整流水线，不碰你的文件）。

装完打开 `工作台/index.html` 能看到真实体检结果。

## 已实测（2026-11-03）

- 机器：macOS + DSH Desktop；系统 Python 3.9.6，DSH 内置 Python 3.12.14（后者拒绝加载 pip 编译库，脚本自动回退到系统 Python）
- 全新安装 + 重复安装各跑一遍，端到端自检 16 项全过（含 transcribe 与 page-aligned 两种契约）
- 从 zip 解压后安装同样通过；4 页纯扫描 PDF 能正确识别「文字层为空」

## Windows / 其他环境

没有 `.command` 双击入口。解压后把 `BOT.md` 全文交给主 Bot，并要求按 `1-发给主Bot一键创建.md` 创建；工具链需 Python 3.10+ 与 poppler（`pdftoppm`），路径以实际环境为准。

## 依赖

| 依赖 | 是否必须 | 说明 |
| --- | --- | --- |
| Python 3.9+ | 必须 | 安装脚本会逐个试，跳过加载不了 pip 编译库的 Python（新版 App 内置 Python 有硬化签名），自动回退到系统 Python |
| poppler（pdftoppm / pdfinfo） | 必须 | DS Bot 运行时目录通常自带；没有就 `brew install poppler` |
| node / npm | 可选 | 只用于 xparse 扫描件初稿路线 |
| tesseract | 不需要 | 扫描件走视觉模型转写或 xParse，不静默装 OCR |

Python 依赖（脚本自动装）：pypdf、pdfminer.six、pdfplumber、pillow；markitdown 为可选（装不上时用内置 `ky-extract-text.py` 提取，功能等价）。

> 已知坑：新版 DS Bot 的内置 Python 带硬化签名，pip 装的 `.so` 会被 macOS 拒绝加载（报 code signature / Team ID）。安装脚本会实测「能否加载编译库」，失败就换下一个 Python，不需要手动处理。

## 包含内容

```
文档重建师Bot/
  install.sh              安装脚本（复制工具链 + venv + 探测 + 自检 + 工作台）
  install.command         macOS 双击入口
  BOT.md                  Bot 完整说明（创建 Bot 时作为 instructions）
  README.md               本文件
  manifest.json           包元信息
  1-发给主Bot一键创建.md   给主 Bot 的创建指令
  tools/
    ky-markdown-rebuilder/  上游开源技能包（只读）
    bin/                    本机工具：环境装载、HTML 转换、抽图、xParse、工作台、自检
    样例/                   已通过验收的参照交付物
```

## 最小使用

```bash
cd ~/文档重建师
source bin/ky-env.sh && ky_check                 # 环境自检
"$KY_PY" bin/ky-workbench.py --work-dir . --init  # 工作台（缺失时才需要）
```

## 卸载

```bash
rm -rf ~/文档重建师
```
工作台里只记路径，没有系统级安装项，删目录即可。

## 许可与来源

- 上游 KY Markdown Rebuilder：MIT（见上游仓库），本包原样内置未修改
- 本包新增脚本（ky-env.sh / ky-md-to-html.py / ky-extract-images.py / ky-xparse.py / ky-workbench.py / ky-selfcheck.py）随包提供，可自由修改
