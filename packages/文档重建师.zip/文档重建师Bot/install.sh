#!/usr/bin/env bash
# 文档重建师 Bot —— 一键安装
# 用法： bash install.sh [安装目录] [--skip-deps] [--skip-check]
# 默认装到 ~/文档重建师
#
# 做五件事：
#   1. 铺工具链（上游 KY Markdown Rebuilder + 本机脚本）
#   2. 找一个能真正加载 pip 编译库的 Python，建独立 venv
#   3. 装 PDF 依赖（markitdown 可选，pdfplumber/pypdf 必装）
#   4. 探测 pdftoppm / pdfinfo / soffice 并缓存进 bin/ky-env.local.sh
#   5. 生成工作台 + 端到端自检
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST=""
SKIP_DEPS=0
SKIP_CHECK=0
for arg in "$@"; do
  case "$arg" in
    --skip-deps)  SKIP_DEPS=1 ;;
    --skip-check) SKIP_CHECK=1 ;;
    -h|--help)    sed -n '2,13p' "$0"; exit 0 ;;
    *)            DEST="$arg" ;;
  esac
done
DEST="${DEST:-$HOME/文档重建师}"
DEST="${DEST/#\~/$HOME}"

say() { printf '%s\n' "$*"; }
step() { printf '\n\033[1m%s\033[0m\n' "$*"; }

say "安装到：$DEST"
mkdir -p "$DEST"

# ---------------------------------------------------------------- 1. 工具链
step "1/5 铺工具链"
HERE_REAL="$(cd "$HERE" && pwd -P)"
DEST_REAL="$(cd "$DEST" && pwd -P)"
if [ "$HERE_REAL" = "$DEST_REAL" ]; then
  say "  目标目录就是安装包目录，跳过复制"
else
  rm -rf "$DEST/ky-markdown-rebuilder"
  cp -R "$HERE/tools/ky-markdown-rebuilder" "$DEST/"
  mkdir -p "$DEST/bin"
  cp "$HERE"/tools/bin/* "$DEST/bin/" 2>/dev/null || true
  cp "$HERE/BOT.md" "$DEST/AGENTS.md"
  rm -rf "$DEST/样例"
  cp -R "$HERE/tools/样例" "$DEST/样例" 2>/dev/null || true
  chmod +x "$DEST/bin"/*.sh 2>/dev/null || true
  say "  已复制：bin/（$(ls "$DEST/bin" | wc -l | tr -d ' ') 个脚本）、ky-markdown-rebuilder/、样例/"
fi
mkdir -p "$DEST/work" "$DEST/.ky-md-work" "$DEST/工作台"

# ---------------------------------------------------------------- 2. Python
step "2/5 找可用的 Python 并建 venv"
ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
  APP_PY="/Applications/DSH Desktop.app/Contents/Resources/runtime/arm64/primary-runtime/dependencies/python/bin/python3"
  APP_PY_ALT="/Applications/DSH Desktop.app/Contents/Resources/runtime/x64/primary-runtime/dependencies/python/bin/python3"
else
  APP_PY="/Applications/DSH Desktop.app/Contents/Resources/runtime/x64/primary-runtime/dependencies/python/bin/python3"
  APP_PY_ALT="/Applications/DSH Desktop.app/Contents/Resources/runtime/arm64/primary-runtime/dependencies/python/bin/python3"
fi

py_min_ok() {
  [ -n "${1:-}" ] && [ -x "$1" ] || return 1
  "$1" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1
}

# 建 venv 并验证「能不能加载 pip 装的编译库」。
# 新版 DS Bot 的 App 内置 Python 带硬化签名，pip 装的 .so 会被拒绝加载；
# 这种 Python 直接跳过，换系统/官方 Python。
try_python() {
  local c="$1" vp
  rm -rf "$DEST/venv"
  "$c" -m venv "$DEST/venv" >/dev/null 2>&1 || return 1
  if [ -x "$DEST/venv/bin/python3" ]; then vp="$DEST/venv/bin/python3"; else vp="$DEST/venv/bin/python"; fi
  "$vp" -m pip install --quiet --upgrade pip >/dev/null 2>&1 || true
  "$vp" -m pip install --quiet "cryptography<44" pillow >/dev/null 2>&1 || return 1
  "$vp" -c "import PIL.Image" >/dev/null 2>&1 || return 1
  return 0
}

CANDS=()
add_cand() {
  local c="${1:-}" x
  [ -n "$c" ] && [ -x "$c" ] || return 0
  for x in "${CANDS[@]:-}"; do [ "$x" = "$c" ] && return 0; done
  CANDS+=("$c")
}
add_cand "$APP_PY"
add_cand "$APP_PY_ALT"
add_cand "/Applications/DS Bot.app/Contents/Resources/primary-runtime/dependencies/python/bin/python3"
add_cand "$(command -v python3.13 || true)"
add_cand "$(command -v python3.12 || true)"
add_cand "$(command -v python3.11 || true)"
add_cand "$(command -v python3.10 || true)"
add_cand /opt/homebrew/bin/python3
add_cand /usr/local/bin/python3
add_cand /usr/bin/python3
add_cand "$(command -v python3 || true)"

CHOSEN=""
# 已装过且 venv 还能加载编译库 → 直接复用，重装不必再逐个试
if [ -x "$DEST/venv/bin/python3" ] && "$DEST/venv/bin/python3" -c "import PIL.Image" >/dev/null 2>&1; then
  CHOSEN="$DEST/venv/bin/python3（复用已装 venv）"
  VENV_PY="$DEST/venv/bin/python3"
  say "  复用已有 venv：$("$VENV_PY" -V 2>&1)"
else
for c in "${CANDS[@]}"; do
  py_min_ok "$c" || continue
  V="$("$c" -V 2>&1 | awk '{print $2}')"
  say "  试用 $c（Python $V）…"
  if try_python "$c"; then
    CHOSEN="$c"
    break
  fi
  say "    不可用：这个 Python 拒绝加载 pip 编译库（常见于 App 硬化签名），换下一个"
done
fi

if [ -z "$CHOSEN" ]; then
  say "错误：没找到能用的 Python 3.9+。请安装官方 Python（https://www.python.org/downloads/）后重试。"
  exit 1
fi
VENV_PY="$DEST/venv/bin/python3"
[ -x "$VENV_PY" ] || VENV_PY="$DEST/venv/bin/python"
say "  采用：$CHOSEN"

# ---------------------------------------------------------------- 3. 依赖
pip_install() {
  if "$VENV_PY" -m pip install --quiet "$@" 2>/dev/null; then return 0; fi
  say "    默认源失败，改用清华镜像重试…"
  "$VENV_PY" -m pip install --quiet -i https://pypi.tuna.tsinghua.edu.cn/simple "$@"
}

if [ "$SKIP_DEPS" -eq 0 ]; then
  step "3/5 装 PDF 依赖（首次约 1–3 分钟）"
  pip_install pypdf pdfminer.six pdfplumber
  if "$VENV_PY" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)'; then
    # markitdown 只是锦上添花；装不上不影响主流程（ky-extract-text.py 兜底）
    if pip_install markitdown; then
      say "  markitdown 已装"
    else
      say "  markitdown 装不上，用内置 ky-extract-text.py 提取（功能不受影响）"
    fi
  else
    say "  当前 Python < 3.10，markitdown 不支持；用内置 ky-extract-text.py 提取"
  fi
  say "  依赖装好"
else
  step "3/5 跳过依赖安装（--skip-deps）"
fi

# ---------------------------------------------------------------- 4. 工具探测
step "4/5 探测 pdftoppm / pdfinfo / soffice"
tool_candidates() {
  printf '%s\n' \
    "$DEST/bin" \
    "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override" \
    "$HOME"/.cache/codex-runtimes/*/dependencies/bin/override \
    "/Applications/DSH Desktop.app/Contents/Resources/runtime/x64/primary-runtime/dependencies/bin" \
    "/Applications/DSH Desktop.app/Contents/Resources/runtime/arm64/primary-runtime/dependencies/bin" \
    "/Applications/DS Bot.app/Contents/Resources/primary-runtime/dependencies/bin/override" \
    "/Applications/DS Bot.app/Contents/Resources/primary-runtime/dependencies/bin" \
    /opt/homebrew/bin /usr/local/bin
}

TOOLBIN=""
while IFS= read -r d; do
  [ -n "$d" ] && [ -d "$d" ] || continue
  if [ -x "$d/pdftoppm" ] || [ -x "$d/soffice" ]; then TOOLBIN="$d"; break; fi
done <<EOF
$(tool_candidates)
EOF

NODE_BIN=""
for d in "/Applications/DSH Desktop.app/Contents/Resources/runtime/x64/primary-runtime/dependencies/node/bin" \
         "/Applications/DSH Desktop.app/Contents/Resources/runtime/arm64/primary-runtime/dependencies/node/bin"; do
  if [ -x "$d/node" ]; then NODE_BIN="$d"; break; fi
done

{
  echo "# 由 install.sh 生成；删掉本文件可让 ky-env.sh 重新探测"
  [ -n "$TOOLBIN" ] && echo "export KY_TOOLBIN=\"$TOOLBIN\""
  [ -n "$NODE_BIN" ] && echo "export KY_NODE_BIN=\"$NODE_BIN\""
  echo "export KY_PY=\"$VENV_PY\""
} > "$DEST/bin/ky-env.local.sh"

if [ -n "$TOOLBIN" ]; then
  say "  工具目录：$TOOLBIN"
  say "  命中：$(cd "$TOOLBIN" && ls pdftoppm pdfinfo soffice 2>/dev/null | tr '\n' ' ')"
else
  say "  ⚠ 没找到 pdftoppm / pdfinfo。渲染逐页原图依赖它们："
  say "    macOS：brew install poppler"
  say "    或确认 DS Bot 运行时目录里有 pdftoppm"
fi

# xparse 可选：装不上不影响主流程
XP_STATE="未安装（可选）"
if [ "$SKIP_DEPS" -eq 0 ]; then
  NPM="$(command -v npm || true)"
  if [ -z "$NPM" ] && [ -n "$NODE_BIN" ] && [ -e "$NODE_BIN/npm" ]; then NPM="$NODE_BIN/npm"; fi
  if [ -n "$NPM" ]; then
    if PATH="$NODE_BIN:$(dirname "$NPM"):$PATH" "$NPM" i -g xparse-cli \
         --registry=https://registry.npmmirror.com >/dev/null 2>&1; then
      XP_STATE="已装（未认证每日 1000 页免费额度）"
    else
      XP_STATE="装失败（不影响主流程；需要时手动 npm i -g xparse-cli）"
    fi
  else
    XP_STATE="未装 npm，跳过（扫描件可用视觉转写）"
  fi
else
  XP_STATE="跳过（--skip-deps）"
fi

# ---------------------------------------------------------------- 5. 工作台 + 自检
step "5/5 自检并生成工作台"
# shellcheck disable=SC1091
. "$DEST/bin/ky-env.sh"

"$VENV_PY" "$DEST/bin/ky-workbench.py" --work-dir "$DEST" \
  --bot-name "文档重建师" --version "1.0.0" --init >/dev/null

CHECK_RESULT="未运行（--skip-check）"
if [ "$SKIP_CHECK" -eq 0 ]; then
  if "$VENV_PY" "$DEST/bin/ky-selfcheck.py" --work-dir "$DEST"; then
    CHECK_RESULT="通过"
  else
    CHECK_RESULT="有失败项（见上方输出）"
  fi
fi

cat <<EOF

══════════════════════════════════════════
安装位置   $DEST
Python     $CHOSEN
工作台     $DEST/工作台/index.html
自检       $CHECK_RESULT
xparse     $XP_STATE
══════════════════════════════════════════

下一步（二选一）：

A. 双击打开 $DEST/工作台/index.html 先看体检结果；
B. 把安装包里的「1-发给主Bot一键创建.md」内容发给 DS Bot 主 Bot，
   由它创建「文档重建师」Bot，工作目录填：
   $DEST

以后每次会话，Bot 先执行：
   cd "$DEST" && source bin/ky-env.sh && ky_check

EOF
