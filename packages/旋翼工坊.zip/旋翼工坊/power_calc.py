#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""无人机方案早期估算器：推重比 / 悬停油门 / 续航 / 重量等级。
用法:
  python3 power_calc.py --weight 240 --motors 4 --thrust 180 --battery 450 --volt 7.4
说明: 估算是工程经验模型，用于早期筛选方案，不能替代实测。
"""
import argparse, sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weight', type=float, required=True, help='起飞重量 g（含电池）')
    ap.add_argument('--motors', type=int, default=4)
    ap.add_argument('--thrust', type=float, required=True, help='单电机最大拉力 g')
    ap.add_argument('--battery', type=float, default=450, help='电池容量 mAh')
    ap.add_argument('--volt', type=float, default=7.4, help='电池电压 V（1S=3.7）')
    ap.add_argument('--hover-efficiency', type=float, default=110, help='悬停功率 W/kg（小型多轴经验值 90-150）')
    a = ap.parse_args()

    total_thrust = a.thrust * a.motors
    twr = total_thrust / a.weight
    # 推力近似与油门平方成正比 -> 悬停油门 = sqrt(重量/总拉力)
    hover_throttle = (a.weight / total_thrust) ** 0.5 * 100
    energy_wh = a.battery / 1000 * a.volt
    hover_power_w = a.hover_efficiency * (a.weight / 1000)
    usable = 0.8  # 保留 20% 电量不榨干
    minutes = (energy_wh * usable) / hover_power_w * 60 if hover_power_w > 0 else 0

    level = '微型（<250g）' if a.weight < 250 else ('轻型（<=7kg 起飞）' if a.weight <= 7000 else '小型及以上')
    print('=== 方案估算 ===')
    print(f'总最大拉力 : {total_thrust:.0f} g')
    print(f'推重比 TWR : {twr:.2f}')
    print(f'悬停油门   : {hover_throttle:.0f}%')
    print(f'电池能量   : {energy_wh:.1f} Wh')
    print(f'悬停功率   : {hover_power_w:.1f} W')
    print(f'估算续航   : {minutes:.1f} 分钟（保留 20% 电量）')
    print(f'重量等级   : {level}')
    print()
    verdict = []
    if twr < 1.3: verdict.append('✗ 推重比偏低（<1.3），抗风与机动不足，建议换更大桨或减重')
    elif twr < 1.6: verdict.append('△ 推重比 1.3-1.6，能飞但余量小，室内/无风环境可以')
    elif twr <= 2.5: verdict.append('✓ 推重比 1.6-2.5，适配入门到进阶')
    else: verdict.append('△ 推重比 >2.5，机动过强，新手难控，且多半续航短')
    if hover_throttle > 70: verdict.append('△ 悬停油门 >70%，几乎没有纠偏余量，容易掉')
    if a.weight >= 250: verdict.append('! 已超过 250g，不再是"微型"，法规要求不同（需实名登记，轻型还需成人现场指导）')
    else: verdict.append('✓ 属微型（<250g），适飞空域内自飞无需执照；但所有者仍需实名登记')
    print('=== 结论 ===')
    for v in verdict: print(v)
    print('\n注：模型粗糙，只用于早期筛选；真实推力和续航必须实测。')

if __name__ == '__main__':
    main()
