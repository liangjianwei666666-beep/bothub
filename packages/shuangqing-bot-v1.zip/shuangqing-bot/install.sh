#!/bin/bash
# 双擎调度 Bot —— 一键安装器
set -u
# 兼容常见安装位置（nvm/local/bin/bun）
for d in "$HOME"/.nvm/versions/node/*/bin "$HOME/.local/bin" "$HOME/.bun/bin" /opt/homebrew/bin /usr/local/bin; do
  [ -d "$d" ] && PATH="$d:$PATH"
done
export PATH
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="${1:-$HOME/Desktop/bot}"
echo "== 安装到: $DEST"
mkdir -p "$DEST/tools" "$DEST/docs"
cp -R "$SRC/tools/." "$DEST/tools/"
cp -R "$SRC/docs/." "$DEST/docs/" 2>/dev/null
cp "$SRC/BOT.md" "$DEST/BOT.md" 2>/dev/null
chmod +x "$DEST/tools/"*.sh "$DEST/tools/"*.py 2>/dev/null

echo "== 依赖检查"
command -v node >/dev/null || echo "  ! 缺 node（codex/pi/WorkBuddy 需要）"
command -v python3 >/dev/null && echo "  ok python3: $(python3 -V 2>&1)"
python3 -c "import playwright" 2>/dev/null && echo "  ok playwright(python)" || echo "  ! 缺 playwright: python3 -m pip install playwright && python3 -m playwright install chromium"
if command -v uv >/dev/null; then
  ( cd "$DEST" && uv venv tools/venv --python 3.11 >/dev/null 2>&1 && uv pip install -q --python tools/venv/bin/python "rnet>=3.0.0rc20" --prerelease=allow >/dev/null 2>&1 \
    && echo "  ok rnet（X 监控用）" || echo "  ! rnet 安装失败，X 监控不可用" )
else
  echo "  ! 缺 uv，X 监控依赖 rnet 需另装（pip install 'rnet>=3.0.0rc20' --pre，需 py>=3.11）"
fi

echo "== 引擎探测"
[ -x /Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex ] && echo "  ok codex" || echo "  - codex 未装（需 ChatGPT macOS 客户端）"
command -v pi >/dev/null && echo "  ok pi" || echo "  - pi 未装"
[ -f /Applications/WorkBuddy.app/Contents/Resources/app.asar.unpacked/cli/dist/codebuddy-lite-wb.mjs ] && echo "  ok WorkBuddy" || echo "  - WorkBuddy 未装"

echo "== 下一步（需要登录的浏览器引擎，各跑一次即可）"
echo "  Gemini : cd $DEST && python3 tools/gemini_login_headed.py   # 弹窗登录 Google"
echo "  Doubao : cd $DEST && python3 tools/doubao_login_headed.py   # 弹窗扫码登录豆包"
echo "  X 监控 : 先导出 cookie 到 $DEST/tools/twitter_cookies.json（auth_token/ct0）"
echo ""
echo "✅ 完成。把 $DEST/BOT.md 的内容贴进新建 Bot 的 instructions，即可开用。"
