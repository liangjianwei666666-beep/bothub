import time, os, sys
from playwright.sync_api import sync_playwright
PROFILE=os.path.expanduser('~/Library/Application Support/dsh-doubao-profile')
os.makedirs(PROFILE, exist_ok=True)
LOG='/Users/a1-6/Desktop/bot/tools/doubao-login-status.log'
def log(m):
    with open(LOG,'a') as f: f.write(time.strftime('%H:%M:%S ')+m+'\n')
    print(m, flush=True)
open(LOG,'w').write('start\n')
with sync_playwright() as p:
    ctx = p.chromium.launch_persistent_context(PROFILE, headless=False,
        args=['--proxy-server=direct://','--proxy-bypass-list=*','--disable-blink-features=AutomationControlled','--start-maximized'],
        locale='zh-CN', timezone_id='Asia/Shanghai',
        user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
        viewport=None, no_viewport=True)
    pg = ctx.pages[0] if ctx.pages else ctx.new_page()
    pg.goto('https://www.doubao.com/chat/', wait_until='domcontentloaded', timeout=60000)
    time.sleep(5)
    log("URL:"+pg.url)
    body = pg.inner_text('body')
    if '登录' in body[:500]:
        try:
            pg.evaluate("""() => { const els=[...document.querySelectorAll('button,span,div')].filter(e=>e.textContent.trim()==='登录'); if(els.length){els[els.length-1].click();} }""")
            log("clicked login")
        except Exception as e: log("click err "+str(e))
    log("WAITING_FOR_LOGIN 窗口已打开，等待扫码/登录，最长 15 分钟")
    for i in range(180):
        time.sleep(5)
        try: b = pg.inner_text('body')
        except Exception: continue
        if '登录' not in b[:500]:
            log("LOGGED_IN at "+time.strftime('%H:%M:%S'))
            time.sleep(4)
            pg.screenshot(path='/Users/a1-6/Desktop/bot/tools/doubao-loggedin.png')
            ctx.close(); sys.exit(0)
        if i % 12 == 0: log(f"still waiting {i*5}s")
    log("TIMEOUT_NO_LOGIN")
    ctx.close()
