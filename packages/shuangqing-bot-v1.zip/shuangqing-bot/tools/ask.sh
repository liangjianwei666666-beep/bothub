#!/bin/zsh
# 统一派单：ask.sh <engine> <prompt文件|-> [--dir DIR] [--timeout N]
TOOLS="$(cd "$(dirname "$0")" && pwd)"
for d in "$HOME"/.nvm/versions/node/*/bin "$HOME/.local/bin" "$HOME/.bun/bin" /opt/homebrew/bin /usr/local/bin; do [ -d "$d" ] && PATH="$d:$PATH"; done
export PATH
ENGINE="$1"; shift; PF_ARG="$1"; shift
DIR="$PWD"; TIMEOUT=300
while [ $# -gt 0 ]; do case "$1" in
  --dir) DIR="$2"; shift 2;;
  --timeout) TIMEOUT="$2"; shift 2;;
  *) shift;; esac; done
mkdir -p "$DIR/out"
if [ "$PF_ARG" = "-" ]; then PROMPT="$(cat)"; else PROMPT="$(cat "$PF_ARG")"; fi
SLUG="$(date +%m%d-%H%M%S)-$ENGINE"
PF="$DIR/out/$SLUG.prompt"; OF="$DIR/out/$SLUG.md"; LOG="$DIR/out/$SLUG.log"
printf '%s\n' "$PROMPT" > "$PF"
S=$(date +%s); CODE=0
case "$ENGINE" in
  codex)
    python3 "$TOOLS/rwt.py" "$TIMEOUT" /Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex exec \
      --skip-git-repo-check -C "$DIR" -s workspace-write -o "$OF" "$PROMPT" </dev/null >"$LOG" 2>&1 || CODE=$?;;
  wb)
    (cd "$DIR" && python3 "$TOOLS/rwt.py" "$TIMEOUT" "$TOOLS/wb.sh" -p "$PROMPT" -y --output-format text </dev/null >"$OF" 2>"$LOG") || CODE=$?;;
  pi)
    (cd "$DIR" && python3 "$TOOLS/rwt.py" "$TIMEOUT" pi -p --thinking off "$PROMPT" </dev/null >"$OF" 2>"$LOG") || CODE=$?;;
  gemini)
    (cd "$DIR" && python3 "$TOOLS/rwt.py" "$TIMEOUT" python3 "$TOOLS/gemini_chat.py" "$PROMPT" >"$OF" 2>"$LOG") || CODE=$?;;
  grok)
    (cd "$DIR" && python3 "$TOOLS/rwt.py" "$TIMEOUT" "$TOOLS/grok_chat.sh" "$PROMPT" >"$OF" 2>"$LOG") || CODE=$?;;
  doubao)
    (cd "$DIR" && python3 "$TOOLS/rwt.py" "$TIMEOUT" python3 "$TOOLS/doubao_chat.py" "$PROMPT" >"$OF" 2>"$LOG") || CODE=$?;;
  *) echo "unknown engine: $ENGINE"; exit 9;;
esac
E=$(date +%s); SZ=$(wc -c <"$OF" 2>/dev/null | tr -d ' ')
echo "engine=$ENGINE exit=$CODE sec=$((E-S)) out=$OF size=$SZ"
