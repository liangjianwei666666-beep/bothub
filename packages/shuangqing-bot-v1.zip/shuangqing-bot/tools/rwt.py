import subprocess, sys
t=float(sys.argv[1]); cmd=sys.argv[2:]
try:
    r=subprocess.run(cmd, timeout=t)
    sys.exit(r.returncode)
except subprocess.TimeoutExpired:
    print(f"[TIMEOUT {t}s]"); sys.exit(124)
