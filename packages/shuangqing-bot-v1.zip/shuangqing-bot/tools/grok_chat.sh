#!/bin/zsh
# Grok 网页版派活：grok_chat.sh "问题" [秒]
export PATH="$HOME/.bun/bin:$PATH"
B="$HOME/.agents/skills/gstack/browse/dist/browse"
PROMPT="$1"; WAIT="${2:-180}"
$B cookie-import-browser chrome --domain .grok.com >/dev/null 2>&1
$B goto https://grok.com >/dev/null 2>&1
sleep 5
$B fill 'div[contenteditable="true"]' "$PROMPT" >/dev/null 2>&1 || { echo "ERROR: 找不到输入框"; exit 3; }
sleep 1
$B press Enter >/dev/null 2>&1
echo "SENT"
START=$(date +%s); LAST=""; STABLE=0
while [ $(( $(date +%s) - START )) -lt $WAIT ]; do
  sleep 4
  T=$($B js "(()=>{const m=document.querySelector('main')||document.body;return m.innerText})()" 2>/dev/null)
  K=$(printf '%s' "$T" | grep -c "Grok finished responding" || true)
  if [ "$T" = "$LAST" ]; then STABLE=$((STABLE+4)); else STABLE=0; LAST="$T"; fi
  if [ "$K" -gt 0 ] || [ "$STABLE" -ge 12 ]; then break; fi
done
printf '%s\n' "$LAST" | sed -n '/^Grok$/,$p' | tail -n +2 | sed '/^Worked for/d;/^Grok finished responding/d'
