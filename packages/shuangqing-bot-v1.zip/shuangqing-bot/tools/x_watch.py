#!/usr/bin/env python3
"""监测指定 X 账号新推文；命中关键词退出码 10。
默认 @thsottiaux（Codex 重置播报）。环境变量: X_HANDLE, X_KEYWORDS, TX_COOKIES
"""
import asyncio, sys, os, json, re, time
BASE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from rnet_twitter import RnetTwitterClient
HANDLE=os.environ.get('X_HANDLE','thsottiaux')
COOKIES=os.environ.get('TX_COOKIES', os.path.join(BASE,'twitter_cookies.json'))
STATE=os.path.join(BASE,'.x_state.json'); LOG=os.path.join(BASE,'x_watch.log')
KEY=re.compile(os.environ.get('X_KEYWORDS', r'\breset|重置|quota|usage limit|credit|replenish'), re.I)
def log(m):
    with open(LOG,'a') as f: f.write(time.strftime('%m-%d %H:%M ')+m+'\n')
async def main():
    st=json.load(open(STATE)) if os.path.exists(STATE) else {'seen':[]}
    c=RnetTwitterClient(); c.load_cookies(COOKIES)
    u=await c.get_user_by_screen_name(HANDLE)
    tw=await c.get_user_tweets(u['rest_id'], count=10)
    st['seen']=st.get('seen',[])[-50:]; hits=[]
    for t in reversed(tw):
        tid=str(t.get('id') or t.get('rest_id')); txt=(t.get('text') or '').replace('\n',' ')
        if tid in st['seen']: continue
        log(f"{tid} {txt[:120]}")
        if KEY.search(txt): hits.append((tid,t.get('created_at'),txt))
        st['seen'].append(tid)
    st['last_check']=time.strftime('%Y-%m-%d %H:%M:%S')
    json.dump(st, open(STATE,'w'))
    if hits:
        for tid,ca,txt in hits: print(f"ALERT|{ca}|{tid}|{txt}")
        return 10
    print(f"OK no_alert | new=0 | checked={st['last_check']}")
    return 0
sys.exit(asyncio.run(main()))
