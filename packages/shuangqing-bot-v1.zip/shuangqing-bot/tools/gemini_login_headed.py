import time, os, sys
from playwright.sync_api import sync_playwright
PROFILE=os.path.expanduser('~/Library/Application Support/dsh-gemini-profile')
os.makedirs(PROFILE, exist_ok=True)
LOG='/Users/a1-6/Desktop/bot/tools/gemini-login-status.log'
def log(m):
    open(LOG,'a').write(time.strftime('%H:%M:%S ')+m+'\n'); print(m, flush=True)
open(LOG,'w').write('start\n')
UA='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
with sync_playwright() as p:
    ctx = p.chromium.launch_persistent_context(PROFILE, headless=False,
        args=['--disable-blink-features=AutomationControlled','--start-maximized'],
        locale='zh-CN', timezone_id='Asia/Shanghai', user_agent=UA, no_viewport=True)
    pg = ctx.pages[0] if ctx.pages else ctx.new_page()
    pg.goto('https://gemini.google.com/app', wait_until='domcontentloaded', timeout=90000)
    time.sleep(6)
    log("URL:"+pg.url)
    log("WAITING_FOR_GOOGLE_LOGIN 窗口已打开，请登录 Google，最长 20 分钟")
    for i in range(240):
        time.sleep(5)
        try:
            b = pg.inner_text('body'); url = pg.url
        except Exception:
            continue
        if ('登录' not in b[:500]) and ('Sign in' not in b[:500]) and 'accounts.google.com' not in url:
            log("LOGGED_IN at "+time.strftime('%H:%M:%S'))
            time.sleep(5)
            pg.screenshot(path='/Users/a1-6/Desktop/bot/tools/gemini-loggedin.png')
            ctx.close(); sys.exit(0)
        if i % 12 == 0: log(f"still waiting {i*5}s url={url[:70]}")
    log("TIMEOUT_NO_LOGIN")
    ctx.close()
