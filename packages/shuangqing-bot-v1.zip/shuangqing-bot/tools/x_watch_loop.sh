#!/bin/zsh
# 每 5 分钟查一次，命中即退出（由宿主 Bot 的 background job 机制通知）
TOOLS="$(cd "$(dirname "$0")" && pwd)"
PY="$TOOLS/venv/bin/python"; [ -x "$PY" ] || PY=python3
while true; do
  OUT=$("$PY" "$TOOLS/x_watch.py" 2>&1); CODE=$?
  if [ $CODE -eq 10 ]; then
    echo "$OUT"
    osascript -e 'display notification "Tibo 发推可能涉及 Codex 重置" with title "Codex 重置预警"' 2>/dev/null
    exit 0
  fi
  [ $CODE -ne 0 ] && echo "watch error: $OUT" && sleep 600
  sleep 300
done
