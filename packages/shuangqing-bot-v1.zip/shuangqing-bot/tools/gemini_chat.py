#!/usr/bin/env python3
"""Gemini 网页版派活：python3 gemini_chat.py "问题" [--timeout 300]"""
import sys, time, os
from playwright.sync_api import sync_playwright
PROFILE=os.path.expanduser('~/Library/Application Support/dsh-gemini-profile')
UA='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
def main():
    prompt=sys.argv[1]; timeout=int(sys.argv[sys.argv.index('--timeout')+1]) if '--timeout' in sys.argv else 300
    with sync_playwright() as p:
        ctx=p.chromium.launch_persistent_context(PROFILE, headless=True,
            args=['--disable-blink-features=AutomationControlled'],
            locale='zh-CN', timezone_id='Asia/Shanghai', user_agent=UA)
        pg=ctx.pages[0] if ctx.pages else ctx.new_page()
        pg.goto('https://gemini.google.com/app', wait_until='domcontentloaded', timeout=90000)
        time.sleep(5)
        body=pg.inner_text('body')[:500]
        if '登录' in body or 'Sign in' in body:
            print("ERROR: 未登录，请先跑 tools/gemini_login_headed.py"); ctx.close(); sys.exit(12)
        # 新对话
        try: pg.goto('https://gemini.google.com/app', wait_until='domcontentloaded', timeout=60000); time.sleep(3)
        except Exception: pass
        inp=None
        for sel in ['div.ql-editor','[contenteditable="true"]','rich-textarea [contenteditable]']:
            e=pg.query_selector_all(sel)
            if e: inp=e[-1]; break
        if not inp: print("ERROR: 找不到输入框"); ctx.close(); sys.exit(3)
        inp.click(); time.sleep(0.4); pg.keyboard.insert_text(prompt); time.sleep(1)
        pg.keyboard.press('Enter'); print("SENT", file=sys.stderr, flush=True)
        # 等回复：轮询 model-response 最后一条
        start=time.time(); last=''; stable=0; ans=''
        while time.time()-start<timeout:
            time.sleep(3)
            try:
                rs=pg.query_selector_all('model-response')
                if not rs: continue
                t=rs[-1].inner_text()
            except Exception: continue
            t=t.replace('Gemini said','').replace('Show thinking','').strip()
            for pre in ('Gemini 说','Gemini said'):
                if t.startswith(pre): t=t[len(pre):].strip()
            if t and t==last: stable+=3
            else: stable=0; last=t
            if stable>=9 and len(t)>1: ans=t; break
        print(ans)
        ctx.close()
if __name__=='__main__': main()
