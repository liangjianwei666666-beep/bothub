#!/usr/bin/env python3
"""豆包网页版派活：python3 doubao_chat.py "问题" [--timeout 240]"""
import sys, time, os, re
from playwright.sync_api import sync_playwright
PROFILE = os.path.expanduser('~/Library/Application Support/dsh-doubao-profile')
ARGS=['--proxy-server=direct://','--proxy-bypass-list=*','--disable-blink-features=AutomationControlled']
UA='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'

NOISE = re.compile(r'^(今天|昨天|\d{1,2}:\d{2}|复制|重新生成|分享|点赞|点踩|停止生成|进入新对话|豆包|内容由 ?AI ?生成.*)$')

def clean(txt, prompt):
    i = txt.rfind(prompt[:20])
    seg = txt[i+20:] if i>=0 else txt
    lines=[l.strip() for l in seg.split('\n')]
    out=[l for l in lines if l and not NOISE.match(l)]
    return '\n'.join(out).strip()

def main():
    prompt = sys.argv[1]
    timeout = int(sys.argv[sys.argv.index('--timeout')+1]) if '--timeout' in sys.argv else 240
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(PROFILE, headless=True, args=ARGS,
            locale='zh-CN', timezone_id='Asia/Shanghai', user_agent=UA)
        pg = ctx.pages[0] if ctx.pages else ctx.new_page()
        pg.goto('https://www.doubao.com/chat/', wait_until='domcontentloaded', timeout=60000)
        time.sleep(4)
        if '登录' in pg.inner_text('body')[:300]:
            print("ERROR: 未登录"); ctx.close(); sys.exit(2)
        inp=None
        for sel in ['div[contenteditable="true"]','textarea']:
            e=pg.query_selector_all(sel)
            if e: inp=e[-1]; break
        if not inp:
            print("ERROR: 找不到输入框"); ctx.close(); sys.exit(3)
        inp.click(); time.sleep(0.3)
        # 用 insertText 避免 IME 插入多余空格
        pg.keyboard.insert_text(prompt)
        time.sleep(1); pg.keyboard.press('Enter')
        print(f"SENT {time.strftime('%H:%M:%S')}", file=sys.stderr, flush=True)
        start=time.time(); last=''; stable=0; ans=''
        while time.time()-start < timeout:
            time.sleep(3)
            try:
                cont = pg.query_selector('[class*="message-list"]')
                t = cont.inner_text() if cont else pg.inner_text('body')
            except Exception:
                continue
            seg = clean(t, prompt)
            if seg and seg==last: stable+=3
            else: stable=0; last=seg
            if stable>=9 and len(seg)>1:
                ans=seg; break
        print(ans)
        if not ans: print("(空回复，可能仍在生成)")
        ctx.close()

if __name__=='__main__': main()
