#!/bin/zsh
# WorkBuddy(CodeBuddy Code) CLI 包装：走自定义模型通道
for d in "$HOME"/.nvm/versions/node/*/bin "$HOME/.local/bin" "$HOME/.bun/bin" /opt/homebrew/bin /usr/local/bin; do [ -d "$d" ] && PATH="$d:$PATH"; done
export PATH
P="${WB_CLI:-/Applications/WorkBuddy.app/Contents/Resources/app.asar.unpacked/cli/dist/codebuddy-lite-wb.mjs}"
[ -f "$P" ] || { echo "ERROR: 未找到 WorkBuddy CLI，请设 WB_CLI"; exit 4; }
if [ -z "$CODEBUDDY_API_KEY" ]; then
  CODEBUDDY_API_KEY="$(pi auth print-api-key --provider ${WB_PROVIDER:-telangpuai} 2>/dev/null | tr -d '\n')"
fi
export CODEBUDDY_API_KEY
export CODEBUDDY_BASE_URL="${WB_BASE_URL:-https://telangpuai.com}"
export CODEBUDDY_MODEL="${WB_MODEL:-gpt-6-astra}"
exec node "$P" "$@"
