#!/bin/bash
# 摘要读取：sum.sh <out文件> [行数，默认30]
F="$1"; MAX="${2:-30}"
[ -f "$F" ] || { echo "no file: $F"; exit 1; }
if grep -qE '={2,}SUMMARY={2,}' "$F"; then
  awk '/={2,}SUMMARY={2,}/{f=1;next}/={2,}END={2,}/{f=0}f' "$F" | head -n "$MAX"
else
  grep -v '^[[:space:]]*$' "$F" | head -n "$MAX"
fi
