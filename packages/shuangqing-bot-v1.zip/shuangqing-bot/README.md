# 双擎调度 Bot（多引擎派活包）

把本机已订阅的 AI（Codex / Gemini / Grok / WorkBuddy / 豆包 / pi）接成一个统一调度台，主力模型只做调度，不烧上下文。

## 一键安装
```bash
bash install.sh                # 默认装到 ~/Desktop/bot
bash install.sh /你的/目录      # 自定义
```

## 然后
1. 打开 `BOT.md`，内容贴进新建 Bot 的 instructions
2. 网页引擎各登录一次（弹窗）：`python3 tools/gemini_login_headed.py`、`tools/doubao_login_headed.py`
3. 派活：`tools/ask.sh codex 任务.txt --dir ~/proj`
4. 看结论：`tools/sum.sh out/xxx.md`

## 前置
- macOS；node；python3 + playwright（网页引擎）
- Codex 需 ChatGPT 客户端；WorkBuddy 走自定义模型通道（需 `pi auth` 可用或自备 API key）
- 网页引擎按账号订阅额度消耗

## 目录
```
tools/   ask.sh sum.sh 各引擎脚本 登录脚本 X监控
docs/    派活协议.md 省token作业规程.md
BOT.md   新建 Bot 的初始化指令
```
