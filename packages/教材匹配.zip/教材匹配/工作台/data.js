window.STATUS = {
 "generated_at": "2026-11-03 16:28",
 "source_xlsx": "/Users/a1-6/Desktop/外教业务/教科书适用学生及对应课时安排（2026-04-01）.xlsx",
 "catalog": {
  "total": 265,
  "series": 60,
  "no_series": 0,
  "no_hours": [
   {
    "name": "中小学生校园同步教材"
   },
   {
    "name": "剑桥少儿英语Kids‘ Box 0（第二版）"
   },
   {
    "name": "A List少儿口语教材  Speak Up （第一阶段）"
   },
   {
    "name": "A List少儿口语教材  Speak Up Plus （第二阶段）"
   }
  ],
  "no_level": 33,
  "categories": [
   {
    "name": "青少年英语",
    "total": 122,
    "linked": 101,
    "hours": 120
   },
   {
    "name": "青少儿灵动版",
    "total": 79,
    "linked": 74,
    "hours": 77
   },
   {
    "name": "日常英语",
    "total": 17,
    "linked": 13,
    "hours": 17
   },
   {
    "name": "商务英语",
    "total": 15,
    "linked": 15,
    "hours": 15
   },
   {
    "name": "语音课程",
    "total": 15,
    "linked": 5,
    "hours": 15
   },
   {
    "name": "考试英语",
    "total": 6,
    "linked": 5,
    "hours": 6
   },
   {
    "name": "外贸英语",
    "total": 6,
    "linked": 0,
    "hours": 6
   },
   {
    "name": "出国英语",
    "total": 5,
    "linked": 3,
    "hours": 5
   }
  ]
 },
 "bridge": {
  "series_total": 60,
  "linked": 44,
  "unlinked": 16,
  "unlinked_list": [
   {
    "name": "American School Textbook",
    "cn": "美国学前/幼儿学科英语 American School Textbook",
    "books": 8
   },
   {
    "name": "Hooked on Phonics",
    "cn": "Hooked on Phonics",
    "books": 7
   },
   {
    "name": "Starlight",
    "cn": "牛津星光英语 Starlight",
    "books": 6
   },
   {
    "name": "Writing 3000",
    "cn": "朗文少儿英语写作3000词",
    "books": 6
   },
   {
    "name": "Sight Words Reader",
    "cn": "高频词流利阅读 Sight Words Reader",
    "books": 5
   },
   {
    "name": "DK English for Everyone",
    "cn": "DK新视觉·人人学英语 第N册教程",
    "books": 4
   },
   {
    "name": "Foreign Trade",
    "cn": "外贸英语（话题王 / 脱口而出 / 口语大全 / 函电）",
    "books": 4
   },
   {
    "name": "School Sync",
    "cn": "中小学生校园同步教材",
    "books": 1
   },
   {
    "name": "Sight Word Fluency",
    "cn": "高频词流利阅读 Sight Word Fluency",
    "books": 1
   },
   {
    "name": "IPA",
    "cn": "国际音标与语音语调",
    "books": 1
   },
   {
    "name": "Let's Learn ABC",
    "cn": "春喜自编 ABC 教材",
    "books": 1
   },
   {
    "name": "Study Abroad",
    "cn": "留学英语情景会话50主题",
    "books": 1
   },
   {
    "name": "Current Affairs 50",
    "cn": "英语畅谈时事热点50主题",
    "books": 1
   },
   {
    "name": "Visa English",
    "cn": "美国签证口语指南",
    "books": 1
   },
   {
    "name": "Shop English",
    "cn": "商铺英语情景口语50主题",
    "books": 1
   },
   {
    "name": "Exhibition English",
    "cn": "会展英语",
    "books": 1
   }
  ],
  "auto": [
   "Practice Oral",
   "Reach"
  ]
 },
 "level_link": {
  "total": 61,
  "ok": 53,
  "miss": [
   {
    "series": "美国地理 Wonder Skills",
    "group": "少儿英语"
   },
   {
    "series": "美国加州数学 CMs",
    "group": "少儿英语"
   },
   {
    "series": "NTC少儿英语系列",
    "group": "少儿英语"
   },
   {
    "series": "NTD少儿英语系列",
    "group": "少儿英语"
   },
   {
    "series": "自研-青少年英语日常口语训练",
    "group": "青少年英语"
   },
   {
    "series": "脱口说",
    "group": "青少年英语"
   },
   {
    "series": "零基础学英语",
    "group": "(成人)通用英语"
   },
   {
    "series": "即学即说-综合能力提升话题",
    "group": "(成人)通用英语"
   }
  ]
 },
 "levels": [
  {
   "name": "1级",
   "band": "Preparatory 入门级",
   "desc": "基本没有学习过英语，或者已经完全忘记.完全没有办法表达与沟通"
  },
  {
   "name": "2级",
   "band": "Preparatory 入门级",
   "desc": "只会一些简单的单词，基本无法表达与沟通，但能简单说出一些关键词"
  },
  {
   "name": "3级",
   "band": "Beginner 初级",
   "desc": "能简单说出一些熟悉的单词与句子。但无法完全表达自己的意愿"
  },
  {
   "name": "4级",
   "band": "Beginner 初级",
   "desc": "能简单做自我介绍，对熟悉的话题基本能简单讨论，无法深刻表达"
  },
  {
   "name": "5级",
   "band": "Intermediate 中级",
   "desc": "能简单表达自己熟悉的句子。有一定的英语句型与简单的语法运用。"
  },
  {
   "name": "6级",
   "band": "Intermediate 中级",
   "desc": "有一定的词汇量并且能熟悉表达一些复合型句子与一定的英语思维模式。"
  },
  {
   "name": "7级",
   "band": "Advanced 高级",
   "desc": "能基本上应付各种场合流畅自如的交流与具有丰富的词汇量。"
  },
  {
   "name": "8级",
   "band": "Advanced 高级",
   "desc": "在大部分场合可以自如，精准使用英语，能深入表达各种话题。"
  },
  {
   "name": "9级",
   "band": "Expert 专家级",
   "desc": "所有场合都能熟练使用英语，运用自如，接近母语发音"
  },
  {
   "name": "10级",
   "band": "Expert 专家级",
   "desc": "能精准，自信的交流。理解所有的对话内容，达到母音发音水平"
  }
 ],
 "covers": {
  "files": 253,
  "mb": 13.0,
  "missing": 12,
  "shared": 0
 },
 "teacher": {
  "total": 397,
  "photo": 396,
  "file": "/Users/a1-6/Desktop/外教业务/外教匹配/match.py"
 },
 "tests": {
  "passed": 13,
  "failed": 0,
  "cases": [
   {
    "ok": true,
    "text": "8岁孩子想练口语               → 美国地道英语口语教材 Speaking Time 灵动版3"
   },
   {
    "ok": true,
    "text": "三年级想补阅读                → 第2版牛津少儿英语探索系列 Oxford Discover 3"
   },
   {
    "ok": true,
    "text": "要准备KET                 → 剑桥少儿英语教材 Power Up 4"
   },
   {
    "ok": true,
    "text": "初中生备考PET               → 第2版 剑桥青少年英语 THiNK L5"
   },
   {
    "ok": true,
    "text": "五年级想练写作                → 朗文少儿英语写作3000词 04级别"
   },
   {
    "ok": true,
    "text": "零基础启蒙                  → 牛津自然拼读世界 1"
   },
   {
    "ok": true,
    "text": "幼儿园4岁学自然拼读             → 牛津自然拼读世界 1"
   },
   {
    "ok": true,
    "text": "成人想练商务英语               → 剑桥商务英语初级"
   },
   {
    "ok": true,
    "text": "外贸从业想练口语               → 外贸英语口语脱口而出"
   },
   {
    "ok": true,
    "text": "想考雅思                   → 雅思口语必备核心话题"
   },
   {
    "ok": true,
    "text": "零基础成人想出国旅游             → 旅游出国英语口语900句"
   },
   {
    "ok": true,
    "text": "想练旅游英语                 → 旅游出国英语口语900句"
   },
   {
    "ok": true,
    "text": "成人想练口语                 → 日常自由交流 （共三册）"
   }
  ],
  "ok": true
 }
};
