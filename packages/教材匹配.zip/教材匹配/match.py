#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
教材匹配器 V1 —— 说一句「孩子几岁、想学什么、能上多少节」，回你一本教材 + 一位能教它的外教。

用法：
    python3 match.py --text "8岁孩子想练口语"
    python3 match.py --audience kid --goal 阅读 --level 3级
    python3 match.py --text "三年级补阅读" --hours 80
    python3 match.py --text "成人想练商务英语" --chat

设计原则（照搬 外教匹配 的三条，不另起一套）：
1. 先建桥再匹配。教材目录是中文名、265 条、同名不同级；老师库是英文标签、72 种写法。
   不做归一，关键词一撞就错配。所以 data/series.json 是桥，data/level_link.json 是第二座桥。
2. 每一分都能解释。分数由「目标方向 / 人群 / 级别 / 课时预算 / 老教材来源」组成，
   给家长看的 reason 只说人话，不出现分数和字段名。
3. 不确定的要说出来。分差小于 6 分算同档；课时数是表里的建议值不是承诺；
   有些系列老师库里根本没有标签 —— 这些缺口直接写出来，不假装匹配上了。
"""
import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUSINESS = ROOT.parent
MATCH_DIR = BUSINESS / "外教匹配"
DATA = ROOT / "data"

CATALOG = json.loads((DATA / "catalog.json").read_text(encoding="utf-8"))["courses"]
SERIES = json.loads((DATA / "series.json").read_text(encoding="utf-8"))["series"]
LEVELS = json.loads((DATA / "levels.json").read_text(encoding="utf-8"))["levels"]
LEVEL_LINK = json.loads((DATA / "level_link.json").read_text(encoding="utf-8"))["books"]
COVER_INDEX = json.loads((DATA / "cover_index.json").read_text(encoding="utf-8"))["index"]
COVER_DIR = ROOT / "封面"

TIE_BAND = 6.0        # 分差在这以内算同档，不假装排得准
HOURS_TOLERANCE = 1.25  # 预算超出建议课时 25% 以内仍可接受

# ---------------- 目标归一化 ----------------
GOAL_ALIASES = {
    "口语": ["口语", "开口", "说话", "表达", "对话", "oral", "speaking", "conversation", "交流"],
    "阅读": ["阅读", "reading", "分级阅读", "绘本", "读"],
    "启蒙": ["启蒙", "零基础", "入门", "phonics", "自然拼读", "幼儿", "学前"],
    "少儿综合": ["少儿综合", "综合", "系统学", "教材课", "打基础", "同步"],
    "应试YLE": ["yle", "剑桥少儿", "starters", "movers", "flyers"],
    "应试KET": ["ket"],
    "应试PET": ["pet"],
    "应试FCE": ["fce"],
    "应试BEC": ["bec"],
    "应试雅思": ["雅思", "ielts"],
    "应试托福": ["托福", "toefl"],
    "商务": ["商务", "职场", "business", "工作", "会议", "汇报", "谈判"],
    "外贸": ["外贸", "贸易", "进出口", "fob"],
    "旅行": ["旅行", "旅游", "出国", "travel", "出境", "酒店", "餐厅"],
    "写作": ["写作", "writing", "作文"],
    "词汇": ["词汇", "单词", "word"],
    "语法": ["语法", "grammar"],
    "语音": ["语音", "发音", "音标", "口音", "语调"],
    "进阶": ["进阶", "高阶", "拔高", "学术", "国际学校", "留学"],
}

TYPE_ALIASES = {
    "菲律宾": ["菲教", "菲律宾", "菲", "philippine", "filipino"],
    "欧美": ["欧美", "北美", "native", "western", "美国老师", "英国老师"],
    "中教": ["中教", "中国老师", "国内老师", "双语老师"],
}

CN_NUM = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}


def norm(s):
    s = str(s).replace("\u3000", " ").replace("\xa0", " ")
    s = s.replace("‘", "'").replace("’", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip().lower()


def parse_goals(raw):
    out, unknown = set(), []
    for g in raw:
        gl = str(g).lower()
        hit = False
        for std, keys in GOAL_ALIASES.items():
            if any(k in gl for k in keys):
                out.add(std)
                hit = True
        if not hit:
            unknown.append(g)
    return out, unknown


def parse_type(raw):
    if not raw:
        return None
    r = str(raw).lower()
    for std, keys in TYPE_ALIASES.items():
        if any(k in r for k in keys):
            return std
    return None


def parse_text(text):
    """一句人话 → 需求字段。只填能确定识别出来的。"""
    t = str(text)
    out = {"goals": []}

    m = re.search(r"(\d{1,2})\s*[-–~到]\s*(\d{1,2})\s*岁", t)
    if m:
        out["age"] = int(m.group(1))
        out["age_max"] = int(m.group(2))
    else:
        m = re.search(r"(\d{1,2})\s*岁", t)
        if m:
            out["age"] = int(m.group(1))

    m = re.search(r"([一二三四五六七八九十两]|\d{1,2})\s*年级", t)
    if m:
        g = m.group(1)
        grade = int(g) if g.isdigit() else CN_NUM.get(g, 0)
        if grade:
            out["grade"] = grade
            out.setdefault("age", grade + 6)
    if re.search(r"幼儿园|学前|宝宝|prek|pk", t, re.I):
        out.setdefault("age", 4)

    # 「旅游英语 / 商务英语 / 雅思」这类不带年龄的说法，按成人通用课处理
    if re.search(r"成人|大人|职场|上班|面试|雅思|托福|bec|商务|外贸|签证|旅游|旅行|出国|"
                 r"从业|职场|自由交流|自己学|我想学", t, re.I):
        out["audience"] = "adult"
    elif re.search(r"孩子|娃|小朋友|儿子|女儿|小孩|小学生|小学|幼儿园|幼儿|宝宝|启蒙", t):
        out["audience"] = "kid"
    if re.search(r"初中|中学|高中生|青少年|青春期", t):
        out["audience"] = "teen"
    if "grade" in out:
        out["audience"] = "adult" if out["grade"] > 12 else ("teen" if out["grade"] >= 7 else "kid")

    m = re.search(r"(?:水平|等级|级别)?\s*(\d{1,2})\s*级", t)
    if m:
        n = int(m.group(1))
        if 1 <= n <= 10:
            out["level"] = str(n)
    m = re.search(r"[Yy]\s*([1-6])", t)
    if m:
        out["y_level"] = "Y" + m.group(1)

    m = re.search(r"(\d{2,4})\s*(?:节|课时|课)", t)
    if m:
        out["hours"] = int(m.group(1))
    m = re.search(r"(?:预算|只有|能上|大概)\s*(\d{2,4})", t)
    if m and "hours" not in out:
        out["hours"] = int(m.group(1))

    for std, keys in GOAL_ALIASES.items():
        if any(k in t.lower() for k in keys):
            out["goals"].append(std)
    for exam in ["KET", "PET", "FCE"]:
        if exam.lower() in t.lower():
            out["goals"].append("应试" + exam)

    tt = parse_type(t)
    if tt:
        out["type"] = tt

    m = re.search(r"(灵动版|青少年英语|商务英语|语音|雅思|托福)", t)
    if m:
        out["keyword"] = m.group(1)

    seen = set()
    out["goals"] = [g for g in out["goals"] if not (g in seen or seen.add(g))]
    return out


# Y 级 → 推荐教材系列（与《英跃外教小班课课程体系设计方案》一致）
Y_LEVEL_SERIES = {
    "Y1": ["oxford_phonics", "oxford_reading_tree", "lets_go", "kids_box", "power_up"],
    "Y2": ["reading_a_z", "oxford_reading_tree", "lets_go", "kids_box", "power_up", "speaking_time"],
    "Y3": ["reading_a_z", "oxford_reading_tree", "lets_go", "kids_box", "power_up", "fun_for"],
    "Y4": ["reading_a_z", "oxford_reading_tree", "kids_box", "power_up", "speaking_time", "ket"],
    "Y5": ["reading_a_z", "power_up", "speaking_time", "pet", "think"],
    "Y6": ["reading_a_z", "power_up", "think", "reading_explorer"],
}

# 1-10 级 → 该级首选系列（从《英语等级及对应推荐课本》里取最主流的那几套）
LEVEL_SERIES = {
    "1": ["oxford_phonics", "sight_words_reader", "lets_go", "kids_box", "our_world", "everybody_up"],
    "2": ["lets_go", "kids_box", "power_up", "oxford_discover", "our_world", "everybody_up", "speaking_time"],
    "3": ["power_up", "oxford_discover", "reading_a_z", "speaking_time", "fun_for", "kids_box", "starlight"],
    "4": ["power_up", "oxford_discover", "reading_a_z", "reach_higher", "fun_for", "ket", "speaking_time"],
    "5": ["reading_a_z", "power_up", "reach_higher", "reading_explorer", "ket", "english_in_mind"],
    "6": ["reading_a_z", "reach_higher", "reading_explorer", "think", "english_in_mind", "pet"],
    "7": ["reading_explorer", "think", "english_in_mind", "great_writing", "side_by_side", "pet"],
    "8": ["reading_explorer", "think", "great_writing", "side_by_side", "fce"],
    "9": ["reading_explorer", "think", "great_writing", "bec", "ielts"],
    "10": ["reading_explorer", "think", "ielts", "toefl", "bec"],
}

AGE_TO_LEVEL = [(5, "1"), (7, "2"), (9, "3"), (11, "4"), (13, "5"), (15, "6")]


def level_from_age(age):
    for limit, lv in AGE_TO_LEVEL:
        if age <= limit:
            return lv
    return None


# 目标 → 主攻这个方向的系列（用于把「想练写作」落到写作教材上，而不是被综合教材的单元撞上）
GOAL_SERIES = {
    "口语": ["speaking_time", "speak_up", "oral_300", "daily_free_talk", "business_topics100",
             "100_topics_daily", "life_100_topics", "practice_oral", "practical_oral_young"],
    "阅读": ["reading_a_z", "oxford_reading_tree", "reading_explorer", "reading_wonders",
             "sight_words_reader", "sight_word_fluency", "unlock"],
    "启蒙": ["oxford_phonics", "kids_box", "everybody_up", "lets_go", "hooked_on_phonics",
             "abc_lets_learn", "ipa"],
    "写作": ["great_writing", "best_writing", "writing_3000"],
    "词汇": ["basic_1000_words", "sight_words_reader", "sight_word_fluency"],
    "语法": ["new_concept", "junior_new_concept", "side_by_side"],
    "语音": ["ipa", "oxford_phonics", "hooked_on_phonics"],
    "商务": ["bec", "experience_business", "business_topics100", "business_oral",
             "dk_business", "international_trade", "business_english_any"],
    "外贸": ["foreign_trade", "shop_english", "exhibition_english", "business_topics100"],
    # 旅行：通用旅游口语优先，签证/酒店/餐厅这类专用书排后面
    "旅行": ["travel_900", "english_for_tourism", "hotel_english", "restaurant_english", "visa"],
    "应试KET": ["ket", "power_up", "think", "english_in_mind"],
    "应试PET": ["pet", "think", "english_in_mind", "reading_explorer"],
    "应试FCE": ["think", "fce", "reading_explorer"],
    "应试雅E": [],
    "应试雅思": ["ielts"],
    "应试托福": ["toefl"],
    "应试BEC": ["bec"],
    "应试YLE": ["fun_for", "kids_box", "power_up", "everybody_up"],
}

# 考试类目标：没有指定级别时，默认按考试对应级别取（KET≈4级 / PET≈6级）
EXAM_LEVEL = {"应试KET": "4", "应试YLE": "2", "应试PET": "6", "应试FCE": "8", "应试BEC": "9",
              "应试雅思": "9", "应试托福": "9"}

# ---------------- 评分 ----------------
# 泛用系列：命中了也不该压过用户点名的专业方向
GENERIC = {"daily_free_talk", "life_100_topics", "100_topics_daily", "current_affairs_50",
           "practice_oral", "topics_discussing"}

W = {
    "series_hit": 30,       # 命中目标系列（同一系列不同级再加）
    "series_extra": 6,      # 同系列每多一个可衔接的级别
    "goal": 8,              # 每个命中目标（上限 24）
    "audience": 12,         # 人群对得上
    "level_exact": 22,      # 级别正好
    "level_near": 10,       # 级别差一级
    "level_link": 10,       # 被「英语等级对照表」正式推荐到该级
    "hours_fit": 8,         # 课时预算装得下
    "hours_over": -10,      # 装不下
    "keyword": 12,          # 关键词命中（灵动版/商务英语/雅思…）
    "generic_penalty": -6,  # 用户点名了专业方向，泛用教材降权
    "audience_wrong": -25,
    "level_far": 0,
    "level_far_step": 8,     # 级别每差一级扣 8 分
    "level_far_cap": 30,     # 最多扣 30 分
}


def level_num(label):
    """把各种级别写法压成一个可比较的数字（越大越高）。"""
    if not label:
        return None
    s = str(label)
    if s in ("入门", "入门级"):
        return 0
    if s == "学前级":
        return -1
    if s in ("初级",):
        return 2
    if s in ("中级",):
        return 5
    if s in ("高级",):
        return 8
    if s in ("Starters",):
        return 2
    if s in ("Movers",):
        return 3
    if s in ("Flyers",):
        return 4
    m = re.match(r"L(\d{1,2})$", s)
    if m:
        return int(m.group(1))
    m = re.match(r"PreK\s*(\d)$", s, re.I)
    if m:
        return -2 + int(m.group(1)) * 0.1
    m = re.match(r"K\s*(\d)$", s, re.I)
    if m:
        return -1 + int(m.group(1)) * 0.1
    m = re.match(r"G\s*([K\d])", s, re.I)
    if m:
        return 0 if m.group(1).upper() == "K" else int(m.group(1))
    m = re.match(r"(\d{1,2})\s*级$", s)
    if m:
        return int(m.group(1))
    m = re.match(r"(\d)\s*年级", s)
    if m:
        return int(m.group(1))
    m = re.match(r"第(\d{1,2})册$", s)
    if m:
        return int(m.group(1))
    m = re.match(r"(\d{1,2})\s*级别$", s)
    if m:
        return int(m.group(1))
    m = re.match(r"(\d{1,2})$", s)
    if m:
        return int(m.group(1))
    return None


def course_series_ids(c):
    return [c["series"]] if c.get("series") else []


def link_for_series(series_id):
    """这个系列被等级对照表推荐到哪些 Level。"""
    out = set()
    for b in LEVEL_LINK:
        if b.get("ids") and series_id in b["ids"]:
            for lv in b["levels"]:
                out.add(lv.replace("Level ", ""))
    return out


LINK_CACHE = {}


def score_course(c, ctx):
    detail, why = {}, []
    sid = c.get("series")
    s = SERIES.get(sid, {})

    if sid and sid in ctx["target_series"]:
        detail["series_hit"] = W["series_hit"]
        why.append("series")
    if sid and sid in ctx["extra_series"]:
        detail["series_hit"] = max(detail.get("series_hit", 0), W["series_hit"] * 0.5)

    goal_hits = set(s.get("goals", [])) & ctx["goals"]
    if goal_hits:
        strong = sid in ctx["goal_series"]
        if strong:
            # 排列顺序也算权重：列表里排前面的方向更贴用户说的
            rank_bonus = 0
            for g in goal_hits:
                lst = GOAL_SERIES.get(g, [])
                if sid in lst:
                    rank_bonus = max(rank_bonus, max(0, 4 - lst.index(sid)))
            detail["goal"] = min(len(goal_hits) * W["goal"], 24) + rank_bonus
        elif not ctx.get("strict_goal"):
            detail["goal"] = min(len(goal_hits) * W["goal"], 24) * 0.25

    aud = ctx["audience"]
    if aud and aud in c.get("audience", []):
        detail["audience"] = W["audience"]
    elif aud and c.get("audience") and aud not in c["audience"]:
        detail["audience_wrong"] = W["audience_wrong"]

    want = ctx["target_level_num"]
    got = level_num(c.get("level_label"))
    if want is not None and got is not None:
        d = abs(want - got)
        if d < 0.5:
            detail["level_exact"] = W["level_exact"]
            why.append("level")
        elif d <= 1.01:
            detail["level_near"] = W["level_near"]
        else:
            # 差两级以上：这本书对这个水平不合适，扣分，别让「方向对上」把它顶上来
            detail["level_far"] = -min((d - 1) * W["level_far_step"], W["level_far_cap"])

    if sid and ctx["link_level"]:
        if ctx["link_level"] in LINK_CACHE.setdefault(sid, link_for_series(sid)):
            detail["level_link"] = W["level_link"]

    h = c.get("hours")
    if ctx["hours"] and h:
        if h <= ctx["hours"]:
            detail["hours_fit"] = W["hours_fit"]
            why.append("hours")
        elif h > ctx["hours"] * HOURS_TOLERANCE:
            detail["hours_over"] = W["hours_over"]

    if sid in GENERIC and ctx.get("has_specific_goal"):
        detail["generic_penalty"] = W["generic_penalty"]

    if ctx["keyword"]:
        blob = norm(c["name"] + " " + c["category"] + " " + c.get("audience_text", ""))
        if norm(ctx["keyword"]) in blob:
            detail["keyword"] = W["keyword"]
            why.append("keyword")

    return sum(detail.values()), detail, why


# ---------------- 对外教 ----------------
def teacher_series_candidates(primary_series, goals, audience):
    """主推系列配不上老师时的兜底链路：
       主推 → 同目标方向里有老师标签的系列 → 同人群里最主流的可教系列。"""
    out = []
    def add(sid):
        if not sid or sid in out or sid not in SERIES:
            return
        if SERIES[sid].get("match_series_exists"):
            out.append(sid)

    add(primary_series)
    for g in goals:
        for sid in GOAL_SERIES.get(g, []):
            if sid in SERIES and (not audience or audience in SERIES[sid]["audience"]):
                add(sid)
    for sid, v in SERIES.items():
        if audience and audience in v["audience"] and v["courses"]:
            add(sid)
    return out


def find_teacher(series_ids, want_type=None):
    """调 外教匹配 的匹配器，把教材系列交给它。失败就老实说没接上。"""
    if not MATCH_DIR.exists():
        return {"error": "找不到外教匹配目录"}
    # 两个文件都叫 match.py —— 不能用 import_module("match")，那会拿到本文件自己。
    # 明确按路径加载外教匹配的那份。
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("_foreign_teacher_match",
                                                      str(MATCH_DIR / "match.py"))
        match_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(match_mod)
    except Exception as e:  # noqa: BLE001
        return {"error": f"外教匹配器加载失败：{e}"}

    ids = []
    for sid in series_ids:
        ms = SERIES.get(sid, {}).get("match_series")
        if ms and ms not in ids:
            ids.append(ms)
    if not ids:
        return {"error": "这些教材在外教老师库里没有对应标签，无法直接配老师"}

    class A:
        pass

    a = A()
    a.text = None
    a.audience = None
    a.age = None
    a.level = None
    a.goal = []
    a.series = ids
    a.type = want_type
    a.time = None
    a.hours = None
    a.keyword = None
    try:
        res = match_mod.match(a)
    except Exception as e:  # noqa: BLE001
        return {"error": f"外教匹配器执行失败：{e}"}

    p = res["primary"]
    return {
        "name": p["name"],
        "type": p["type"],
        "price": p["price"],
        "experience": p["experience"],
        "degree": p["degree"],
        "series_short": p.get("series_short", []),
        "reason": p["reason"],
        "risks": p["risks"],
        "photo": p.get("photo", ""),
        "photo_exists": p.get("photo_exists", False),
        "alternates": [{"name": x["name"], "type": x["type"], "price": x["price"]}
                       for x in res.get("alternates", [])],
        "tie": res.get("tie"),
        "data_gaps": res.get("data_gaps", []),
        "series_used": ids,
    }


# ---------------- 主流程 ----------------
def match(args):
    parsed = parse_text(args.text) if getattr(args, "text", None) else {}

    audience = args.audience or parsed.get("audience")
    age = args.age or parsed.get("age")
    if not audience:
        audience = "adult" if (age and age >= 18) else "kid"

    goal_list = args.goal if args.goal else parsed.get("goals", [])
    goals, unknown_goals = parse_goals(goal_list) if goal_list else (set(), [])

    want_type = parse_type(args.type) if args.type else parsed.get("type")
    hours = args.hours or parsed.get("hours")

    level = args.level or parsed.get("level")
    if not level and parsed.get("y_level"):
        level = None
    level_num_target = level_num(str(level)) if level else None
    if level_num_target is None and parsed.get("y_level"):
        y = parsed["y_level"]
        level_num_target = int(y[1])
        level = y
    if level_num_target is None and age and audience != "adult":
        guess = level_from_age(age)
        if guess:
            level = guess + "级"
            level_num_target = int(guess)
            level_guessed = True
        else:
            level_guessed = False
    else:
        level_guessed = False
    if level_num_target is None and audience == "adult":
        level_guessed = False

    # 人群过滤：给孩子的需求不该推成人段教材
    def aud_ok(sid):
        return not audience or audience in SERIES[sid]["audience"]

    # 考试类目标没给级别时，按考试默认级别取（KET≈4级、PET≈6级…），并标出来是推的
    exam_level_guessed = False
    if level_num_target is None and goals:
        for g in sorted(goals):
            if g in EXAM_LEVEL:
                level_num_target = int(EXAM_LEVEL[g])
                level = EXAM_LEVEL[g] + "级"
                exam_level_guessed = True
                break

    # 目标系列
    target_series, extra_series = set(), set()
    if args.series:
        for s in args.series:
            if s in SERIES:
                target_series.add(s)
            else:
                for sid, v in SERIES.items():
                    if norm(s) in norm(v["name"]) or s in v["cn"]:
                        target_series.add(sid)
    if not target_series and parsed.get("y_level"):
        target_series |= set(Y_LEVEL_SERIES.get(parsed["y_level"], []))
    if not target_series and level_num_target is not None:
        key = str(int(level_num_target))
        target_series |= set(LEVEL_SERIES.get(key, []))
    if not target_series and goals:
        target_series = {sid for sid, v in SERIES.items() if set(v["goals"]) & goals}
    # 目标方向：用户说的是「练写作 / 考 KET」，就该落到写作教材、KET 教材上
    goal_series = set()
    for g in goals:
        for sid in GOAL_SERIES.get(g, []):
            if sid in SERIES and aud_ok(sid):
                goal_series.add(sid)
                target_series.add(sid)
    if goals:
        extra_series = {sid for sid, v in SERIES.items() if set(v["goals"]) & goals} - target_series

    # 目标系列收口：只留存在的、人群对得上的
    target_series = {s for s in target_series if s in SERIES and aud_ok(s)}
    if not target_series:
        target_series = {s for s, v in SERIES.items() if aud_ok(s) and v["courses"]}

    ctx = {
        "goals": goals,
        "goal_series": goal_series,
        "audience": audience,
        "target_series": target_series,
        "extra_series": extra_series,
        "target_level_num": level_num_target,
        "link_level": str(int(level_num_target)) if level_num_target is not None else None,
        "hours": hours,
        "keyword": args.keyword or parsed.get("keyword"),
        "strict_goal": bool({g for g in goals if g.startswith("应试") or g in ("进阶", "商务", "外贸", "写作", "语音")}),
        "has_specific_goal": bool({g for g in goals if g in ("商务", "外贸", "旅行", "写作", "语音", "词汇", "语法", "进阶")}),
    }

    scored = []
    for c in CATALOG:
        s, detail, why = score_course(c, ctx)
        if s > 0:
            scored.append({"course": c, "score": s, "detail": detail, "why": why})
    if not scored:
        scored = [{"course": c, "score": 0, "detail": {}, "why": []} for c in CATALOG
                  if aud_ok(c.get("series"))]

    # 同系列内：级别对的排前、课时少的排前、主目录优先
    def order_key(r):
        c = r["course"]
        lvl_d = abs((level_num(c.get("level_label")) or 0) - (level_num_target or 0)) \
            if (level_num_target is not None and level_num(c.get("level_label")) is not None) else 9
        return (-r["score"], lvl_d, c.get("hours") or 9999, c["id"])

    scored.sort(key=order_key)

    band = [r for r in scored if r["score"] >= scored[0]["score"] - TIE_BAND]
    top = scored[0]["course"]

    # 同系列的其他级别：用来讲「这套书还有别的级」
    # 「灵动版」和原版是两套书，同一版本族内部才叫「其他级别」
    def fam(name):
        return "灵动版" if "灵动版" in name else "原版"

    same_series = [c for c in CATALOG
                   if c.get("series") == top.get("series") and c["id"] != top["id"]
                   and fam(c["name"]) == fam(top["name"])]
    same_series.sort(key=lambda c: (abs((level_num(c.get("level_label")) or 0) - (level_num_target or 0))
                                    if level_num(c.get("level_label")) is not None else 99))

    # 讲人话的理由
    why = []
    if "series" in scored[0]["why"]:
        why.append("方向正好对上")
    elif scored[0]["detail"].get("goal"):
        why.append("教材方向对得上")
    if scored[0]["detail"].get("level_exact"):
        why.append("级别正合适")
    elif scored[0]["detail"].get("level_near"):
        why.append("级别差一级，可以衔接")
    if scored[0]["detail"].get("audience"):
        why.append("就是给这个年龄段设计的")
    if scored[0]["detail"].get("hours_fit"):
        why.append(f"{hours} 节装得下")
    reason = "，".join(why) if why else "综合排序靠前，但没有直接命中项"

    risks = []
    if scored[0]["detail"].get("hours_over"):
        risks.append(f"按表里建议是 {top.get('hours')} 节，预算 {hours} 节装不完，需要减单元或加课时")
    if not scored[0]["detail"].get("level_exact") and level_num_target is not None:
        risks.append("级别是推断的，跟实际水平有偏差就换一个级别")
    if not top.get("desc"):
        risks.append("表里没有这本书的简介，特色需人工确认")

    # 外教：先按主推系列配；配不上就退到同方向里有标签的系列，并说清楚是退过了
    series_chain = [top["series"]] + [c["series"] for c in same_series[:3] if c.get("series")]
    teacher = find_teacher(series_chain, want_type)
    teacher_fallback = False
    if isinstance(teacher, dict) and teacher.get("error"):
        alt_ids = teacher_series_candidates(top["series"], goals, audience)[:6]
        if alt_ids:
            teacher = find_teacher(alt_ids, want_type)
            teacher_fallback = not (isinstance(teacher, dict) and teacher.get("error"))
            if teacher_fallback:
                teacher["fallback_note"] = (
                    f"这套书老师库没有标签，老师是按同类方向配的（{'、'.join(teacher['series_short'][:3])}）")

    pic = top.get("pic_id")
    cover = ""
    if pic:
        fname = COVER_INDEX.get(f"{pic}|{top['id']}") or COVER_INDEX.get(pic)
        if fname and (COVER_DIR / fname).is_file():
            cover = str((COVER_DIR / fname).resolve())

    result = {
        "query": {
            "audience": audience, "age": age, "level": level,
            "level_guessed": level_guessed, "goals": sorted(goals),
            "unknown_goals": unknown_goals, "hours": hours,
            "type": want_type or "不限",
            "series": sorted(target_series)[:12],
        },
        "primary": {
            "name": top["name"].replace("\n", " "),
            "category": top["category"],
            "series": top.get("series"),
            "series_name": SERIES.get(top.get("series"), {}).get("name", ""),
            "series_cn": SERIES.get(top.get("series"), {}).get("cn", ""),
            "level": top.get("level_label"),
            "hours": top.get("hours"),
            "schedule": top.get("schedule"),
            "audience_text": top.get("audience_text"),
            "desc": top.get("desc"),
            "score": round(scored[0]["score"], 1),
            "reason": reason,
            "risks": risks,
            "cover": cover,
            "cover_exists": bool(cover),
            "tie_count": len(band),
        },
        "next_levels": [
            {"name": c["name"].replace("\n", " "), "level": c.get("level_label"), "hours": c.get("hours")}
            for c in same_series[:3]
        ],
        "alternates": [
            {"name": r["course"]["name"].replace("\n", " "), "level": r["course"].get("level_label"),
             "hours": r["course"].get("hours"), "score": round(r["score"], 1),
             "series_cn": SERIES.get(r["course"].get("series"), {}).get("cn", "")}
            for r in scored[1:3]
        ],
        "teacher": teacher,
        "teacher_fallback": teacher_fallback,
        "data_gaps": [],
    }

    if level_guessed and age:
        result["data_gaps"].append(f"没给水平，按 {age} 岁推的是 {level}；实际水平不同要换教材")
    if exam_level_guessed:
        result["data_gaps"].append(f"考{level}按 {level} 对应的教材挑的；如果孩子实际水平差得多要换")
    if unknown_goals:
        result["data_gaps"].append(f"这些目标没识别出来：{unknown_goals}")
    if top.get("hours") is None:
        result["data_gaps"].append("这本书表里没写课时数，课时需要跟教务确认")
    if isinstance(teacher, dict) and teacher.get("error"):
        result["data_gaps"].append(f"没配上老师：{teacher['error']}")
        result["teacher_error"] = teacher["error"]
    no_tag = SERIES.get(top.get("series"), {}).get("match_series_exists") is False
    if no_tag:
        if teacher_fallback:
            result["data_gaps"].append(
                f"《{SERIES.get(top.get('series'), {}).get('name')}》在老师库里没有对应标签，"
                "老师是按同类教材方向配的，不是正在教这套书，接单前需要人工确认")
        else:
            result["data_gaps"].append(
                f"《{SERIES.get(top.get('series'), {}).get('name')}》在老师库里没有对应标签，"
                "也没找到同类方向的老师，建议人工派单")
    if hours is None:
        result["data_gaps"].append("课时数是表里的建议值，实际按学生情况定，不是承诺")

    return result


def render_chat(res):
    p = res["primary"]
    t = res.get("teacher") or {}

    lines = []
    if p.get("cover_exists"):
        lines.append(f"![{p['name']}]({p['cover']})")
        lines.append("")
    lvl = f" · {p['level']}" if p.get("level") else ""
    hrs = f" · 建议 {p['hours']} 节" if p.get("hours") else ""
    lines.append(f"**{p['name']}**{lvl}{hrs}")
    lines.append("")
    lines.append(p["reason"])
    if p.get("schedule"):
        lines.append("")
        lines.append(f"节奏：{p['schedule']}")
    lines.append("")
    lines.append("—")

    if t and not t.get("error"):
        tl = {"菲律宾外教": "菲教", "欧美外教": "欧美", "中教": "中教"}.get(t["type"], t["type"])
        price = f"¥{t['price']}/节" if t.get("price") else "价格待定"
        if t.get("photo_exists") and t.get("photo"):
            lines.append("")
            lines.append(f"![Teacher {t['name']}]({t['photo']})")
        lines.append("")
        lines.append(f"这套书能教的老师：**Teacher {t['name']} · {tl} · {price}**")
        if t.get("series_short"):
            lines.append(f"擅长：{'、'.join(t['series_short'][:4])}")
        alts = [f"Teacher {a['name']}（{('¥' + str(a['price'])) if a.get('price') else '待定'}）"
                for a in t.get("alternates", [])]
        if alts:
            lines.append(f"备选：{'、'.join(alts)}")
    elif t.get("error"):
        lines.append("")
        lines.append(f"老师这边：{t['error']}")

    if res["next_levels"]:
        nl = "、".join(f"{x['name']}（{x['level']}）" for x in res["next_levels"][:3])
        lines.append("")
        lines.append(f"同一套书的其他级别：{nl}")

    for g in res.get("data_gaps", []):
        lines.append(f"\n⚠ {g}")
    return "\n".join(lines)


def render_plain(res):
    q, p = res["query"], res["primary"]
    L = []
    L.append(f"需求识别：{q['audience']}｜年龄 {q['age'] or '未指定'}｜水平 {q['level'] or '未指定'}"
             f"｜目标 {q['goals'] or '未指定'}｜课时 {q['hours'] or '未指定'}｜师资 {q['type']}")
    L.append(f"封面：{p['cover'] or '（无）'}")
    L.append("")
    L.append(f"【主推教材】{p['name']}" + (f"（{p['level']}）" if p.get('level') else ""))
    L.append(f"分类：{p['category']}　系列：{p['series_cn']}")
    L.append(f"建议课时：{p['hours'] if p.get('hours') else '未标注'}")
    if p.get("schedule"):
        L.append(f"课时安排：{p['schedule']}")
    L.append(f"为什么是它：{p['reason']}")
    if p["risks"]:
        L.append(f"需要注意：{'；'.join(p['risks'])}")
    L.append(f"匹配分：{p['score']}")
    t = res.get("teacher") or {}
    if t and not t.get("error"):
        L.append("")
        L.append(f"【配套老师】Teacher {t['name']}（{t['type']}）"
                 f"¥{t['price']}/节" if t.get("price") else f"【配套老师】Teacher {t['name']}")
        L.append(f"理由：{t['reason']}")
    for i, a in enumerate(res["alternates"], 1):
        L.append(f"备选 {i}：{a['name']}（{a['level'] or '无级别'}，{a['hours'] or '?'} 节）— {a['series_cn']}")
    if res["data_gaps"]:
        L.append("")
        for g in res["data_gaps"]:
            L.append(f"⚠ {g}")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="教材匹配器")
    ap.add_argument("--text", help="直接说需求，如「8岁孩子想练口语」「三年级补阅读」")
    ap.add_argument("--audience", choices=["kid", "teen", "adult"])
    ap.add_argument("--age", type=int)
    ap.add_argument("--level", help="水平：1-10 级 或 Y1-Y6")
    ap.add_argument("--goal", nargs="*", help="目标：口语 阅读 启蒙 商务 应试KET ...")
    ap.add_argument("--series", nargs="*", help="指定教材系列 id，如 lets_go / thinking / ielts")
    ap.add_argument("--hours", type=int, help="课时预算（节）")
    ap.add_argument("--keyword", help="关键词，如 灵动版 / 商务英语")
    ap.add_argument("--type", help="师资偏好：菲教/菲律宾/欧美/中教")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--chat", action="store_true")
    args = ap.parse_args()

    res = match(args)
    if args.json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    elif args.chat:
        print(render_chat(res))
    else:
        print(render_plain(res))


if __name__ == "__main__":
    main()
