#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从《教科书适用学生及对应课时安排（2026-04-01）.xlsx》抽取结构化数据。

产出（都在 ../data/ 下）：
  courses.json     265 条教材，含名称/分类/简介/适用学生/课时安排/课时数
  levels.json      1-10 级水平带与中文能力描述
  level_map.json   英语等级（Level 0-10）× 推荐课本 对照网格

用法：
    python3 tools/extract.py
数据源默认取上一级目录里的 xlsx，可用 --xlsx 指定。
"""
import argparse
import json
import re
from pathlib import Path

import openpyxl

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data"

# 分类表：sheet 名 -> 教材分类名
SHEET_CATEGORY = {
    "青少年英语": "青少年英语",
    "灵动版合集（青少儿教材）": "青少儿灵动版",
    "商务英语": "商务英语",
    "语音课程": "语音课程",
    "考试英语": "考试英语",
    "日常英语": "日常英语",
    "出国英语": "出国英语",
    "外贸英语": "外贸英语",
}

COLS = ["no", "name", "pic", "desc", "audience", "schedule", "hours"]


def clean(v):
    if v is None:
        return ""
    s = str(v)
    s = s.replace("\u3000", " ").replace("\xa0", " ")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n{2,}", "\n", s)
    return s.strip()


def parse_hours(v):
    """课时数可能是数字或字符串；解析不出来返回 None。"""
    s = clean(v)
    if not s:
        return None
    m = re.search(r"\d+(?:\.\d+)?", s)
    if not m:
        return None
    n = float(m.group(0))
    return int(n) if n == int(n) else n


def find_header(ws):
    """表头行：第一个包含「课本名称」的行。返回 (行号, 列名->索引)。"""
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        vals = [clean(v) for v in row[:10]]
        if any("课本名称" in v for v in vals):
            idx = {}
            for j, v in enumerate(vals):
                if "课本名称" in v:
                    idx["name"] = j
                elif "课本图片" in v:
                    idx["pic"] = j
                elif "课本简介" in v:
                    idx["desc"] = j
                elif "适用学生" in v:
                    idx["audience"] = j
                elif "课时安排" in v:
                    idx["schedule"] = j
                elif "课时数" in v:
                    idx["hours"] = j
                elif v.startswith("No"):
                    idx["no"] = j
            return i, idx
        if i > 5:
            break
    return None, None


def extract_courses(wb):
    out = []
    for sheet, category in SHEET_CATEGORY.items():
        if sheet not in wb.sheetnames:
            print(f"  ! 缺少工作表：{sheet}")
            continue
        ws = wb[sheet]
        hrow, idx = find_header(ws)
        if hrow is None:
            print(f"  ! {sheet} 找不到表头")
            continue
        n = 0
        for row in ws.iter_rows(min_row=hrow + 2, values_only=True):
            name = clean(row[idx["name"]]) if idx.get("name") is not None and idx["name"] < len(row) else ""
            if not name:
                continue
            pic_raw = clean(row[idx["pic"]]) if idx.get("pic") is not None and idx["pic"] < len(row) else ""
            m = re.search(r'DISPIMG\(\s*"([^"]+)"', pic_raw)
            rec = {
                "id": f"{category}-{len(out) + 1}",
                "category": category,
                "sheet": sheet,
                "no": clean(row[idx["no"]]) if idx.get("no") is not None else "",
                "name": name,
                "desc": clean(row[idx["desc"]]) if idx.get("desc") is not None else "",
                "audience_text": clean(row[idx["audience"]]) if idx.get("audience") is not None else "",
                "schedule": clean(row[idx["schedule"]]) if idx.get("schedule") is not None else "",
                "hours": parse_hours(row[idx["hours"]]) if idx.get("hours") is not None else None,
                "pic_id": m.group(1) if m else None,
            }
            out.append(rec)
            n += 1
        print(f"  {sheet}: {n} 条")
    return out


def extract_levels(wb):
    """级别表：第 0 行是水平带名，第 1 行是 1-10 级，第 2 行是中文描述。"""
    ws = wb["级别"]
    rows = list(ws.iter_rows(values_only=True))
    band_row = [clean(v) for v in rows[0]]
    num_row = [clean(v) for v in rows[1]]
    desc_row = [clean(v) for v in rows[2]]
    # 水平带名跨列（合并单元格），向右填充
    bands, cur = [], ""
    for v in band_row:
        if v:
            cur = re.sub(r"\s{2,}", " ", v).strip()
        bands.append(cur)
    levels = []
    for i, num in enumerate(num_row):
        if not num:
            continue
        levels.append({
            "name": num,
            "band": bands[i] if i < len(bands) else "",
            "desc": desc_row[i] if i < len(desc_row) else "",
        })
    return levels


def extract_level_map(wb):
    """等级对照表：B 列是教材系列名，C 列起是 Level 0..10。"""
    ws = wb["英语等级及对应推荐课本"]
    rows = list(ws.iter_rows(values_only=True))
    # 表头行：含 "英语等级"
    hidx = None
    for i, r in enumerate(rows[:5]):
        if any("英语等级" in clean(v) for v in r[:3]):
            hidx = i
            break
    if hidx is None:
        return []
    header = [clean(v) for v in rows[hidx]]
    # 找 Level 列起点
    start = None
    for j, v in enumerate(header):
        if re.match(r"^Level\s*\d+$", v, re.I):
            start = j
            break
    if start is None:
        return []
    level_names = []
    for j in range(start, len(header)):
        v = header[j]
        m = re.match(r"^Level\s*(\d+)$", v, re.I)
        level_names.append(("Level " + m.group(1)) if m else None)
    # 前几行是元信息行（语言阶段/词汇量/证书…），也一并保留
    # 结构：B 列（第二列）有值的是教材行；B 列为空、A 列是标签的是元信息行
    meta_rows, books = [], []
    for r in rows[hidx + 1:]:
        vals = [clean(v) for v in r]
        first = vals[0] if vals else ""
        second = vals[1] if len(vals) > 1 else ""
        row_levels = {}
        for k, lname in enumerate(level_names):
            j = start + k
            if lname and j < len(vals) and vals[j]:
                row_levels[lname] = vals[j]
        if not row_levels:
            continue
        if not second:
            meta_rows.append({"label": re.sub(r"\s+", " ", first), "values": row_levels})
        else:
            books.append({"group": first,
                          "series": re.sub(r"\s*\n\s*", " ", second),
                          "levels": row_levels})
    return {"levels": [x for x in level_names if x], "meta": meta_rows, "books": books}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", default=str(ROOT.parent / "教科书适用学生及对应课时安排（2026-04-01）.xlsx"))
    args = ap.parse_args()

    src = Path(args.xlsx)
    if not src.is_file():
        raise SystemExit(f"找不到数据源：{src}")
    print(f"数据源：{src.name}")
    wb = openpyxl.load_workbook(src, read_only=True, data_only=True)

    DATA.mkdir(exist_ok=True)
    courses = extract_courses(wb)
    levels = extract_levels(wb)
    level_map = extract_level_map(wb)

    (DATA / "courses.json").write_text(
        json.dumps({"_source": src.name, "count": len(courses), "courses": courses},
                   ensure_ascii=False, indent=1), encoding="utf-8")
    (DATA / "levels.json").write_text(
        json.dumps({"_source": src.name, "levels": levels}, ensure_ascii=False, indent=1),
        encoding="utf-8")
    (DATA / "level_map.json").write_text(
        json.dumps({"_source": src.name, **level_map}, ensure_ascii=False, indent=1),
        encoding="utf-8")

    print(f"courses.json   {len(courses)} 条")
    print(f"levels.json    {len(levels)} 级")
    print(f"level_map.json {len(level_map.get('books', []))} 个教材系列 × {len(level_map.get('levels', []))} 级")
    no_hours = [c["name"] for c in courses if c["hours"] is None]
    print(f"课时数缺失：{len(no_hours)} 条 {no_hours[:5]}")


if __name__ == "__main__":
    main()
