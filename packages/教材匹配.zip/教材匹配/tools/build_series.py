#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
建教材桥：把 265 条教材归到「系列」，并映射到外教匹配已有的 series_id。

为什么需要这座桥（照搬外教匹配的教训）：
  教材目录用中文名，且同一套书写法五花八门（「第5版 牛津少儿英语入门 1」
  「第5版 牛津少儿英语 1」「牛津少儿 Let's Go 1-2」），老师库那边是英文标签。
  不做归一，匹配只能靠关键词撞运气。

产出：
  data/series.json   本目录自己的系列表（id/name/cn/goals/audience/级别/match_series）
  data/catalog.json  265 条教材 + 归好的 series / level_label / 适用年龄区间

用法：
    python3 tools/build_series.py
"""
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data"
MATCH_SERIES = ROOT.parent / "外教匹配" / "data" / "series.json"

# ---------------------------------------------------------------- 系列规则
# (系列id, 英文常用名, 中文名, 目标, 人群, 外教匹配里的 series_id 或 None, 命中正则)
RULES = [
    ("lets_go", "Let's Go", "牛津少儿英语 Let's Go", ["少儿综合", "启蒙"], ["kid"], "lets_go",
     r"第5版 牛津少儿英语"),
    ("american_school", "American School Textbook", "美国学前/幼儿学科英语 American School Textbook",
     ["少儿综合", "学科英语"], ["kid"], None, r"American School Textbook"),
    ("junior_new_concept", "Junior New Concept", "朗文外研社新概念英语青少版", ["少儿综合", "语法"],
     ["kid", "teen"], "junior_new_concept", r"新概念英语青少版"),
    ("school_sync", "School Sync", "中小学生校园同步教材", ["同步", "综合"], ["kid", "teen"], None,
     r"校园同步教材"),
    ("wonders", "Wonders", "美国加州 Wonders 教材", ["阅读", "少儿综合", "国际学校"], ["kid"], "reading_wonders",
     r"Workshop G"),
    ("kids_box", "Kid's Box", "剑桥国际少儿英语 Kids' Box", ["启蒙", "少儿综合", "应试YLE"], ["kid"],
     "kids_box", r"Kids[‘’']?\s*Box"),
    ("side_by_side", "Side by Side", "朗文国际英语教程 Side by Side", ["综合", "口语", "应试KET"],
     ["teen", "adult"], "side_by_side", r"Side by Side|Side by Side|Side by Side"),
    ("english_in_mind", "English in Mind", "剑桥青少年英语 English in Mind",
     ["应试KET", "应试PET", "综合"], ["teen"], "english_in_mind", r"English in Mind"),
    ("power_up", "Power Up", "剑桥少儿英语 Power Up", ["少儿综合", "应试YLE", "应试KET"], ["kid"],
     "power_up", r"Power Up"),
    ("oxford_discover", "Oxford Discover", "牛津少儿英语探索系列 Oxford Discover", ["少儿综合", "阅读"],
     ["kid"], "oxford_discover", r"Oxford Discover"),
    ("fun_for", "Fun For", "剑桥少儿英语 YLE 备考 Fun For 系列", ["应试YLE"], ["kid"], "fun_for",
     r"Fun For"),
    ("reach_higher", "Reach Higher", "美国国家地理小学综合教程 Reach Higher", ["少儿综合", "国际学校"],
     ["kid"], "reach_higher", r"Reach Higher"),
    ("reach", "Reach", "美国国家地理小学教材 Reach", ["少儿综合", "国际学校"], ["kid"], None,
     r"美国国家地理小学教材\s*Reach"),
    ("our_world", "Our World", "美国国家地理少儿英语教材 Our World", ["少儿综合"], ["kid"], "our_world",
     r"Our World"),
    ("great_writing", "Great Writing", "美国国家地理写作教材 Great Writing", ["写作", "进阶"],
     ["teen"], "great_writing", r"Great Writing"),
    ("reading_explorer", "Reading Explorer", "美国国家地理 Reading Explorer", ["阅读", "应试PET", "进阶"],
     ["teen"], "reading_explorer", r"Reading Explorer"),
    ("ket", "KET", "KET 口试模拟测试话题", ["应试KET"], ["teen"], "ket", r"KET口试模拟"),
    ("pet", "PET", "PET 口试模拟测试话题", ["应试PET"], ["teen"], "pet", r"PET口试模拟"),
    ("starlight", "Starlight", "牛津星光英语 Starlight", ["少儿综合"], ["kid"], None, r"Starlight"),
    ("primary_longman_elect", "Primary Longman Elect", "培生香港朗文小学英语 Primary Longman Elect",
     ["少儿综合"], ["kid"], "primary_longman_elect", r"Primary Longman Elect"),
    ("think", "THiNK", "剑桥青少年英语 THiNK", ["应试KET", "应试PET", "应试FCE", "进阶"], ["teen"],
     "think", r"THiNK"),
    ("ready", "Ready", "牛津香港小学英语教材 Ready", ["少儿综合"], ["kid"], "ready", r"教材\s*Ready"),
    ("speaking_time", "Speaking Time", "美国地道英语口语教材 Speaking Time", ["口语", "少儿综合"],
     ["kid"], "speaking_time", r"Speaking Time"),
    ("oral_300", "300 Questions", "少儿基础日常口语300问", ["口语"], ["kid"], "300_questions",
     r"少儿基础日常口语300问"),
    ("oxford_reading_tree", "Oxford Reading Tree", "牛津阅读树 Oxford Reading Tree", ["阅读", "绘本表达"],
     ["kid"], "oxford_reading_tree", r"牛津阅读树"),
    ("reading_a_z", "Reading A-Z", "Reading A-Z 分级阅读", ["阅读"], ["kid"], "reading_a_z", r"Reading A-Z"),
    ("basic_1000_words", "1000 Basic English Words", "少儿基础英语1000词", ["词汇"], ["kid"],
     "1000_words", r"少儿基础英语1000词"),
    ("writing_3000", "Writing 3000", "朗文少儿英语写作3000词", ["写作", "词汇"], ["kid"], None,
     r"写作3000词"),
    ("best_writing", "The Best Writing", "初级英语写作系列 The Best Writing", ["写作"], ["kid", "teen"],
     "best_writing", r"The Best Writing"),
    ("everybody_up", "Everybody Up", "牛津少儿英语 Everybody Up", ["启蒙", "少儿综合", "应试YLE"],
     ["kid"], "everybody_up", r"Everybody Up"),
    ("oxford_phonics", "Oxford Phonics World", "牛津自然拼读世界", ["启蒙", "自然拼读"], ["kid"],
     "oxford_phonics", r"牛津自然拼读世界"),
    ("sight_words_reader", "Sight Words Reader", "高频词流利阅读 Sight Words Reader", ["阅读", "词汇"],
     ["kid"], None, r"Sight Words Reader"),
    ("sight_word_fluency", "Sight Word Fluency", "高频词流利阅读 Sight Word Fluency", ["阅读", "词汇"],
     ["kid"], None, r"Sight Word Fluency"),
    ("speak_up", "Speak Up", "A List 少儿口语教材 Speak Up", ["口语"], ["kid"], "speak_up", r"Speak Up"),
    ("bec", "BEC", "剑桥商务英语 BEC 初级/中级/高级", ["商务", "应试BEC"], ["adult"], "business_english",
     r"剑桥商务英语"),
    ("experience_business", "Experience Business", "体验商务英语（第二版）", ["商务"], ["adult"],
     "business_english", r"体验商务英语"),
    ("business_topics100", "100 Business Topics", "商务英语情景口语100主题", ["商务", "职场口语"],
     ["adult"], "100_topics_business", r"商务英语情景口语100主题"),
    ("business_oral", "Business Oral", "商务英语口语 / 口语大全 / 模拟实训", ["商务", "职场口语"],
     ["adult"], "business_english", r"商务英语口语"),
    ("dk_business", "DK Business", "DK新视觉·人人学英语 商务英语教程", ["商务"], ["adult"],
     "business_english", r"商务英语教程"),
    ("international_trade", "International Business", "国际商务与贸易 Master CLASS", ["商务"], ["adult"],
     "business_english", r"国际商务与贸易"),
    ("ipa", "IPA", "国际音标与语音语调", ["语音", "启蒙"], ["kid", "teen", "adult"], None, r"国际音标"),
    ("abc_lets_learn", "Let's Learn ABC", "春喜自编 ABC 教材", ["启蒙", "语音"], ["kid"], None,
     r"Lets Learn ABC"),
    ("hooked_on_phonics", "Hooked on Phonics", "Hooked on Phonics", ["启蒙", "自然拼读"], ["kid"], None,
     r"Hooked on Phonics"),
    ("ielts", "IELTS", "雅思口语（王陆雅思 / 核心话题）", ["应试雅思"], ["adult"], "ielts",
     r"雅思"),
    ("toefl", "TOEFL", "新托福考试专项进阶", ["应试托福"], ["adult"], "toefl", r"托福"),
    ("study_abroad", "Study Abroad", "留学英语情景会话50主题", ["旅行", "留学"], ["adult"], None,
     r"留学英语情景会话"),
    ("new_concept", "New Concept English", "朗文新概念英语（经典版）", ["综合", "语法"],
     ["kid", "teen", "adult"], "new_concept", r"^朗文新概念英语\d"),
    ("cambridge_international", "Cambridge International", "剑桥国际英语教程", ["综合", "成人通用"],
     ["adult"], "cambridge_international", r"剑桥国际英语教程"),
    ("life_100_topics", "100 Daily Topics", "生活英语情景口语100主题", ["口语", "日常口语"], ["adult"],
     "100_topics_daily", r"生活英语情景口语100主题"),
    ("daily_free_talk", "Daily Free Talk", "日常自由交流（共三册）", ["口语", "日常口语"], ["adult", "teen"],
     "daily_free_talk", r"日常自由交流"),
    ("dk_general", "DK English for Everyone", "DK新视觉·人人学英语 第N册教程", ["综合", "成人通用"],
     ["adult"], None, r"DK新视觉·人人学英语 第\d册"),
    ("practice_oral", "Practice Oral", "即说即练-口语突破训练话题", ["口语"], ["adult"], None, r"即说即练"),
    ("hotel_english", "Hotel English", "饭店英语情景口语50主题", ["旅行", "职场口语"], ["adult"],
     "english_for_tourism", r"饭店英语"),
    ("travel_900", "Travel 900", "旅游出国英语口语900句", ["旅行"], ["adult"], "english_for_tourism",
     r"旅游出国英语口语900句"),
    ("restaurant_english", "Restaurant English", "餐厅英语情景口语50主题", ["旅行", "职场口语"],
     ["adult"], "english_for_tourism", r"餐厅英语"),
    ("current_affairs_50", "Current Affairs 50", "英语畅谈时事热点50主题", ["口语", "观点表达"],
     ["adult"], None, r"英语畅谈时事热点"),
    ("visa", "Visa English", "美国签证口语指南", ["旅行", "面试"], ["adult"], None, r"美国签证口语指南"),
    ("foreign_trade", "Foreign Trade", "外贸英语（话题王 / 脱口而出 / 口语大全 / 函电）",
     ["商务", "外贸"], ["adult"], None, r"外贸英语"),
    ("shop_english", "Shop English", "商铺英语情景口语50主题", ["商务", "职场口语"], ["adult"], None,
     r"商铺英语"),
    ("exhibition_english", "Exhibition English", "会展英语", ["商务", "职场口语"], ["adult"], None,
     r"会展英语"),
]

COMPILED = [(rid, name, cn, goals, aud, ms, re.compile(pat)) for rid, name, cn, goals, aud, ms, pat in RULES]


# 英语等级对照表（61 行）→ 本目录系列 id。
# None 表示这本/这类书在 265 条教材目录里没有对应条目（对照表比教材目录宽）。
LEVEL_MAP_LINK = [
    ["oxford_phonics"],          # 0 牛津自然拼读世界
    ["sight_word_fluency"],      # 1 Sight Word Fluency
    ["sight_words_reader"],      # 2 Sight Words Reader
    ["fun_for"],                 # 3 Fun For
    ["oral_300"],                # 4 少儿基础日常口语300问
    ["lets_go"],                 # 5 Let's Go
    ["kids_box"],                # 6 Kids Box
    ["power_up"],                # 7 Power Up
    ["power_up"],                # 8 Power Up 灵动版
    ["american_school"],         # 9 用美国幼儿园课本学英语 AST
    ["reading_a_z"],             # 10 Reading A-Z
    ["oxford_reading_tree"],     # 11 牛津阅读树
    ["our_world"],               # 12 Our World
    ["wonders"],                 # 13 Wonders
    None,                        # 14 Wonder Skills（教材目录无）
    ["primary_longman_elect"],   # 15 香港朗文少儿 PLE
    ["starlight"],               # 16 牛津星光英语 Starlight
    None,                        # 17 美国加州数学 CMs（教材目录无）
    ["speaking_time"],           # 18 Speaking Time
    ["ready"],                   # 19 Ready
    ["best_writing"],            # 20 The Best Writing
    ["oxford_discover"],         # 21 Oxford Discover
    ["reach_higher"],            # 22 Reach Higher
    None,                        # 23 NTC（教材目录无）
    None,                        # 24 NTD（教材目录无）
    ["everybody_up"],            # 25 Everybody Up
    ["basic_1000_words"],        # 26 少儿基础英语1000词
    ["basic_1000_words"],        # 27 少儿基础英语1000词 灵动版
    ["reach"],                   # 28 美国国家地理小学教材 Reach
    ["speak_up"],                # 29 Speak Up
    ["writing_3000"],            # 30 朗文少儿英语写作3000词
    ["great_writing"],           # 31 Great Writing
    None,                        # 32 自研-青少年日常口语训练（教材目录无）
    None,                        # 33 脱口说（教材目录无）
    ["junior_new_concept"],      # 34 新概念英语青少版 JNC
    ["side_by_side"],            # 35 Side By Side
    ["english_in_mind"],         # 36 English In Mind
    ["ket", "pet"],              # 37 KET & PET 口试模拟
    ["reading_explorer"],        # 38 Reading Explorer
    ["think"],                   # 39 THiNK
    ["reach_higher"],            # 40 Reach Higher 灵动版
    ["ielts"],                   # 41 雅思口语冲刺
    ["toefl"],                   # 42 新托福考试专项进阶
    ["ielts", "toefl"],          # 43 其他雅思托福类
    None,                        # 44 零基础学英语（教材目录无）
    ["new_concept"],             # 45 新概念英语新版
    None,                        # 46 即学即说（教材目录无）
    ["practice_oral"],           # 47 即说即练
    ["hotel_english", "shop_english", "exhibition_english"],  # 48 行业英语大类
    ["foreign_trade"],           # 49 外贸英语大类
    ["bec"],                     # 50 BEC
    ["experience_business"],     # 51 体验商务英语
    ["business_topics100", "business_oral", "international_trade", "dk_business"],  # 52 其他商务英语类
    ["business_oral"],           # 53 商务英语口语训练系列
    ["dk_general"],              # 54 DK 新视觉
    ["study_abroad"],            # 55 留学英语情景会话
    ["travel_900", "hotel_english", "restaurant_english"],  # 56 旅游英语大类
    ["visa"],                    # 57 面试英语大类
    ["daily_free_talk"],         # 58 Daily Talk
    ["cambridge_international"],  # 59 剑桥国际英语教程
    ["life_100_topics"],         # 60 生活英语情景口语100主题
]


def build_level_link(level_map_path):
    """把等级对照表的系列行对到本目录 series id，写 data/level_link.json。"""
    if not level_map_path.exists():
        return
    lm = json.loads(level_map_path.read_text(encoding="utf-8"))
    books = lm.get("books", [])
    if len(books) != len(LEVEL_MAP_LINK):
        print(f"  ! 等级对照表行数 {len(books)} 与映射表 {len(LEVEL_MAP_LINK)} 不一致，按行号对齐")
    out = []
    for i, b in enumerate(books):
        ids = LEVEL_MAP_LINK[i] if i < len(LEVEL_MAP_LINK) else None
        out.append({"series": b["series"], "group": b["group"],
                    "ids": ids, "levels": b["levels"]})
    unlinked = [x["series"] for x in out if not x["ids"]]
    (DATA / "level_link.json").write_text(
        json.dumps({"_说明": "英语等级对照表 → 本目录 series id；ids 为 null 表示教材目录里没有这本书",
                    "books": out}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"等级对照表已对接 {len(out) - len(unlinked)}/{len(out)} 行")
    if unlinked:
        print(f"  对不上（教材目录无此书）：{len(unlinked)} 行 → {unlinked}")


def guess_match_series(name, cn, match_ids_map):
    """规则里没写 match_series 时，用外教匹配的 curriculum_keys / 名称反查一次。"""
    blob = norm_name(name + " " + cn).lower()
    best = None
    for sid, v in match_ids_map.items():
        for k in [v.get("name", "")] + v.get("curriculum_keys", []):
            k2 = norm_name(k).lower()
            if len(k2) >= 4 and k2 in blob:
                # 取最长的命中，避免 "Kid's Box" 被 "Box" 这类短标签抢走
                if best is None or len(k2) > best[1]:
                    best = (sid, len(k2))
    return best[0] if best else None


def norm_name(s):
    s = str(s).replace("\u3000", " ").replace("\xa0", " ")
    s = s.replace("‘", "'").replace("’", "'").replace("“", '"').replace("”", '"')
    s = re.sub(r"\s+", " ", s).strip()
    return s


def series_of(name):
    n = norm_name(name)
    for rid, _, _, _, _, _, rx in COMPILED:
        if rx.search(n):
            return rid
    return None


# ---------------------------------------------------------------- 级别标签
# 注意：中文紧挨着字母时 \b 不成立（「灵动版L0」），所以用前后向断言而不是 \b。
LEVEL_PATTERNS = [
    (r"Level\s*(\d{1,2})", lambda m: "L" + m.group(1)),
    (r"(?<![A-Za-z])L\s*(\d{1,2})(?!\d)", lambda m: "L" + m.group(1)),
    (r"(\d{1,2})\s*级(?!别)", lambda m: str(int(m.group(1))) + "级"),
    (r"(\d)\s*年级", lambda m: m.group(1) + "年级"),
    (r"第\s*(\d{1,2})\s*册", lambda m: "第" + m.group(1) + "册"),
    (r"(?<![A-Za-z])G\s*([K\d])(?![A-Za-z\d])", lambda m: "G" + m.group(1)),
    (r"(?<![A-Za-z])(PK|PreK|K)\s*(\d)", lambda m: m.group(1) + m.group(2)),
    (r"Box\s*(\d)", lambda m: m.group(1)),
    (r"(入门|初级|中级|高级|学前级|入门级)", lambda m: m.group(1)),
    (r"(Starters|Movers|Flyers)", lambda m: m.group(1)),
    (r"(第[一二三四五六七八九十]阶段)", lambda m: m.group(1)),
    (r"(\d{1,2})\s*级别", lambda m: m.group(1) + "级别"),
    (r"教程\s*(\d{1,2})", lambda m: m.group(1)),
    (r"(?<![A-Za-z])G\s*(\d[AB])(?![A-Za-z\d])", lambda m: "G" + m.group(1)),
    (r"(\d{1,2})\s*$", lambda m: str(int(m.group(1)))),
]


def level_of(name):
    n = norm_name(name)
    for pat, fn in LEVEL_PATTERNS:
        m = re.search(pat, n, re.I)
        if m:
            return fn(m)
    return ""


# ---------------------------------------------------------------- 年龄区间
def age_range(text):
    """从「适用学生」里抽年龄区间，抽不到返回 None。"""
    t = norm_name(text)
    m = re.search(r"(\d{1,2})\s*[-–~至]\s*(\d{1,2})\s*岁", t)
    if m:
        return [int(m.group(1)), int(m.group(2))]
    m = re.search(r"(\d{1,2})\s*岁", t)
    if m:
        return [int(m.group(1)), int(m.group(1))]
    return None


def audience_of(text, series_aud):
    """人群：先按系列默认，再用「适用学生」文字里的年龄/学段信号校正。"""
    t = norm_name(text)
    if re.search(r"成人|职场|商务|从业|大学|四级|六级|雅思|托福|出国|签证|外贸|面试", t):
        return ["adult"]
    if re.search(r"幼儿园|学前|少儿|小学|儿童|低龄|2-\d{1,2}岁|5-\d{1,2}岁", t):
        return ["kid"]
    if re.search(r"青少|初中|中学|高中|KET|PET", t):
        return ["teen"]
    return series_aud


def main():
    courses = json.loads((DATA / "courses.json").read_text(encoding="utf-8"))["courses"]
    match_map = {}
    if MATCH_SERIES.exists():
        match_map = json.loads(MATCH_SERIES.read_text(encoding="utf-8"))["series"]
    match_ids = set(match_map.keys())

    series = {}
    for rid, name, cn, goals, aud, ms, _ in RULES:
        source = "rule" if ms else ""
        if not ms:
            ms = guess_match_series(name, cn, match_map)
            source = "auto" if ms else ""
        series[rid] = {
            "name": name, "cn": cn, "goals": goals, "audience": aud,
            "match_series": ms,
            "match_series_exists": bool(ms and ms in match_ids),
            "match_source": source,
            "courses": [],
        }

    unmapped = []
    for c in courses:
        rid = series_of(c["name"])
        c["series"] = rid
        c["level_label"] = level_of(c["name"])
        c["age_range"] = age_range(c["audience_text"])
        c["audience"] = audience_of(c["audience_text"], series[rid]["audience"] if rid else ["kid"])
        c["name_norm"] = norm_name(c["name"])
        c.setdefault("pic_id", None)  # 封面 ID 由 extract.py 写入，这里只保证字段存在
        if rid:
            series[rid]["courses"].append({"id": c["id"], "name": c["name"],
                                           "level": c["level_label"], "hours": c["hours"]})
        else:
            unmapped.append(c["name"])

    (DATA / "series.json").write_text(
        json.dumps({"_说明": "教材系列表；match_series 指向 外教匹配/data/series.json 的 id，为 null 表示外教匹配里没有对应标签",
                    "series": series}, ensure_ascii=False, indent=1), encoding="utf-8")
    build_level_link(DATA / "level_map.json")

    (DATA / "catalog.json").write_text(
        json.dumps({"_说明": "265 条教材 + 归好的系列/级别/年龄/人群",
                    "count": len(courses), "courses": courses}, ensure_ascii=False, indent=1),
        encoding="utf-8")

    print(f"系列 {len(series)} 个，覆盖 {len(courses) - len(unmapped)}/{len(courses)} 条")
    if unmapped:
        print(f"未归类 {len(unmapped)} 条：")
        for n in unmapped:
            print("  -", n)
    linked = sum(1 for s in series.values() if s["match_series_exists"])
    print(f"能直接对接外教匹配的老师标签：{linked} 个系列")
    no_link = [s["name"] for s in series.values() if not s["match_series_exists"] and s["courses"]]
    print(f"有教材但外教匹配无标签：{len(no_link)} 个 → {no_link}")


if __name__ == "__main__":
    main()
