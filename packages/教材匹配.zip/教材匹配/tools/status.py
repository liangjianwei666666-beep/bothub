#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把匹配体系的状态汇总成一份 JSON，供工作台 HTML 读取。

工作台要显示的不是「有哪些书」，而是「这套匹配机制现在处于什么状态」：
哪些环节通了、哪些是断的、下一步该补什么。
所以这里统计的是覆盖率、缺口、最近一次回归结果，不是书单本身。

用法：
    python3 tools/status.py                # 生成 工作台/data.js
    python3 tools/status.py --json         # 只打印，不写文件
"""
import argparse
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BUSINESS = ROOT.parent
DATA = ROOT / "data"
MATCH_DIR = BUSINESS / "外教匹配"
OUT_DIR = ROOT / "工作台"


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def count_covers():
    d = ROOT / "封面"
    if not d.is_dir():
        return 0, 0
    files = list(d.glob("*.jpg"))
    return len(files), sum(f.stat().st_size for f in files)


def run_tests():
    """跑一次回归用例，拿到真实通过情况（不用记下来的旧结论）。"""
    try:
        r = subprocess.run([sys.executable, str(HERE / "test_cases.py")],
                           capture_output=True, text=True, timeout=120, cwd=str(ROOT))
        out = r.stdout
        passed = failed = 0
        lines = []
        for line in out.splitlines():
            s = line.strip()
            if s.startswith("✓"):
                passed += 1
                lines.append({"ok": True, "text": s[1:].strip()})
            elif s.startswith("✗"):
                failed += 1
                lines.append({"ok": False, "text": s[1:].strip()})
            elif s.startswith("期望包含"):
                if lines:
                    lines[-1]["expect"] = s.split("：", 1)[-1].strip()
        return {"passed": passed, "failed": failed, "cases": lines, "ok": failed == 0}
    except Exception as e:  # noqa: BLE001
        return {"passed": 0, "failed": 0, "cases": [], "ok": False, "error": str(e)}


def build():
    catalog = load(DATA / "catalog.json")
    series = load(DATA / "series.json")["series"]
    levels = load(DATA / "levels.json")["levels"]
    link = load(DATA / "level_link.json")["books"]
    covers_n, covers_bytes = count_covers()

    courses = catalog["courses"]

    # 覆盖：教材 → 系列
    no_series = [c for c in courses if not c.get("series")]
    # 覆盖：系列 → 老师标签
    linked = {k: v for k, v in series.items() if v.get("match_series_exists")}
    unlinked = {k: v for k, v in series.items()
                if not v.get("match_series_exists") and v["courses"]}
    # 覆盖：等级对照表 → 教材目录
    link_ok = [b for b in link if b.get("ids")]
    link_miss = [b for b in link if not b.get("ids")]

    # 哪些书缺课时数、缺封面、缺级别
    no_hours = [c for c in courses if c.get("hours") is None]
    no_cover = [c for c in courses if not c.get("pic_id")]
    no_level = [c for c in courses if not c.get("level_label")]

    by_cat = {}
    for c in courses:
        by_cat.setdefault(c["category"], {"total": 0, "linked": 0, "hours": 0})
        by_cat[c["category"]]["total"] += 1
        if series.get(c["series"], {}).get("match_series_exists"):
            by_cat[c["category"]]["linked"] += 1
        if c.get("hours"):
            by_cat[c["category"]]["hours"] += 1

    # 外教匹配那边：老师总量与可固定情况
    teacher_stat = {"total": 0, "photo": 0, "file": str(MATCH_DIR / "match.py")}
    teachers_json = BUSINESS / "教育应用" / "约课系统" / "public" / "teachers.json"
    if teachers_json.is_file():
        ts = load(teachers_json)
        teacher_stat["total"] = len(ts)
        teacher_stat["photo"] = sum(1 for t in ts if t.get("photoLocal"))

    return {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "source_xlsx": str(BUSINESS / "教科书适用学生及对应课时安排（2026-04-01）.xlsx"),
        "catalog": {
            "total": len(courses),
            "series": len(series),
            "no_series": len(no_series),
            "no_hours": [{"name": c["name"].replace("\n", " ")} for c in no_hours],
            "no_level": len(no_level),
            "categories": [{"name": k, **v} for k, v in
                           sorted(by_cat.items(), key=lambda x: -x[1]["total"])],
        },
        "bridge": {
            "series_total": len(series),
            "linked": len(linked),
            "unlinked": len(unlinked),
            "unlinked_list": sorted(
                [{"name": v["name"], "cn": v["cn"], "books": len(v["courses"])}
                 for v in unlinked.values()],
                key=lambda x: -x["books"]),
            "auto": sorted([v["name"] for v in series.values() if v.get("match_source") == "auto"]),
        },
        "level_link": {
            "total": len(link),
            "ok": len(link_ok),
            "miss": [{"series": b["series"], "group": b["group"]} for b in link_miss],
        },
        "levels": levels,
        "covers": {
            "files": covers_n,
            "mb": round(covers_bytes / 1048576, 1),
            "missing": len(no_cover),
            "shared": 0,
        },
        "teacher": teacher_stat,
        "tests": run_tests(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    data = build()
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=1))
        return

    OUT_DIR.mkdir(exist_ok=True)
    js = "window.STATUS = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n"
    (OUT_DIR / "data.js").write_text(js, encoding="utf-8")

    b, t = data["bridge"], data["tests"]
    print(f"工作台数据已生成：{OUT_DIR / 'data.js'}")
    print(f"  教材 {data['catalog']['total']} 条 / 系列 {b['series_total']} 个")
    print(f"  老师标签已挂 {b['linked']}，未挂 {b['unlinked']}")
    print(f"  等级对照表对上 {data['level_link']['ok']}/{data['level_link']['total']}")
    print(f"  封面 {data['covers']['files']} 张（{data['covers']['mb']} MB）")
    print(f"  回归用例 通过 {t['passed']}，失败 {t['failed']}")


if __name__ == "__main__":
    main()
