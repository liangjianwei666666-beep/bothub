#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
打「教材匹配 Bot」一键安装包。

产物（在 .build/dist/ 下）：
  教材匹配Bot-轻量版.zip   ≈ 35 MB  教材匹配 + 外教匹配（含照片）+ 安装器
  教材匹配Bot-完整版.zip   ≈ 87 MB  再加 52 MB 的源表 xlsx

为什么要有两个版本：
  运行匹配只需要已经抽取好的 data/ 和 封面/，不需要那张 52 MB 的源表；
  源表只在「要从头重抽一遍数据」时才用得上。发给同事优先轻量版。

包里装什么、装到哪、怎么自检，全部由 install.sh 负责；
主 Bot 只需要跑一条命令，然后把生成的 Bot 指令粘进 create_bot。

用法：
    python3 tools/build_package.py                 # 轻量版 + 完整版
    python3 tools/build_package.py --slim-only     # 只出轻量版
    python3 tools/build_package.py --with-test     # 打完在临时目录真装一遍（默认就做）
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent                     # 教材匹配/
BUSINESS = ROOT.parent                 # 外教业务/
BUILD = ROOT / ".build"
PKG = BUILD / "pkg"
DIST = BUILD / "dist"

XLSX_NAME = "教科书适用学生及对应课时安排（2026-04-01）.xlsx"
XLSX = BUSINESS / XLSX_NAME
MATCH_DIR = BUSINESS / "外教匹配"

# 复制时一律跳过
SKIP_DIRS = {".build", ".bsk", "__pycache__", ".git", ".DS_Store", "node_modules", ".idea", ".vscode"}
SKIP_FILES = {".DS_Store"}

VERSION = time.strftime("%Y.%m.%d")


# ---------------------------------------------------------------- 工具
def log(msg=""):
    print(msg, flush=True)


def copytree(src: Path, dst: Path, exclude_extra=()):
    """复制目录，跳过缓存和本机构建产物。"""
    def ignore(dirpath, names):
        skip = set(SKIP_DIRS) | set(SKIP_FILES) | set(exclude_extra)
        return [n for n in names if n in skip]

    shutil.copytree(src, dst, ignore=ignore, dirs_exist_ok=True)


def human(nbytes):
    for unit in ("B", "KB", "MB", "GB"):
        if nbytes < 1024:
            return f"{nbytes:.0f} {unit}"
        nbytes /= 1024
    return f"{nbytes:.1f} GB"


def dir_size(p: Path):
    total = 0
    for f in p.rglob("*"):
        if f.is_file():
            total += f.stat().st_size
    return total


def sha256(p: Path):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------- install.sh
INSTALL_SH = r'''#!/usr/bin/env bash
# 教材匹配 Bot · 一键安装
#
# 干四件事：
#   1. 找到能用的 python3（不同 macOS 上位置不一样）
#   2. 把 教材匹配/ 和 外教匹配/ 复制到目标目录（保持同级，两个匹配器靠这个相对位置互相找）
#   3. 跑自检：13 条回归用例 + 一次真实匹配
#   4. 生成「Bot 指令（路径已填好）」，主 Bot 把里面那段粘进 create_bot 就行
#
# 用法：
#   bash install.sh                      # 装到 ~/Desktop/外教业务
#   bash install.sh --dir ~/somewhere    # 装到别处
#   bash install.sh --check              # 只跑自检，不装
#   bash install.sh --force              # 覆盖已存在的同名目录（会先备份）

set -uo pipefail

# 有些环境（比如从别的程序里拉起 bash）locale 是 C，bash 3.2 会把中文的字节
# 当成变量名的一部分，导致 "PY?: unbound variable" 这种怪错。这里钉死 UTF-8。
export LANG="${LANG:-en_US.UTF-8}"
export LC_ALL="${LC_ALL:-en_US.UTF-8}"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$HERE/payload"
DEST="${HOME}/Desktop/外教业务"
MODE="install"
FORCE=0

while [ $# -gt 0 ]; do
  case "$1" in
    --dir)   DEST="${2%/}"; shift 2 ;;
    --check) MODE="check"; shift ;;
    --force) FORCE=1; shift ;;
    -h|--help)
      sed -n '2,16p' "$0" | sed 's/^# \{0,1\}//'
      exit 0 ;;
    *) echo "未知参数：$1（用 --help 看用法）" >&2; exit 1 ;;
  esac
done

say()  { printf '%s\n' "$*"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; }
bad()  { printf '  \033[31m✗\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
head_() { printf '\n\033[1m%s\033[0m\n' "$*"; }

# ---------- 1. 找 python3 ----------
find_python() {
  local p
  if command -v python3 >/dev/null 2>&1 && python3 -c "import sys" >/dev/null 2>&1; then
    command -v python3; return 0
  fi
  for p in /usr/bin/python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
    [ -x "$p" ] && "$p" -c "import sys" >/dev/null 2>&1 && { echo "$p"; return 0; }
  done
  for p in "$HOME"/.pyenv/versions/*/bin/python3; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  for p in "$HOME"/miniconda3/bin/python3 "$HOME"/anaconda3/bin/python3 /opt/miniconda3/bin/python3; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  return 1
}

PY="$(find_python)" || {
  head_ "没找到 Python 3"
  say "macOS 一般自带 /usr/bin/python3。如果确实没有："
  say "  1) 打开「终端」跑 xcode-select --install"
  say "  2) 或从 https://www.python.org/downloads/ 装 3.x"
  exit 1
}

head_ "教材匹配 Bot · 安装"
say "  Python：${PY}（$("$PY" -V 2>&1)）"
say "  安装到：${DEST}"

# ---------- 2. 复制 ----------
backup_if_needed() {
  local t="$1"
  if [ -e "$t" ]; then
    if [ "$FORCE" = "1" ]; then
      local bak="$t.bak-$(date +%Y%m%d-%H%M%S)"
      mv "$t" "$bak"
      warn "已存在，备份为 $(basename "$bak")"
    else
      return 1
    fi
  fi
  return 0
}

install_payload() {
  local name="$1" min="${2:-0}"
  local src="$PAYLOAD/$name"
  local dst="$DEST/$name"
  [ -d "$src" ] || { bad "安装包里缺 payload/$name"; return 1; }

  if backup_if_needed "$dst"; then
    mkdir -p "$DEST"
    cp -R "$src" "$dst"
    ok "$name → $dst"
    return 0
  else
    warn "$name 已存在，跳过（要覆盖加 --force）"
    return 2
  fi
}

install_payload "教材匹配"
ST_MATCH=$?
# 源表只有完整版才带，装上留着以后重抽数据用；没有也不算失败
if [ -d "$PAYLOAD/源数据" ]; then
  if [ -d "$DEST/源数据" ]; then
    warn "源数据 已存在，跳过（要覆盖加 --force）"
  else
    mkdir -p "$DEST"
    cp -R "$PAYLOAD/源数据" "$DEST/源数据"
    ok "源数据 → $DEST/源数据（$(ls "$DEST/源数据" | wc -l | tr -d ' ') 个文件）"
  fi
fi
# 外教匹配：同事可能已经有更新的一份（老师库会变），默认不覆盖
install_payload "外教匹配"
ST_TEACHER=$?

if [ "$ST_MATCH" != "0" ] && [ "$ST_MATCH" != "2" ]; then
  bad "教材匹配 安装失败"
  exit 1
fi

# ---------- 3. 自检 ----------
head_ "自检"

FAIL=0
M="$DEST/教材匹配"
T="$DEST/外教匹配"

# 3.1 目录结构
[ -f "$M/match.py" ] && ok "匹配器在位" || { bad "缺 match.py"; FAIL=1; }
[ -f "$M/推荐.sh" ] && ok "入口脚本在位" || { bad "缺 推荐.sh"; FAIL=1; }
[ -d "$M/data" ] && ok "数据在位（$(ls "$M/data" | wc -l | tr -d ' ') 个文件）" || { bad "缺 data/"; FAIL=1; }
NCOVER=$(ls "$M/封面" 2>/dev/null | wc -l | tr -d ' ')
[ "$NCOVER" -gt 0 ] && ok "封面 $NCOVER 张" || warn "封面目录是空的（不影响匹配，只是没图）"
[ -f "$T/match.py" ] && ok "外教匹配器在位" || { bad "缺 外教匹配/match.py，配不上老师"; FAIL=1; }
[ -d "$DEST/源数据" ] && warn "带源表（以后重抽数据用，运行不需要）" || true

# 3.2 回归用例
TC_OUT="$(cd "$M" && "$PY" tools/test_cases.py 2>&1)"
PASS=$(printf '%s' "$TC_OUT" | grep -c '^✓' || true)
FAILC=$(printf '%s' "$TC_OUT" | grep -c '^✗' || true)
if [ "$FAILC" = "0" ] && [ "$PASS" -gt 0 ]; then
  ok "回归用例 $PASS 条全过"
else
  bad "回归用例 通过 ${PASS}，失败 ${FAILC}"
  printf '%s\n' "$TC_OUT" | grep '^✗' | sed 's/^/      /'
  FAIL=1
fi

# 3.3 真实跑一次匹配（连老师一起）
SMOKE="$(cd "$M" && bash 推荐.sh --text "8岁孩子想练口语" --json 2>&1)"
printf '%s' "$SMOKE" | "$PY" -c '
import json,sys
try:
    r = json.load(sys.stdin)
except Exception as e:
    print("  \033[31m✗\033[0m 匹配器没吐出 JSON：" + str(e)); sys.exit(1)
p = r.get("primary", {})
t = r.get("teacher") or {}
print("  \033[32m✓\033[0m 教材：%s（%s 节）" % (p.get("name","?"), p.get("hours","?")))
if t.get("name"):
    print("  \033[32m✓\033[0m 老师：Teacher %s（%s）" % (t["name"], t.get("type","")))
else:
    print("  \033[33m!\033[0m 老师没配上：" + str(t.get("error","未知")))
    sys.exit(2)
' || FAIL=1

# ---------- 4. 生成 Bot 指令 ----------
head_ "生成 Bot 指令"
SRC_DOC="$M/1-给Bot的指令.md"
OUT_DOC="$DEST/Bot指令-已填好路径.md"
if [ -f "$SRC_DOC" ]; then
  OLD_BASE="/Users/a1-6/Desktop/外教业务"
  sed "s|$OLD_BASE|$DEST|g" "$SRC_DOC" > "$OUT_DOC"
  # 顺带把 README 里的路径也换掉，方便同事看
  if [ -f "$M/README.md" ]; then
    sed "s|$OLD_BASE|$DEST|g" "$M/README.md" > "$M/README.md.tmp" && mv "$M/README.md.tmp" "$M/README.md"
  fi
  ok "$OUT_DOC"
else
  bad "缺 1-给Bot的指令.md"
  FAIL=1
fi

# ---------- 收尾 ----------
head_ "结果"
if [ "$FAIL" = "0" ]; then
  ok "安装成功，自检全过。"
else
  bad "装完了，但自检有问题（见上面 ✗）。"
fi
say ""
say "  教材目录：${M}"
say "  工作台  ：${M}/工作台/index.html（双击即可打开）"
say "  Bot 指令：${OUT_DOC}"
say ""
say "  试一条："
say "    cd \"$M\" && bash 推荐.sh --text \"8岁孩子想练口语\" --chat"
say ""
say "  下一步（给主 Bot）：把 $OUT_DOC 里"
say "  「--- 复制开始 ---」到「--- 复制结束 ---」之间的内容，"
say "  粘进 create_bot 的 instructions，work_dir 设成 $M"
exit "$FAIL"
'''

# ---------------------------------------------------------------- 双击入口
COMMAND_SH = r'''#!/usr/bin/env bash
# 双击运行（macOS）。终端窗口会留着，看完按回车关。
cd "$(dirname "${BASH_SOURCE[0]}")"
bash ./install.sh "$@"
echo ""
read -r -p "按回车关闭…" _
'''

# ---------------------------------------------------------------- 给主 Bot
MAIN_BOT_DOC = r'''# 给主 Bot：一键安装「教材匹配」Bot

> 这是一个安装包，不是文档。你要做的是**跑一条命令**，然后把这个 Bot 创建出来。
> 全程大约 1 分钟，不需要装任何依赖（macOS 自带 python3 就够）。

---

## 第 1 步：解压

把 zip 解压到一个临时位置，比如 `~/Downloads`。解压后目录长这样：

```
教材匹配Bot/
├── install.sh
├── 一键安装.command
├── 给主Bot的执行说明.md      ← 就是本文件
├── payload/
│   ├── 教材匹配/             ← 本体（数据 + 封面 + 匹配器 + 工作台）
│   └── 外教匹配/             ← 配老师用的（含老师库与照片）
└── 校验/
```

## 第 2 步：跑安装

```bash
bash "<解压目录>/教材匹配Bot/install.sh"
```

默认装到 `~/Desktop/外教业务/`。要换地方：

```bash
bash "<解压目录>/教材匹配Bot/install.sh" --dir ~/Documents/外教业务
```

它会：找 python3 → 复制 → 跑 13 条回归用例 → 真跑一次匹配（含配老师）→ 生成 Bot 指令。

**看到这一行才算成功：**
```
安装成功，自检全过。
```

如果报错，把整段输出原样交给用户，不要自己猜着往下走。

## 第 3 步：建 Bot

1. 读安装脚本最后打印的 `Bot指令-已填好路径.md`（默认在 `~/Desktop/外教业务/` 下）
2. 取里面 **「--- 复制开始 ---」到「--- 复制结束 ---」之间** 的全部内容，作为 `instructions`
3. 调用 create_bot：

```
name         = 教材匹配
role         = 教材
instructions = <上面那段内容，路径已经是装好的真实路径>
work_dir     = <安装脚本打印的 教材匹配 目录>
brief        = 同事要用它把「学生要学什么」对上「哪套教材 + 谁能教」
```

4. 建完让新 Bot 回一句话确认，然后跑一次冒烟：

```
bash <教材匹配目录>/推荐.sh --text "8岁孩子想练口语" --chat
```

出得来「教材名 + 建议课时 + 一位老师 + 封面」就算通了。

## 别做的事

- **不要**把 `payload/` 里的文件手动一个个拷过去，`install.sh` 要保证 教材匹配/ 和 外教匹配/ **同级**。两个匹配器靠这个相对位置互相找，拆开就配不上老师。
- **不要**覆盖同事已有的 `外教匹配/`。如果那台机器已经有这个目录，安装器会跳过并提示 —— 这是对的，那边的老师库可能比包里新。这时只验证「教材匹配 → 老师」这条链还通就行（自检里的第 3.3 项会验）。
- **不要**改 Bot 指令里的绝对路径。指令里的路径是按实际安装位置现生成的，改了就对不上。
- 包里**不含任何密钥**。所有数据都是本地文件，不外连。

## 两个版本怎么选

| 包 | 大小 | 含什么 | 什么时候用 |
|---|---|---|---|
| 轻量版 | ≈ 35 MB | 教材匹配 + 外教匹配（含 505 张老师照片）+ 安装器 | **默认发这个**，运行完全够 |
| 完整版 | ≈ 87 MB | 上面全部 + 52 MB 教材源表 xlsx | 对方要自己重抽数据、改教材表时才用 |

数据已经抽好放在 `教材匹配/data/` 里，运行不需要源表。

## 装完之后它有什么

| 能力 | 位置 |
|---|---|
| 一句话出「教材 + 课时 + 老师 + 封面」 | `推荐.sh --text "…" --chat` |
| 265 条教材 / 60 个系列 / 253 张封面 | `教材匹配/data/`、`教材匹配/封面/` |
| 13 条回归用例 | `python3 tools/test_cases.py` |
| 工作台（工作流 + 目标 + 缺口） | `教材匹配/工作台/index.html` |
| 改规则/重抽数据 | `教材匹配/tools/` |
| 配老师的老师库与照片 | `外教匹配/data/`、`外教匹配/照片/` |

---

装完就结束了。用户后面直接用这个 Bot 说话就行，不用再提安装包。
'''


# ---------------------------------------------------------------- 构建
def stage(include_xlsx: bool):
    if PKG.exists():
        shutil.rmtree(PKG)
    PKG.mkdir(parents=True)

    log("  复制 教材匹配 …")
    copytree(ROOT, PKG / "payload" / "教材匹配")

    log("  复制 外教匹配（只读依赖，不含本机构建产物）…")
    copytree(MATCH_DIR, PKG / "payload" / "外教匹配")

    if include_xlsx:
        if XLSX.is_file():
            (PKG / "payload" / "源数据").mkdir(parents=True, exist_ok=True)
            shutil.copy2(XLSX, PKG / "payload" / "源数据" / XLSX_NAME)
            log(f"  复制源表 {human(XLSX.stat().st_size)}")
        else:
            log(f"  ! 找不到源表，跳过：{XLSX}")

    (PKG / "install.sh").write_text(INSTALL_SH, encoding="utf-8")
    (PKG / "一键安装.command").write_text(COMMAND_SH, encoding="utf-8")
    (PKG / "给主Bot的执行说明.md").write_text(MAIN_BOT_DOC, encoding="utf-8")

    # 校验清单
    chk = PKG / "校验"
    chk.mkdir()
    lines, total, files = [], 0, 0
    for f in sorted(PKG.rglob("*")):
        if not f.is_file() or chk in f.parents:
            continue
        rel = f.relative_to(PKG)
        h = sha256(f)
        lines.append(f"{h}  {rel}")
        total += f.stat().st_size
        files += 1
    (chk / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (chk / "manifest.json").write_text(json.dumps({
        "name": "教材匹配Bot", "version": VERSION,
        "built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "with_xlsx": include_xlsx, "files": files,
        "bytes": total, "human": human(total),
    }, ensure_ascii=False, indent=1), encoding="utf-8")

    for sh in (PKG / "install.sh", PKG / "一键安装.command"):
        sh.chmod(0o755)
    return files, total


def zip_pkg(out: Path, root_name: str):
    """打包。先复制成 <root_name>/ 再压，解压出来是干净的单个文件夹。"""
    tmp = BUILD / "_zipstage" / root_name
    if tmp.parent.exists():
        shutil.rmtree(tmp.parent)
    tmp.parent.mkdir(parents=True)
    shutil.copytree(PKG, tmp)

    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for f in sorted(tmp.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(tmp.parent))
    shutil.rmtree(tmp.parent)
    return out


def test_install():
    """真的在临时目录装一遍，然后跑匹配。装不上不算做完。"""
    log("")
    log("在临时目录真装一遍 …")
    base = Path(tempfile.mkdtemp(prefix="jiaocai-install-"))
    dest = base / "外教业务"
    r = subprocess.run(["bash", str(PKG / "install.sh"), "--dir", str(dest)],
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=300)
    out = r.stdout + r.stderr
    ok = (r.returncode == 0) and ("安装成功" in out)
    if ok:
        log("  ✓ 安装通过，自检全过")
        # 再验一次真实输出
        m = dest / "教材匹配"
        r2 = subprocess.run(["bash", str(m / "推荐.sh"), "--text", "8岁孩子想练口语", "--json"],
                            capture_output=True, text=True, encoding="utf-8",
                            errors="replace", timeout=120)
        try:
            import json as _json
            res = _json.loads(r2.stdout)
            t = res.get("teacher") or {}
            log(f"  ✓ 实跑：{res['primary']['name'][:34]} / 老师 {t.get('name','(无)')}")
            ok = bool(t.get("name"))
            if not ok:
                log("  ✗ 老师没配上")
        except Exception as e:  # noqa: BLE001
            log(f"  ✗ 实跑解析失败：{e}")
            ok = False
    else:
        log("  ✗ 安装失败：")
        for line in out.splitlines()[-30:]:
            log("    " + line)

    shutil.rmtree(base, ignore_errors=True)
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slim-only", action="store_true", help="只出轻量版")
    ap.add_argument("--with-test", action="store_true", default=True, help="打完真装一遍")
    ap.add_argument("--no-test", dest="with_test", action="store_false")
    args = ap.parse_args()

    BUILD.mkdir(exist_ok=True)
    DIST.mkdir(exist_ok=True)

    made = []

    log("打包：轻量版（不含源表）")
    files, total = stage(include_xlsx=False)
    if args.with_test and not test_install():
        log("！轻量版装不上，停在这里，不出 zip")
        return 1
    out = zip_pkg(DIST / "教材匹配Bot-轻量版.zip", "教材匹配Bot")
    made.append((out, files, total))
    log(f"  → {out.name}  {human(out.stat().st_size)}")

    if not args.slim_only:
        log("")
        log("打包：完整版（含源表）")
        files, total = stage(include_xlsx=True)
        out = zip_pkg(DIST / "教材匹配Bot-完整版.zip", "教材匹配Bot")
        made.append((out, files, total))
        log(f"  → {out.name}  {human(out.stat().st_size)}")

    # 清理中间产物，只留 dist
    if PKG.exists():
        shutil.rmtree(PKG)

    log("")
    log("完成。")
    for out, files, total in made:
        log(f"  {out}")
        log(f"    {files} 个文件，解压后 {human(total)}，压缩包 {human(out.stat().st_size)}")
    log("")
    log("发之前建议自己解压一次，按「给主Bot的执行说明.md」走一遍。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
