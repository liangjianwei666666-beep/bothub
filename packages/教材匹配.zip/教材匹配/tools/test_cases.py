#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回归用例：跑一遍 match.py，把每个用例的主推教材钉在测试里。
改规则前后对比这张表，就能看出改坏了什么。

用法：
    python3 tools/test_cases.py          # 跑并比对
    python3 tools/test_cases.py --update # 用当前结果刷新基线（只在确认新结果正确时用）
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import match  # noqa: E402

BASE = ROOT / "data" / "test_baseline.json"

# (用例, 期望的主推教材名关键字, 说明)
CASES = [
    ("8岁孩子想练口语", "Speaking Time", "少儿口语方向"),
    ("三年级想补阅读", "Oxford Discover", "小学阅读，3级"),
    ("要准备KET", "Power Up", "KET 默认按 4 级"),
    ("初中生备考PET", "THiNK", "青少年应试，6级"),
    ("五年级想练写作", "写作3000词", "写作专项"),
    ("零基础启蒙", "牛津自然拼读世界", "启蒙"),
    ("幼儿园4岁学自然拼读", "牛津自然拼读世界", "学前"),
    ("成人想练商务英语", "商务英语", "成人商务"),
    ("外贸从业想练口语", "外贸英语", "外贸方向不被泛口语顶掉"),
    ("想考雅思", "雅思", "雅思"),
    ("零基础成人想出国旅游", "旅游出国英语口语900句", "旅游通用优先于签证专用"),
    ("想练旅游英语", "旅游出国英语口语900句", "成人识别不被当成小孩"),
    ("成人想练口语", "日常自由交流", "成人泛口语"),
]


class Args:
    def __init__(self, text, **kw):
        self.text = text
        self.audience = kw.get("audience")
        self.age = kw.get("age")
        self.level = kw.get("level")
        self.goal = kw.get("goal", [])
        self.series = kw.get("series")
        self.hours = kw.get("hours")
        self.keyword = kw.get("keyword")
        self.type = kw.get("type")


def run():
    results = {}
    for text, expect, note in CASES:
        res = match.match(Args(text))
        got = res["primary"]["name"]
        ok = expect in got
        results[text] = {"expect": expect, "got": got, "pass": ok, "note": note,
                         "level": res["primary"].get("level"),
                         "hours": res["primary"].get("hours"),
                         "cover": res["primary"].get("cover_exists"),
                         "teacher": (res.get("teacher") or {}).get("name")}
    return results


def main():
    update = "--update" in sys.argv
    results = run()
    failed = [k for k, v in results.items() if not v["pass"]]

    for k, v in results.items():
        flag = "✓" if v["pass"] else "✗"
        print(f"{flag} {k:<22} → {v['got'][:46]}")
        if not v["pass"]:
            print(f"    期望包含：{v['expect']}")

    no_cover = [k for k, v in results.items() if not v["cover"]]
    no_teacher = [k for k, v in results.items() if not v["teacher"] and v["note"] != "—"]
    print()
    print(f"通过 {len(results) - len(failed)}/{len(results)}")
    if no_cover:
        print(f"没封面的用例：{no_cover}")
    if no_teacher:
        print(f"没配到老师的用例：{no_teacher}")

    if update:
        BASE.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"已刷新基线：{BASE}")
    elif BASE.exists():
        old = json.loads(BASE.read_text(encoding="utf-8"))
        changed = [k for k in results if k in old and old[k]["got"] != results[k]["got"]]
        if changed:
            print(f"与基线不同（{len(changed)} 个）：")
            for k in changed:
                print(f"  {k}: {old[k]['got'][:40]} → {results[k]['got'][:40]}")

    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
