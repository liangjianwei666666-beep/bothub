#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 xlsx 里内嵌的课本封面（WPS 的 DISPIMG 单元格图片）抽出来，转成聊天能直接显示的 jpg。

为什么要转：
  · 原图是 png/emf 混装，有的带透明通道、有的尺寸上万像素，聊天里直接引用又慢又可能不显示
  · 文件名必须是纯 ASCII（ID_xxx.jpg），中文路径在有些客户端会挂

产出：
  封面/ID_xxx.jpg          压缩后的封面（文件名仍用 ID_，纯 ASCII）
  data/cover_index.json    "pic_id|catalog_id" -> 文件名
                           37 张图被一本书的多个级别共用（如 Let's Go 1-8 共用一张），
                           所以按「图片 + 教材条目」两个键建索引，避免两个级别抢同一张图。

用法：
  python3 tools/extract_covers.py
"""
import io
import json
import re
import zipfile
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data"
COVER_DIR = ROOT / "封面"
XLSX = ROOT.parent / "教科书适用学生及对应课时安排（2026-04-01）.xlsx"

MAX_SIDE = 900
QUALITY = 82


def parse_cellimages(z):
    """cellimages.xml 里 name="ID_xxx" 与 r:embed="rIdNN" 成对出现。"""
    xml = z.read("xl/cellimages.xml").decode("utf-8", "replace")
    rels = z.read("xl/_rels/cellimages.xml.rels").decode("utf-8", "replace")
    rid2file = {}
    for m in re.finditer(r'Id="(rId\d+)"[^>]*Target="([^"]+)"', rels):
        rid2file[m.group(1)] = m.group(2)
    for m in re.finditer(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels):
        rid2file.setdefault(m.group(1), m.group(2))

    pic2file = {}
    for pic in re.finditer(r"<etc:cellImage>.*?</etc:cellImage>", xml, re.S):
        block = pic.group(0)
        name = re.search(r'name="(ID_[^"]+)"', block)
        embed = re.search(r'r:embed="([^"]+)"', block)
        if not (name and embed):
            continue
        target = rid2file.get(embed.group(1))
        if not target:
            continue
        if not target.startswith("xl/"):
            target = "xl/" + target.lstrip("/")
        pic2file[name.group(1)] = target
    return pic2file


def convert(raw, dst):
    """尽力转 jpg；遇到 EMF/WMF 这类 PIL 读不了的，返回 False。"""
    try:
        im = Image.open(io.BytesIO(raw))
    except Exception:
        return False
    try:
        im.load()
    except Exception:
        return False
    if im.mode in ("RGBA", "LA", "P"):
        im = im.convert("RGBA")
        bg = Image.new("RGB", im.size, (255, 255, 255))
        bg.paste(im, mask=im.split()[-1])
        im = bg
    elif im.mode != "RGB":
        im = im.convert("RGB")
    w, h = im.size
    if max(w, h) > MAX_SIDE:
        k = MAX_SIDE / max(w, h)
        im = im.resize((max(1, int(w * k)), max(1, int(h * k))), Image.LANCZOS)
    im.save(dst, "JPEG", quality=QUALITY, optimize=True)
    return True


def main():
    if not XLSX.is_file():
        raise SystemExit(f"找不到数据源：{XLSX}")
    courses = json.loads((DATA / "courses.json").read_text(encoding="utf-8"))["courses"]
    needed = [c for c in courses if c.get("pic_id")]

    COVER_DIR.mkdir(exist_ok=True)
    z = zipfile.ZipFile(XLSX)
    pic2file = parse_cellimages(z)
    print(f"表格内单元格图片 {len(pic2file)} 张，需要 {len(needed)} 本封面")

    # 一张图被几条教材共用时，按目录顺序拆成 _a/_b 多份
    use_count = {}
    index, ok, fail, miss = {}, 0, [], []
    for c in needed:
        pid = c["pic_id"]
        target = pic2file.get(pid)
        if not target:
            miss.append(c["name"])
            continue
        use_count[pid] = use_count.get(pid, 0) + 1
        suffix = "" if use_count[pid] == 1 else f"_{chr(96 + use_count[pid])}"
        dst = COVER_DIR / f"{pid}{suffix}.jpg"
        if dst.exists():
            index[f"{pid}|{c['id']}"] = dst.name
            index.setdefault(pid, dst.name)
            ok += 1
            continue
        raw = z.read(target)
        if convert(raw, dst):
            index[f"{pid}|{c['id']}"] = dst.name
            index.setdefault(pid, dst.name)
            ok += 1
        else:
            fail.append((c["name"], target))

    (DATA / "cover_index.json").write_text(
        json.dumps({"_说明": "键有两类：「pic_id|catalog_id」精确到教材条目；纯 pic_id 为兜底",
                    "index": index}, ensure_ascii=False, indent=0), encoding="utf-8")

    total_mb = sum(f.stat().st_size for f in COVER_DIR.glob("*.jpg")) / 1048576
    print(f"转换成功 {ok} 张，占 {total_mb:.1f} MB")
    if fail:
        print(f"格式读不了 {len(fail)} 张（可能是 EMF 矢量图）：")
        for n, t in fail[:8]:
            print("  -", n.replace("\n", "/"), t)
    if miss:
        print(f"表里没找到图片的 {len(miss)} 条：{[n.replace(chr(10),'/') for n in miss[:5]]}")


if __name__ == "__main__":
    main()
