#!/bin/bash
# 打包科普片导演技能包，便于发给别人的主 Bot
#
# 用法：bash package.sh           输出到 ~/Downloads/science-doc-director.tar.gz
# 安全：打包前会扫一遍有没有疑似密钥，有就中止。
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAME="$(basename "$SKILL_DIR")"
DEST="${1:-$HOME/Downloads}"
OUT="$DEST/$NAME.tar.gz"

echo "=========================================="
echo "  打包 $NAME"
echo "=========================================="
echo "  源目录：$SKILL_DIR"
echo ""

# ---------- 1) 密钥扫描 ----------
echo "[1/3] 扫描疑似密钥..."
PATTERNS='sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{30,}|xox[baprs]-[A-Za-z0-9-]{10,}|api[_-]?key\s*[:=]\s*["'\'']?[A-Za-z0-9]{16,}'
HITS="$(grep -rEIil "$PATTERNS" "$SKILL_DIR" --exclude-dir=.git 2>/dev/null || true)"
if [ -n "$HITS" ]; then
  echo "      ✗ 发现疑似密钥，已中止打包："
  echo "$HITS" | sed 's/^/        /'
  echo ""
  echo "      确认并删除后再打包。"
  exit 1
fi
echo "      ✓ 未发现疑似密钥"

# 额外提示：确认没有 .env / credentials 之类的文件
SECRETS="$(find "$SKILL_DIR" -type f \( -name '.env' -o -name '*.pem' -o -name '*credential*' -o -name '*secret*' \) 2>/dev/null || true)"
if [ -n "$SECRETS" ]; then
  echo "      ✗ 发现密钥类文件，已中止："
  echo "$SECRETS" | sed 's/^/        /'
  exit 1
fi
echo "      ✓ 无密钥类文件"

# ---------- 2) 清理临时产物 ----------
echo "[2/3] 清理渲染产物..."
rm -rf "$SKILL_DIR"/examples/out "$SKILL_DIR"/examples/qc "$SKILL_DIR"/templates/out 2>/dev/null || true
echo "      ✓ 已清理 out/ 与 qc/"

# ---------- 3) 打包 ----------
echo "[3/3] 压缩..."
mkdir -p "$DEST"
cd "$(dirname "$SKILL_DIR")"
tar --exclude='.DS_Store' --exclude='__pycache__' -czf "$OUT" "$NAME"

SIZE="$(du -h "$OUT" | cut -f1)"
FILES="$(tar -tzf "$OUT" | wc -l | tr -d ' ')"

echo ""
echo "=========================================="
echo "  完成 ✓"
echo "=========================================="
echo "  文件：$OUT"
echo "  大小：$SIZE   条目：$FILES"
echo ""
echo "发给别人时这样说："
echo "  「把这个压缩包丢给你的主 Bot，说：装科普片导演」"
