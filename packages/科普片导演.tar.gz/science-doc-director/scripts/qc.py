#!/usr/bin/env python3
"""
科普片导演 · 量化质检

不靠肉眼，从成片里抽帧算指标：
  亮度 / 对比度  → 抓空镜、黑镜、糊成一片的镜头
  边缘密度       → 抓「信息层压在死云上，什么也读不出来」
  暖金 / 冷青 / 暗珊瑚 占比 → 核对「能量 / 结构 / 破坏」三条视觉语义真的出现在画面上
  字幕区方差     → 核对字幕底板确实烧进去了

用法：
    python3 qc.py projects/示例
    python3 qc.py projects/示例 --out qc/指标.json
退出码：0 全部通过；1 有质量门未通过（便于流水线中断）
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    import imageio_ffmpeg
except ImportError:
    imageio_ffmpeg = None


# ---------------- 色相判定（与 DESIGN 规范一致） ----------------
def hue_ratios(a):
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    amber = ((r > 170) & (g > 110) & (b < 130)).mean() * 100
    cyan = ((g > 140) & (b > 130) & (r < 140)).mean() * 100
    coral = ((r > 170) & (g < 120) & (b < 120)).mean() * 100
    return amber, cyan, coral


def metrics(arr):
    a = arr.astype(np.float32)
    h, w = a.shape[:2]
    luma = 0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2]
    gy = np.abs(np.diff(luma, axis=0))[:h - 1, :w - 1]
    gx = np.abs(np.diff(luma, axis=1))[:h - 1, :w - 1]
    grad = np.sqrt(gx ** 2 + gy ** 2)
    mx = a.max(axis=2)
    mn = a.min(axis=2)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1), 0)
    amber, cyan, coral = hue_ratios(a)
    return {
        'luma_mean': round(float(luma.mean()), 1),
        'luma_std': round(float(luma.std()), 1),
        'near_black_pct': round(float((luma < 12).mean() * 100), 1),
        'near_white_pct': round(float((luma > 235).mean() * 100), 1),
        'edge_density': round(float((grad > 18).mean()), 4),
        'sat_mean': round(float(sat.mean() * 100), 1),
        'amber_pct': round(float(amber), 2),
        'cyan_pct': round(float(cyan), 2),
        'coral_pct': round(float(coral), 2),
        'sub_region_std': round(float(
            luma[int(h * 0.72):int(h * 0.96), int(w * 0.2):int(w * 0.8)].std()), 1),
    }


def ffmpeg():
    if imageio_ffmpeg is None:
        raise SystemExit('缺少 imageio-ffmpeg，请先运行：python3 -m pip install imageio-ffmpeg')
    return imageio_ffmpeg.get_ffmpeg_exe()


def grab(mp4, t, size):
    w, h = size
    r = subprocess.run(
        [ffmpeg(), '-v', 'quiet', '-ss', f'{max(0, t):.3f}', '-i', str(mp4),
         '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'],
        capture_output=True)
    need = w * h * 3
    if len(r.stdout) < need:
        return None
    return np.frombuffer(r.stdout[:need], dtype=np.uint8).reshape(h, w, 3)


def eval_gates(shots, blank):
    luma = [s['luma_mean'] for s in shots if 'luma_mean' in s]
    stds = [s['luma_std'] for s in shots if 'luma_std' in s]
    gates = []

    def g(name, ok, detail):
        gates.append({'name': name, 'ok': bool(ok), 'detail': detail})

    g('每镜亮度 ≥ 30（不出现接近黑屏的空镜）',
      bool(luma) and min(luma) >= 30,
      f'最低 {min(luma):.1f} / 最高 {max(luma):.1f}' if luma else '无数据')
    g('每镜对比度 ≥ 20（不出现糊成一片的镜头）',
      bool(stds) and min(stds) >= 20,
      f'最低 {min(stds):.1f}' if stds else '无数据')
    g('无全黑帧或空帧', len(blank) == 0, f'可疑帧 {len(blank)} 个')
    coral_top = max([s.get('coral_pct', 0) for s in shots] or [0])
    g('「破坏 / 衰减」语义可见：至少一镜暗珊瑚 ≥ 0.5%',
      coral_top >= 0.5, f'最高 {coral_top:.2f}%')
    amber_shots = [s['shot'] for s in shots if s.get('amber_pct', 0) >= 1.0]
    g('「能量」语义可见：至少 3 镜暖金 ≥ 1%',
      len(amber_shots) >= 3,
      '含暖金镜头：' + (', '.join(map(str, amber_shots)) if amber_shots else '无'))
    g('字幕已烧录：字幕区有内容', 
      all(s.get('sub_region_std', 0) >= 8 for s in shots if 'luma_mean' in s),
      f'最低字幕区方差 {min([s.get("sub_region_std", 0) for s in shots] or [0]):.1f}')
    return gates


def contact_sheet(mp4, project, size, shots, dst):
    w, h = size
    tw, th, cols = 320, 180, 4
    rows = math.ceil(len(shots) / cols)
    sheet = Image.new('RGB', (cols * tw, rows * (th + 26)), (12, 18, 26))
    ds = ImageDraw.Draw(sheet)
    try:
        fnt = ImageFont.truetype('/System/Library/Fonts/Hiragino Sans GB.ttc', 15, index=2)
    except Exception:
        fnt = ImageFont.load_default()
    for k, s in enumerate(shots):
        arr = grab(mp4, s['t'], size)
        if arr is None:
            continue
        th_im = Image.fromarray(arr).resize((tw, th), Image.Resampling.LANCZOS)
        x = (k % cols) * tw
        y = (k // cols) * (th + 26)
        sheet.paste(th_im, (x, y))
        ds.text((x + 6, y + th + 4), f'{s["shot"]:02d} {s.get("label", "")}',
                font=fnt, fill=(233, 242, 238))
    sheet.save(dst, quality=88)
    return dst


def main(argv=None):
    ap = argparse.ArgumentParser(description='科普片导演 · 量化质检')
    ap.add_argument('project', help='项目目录')
    ap.add_argument('--out', default='', help='指标 JSON 输出路径')
    ap.add_argument('--video', default='', help='覆盖成片路径')
    ap.add_argument('--strict', action='store_true', help='有门未通过时返回非零退出码')
    args = ap.parse_args(argv)

    root = Path(args.project).resolve()
    cfg = json.loads((root / 'project.json').read_text(encoding='utf-8'))
    w = int(cfg.get('width', 1280))
    h = int(cfg.get('height', 720))
    video = Path(args.video) if args.video else root / cfg.get('out', 'out/成片.mp4')
    if not video.exists():
        raise SystemExit(f'成片不存在：{video}')

    shots = []
    print(f'{"镜":>3} {"时间":>8} {"名称":<12} {"亮度":>6} {"对比":>6} {"边缘":>7} '
          f'{"暖金":>6} {"冷青":>6} {"珊瑚":>6}')
    for i, s in enumerate(cfg['shots'], 1):
        t = s['start'] + (s['end'] - s['start']) * 0.6
        arr = grab(video, t, (w, h))
        if arr is None:
            shots.append({'shot': i, 'label': s.get('label', ''), 't': round(t, 2),
                          'error': 'no frame'})
            continue
        m = metrics(arr)
        m.update({'shot': i, 'label': s.get('label', ''), 't': round(t, 2),
                  'dur': round(s['end'] - s['start'], 2)})
        shots.append(m)
        print(f'{i:>3} {t:>7.2f}s {s.get("label", ""):<12} {m["luma_mean"]:>6.1f} '
              f'{m["luma_std"]:>6.1f} {m["edge_density"]:>7.4f} '
              f'{m["amber_pct"]:>6.2f} {m["cyan_pct"]:>6.2f} {m["coral_pct"]:>6.2f}')

    # 逐秒扫一遍，抓黑帧
    blank = []
    dur = float(cfg.get('duration', 0))
    for sec in range(int(dur)):
        arr = grab(video, sec + 0.5, (w, h))
        if arr is None:
            blank.append(sec)
            continue
        m = metrics(arr)
        if m['luma_mean'] < 8 or m['luma_std'] < 4:
            blank.append({'t': sec + 0.5, 'luma': m['luma_mean']})

    gates = eval_gates(shots, blank)
    qc_dir = root / 'qc'
    qc_dir.mkdir(exist_ok=True)
    sheet = contact_sheet(video, cfg, (w, h), [s for s in shots if 't' in s],
                          qc_dir / '联系表.jpg')

    report = {
        'video': str(video),
        'size_mb': round(video.stat().st_size / 1024 / 1024, 2),
        'shots': shots,
        'suspicious_frames': blank,
        'gates': gates,
        'contact_sheet': str(sheet),
        'passed': sum(1 for g in gates if g['ok']),
        'total_gates': len(gates),
    }
    out = Path(args.out) if args.out else (qc_dir / '指标.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    print('\n质量门：')
    for g in gates:
        print(('  ✅ ' if g['ok'] else '  ❌ ') + g['name'] + ' — ' + g['detail'])
    print(f'\n通过 {report["passed"]}/{report["total_gates"]}')
    print(f'联系表：{sheet}')
    print(f'指标：{out}')

    failed = [g for g in gates if not g['ok']]
    return 1 if (failed and args.strict) else 0


if __name__ == '__main__':
    sys.exit(main())
