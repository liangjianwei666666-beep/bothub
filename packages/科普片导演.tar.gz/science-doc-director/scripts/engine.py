#!/usr/bin/env python3
"""
科普片导演 · 通用逐帧合成引擎

一个科普项目 = 一个目录：
    project.json   项目配置（画幅、时长、色板、镜头表、字幕、资产、配音）
    scenes.py      场景层：def shotNN(p, t) -> Image，每个镜头画什么
    assets/        AI 生成的云/海/风场静帧（可为空，会自动降级为程序化背景）

引擎负责：资产加载、摄影机运动、调色后处理、字幕烧录、章节 HUD、
        逐帧直接管道送 ffmpeg 编码、混入配音。

用法：
    python3 engine.py projects/示例                 # 全片渲染
    python3 engine.py projects/示例 --limit 30      # 只渲前 30 帧（快速自检）
    python3 engine.py projects/示例 --preview 6     # 每镜取中段帧存 PNG，不做编码
    python3 engine.py projects/示例 --probe         # 只检查配置、字体和资产

设计约束（来自 DESIGN 规范，写死在引擎里）：
  - 一镜最多三种主色；暖金只表示能量，暗珊瑚只表示破坏或衰减
  - 中文、数字、箭头、标注全部由本引擎绘制，AI 只提供云/海/风场纹理
  - 字幕不遮挡核心结构；章节标与进度条保持极简
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import math
import random
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

try:
    import imageio_ffmpeg
except ImportError:  # pragma: no cover
    imageio_ffmpeg = None

# ============================================================
# 画幅（可由 project.json 覆盖，必须在导入 scenes 之前生效）
# ============================================================
W, H, FPS = 1280, 720, 30
DUR = 60.0

# 默认色板：深夜海军蓝 / 深海蓝 / 冷青 / 暖金 / 暗珊瑚 / 雾白
BG = (6, 21, 34)
DEEP_SEA = (11, 63, 90)
CYAN = (114, 217, 208)
AMBER = (255, 180, 94)
CORAL = (233, 105, 98)
FOG = (233, 242, 238)

PALETTE_KEYS = ('bg', 'deep', 'cyan', 'amber', 'coral', 'fog')

# ============================================================
# 字体：跨平台探测，必须能渲染中文
# ============================================================
FONT_CANDIDATES = [
    # macOS
    ('/System/Library/Fonts/Hiragino Sans GB.ttc', 0, 2),
    ('/System/Library/Fonts/PingFang.ttc', 0, 1),
    ('/System/Library/Fonts/STHeiti Light.ttc', 0, 2),
    ('/System/Library/Fonts/Supplemental/Songti.ttc', 3, 1),
    # Linux
    ('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 0, 1),
    ('/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf', 0, 0),
    ('/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc', 0, 1),
    ('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc', 0, 0),
    ('/usr/share/fonts/truetype/wqy/wqy-microhei.ttc', 0, 0),
    ('/usr/share/fonts/truetype/arphic/uming.ttc', 0, 0),
    # Windows
    ('C:/Windows/Fonts/msyh.ttc', 0, 1),
    ('C:/Windows/Fonts/msyhbd.ttc', 0, 0),
    ('C:/Windows/Fonts/simhei.ttf', 0, 0),
]

MONO_CANDIDATES = [
    ('/System/Library/Fonts/SFNSMono.ttf', 0),
    ('/System/Library/Fonts/Menlo.ttc', 0),
    ('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 0),
    ('/usr/share/fonts/truetype/libreoffice/opensans-webkit.ttf', 0),
    ('C:/Windows/Fonts/consola.ttf', 0),
]

_FONT_REG = None   # (path, index)
_FONT_BOLD = None
_MONO = None
_font_cache = {}
CJK_PROBE = '科普台风'


def _face_ok(path, index):
    """字体是否存在且真的能画出中文（避免选到只覆盖拉丁的字体）"""
    try:
        if not Path(path).exists():
            return False
        f = ImageFont.truetype(path, 24, index=index)
        l, t, r, b = f.getbbox(CJK_PROBE)
        return (r - l) > 10 and (b - t) > 10
    except Exception:
        return False


def resolve_fonts():
    """选一个能渲染中文的正体与粗体；返回实际使用的字体信息，便于打印核验"""
    global _FONT_REG, _FONT_BOLD, _MONO
    for path, reg_idx, bold_idx in FONT_CANDIDATES:
        if _FONT_REG is None and _face_ok(path, reg_idx):
            _FONT_REG = (path, reg_idx)
        if _FONT_BOLD is None and _face_ok(path, bold_idx):
            _FONT_BOLD = (path, bold_idx)
        if _FONT_REG and _FONT_BOLD:
            break
    if _FONT_REG is None:
        raise RuntimeError(
            '找不到可渲染中文的字体。请安装任一中文字体后重试：\n'
            '  macOS:  系统自带 Hiragino Sans GB\n'
            '  Linux:  sudo apt install fonts-noto-cjk\n'
            '  Windows: 系统自带微软雅黑\n'
            f'已尝试：{", ".join(p for p, _, _ in FONT_CANDIDATES)}')
    if _FONT_BOLD is None:
        _FONT_BOLD = _FONT_REG
    for path, idx in MONO_CANDIDATES:
        if Path(path).exists():
            _MONO = (path, idx)
            break
    if _MONO is None:
        _MONO = _FONT_REG
    return {'regular': _FONT_REG, 'bold': _FONT_BOLD, 'mono': _MONO}


def font(size, bold=False):
    """中文正文/标题。召唤前必须已 resolve_fonts()"""
    key = (size, bold)
    if key not in _font_cache:
        path, idx = _FONT_BOLD if bold else _FONT_REG
        _font_cache[key] = ImageFont.truetype(path, size, index=idx)
    return _font_cache[key]


def mono(size):
    """数字与英文辅助标签"""
    key = ('mono', size)
    if key not in _font_cache:
        path, idx = _MONO
        _font_cache[key] = ImageFont.truetype(path, size, index=idx)
    return _font_cache[key]


# ============================================================
# 基础工具
# ============================================================
def clamp(x, a=0.0, b=1.0):
    return a if x < a else (b if x > b else x)


def ease_out(x):
    x = clamp(x)
    return 1 - (1 - x) ** 3


def ease_in(x):
    x = clamp(x)
    return x ** 3


def ease_in_out(x):
    x = clamp(x)
    return x * x * (3 - 2 * x)


def lerp(a, b, t):
    return a + (b - a) * t


# ============================================================
# 资产与摄影机
# ============================================================
def make_placeholder(key, seed=0):
    """资产缺失时的程序化占位背景：深蓝渐变 + 柔和云团。

    目标：亮度落在 60-90，保证代码标注、字幕和线条在上面都读得清，
    不至于因为没接生图 API 就得到一个接近黑屏的片子。
    """
    rng = random.Random(abs(hash((key, seed))) % (2 ** 31))
    w, h = int(W * 1.25), int(H * 1.25)
    top = np.array(BG, dtype=np.float32)
    bot = np.array((26, 84, 118), dtype=np.float32)      # 比 BG 亮得多，撑起画面
    ramp = np.linspace(0.28, 1.10, h, dtype=np.float32)[:, None, None]
    mid = top[None, None, :] * 0.45 + bot[None, None, :] * 0.55
    arr = mid * ramp
    arr = np.repeat(arr, w, axis=1)

    layer = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    for _ in range(34):
        cx, cy = rng.uniform(0, w), rng.uniform(0, h)
        rx = rng.uniform(w * 0.08, w * 0.30)
        ry = rng.uniform(h * 0.06, h * 0.22)
        a = rng.randint(34, 78)
        if rng.random() < 0.66:
            col = (44, 104, 140)                          # 云体
        else:
            col = CYAN                                     # 冷青高光
            a = int(a * 0.5)
        ld.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=(*col, a))
    small = layer.resize((max(1, w // 8), max(1, h // 8)), Image.Resampling.BILINEAR)
    layer = small.resize((w, h), Image.Resampling.BILINEAR).filter(
        ImageFilter.GaussianBlur(10))
    base_im = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).convert('RGBA')
    base_im.alpha_composite(layer)
    return base_im.convert('RGB')


class AssetDict(dict):
    """资产字典：访问不存在的资产时自动生成程序化背景，而不是抛 KeyError"""

    def __missing__(self, key):
        im = make_placeholder(key)
        self[key] = im
        return im


A = AssetDict()   # {资产ID: 原生分辨率 PIL.Image}
ASSET_PATHS = {}  # {资产ID: 绝对路径}


def load_native(path, fallback_size=None):
    """按 16:9 居中裁切并保留原生分辨率，供摄影机推拉使用"""
    fallback_size = fallback_size or (W, H)
    p = Path(path)
    if not p.exists():
        return Image.new('RGB', _canvas(fallback_size), DEEP_SEA)
    im = Image.open(p).convert('RGB')
    target = W / H
    aspect = im.width / im.height
    if aspect > target:
        nw = int(im.height * target)
        x = (im.width - nw) // 2
        im = im.crop((x, 0, x + nw, im.height))
    elif aspect < target:
        nh = int(im.width / target)
        y = (im.height - nh) // 2
        im = im.crop((0, y, im.width, y + nh))
    return im


def _canvas(size):
    """资产占位尺寸：保证不小于画幅，推近时不会糊"""
    w, h = size
    return (max(w, int(W * 1.2)), max(h, int(H * 1.2)))


def cam(src, zoom=1.0, cx=0.5, cy=0.5):
    """摄影机：按 zoom(>=1 推近) 与构图中心裁切后缩放到画幅"""
    zoom = max(1.0, min(1.6, zoom))
    cw = src.width / zoom
    ch = src.height / zoom
    x = (src.width - cw) * clamp(cx)
    y = (src.height - ch) * clamp(cy)
    x = max(0, min(src.width - cw, x))
    y = max(0, min(src.height - ch, y))
    box = (int(x), int(y), int(x + cw), int(y + ch))
    return src.crop(box).resize((W, H), Image.Resampling.BOX)


def dim(img, k=0.42):
    arr = np.asarray(img, dtype=np.float32) * k
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


def tone_bg(img, k=0.5, lift=(10, 32, 50), lift_k=0.45):
    """压暗背景但保留云层纹理：暗部抬升到深蓝，避免整屏死黑"""
    arr = np.asarray(img, dtype=np.float32) * k
    arr = arr + np.array(lift, dtype=np.float32)[None, None, :] * lift_k
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


def soft_bg(key, zoom, cx=0.5, cy=0.5, k=0.5, blur=10, lift=(12, 36, 56), lift_k=0.6):
    """柔化后的背景：保留云层纹理但压平对比，专门给信息层当底"""
    base = cam(A[key], zoom, cx, cy)
    small = base.resize((max(1, W // 2), max(1, H // 2)), Image.Resampling.BILINEAR)
    small = small.filter(ImageFilter.GaussianBlur(max(0.5, blur / 2)))
    base = small.resize((W, H), Image.Resampling.BILINEAR)
    arr = np.asarray(base, dtype=np.float32) * k
    arr = arr + np.array(lift, dtype=np.float32)[None, None, :] * lift_k
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


# ============================================================
# 贴图与光效
# ============================================================
def soft_paste(im, layer):
    """把 RGBA 图层按 alpha 合成到 RGB 图"""
    im.paste(layer, (0, 0), layer)


def paste_scaled(im, small, scale, radius=0.0):
    """低分辨率模糊层再放大贴回：等价全画幅高斯模糊，但快十倍以上"""
    if radius:
        small = small.filter(ImageFilter.GaussianBlur(max(0.4, radius / scale)))
    big = small.resize((W, H), Image.Resampling.BILINEAR)
    im.paste(big, (0, 0), big)


def blur_paste(im, layer, radius, scale=4):
    w, h = max(1, W // scale), max(1, H // scale)
    small = layer.resize((w, h), Image.Resampling.BILINEAR)
    paste_scaled(im, small, scale, radius)


def glow_ring(cx, cy, rx, ry, color, blur, strength, scale=4):
    """在低分辨率画布上画光晕环，返回 (小图, scale)"""
    g = Image.new('RGBA', (max(1, W // scale), max(1, H // scale)), (0, 0, 0, 0))
    gd = ImageDraw.Draw(g)
    k = 1.0 / scale
    for i in range(4, 0, -1):
        s = 1 + i * 0.16
        a = int(strength * (5 - i) / 4)
        gd.ellipse([(cx - rx * s) * k, (cy - ry * s) * k,
                    (cx + rx * s) * k, (cy + ry * s) * k],
                   outline=(*color, a), width=max(1, int(6 * s * k)))
    return g, scale


def coral_tint(im, x0, x1, amount=0.5, feather=120):
    """按亮度把局部云层染成暗珊瑚：破坏/衰减区既有色相又有体积感"""
    amount = clamp(amount)
    if amount <= 0.01:
        return im
    arr = np.asarray(im, dtype=np.float32)
    luma = (0.2126 * arr[..., 0] + 0.7152 * arr[..., 1] + 0.0722 * arr[..., 2]) / 255.0
    coral = np.array(CORAL, dtype=np.float32)
    tinted = coral[None, None, :] * (0.30 + 0.95 * luma[..., None])
    xs = np.arange(W, dtype=np.float32)
    w = np.zeros(W, dtype=np.float32)
    w[(xs >= x0) & (xs <= x1)] = 1.0
    if feather > 0:
        ramp = np.clip((x0 + feather - xs) / feather, 0, 1)
        mask = (xs >= x0) & (xs < x0 + feather)
        w[mask] = ramp[mask]
    wgt = (w * amount)[None, :, None]
    out = arr * (1 - wgt) + tinted * wgt
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))


def coral_wash(im, x0, x1, strength=90, feather=300):
    """在指定横向区间叠加暗珊瑚薄雾"""
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    for i in range(feather):
        f = i / max(1, feather - 1)
        a = int(strength * (1 - f) ** 1.6)
        if a <= 0:
            continue
        xa = int(x1 - i)
        if xa < 0:
            break
        ld.line([(xa, 0), (xa, H)], fill=(*CORAL, a))
    if x0 > 0:
        crop = layer.crop((x0, 0, W, H))
        layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        layer.paste(crop, (x0, 0))
    blur_paste(im, layer, 34, scale=6)


def scrim(im, box, alpha=140, radius=18):
    """半透明深色衬底，让标注压在复杂云图上仍可读"""
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    ld.rounded_rectangle(box, radius=radius, fill=(4, 13, 22, alpha))
    small = layer.resize((max(1, W // 2), max(1, H // 2)), Image.Resampling.BILINEAR)
    big = small.resize((W, H), Image.Resampling.BILINEAR)
    im.paste(big, (0, 0), big)


# ============================================================
# 标注原语
# ============================================================
def tag(d, x, y, text, size=20, color=None, bold=True, align='lm',
        plate=True, plate_a=150, radius=7, pad=(11, 6)):
    """带半透明深色底板的小标签，保证在任意云图上可读"""
    if color is None:
        color = FOG
    f = font(size, bold)
    l, t, r, b = d.textbbox((0, 0), text, font=f)
    tw, th = r - l, b - t
    if align[0] == 'm':
        x -= tw // 2
    elif align[0] == 'r':
        x -= tw
    if align[1] == 'm':
        y -= th // 2
    elif align[1] == 'b':
        y -= th
    if plate and plate_a > 0:
        d.rounded_rectangle(
            [x - pad[0], y - pad[1], x + tw + pad[0], y + th + pad[1]],
            radius=radius, fill=(4, 14, 24, plate_a))
    d.text((x - l, y - t), text, font=f, fill=color)


def arrow(d, p0, p1, color, width=4, head=13, alpha=255):
    x0, y0 = p0
    x1, y1 = p1
    ang = math.atan2(y1 - y0, x1 - x0)
    bx, by = x1 - math.cos(ang) * head, y1 - math.sin(ang) * head
    c = (*color, alpha) if len(color) == 3 else color
    d.line([(x0, y0), (bx, by)], fill=c, width=width)
    left = (x1 - math.cos(ang - 0.42) * head, y1 - math.sin(ang - 0.42) * head)
    right = (x1 - math.cos(ang + 0.42) * head, y1 - math.sin(ang + 0.42) * head)
    d.polygon([(x1, y1), left, right], fill=c)


# ============================================================
# 程序化底：渐变、暗角、颗粒、粒子
# ============================================================
def make_bg_gradient():
    top = np.array(BG, dtype=np.float32)
    bot = np.array(DEEP_SEA, dtype=np.float32)
    ramp = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    arr = top[None, None, :] + (bot - top)[None, None, :] * ramp
    arr = np.repeat(arr, W, axis=1)
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


BG_IMG = None


def make_vignette():
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    nx = (xx - W / 2) / (W / 2)
    ny = (yy - H / 2) / (H / 2)
    r = np.sqrt(nx ** 2 * 0.85 + ny ** 2 * 1.05)
    fall = np.clip((r - 0.55) / 0.95, 0, 1) ** 1.5
    return (1.0 - 0.45 * fall).astype(np.float32)[:, :, None]


VIGNETTE = None
GRAIN = []
PARTICLES = []


def build_luts(grain_tiles=6, grain_amp=3.2):
    """一次性预计算暗角与颗粒，避免逐帧重算"""
    global VIGNETTE, GRAIN, PARTICLES, BG_IMG
    VIGNETTE = make_vignette()
    GRAIN = []
    for s in range(grain_tiles):
        rng = np.random.default_rng(1000 + s)
        GRAIN.append(rng.normal(0, grain_amp, (H, W, 1)).astype(np.float32))
    rng = random.Random(7)
    PARTICLES = [(
        rng.uniform(0, W), rng.uniform(0, 1), rng.uniform(38, 120),
        rng.uniform(1.1, 3.0), rng.uniform(0.55, 1.0),
    ) for _ in range(110)]
    BG_IMG = make_bg_gradient()


# ============================================================
# 项目配置
# ============================================================
class Project:
    def __init__(self, root):
        self.root = Path(root).resolve()
        cfg_path = self.root / 'project.json'
        if not cfg_path.exists():
            raise SystemExit(f'缺少项目配置：{cfg_path}')
        self.cfg = json.loads(cfg_path.read_text(encoding='utf-8'))

        self.duration = float(self.cfg.get('duration', DUR))
        self.fps = int(self.cfg.get('fps', FPS))
        self.shots = self.cfg.get('shots') or []
        if not self.shots:
            raise SystemExit('project.json 里没有任何镜头（shots 为空）')
        self.subs = [tuple(s) for s in self.cfg.get('subtitles', [])]
        self.hud = self.cfg.get('hud', {'chapter': True, 'progress': True})
        self.fade = self.cfg.get('fade', {'in': 0.7, 'out': 0.9})
        self.out_rel = self.cfg.get('out', 'out/成片.mp4')
        self.audio_rel = self.cfg.get('audio') or ''
        self.assets = self.cfg.get('assets') or {}
        self.scenes_rel = self.cfg.get('scenes', 'scenes.py')

    # ---- 校验 ----
    def validate(self):
        problems = []
        prev_end = None
        for i, s in enumerate(self.shots, 1):
            if 'start' not in s or 'end' not in s:
                problems.append(f'镜 {i} 缺少 start/end')
                continue
            if s['end'] <= s['start']:
                problems.append(f'镜 {i} 的 end <= start')
            if prev_end is not None and abs(s['start'] - prev_end) > 0.001:
                problems.append(f'镜 {i} 起点 {s["start"]} 与上一镜终点 {prev_end} 不连续')
            prev_end = s['end']
        if prev_end is not None and abs(prev_end - self.duration) > 0.05:
            problems.append(f'最后一镜终点 {prev_end} 与项目时长 {self.duration} 不一致')
        for t0, t1, _ in self.subs:
            if t1 <= t0:
                problems.append(f'字幕时间窗非法：{t0}..{t1}')
        return problems


# ============================================================
# 字幕与 HUD
# ============================================================
def wrap_cn(text, limit=22):
    """按标点和长度切字幕行，最多两行"""
    if len(text) <= limit:
        return [text]
    best, best_score = None, 1e9
    for i in range(8, len(text) - 6):
        if text[i] in '，。、；：！？':
            score = abs(i - len(text) / 2)
            if score < best_score:
                best, best_score = i + 1, score
    if best is None:
        best = len(text) // 2
    return [text[:best], text[best:]]


def draw_subtitle(im, t, subs):
    for t0, t1, text in subs:
        if t0 <= t < t1:
            lines = wrap_cn(text)
            f = font(26)
            lh = 38
            pad_x, pad_y = 26, 15
            widths = []
            for ln in lines:
                lb = f.getbbox(ln)
                widths.append(lb[2] - lb[0])
            bw = max(widths) + pad_x * 2
            bh = len(lines) * lh + pad_y * 2 - 10
            x0 = (W - bw) // 2
            y0 = H - 48 - bh
            overlay = Image.new('RGBA', (W, H), (0, 0, 0, 0))
            od = ImageDraw.Draw(overlay)
            od.rounded_rectangle([x0, y0, x0 + bw, y0 + bh], radius=10, fill=(4, 14, 24, 176))
            im.paste(overlay, (0, 0), overlay)
            d = ImageDraw.Draw(im, 'RGBA')
            for i, ln in enumerate(lines):
                d.text((W // 2, y0 + pad_y + i * lh), ln, font=f, fill=FOG, anchor='mt')
            return


def draw_hud(im, idx, t, shots, duration, hud):
    if not hud.get('chapter', True) and not hud.get('progress', True):
        return
    d = ImageDraw.Draw(im, 'RGBA')
    if hud.get('chapter', True):
        label = shots[idx].get('label', '')
        d.text((44, 34), f'{idx + 1:02d}', font=mono(14), fill=(*CYAN, 130))
        if label:
            d.text((76, 33), f'/ {len(shots):02d}   {label}', font=font(14), fill=(*FOG, 120))
    if hud.get('progress', True):
        y = H - 16
        d.line([(44, y), (W - 44, y)], fill=(*CYAN, 55), width=2)
        prog = 44 + int((W - 88) * clamp(t / max(1e-6, duration)))
        d.line([(44, y), (prog, y)], fill=(*CYAN, 210), width=3)
        d.ellipse([prog - 3, y - 3, prog + 3, y + 3], fill=(*AMBER, 235))


# ============================================================
# 后处理
# ============================================================
def post(im, n, t, duration, fade):
    arr = np.asarray(im, dtype=np.float32)
    if VIGNETTE is not None:
        arr = arr * VIGNETTE
    if GRAIN:
        arr = arr + GRAIN[n % len(GRAIN)]
    f_in = float(fade.get('in', 0.7) or 0)
    f_out = float(fade.get('out', 0.9) or 0)
    alpha = 1.0
    if f_in > 0 and t < f_in:
        alpha = clamp(t / f_in)
    if f_out > 0 and t > duration - f_out:
        alpha = min(alpha, clamp((duration - t) / f_out))
    if alpha < 1.0:
        arr = arr * (alpha ** 0.9)
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))


# ============================================================
# 载入场景层
# ============================================================
def load_scenes(project):
    """导入项目的 scenes.py，并返回 SHOT_FN"""
    path = project.root / project.scenes_rel
    if not path.exists():
        raise SystemExit(f'缺少场景文件：{path}')
    # 关键：以脚本方式运行时本模块名是 __main__，
    # 场景层的 `from engine import *` 会再加载一份独立副本，
    # 导致字体、画幅、色板全部对不上。这里强制指向同一个模块对象。
    sys.modules['engine'] = sys.modules[__name__]
    spec = importlib.util.spec_from_file_location('project_scenes', path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules['project_scenes'] = mod
    spec.loader.exec_module(mod)
    fns = getattr(mod, 'SHOT_FN', None)
    if not fns:
        raise SystemExit(f'{path} 里没有定义 SHOT_FN 列表')
    if len(fns) < len(project.shots):
        raise SystemExit(
            f'镜头表有 {len(project.shots)} 镜，但 scenes.py 只提供了 {len(fns)} 个函数')
    return fns


def apply_palette(cfg):
    """按项目色板覆盖模块级颜色（必须在导入 scenes 之前调用）"""
    global BG, DEEP_SEA, CYAN, AMBER, CORAL, FOG
    pal = cfg.get('palette') or {}

    def hx(s, default):
        if not s:
            return default
        s = s.lstrip('#')
        return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))

    BG = hx(pal.get('bg'), BG)
    DEEP_SEA = hx(pal.get('deep'), DEEP_SEA)
    CYAN = hx(pal.get('cyan'), CYAN)
    AMBER = hx(pal.get('amber'), AMBER)
    CORAL = hx(pal.get('coral'), CORAL)
    FOG = hx(pal.get('fog'), FOG)


# ============================================================
# 渲染
# ============================================================
def shot_index(shots, t):
    for i, s in enumerate(shots):
        if s['start'] <= t < s['end']:
            return i
    return len(shots) - 1


def make_renderer(project, shot_fns):
    fps = project.fps
    shots = project.shots
    subs = project.subs
    dur = project.duration
    hud = project.hud
    fade = project.fade

    def render_frame(n):
        t = n / fps
        idx = shot_index(shots, t)
        s = shots[idx]
        p = clamp((t - s['start']) / max(1e-6, s['end'] - s['start']))
        im = shot_fns[idx](p, t)
        if im.size != (W, H):
            im = im.resize((W, H), Image.Resampling.BILINEAR)
        if im.mode != 'RGB':
            im = im.convert('RGB')
        draw_subtitle(im, t, subs)
        draw_hud(im, idx, t, shots, dur, hud)
        return post(im, n, t, dur, fade)

    return render_frame


def probe(project):
    info = resolve_fonts()
    print('字体：')
    print(f'  正文 {info["regular"][0]} (index {info["regular"][1]})')
    print(f'  粗体 {info["bold"][0]} (index {info["bold"][1]})')
    print(f'  数字 {info["mono"][0]} (index {info["mono"][1]})')
    print(f'画幅：{W}x{H} @ {project.fps}fps  时长 {project.duration}s '
          f'= {int(round(project.duration * project.fps))} 帧')
    print(f'镜头：{len(project.shots)} 个  字幕：{len(project.subs)} 条')
    print('资产：')
    for key, rel in project.assets.items():
        p = project.root / rel
        mark = '✓' if p.exists() else '✗ 缺失（将降级为程序化背景）'
        print(f'  {key:<6} {mark}  {rel}')
    if not project.assets:
        print('  （未配置资产，全部镜头使用程序化背景）')
    audio = project.root / project.audio_rel if project.audio_rel else None
    if audio:
        print(f'配音：{"✓" if audio.exists() else "✗ 缺失"}  {project.audio_rel}')
    else:
        print('配音：未指定（将输出无声视频）')
    print(f'输出：{project.root / project.out_rel}')
    problems = project.validate()
    if problems:
        print('\n配置问题：')
        for x in problems:
            print('  ✗ ' + x)
    else:
        print('\n配置校验：通过')
    return not problems


def main(argv=None):
    ap = argparse.ArgumentParser(description='科普片导演 · 逐帧合成引擎')
    ap.add_argument('project', help='项目目录，例如 projects/示例')
    ap.add_argument('--limit', type=int, default=0, help='只渲染前 N 帧（快速自检）')
    ap.add_argument('--preview', type=int, default=0, help='每镜取一帧存 PNG，不做编码')
    ap.add_argument('--probe', action='store_true', help='只检查配置、字体与资产')
    ap.add_argument('--crf', type=int, default=18, help='x264 CRF，默认 18')
    ap.add_argument('--out', default='', help='覆盖输出路径')
    args = ap.parse_args(argv)

    project = Project(args.project)
    # 先定画幅与色板，再导入场景层
    global W, H, FPS, DUR
    W = int(project.cfg.get('width', W))
    H = int(project.cfg.get('height', H))
    FPS = project.fps
    DUR = project.duration
    apply_palette(project.cfg)
    resolve_fonts()
    build_luts()

    if args.probe:
        return 0 if probe(project) else 1

    # 资产
    A.clear()
    ASSET_PATHS.clear()
    for key, rel in project.assets.items():
        p = project.root / rel
        ASSET_PATHS[key] = str(p)
        A[key] = load_native(p)

    shot_fns = load_scenes(project)
    render_frame = make_renderer(project, shot_fns)

    total = int(round(project.duration * project.fps))
    if args.limit:
        total = min(total, args.limit)

    out_path = Path(args.out) if args.out else (project.root / project.out_rel)

    # ---- 预检模式：只出 PNG ----
    if args.preview:
        dst = project.root / 'qc' / 'preview'
        dst.mkdir(parents=True, exist_ok=True)
        made = []
        for i, s in enumerate(project.shots):
            t = s['start'] + (s['end'] - s['start']) * 0.6
            n = int(t * project.fps)
            if n >= total:
                continue
            f = dst / f'{i + 1:02d}_{s.get("label", "shot")}.png'
            render_frame(n).save(f)
            made.append(f.name)
        print(f'已输出 {len(made)} 张预览帧到 {dst}')
        for x in made:
            print('  ' + x)
        return 0

    if imageio_ffmpeg is None:
        raise SystemExit('缺少 imageio-ffmpeg，请先运行：python3 -m pip install imageio-ffmpeg')
    ff = imageio_ffmpeg.get_ffmpeg_exe()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    silent = out_path.with_name(out_path.stem + '_silent.mp4')

    print('=' * 60)
    print(f'科普片导演 · 渲染 {project.root.name}')
    print(f'  {W}x{H} @ {project.fps}fps  {project.duration}s  =  {total} 帧')
    print('=' * 60)

    log_path = out_path.with_name('encode.log')
    log = open(log_path, 'wb')
    cmd = [
        ff, '-y',
        '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(project.fps),
        '-i', '-', '-an',
        '-c:v', 'libx264', '-preset', 'medium', '-crf', str(args.crf),
        '-pix_fmt', 'yuv420p', '-r', str(project.fps),
        '-movflags', '+faststart', str(silent),
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                            stdout=subprocess.DEVNULL, stderr=log)
    t0 = time.time()
    try:
        for n in range(total):
            proc.stdin.write(render_frame(n).tobytes())
            if n % 150 == 0:
                el = time.time() - t0
                fps_now = (n + 1) / max(1e-6, el)
                eta = (total - n - 1) / max(1e-6, fps_now)
                print(f'  {n:4d}/{total}  {fps_now:5.1f} fps  剩余 {eta:5.0f}s')
            if proc.poll() is not None:
                raise RuntimeError(f'ffmpeg 提前退出，见 {log_path}')
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()
        log.close()
    if proc.returncode not in (0, None):
        raise RuntimeError(f'ffmpeg 失败（{proc.returncode}），见 {log_path}')

    audio = (project.root / project.audio_rel) if project.audio_rel else None
    if audio and audio.exists():
        print('[混音] 合成配音...')
        subprocess.run([
            ff, '-y', '-i', str(silent), '-i', str(audio),
            '-map', '0:v:0', '-map', '1:a:0',
            '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k',
            '-shortest', str(out_path),
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        silent.unlink(missing_ok=True)
    else:
        silent.replace(out_path)

    size = out_path.stat().st_size / 1024 / 1024
    print(f'\n✓ 成片：{out_path}')
    print(f'  {size:.1f} MB   耗时 {time.time() - t0:.0f}s')
    return 0


if __name__ == '__main__':
    sys.exit(main())
