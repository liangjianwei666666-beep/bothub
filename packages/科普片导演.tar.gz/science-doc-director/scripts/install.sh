#!/bin/bash
# 科普片导演 · 一键装配脚本
#
# 用法：bash install.sh [工作目录]      默认 ~/science-doc
# 作用：装入渲染引擎与质检脚本、建项目骨架、检查依赖。可重复执行，不覆盖已有内容。
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${1:-$HOME/science-doc}"

echo "=========================================="
echo "  科普片导演 · 环境装配"
echo "=========================================="
echo "  技能目录：$SKILL_DIR"
echo "  工作目录：$WORK"
echo ""

mkdir -p "$WORK"
cd "$WORK"

# ---------- 1) 装入引擎 ----------
mkdir -p "$WORK/.engine"
cp -R "$SKILL_DIR/scripts/." "$WORK/.engine/"
rm -f "$WORK/.engine/install.sh"
echo "[1/5] ✓ 渲染引擎已装入（engine.py / qc.py）"

# ---------- 2) 建示例项目 ----------
if [ ! -d "$WORK/projects/台风示例" ]; then
  mkdir -p "$WORK/projects/台风示例"
  cp -R "$SKILL_DIR/examples/." "$WORK/projects/台风示例/"
  rm -rf "$WORK/projects/台风示例/out" "$WORK/projects/台风示例/qc"
  echo "[2/5] ✓ 生成示例项目 projects/台风示例（含 7 张演示资产与配音）"
else
  echo "[2/5] · 示例项目已存在，保留不动"
fi

# ---------- 3) 新项目模板 ----------
if [ ! -d "$WORK/projects/_模板" ]; then
  mkdir -p "$WORK/projects/_模板/assets"
  cp "$SKILL_DIR/templates/project.example.json" "$WORK/projects/_模板/project.json"
  cp "$SKILL_DIR/templates/scenes.example.py"    "$WORK/projects/_模板/scenes.py"
  if [ -d "$SKILL_DIR/templates/assets" ]; then
    cp -R "$SKILL_DIR/templates/assets/." "$WORK/projects/_模板/assets/"
  fi
  echo "[3/5] ✓ 生成新项目模板 projects/_模板"
else
  echo "[3/5] · 项目模板已存在，保留不动"
fi

# ---------- 4) 说明文件 ----------
cat > "$WORK/怎么用.md" <<'EOF'
# 科普片导演 · 工作目录

## 两个命令
```bash
python3 .engine/engine.py projects/<项目名>            # 渲染成片
python3 .engine/qc.py    projects/<项目名>            # 量化质检
```

## 自检（不渲染）
```bash
python3 .engine/engine.py projects/<项目名> --probe     # 查字体、资产、镜头连续性
python3 .engine/engine.py projects/<项目名> --preview 1 # 每镜出一张预览图
python3 .engine/engine.py projects/<项目名> --limit 60  # 只渲前 60 帧试跑
```

## 新建一个片子
```bash
cp -R projects/_模板 projects/我的新片
# 改 project.json（镜头表、字幕、时长）和 scenes.py（每镜画什么）
# 把 AI 生成的云/海/风场图放进 projects/我的新片/assets/
```

## 目录说明
- `project.json` 画幅、时长、色板、镜头表、字幕、资产、配音路径
- `scenes.py`    场景层：`def shotNN(p, t) -> Image`，每镜一个函数
- `assets/`      AI 静帧。缺图不会崩，会自动降级为程序化背景
- `audio/`       配音。没放就是无声片
- `out/`         成片
- `qc/`          质检指标、联系表、预览帧
EOF
echo "[4/5] ✓ 写入 怎么用.md"

# ---------- 5) 依赖检查 ----------
echo "[5/5] 检查依赖"
PY="$(command -v python3 || true)"
if [ -z "$PY" ]; then
  echo "      ✗ 找不到 python3，请先安装 Python 3.9+"
  exit 1
fi
echo "      ✓ python3: $($PY -V 2>&1)"

if ! $PY - <<'PYEOF'
import importlib, sys
need = {"PIL": "pillow", "numpy": "numpy"}
missing = []
for mod, pkg in need.items():
    try:
        importlib.import_module(mod)
        print(f"      ✓ {pkg}")
    except ImportError:
        print(f"      ✗ {pkg} 未安装")
        missing.append(pkg)
try:
    import imageio_ffmpeg
    print("      ✓ imageio-ffmpeg")
except ImportError:
    print("      ✗ imageio-ffmpeg 未安装")
    missing.append("imageio-ffmpeg")
if missing:
    print("")
    print("      缺依赖，请运行：")
    print(f"        {sys.executable} -m pip install " + " ".join(missing))
    sys.exit(1)
PYEOF
then
  echo ""
  echo "依赖不全，装完依赖后再跑一次本脚本即可（已装入的内容不会重复）。"
  exit 2
fi

# 字体检查
$PY - "$WORK" <<'PYEOF'
import sys
from pathlib import Path
work = Path(sys.argv[1])
sys.path.insert(0, str(work / '.engine'))
import engine
try:
    info = engine.resolve_fonts()
    print(f"      ✓ 中文字体：{info['regular'][0]}")
except RuntimeError as e:
    print("      ✗ " + str(e).split("\n")[0])
    print("        装好中文字体后再跑本脚本。")
    sys.exit(1)
PYEOF

echo ""
echo "=========================================="
echo "  装配完成 ✓"
echo "=========================================="
echo ""
echo "先跑自检："
echo "  cd $WORK && python3 .engine/engine.py projects/台风示例 --probe"
echo ""
echo "出片："
echo "  cd $WORK && python3 .engine/engine.py projects/台风示例"
echo ""
echo "要接 AI 生图，准备好生图网关 Key，把云/海/风场静帧生成到"
echo "  $WORK/projects/<项目名>/assets/"
echo "然后在 project.json 的 assets 里登记文件名。"
