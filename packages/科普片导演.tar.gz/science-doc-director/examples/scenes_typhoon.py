"""
示例项目：台风是如何形成的（16 镜纪录片版）
这是「场景层」——每个科普项目只需要改这个文件。
引擎负责运镜、调色、字幕、编码；这里只负责「每一镜画什么」。

接口：def shotNN(p, t) -> PIL.Image
  p: 该镜头内的进度 0..1
  t: 全片时间（秒），用于需要跨镜连续的动画
"""
from engine import *

def shot01(p, t):
    """01 暖海洋远景：极慢推近，暖金光带从海面升起，标题入场"""
    im = cam(A['A01'], lerp(1.00, 1.07, ease_out(p * 0.9)),
             0.5, lerp(0.56, 0.46, ease_out(p)))
    d = ImageDraw.Draw(im, 'RGBA')

    # 暖金光带（能量来源）
    rise = ease_out(clamp(p * 1.5))
    top_y = int(H - 250 * rise)
    band = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(band)
    span = max(1, H - top_y)
    for y in range(top_y, H, 2):
        a = int(74 * (1 - (y - top_y) / span) ** 1.4)
        bd.rectangle([(0, y), (W, y + 2)], fill=(*AMBER, a))
    blur_paste(im, band, 30)

    # 标题组
    a_in = int(255 * ease_out(clamp(p / 0.42)))
    d.text((94, 206), 'HOW A TYPHOON FORMS', font=mono(15), fill=(*AMBER, int(a_in * 0.85)))
    d.text((92, 228), '台风是如何形成的', font=font(48, True), fill=(*FOG, a_in))
    d.line([(94, 302), (474, 302)], fill=(*CYAN, int(a_in * 0.5)), width=1)
    d.text((94, 314), '海洋  ·  水汽  ·  凝结  ·  旋转',
           font=font(17), fill=(*FOG, int(a_in * 0.62)))
    return im


def shot02(p, t):
    """02 海洋剖面：垂直下潜后停住，暖水层厚度与温度标注"""
    im = cam(A['A02'], lerp(1.16, 1.05, ease_in_out(p)),
             0.5, lerp(0.64, 0.40, ease_in_out(p)))
    d = ImageDraw.Draw(im, 'RGBA')
    a = ease_out(clamp((p - 0.15) / 0.5))

    # 热量上升柱
    col = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    cd = ImageDraw.Draw(col)
    y_bot = H - 60
    top = int(lerp(y_bot, 120, ease_out(p)))
    if top < y_bot - 2:
        cd.rectangle([(W // 2 - 16, top), (W // 2 + 16, y_bot)], fill=(*AMBER, int(58 * a)))
        blur_paste(im, col, 22)

    # 暖水层深度标尺
    if a > 0.05:
        x = 232
        y0, y1 = int(H * 0.52), int(H * 0.88)
        cx = int(lerp(x, x, 1))
        d.line([(cx, y0), (cx, y1)], fill=(*AMBER, int(200 * a)), width=2)
        for yy in (y0, y1):
            d.line([(cx - 9, yy), (cx + 9, yy)], fill=(*AMBER, int(220 * a)), width=2)
        tag(d, cx + 20, (y0 + y1) // 2 - 16, '暖水层', 24, (*AMBER, int(255 * a)), True, 'lm', plate_a=int(140 * a))
        tag(d, cx + 20, (y0 + y1) // 2 + 18, '有一定深度', 17, (*FOG, int(200 * a)), False, 'lm', plate_a=int(140 * a))

    if p > 0.42:
        a2 = ease_out(clamp((p - 0.42) / 0.4))
        arrow(d, (W // 2, H - 96), (W // 2, int(lerp(H - 96, 150, a2))),
              AMBER, width=4, head=15, alpha=int(230 * a2))
        tag(d, W // 2 + 26, 176, '热量与水汽向上', 18, (*FOG, int(230 * a2)), False, 'lm',
            plate_a=int(140 * a2))
        tag(d, W - 60, H - 140, '海表温度 ≥ 26.5°C', 18, (*AMBER, int(240 * a2)), False, 'rm',
            plate_a=int(150 * a2))
    return im


def shot03(p, t):
    """03 初始扰动：水汽粒子脱离海面，低压扰动圈出现"""
    im = cam(A['A03'], lerp(1.02, 1.09, ease_in_out(p)), 0.5, lerp(0.55, 0.48, p))
    d = ImageDraw.Draw(im, 'RGBA')

    # 上升水汽粒子
    for (px, ph, spd, rad, ak) in PARTICLES:
        y = ((ph * (H + 60) - t * spd) % (H + 60)) - 30
        x = px + math.sin(t * 0.7 + ph * 6.28) * 12
        a = int(170 * ak * clamp((y + 30) / 220))
        if a <= 4:
            continue
        d.ellipse([x - rad, y - rad, x + rad, y + rad], fill=(*CYAN, a))

    # 扰动圈
    if p > 0.42:
        a = ease_out(clamp((p - 0.42) / 0.45))
        cx, cy = W // 2, int(H * 0.42)
        r = int(40 + 110 * a)
        for k, al in ((1.0, 190), (0.72, 120), (0.46, 80)):
            rr = int(r * k)
            d.ellipse([cx - rr, cy - rr * 0.62, cx + rr, cy + rr * 0.62],
                      outline=(*CYAN, int(al * a)), width=2)
        tag(d, cx, cy + int(r * 0.62) + 26, '低气压扰动', 19, (*CYAN, int(240 * a)), False, 'mm',
            plate_a=int(150 * a))
    return im


def shot04(p, t):
    """04 水汽上升：柱状流线进入云底"""
    im = cam(A['A03'], lerp(1.06, 1.14, ease_in_out(p)), 0.5, lerp(0.52, 0.44, p))
    d = ImageDraw.Draw(im, 'RGBA')

    for i, bx in enumerate((W // 2 - 190, W // 2, W // 2 + 190)):
        ph = i * 0.18
        prog = ease_in_out(clamp((p - ph) / 0.7))
        if prog <= 0:
            continue
        y_bot = H - 40
        y_top = int(lerp(y_bot, 96, prog))
        # 虚线式流线
        seg = 26
        y = y_bot
        while y > y_top:
            y2 = max(y_top, y - seg * 2)
            d.line([(bx, y), (bx, y2)], fill=(*CYAN, 150), width=3)
            y -= seg * 2 + 14
        arrow(d, (bx, y_top + 46), (bx, y_top), CYAN, width=3, head=13, alpha=230)

    if p > 0.35:
        a = ease_out(clamp((p - 0.35) / 0.4))
        tag(d, W // 2, 120, '暖湿空气持续上升', 20, (*FOG, int(235 * a)), False, 'mm',
            plate_a=int(150 * a))
    return im


def shot05(p, t):
    """05 凝结放热：云内水滴凝结，暖金凝结环脉冲"""
    im = cam(A['A04'], lerp(1.10, 1.04, ease_in_out(p)), 0.5, 0.5)
    d = ImageDraw.Draw(im, 'RGBA')

    cx, cy = W // 2, int(H * 0.46)
    pulse = 0.5 + 0.5 * math.sin(t * 3.4)
    r = int(90 + 34 * pulse)
    g, sc = glow_ring(cx, cy, r, int(r * 0.78), AMBER, 20, 130)
    paste_scaled(im, g, sc, 20)

    # 水滴凝结
    rng = random.Random(21)
    for i in range(30):
        ang = rng.uniform(0, math.tau)
        rr = rng.uniform(0.35, 1.25) * r
        a = int(200 * clamp((p - 0.1) / 0.5)) * (1 if (i + int(t * 2)) % 3 else 0)
        if a <= 8:
            continue
        x = cx + math.cos(ang) * rr
        y = cy + math.sin(ang) * rr * 0.8
        s = rng.uniform(1.4, 3.0)
        d.ellipse([x - s, y - s, x + s, y + s], fill=(*AMBER, a // 2))

    if p > 0.3:
        a = ease_out(clamp((p - 0.3) / 0.4))
        tag(d, W // 2, 118, '水汽凝结成云滴', 20, (*FOG, int(235 * a)), False, 'mm', plate_a=int(150 * a))
        tag(d, cx, cy + r + 40, '潜热释放', 22, (*AMBER, int(245 * a)), True, 'mm', plate_a=int(140 * a))
    return im


def shot06(p, t):
    """06 反馈闭环：上升—凝结—放热—继续上升"""
    im = cam(A['A04'], lerp(1.12, 1.06, ease_in_out(p)), lerp(0.46, 0.54, p), 0.5)
    d = ImageDraw.Draw(im, 'RGBA')

    cx, cy = W // 2, int(H * 0.45)
    rx, ry = 210, 118
    a_all = ease_out(clamp(p / 0.35))
    for i in range(4):
        base = i * math.pi / 2 + t * 0.55
        pts = []
        for s in range(24):
            ang = base + s / 23 * (math.pi / 2) * 0.86
            pts.append((cx + math.cos(ang) * rx, cy + math.sin(ang) * ry))
        if len(pts) > 1:
            d.line(pts, fill=(*AMBER, int(215 * a_all)), width=4, joint='curve')
        # 箭头
        tip = pts[-1]
        prev = pts[-3]
        arrow(d, prev, tip, AMBER, width=1, head=15, alpha=int(235 * a_all))

    tag(d, cx, cy, '上升', 20, (*FOG, int(240 * a_all)), True, 'mm', plate=False)
    if p > 0.5:
        a = ease_out(clamp((p - 0.5) / 0.35))
        tag(d, W // 2, H - 168, '凝结 → 放热 → 继续上升', 20, (*AMBER, int(245 * a)), False, 'mm',
            plate_a=int(155 * a))
    return im


def shot07(p, t):
    """07 低压增强：云塔长高，底部气压区变暗"""
    im = cam(A['A03'], lerp(1.03, 1.11, ease_in_out(p)), 0.5, lerp(0.60, 0.46, p))
    d = ImageDraw.Draw(im, 'RGBA')

    # 真空吸积：底部气压阴影
    a = ease_in_out(p)
    shade = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shade)
    h = int(240 * (0.4 + 0.6 * a))
    for y in range(H - h, H):
        al = int(120 * a * (y - (H - h)) / max(1, h))
        sd.rectangle([(0, y), (W, y + 2)], fill=(4, 12, 20, al))
    blur_paste(im, shade, 18)

    # 云塔轮廓：随 p 向上生长
    if p > 0.15:
        ga = ease_out(clamp((p - 0.15) / 0.6))
        col = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        cd = ImageDraw.Draw(col)
        top = int(lerp(H - 150, 90, ga))
        w0 = 150 + 60 * ga
        for k in range(8):
            yy = top + k * (H - 60 - top) / 8
            ww = w0 * (1 - 0.35 * k / 8)
            cd.ellipse([W // 2 - ww, yy - 34, W // 2 + ww, yy + 34],
                       fill=(*CYAN, int(26 + 12 * math.sin(t * 2 + k))))
        blur_paste(im, col, 26)

    tag(d, W // 2, H - 76, '中心气压持续降低', 20, (*CYAN, 240), False, 'mm', plate_a=155)
    if p > 0.55:
        a2 = ease_out(clamp((p - 0.55) / 0.35))
        tag(d, 150, 150, '云塔升高', 17, (*FOG, int(215 * a2)), False, 'lm', plate_a=int(140 * a2))
    return im


def shot08(p, t):
    """08 气流偏转：直线流入的气流在中心附近弯曲"""
    im = soft_bg('A05', lerp(1.20, 1.10, ease_in_out(p)), 0.5, 0.5, k=0.46, blur=6)
    d = ImageDraw.Draw(im, 'RGBA')

    cx, cy = W // 2, H // 2
    bend_amt = ease_in_out(clamp(p / 0.85))
    for i in range(12):
        ang0 = i / 12 * math.tau
        pts = []
        for s in range(26):
            f = s / 25
            r = 470 * (1 - f) + 60
            ang = ang0 + bend_amt * f * 1.15
            pts.append((cx + math.cos(ang) * r, cy + math.sin(ang) * r * 0.62))
        if len(pts) > 2:
            d.line(pts, fill=(*CYAN, 165), width=3, joint='curve')
            arrow(d, pts[-6], pts[-1], CYAN, width=1, head=14, alpha=235)

    tag(d, cx, cy, '偏转', 24, (*FOG, 245), True, 'mm', plate=True, plate_a=170)
    if p > 0.4:
        a = ease_out(clamp((p - 0.4) / 0.4))
        tag(d, W // 2, 112, '地球自转使流入气流发生偏转', 20, (*FOG, int(240 * a)), False, 'mm',
            plate_a=int(155 * a))
    return im


def shot09(p, t):
    """09 旋转闭合：弯曲流线闭合成螺旋，中心形成风眼"""
    im = cam(A['A05'], lerp(1.14, 1.05, ease_in_out(p)), 0.5, 0.5)
    d = ImageDraw.Draw(im, 'RGBA')

    cx, cy = W // 2, H // 2
    close = ease_in_out(clamp(p / 0.8))
    for k in range(5):
        pts = []
        for s in range(56):
            f = s / 55
            th = -k * math.tau / 5 + f * math.tau * 1.15 + t * 0.5
            r = 40 + f * 380 * close
            pts.append((cx + math.cos(th) * r, cy + math.sin(th) * r * 0.66))
        if len(pts) > 2:
            d.line(pts, fill=(*CYAN, int(70 + 110 * close)), width=3, joint='curve')

    # 风眼
    if p > 0.5:
        a = ease_out(clamp((p - 0.5) / 0.35))
        r = int(44 + 6 * math.sin(t * 2))
        d.ellipse([cx - r, cy - int(r * 0.78), cx + r, cy + int(r * 0.78)],
                  outline=(*FOG, int(225 * a)), width=2)
        d.ellipse([cx - r + 8, cy - int(r * 0.78) + 8, cx + r - 8, cy + int(r * 0.78) - 8],
                  outline=(*FOG, int(90 * a)), width=1)
        tag(d, cx, cy + int(r * 0.78) + 34, '风眼', 18, (*FOG, int(235 * a)), False, 'mm',
            plate_a=int(150 * a))
    if p > 0.66:
        a = ease_out(clamp((p - 0.66) / 0.3))
        tag(d, cx, 104, '旋转结构形成', 20, (*CYAN, int(240 * a)), False, 'mm', plate_a=int(155 * a))
    return im


def shot10(p, t):
    """10 风切变对比：左侧结构保持，右侧被高空风拉扯（对称分屏）"""
    src = A['A06']
    hw = W // 2
    left = cam(src, 1.25, 0.22, 0.5)
    right = cam(src, 1.25, 0.78, 0.5)

    im = Image.new('RGB', (W, H))
    im.paste(left.crop((0, 0, hw, H)), (0, 0))
    im.paste(right.crop((hw, 0, W, H)), (hw, 0))
    d = ImageDraw.Draw(im, 'RGBA')

    # 分屏线
    d.line([(hw, 0), (hw, H)], fill=(*FOG, 70), width=1)

    a = ease_in_out(clamp(p / 0.7))

    # 右侧：云层染成暗珊瑚，明确「破坏」语义
    im = coral_tint(im, hw + 20, W, amount=0.42 * a, feather=200)
    coral_wash(im, hw, W, strength=int(120 * a), feather=360)
    d = ImageDraw.Draw(im, 'RGBA')

    # 右侧：高空横向拉扯流线（加粗加不透明，保证可读）
    for i in range(7):
        y = 140 + i * 54
        x0 = hw + 24 + int(30 * math.sin(i))
        x1 = W - 30
        d.line([(x0, y), (x1, y - int(26 * a))], fill=(*CORAL, int(225 * a)), width=3)
    if a > 0.2:
        arrow(d, (W - 132, 420), (W - 40, 410), CORAL, width=4, head=16, alpha=int(240 * a))

    # 左侧：冷青虚线，表示结构稳定
    for i in range(5):
        y = 170 + i * 60
        d.line([(60, y), (hw - 60, y)], fill=(*CYAN, int(120 * a)), width=2)

    tag(d, 100, H - 128, '弱风切变', 25, (*CYAN, 245), True, 'lm', plate_a=165)
    tag(d, 100, H - 96, '雷雨云保持组织', 18, (*FOG, 215), False, 'lm', plate_a=150)
    tag(d, hw + 96, H - 128, '强风切变', 25, (*CORAL, 245), True, 'lm', plate_a=165)
    tag(d, hw + 96, H - 96, '雷雨云被拉扯吹散', 18, (*FOG, 215), False, 'lm', plate_a=150)

    if p > 0.5:
        a2 = ease_out(clamp((p - 0.5) / 0.4))
        tag(d, W // 2, 60, '高空风向与风速差异', 18, (*FOG, int(225 * a2)), False, 'mm',
            plate_a=int(150 * a2))
    return im


def shot11(p, t):
    """11 云团被吹散：强侧云墙撕开，冷青结构变成暗珊瑚碎片"""
    im = cam(A['A06'], lerp(1.18, 1.10, ease_in_out(p)), 0.72, 0.5)
    d = ImageDraw.Draw(im, 'RGBA')

    a = ease_out(clamp((p - 0.08) / 0.60))
    # 一次性加速的撕裂动作：第 8% 起手，60% 内完成，后段保持
    rng = random.Random(33)
    for i in range(64):
        sx = rng.uniform(0.36, 1.0) * W
        sy = rng.uniform(0.08, 0.92) * H
        drift = ease_out(clamp(p * 1.4)) * rng.uniform(60, 190)
        x = sx + drift * rng.uniform(0.7, 1.3)
        y = sy - drift * 0.22 * rng.uniform(0.5, 1.4)
        if x > W + 20:
            continue
        s = rng.uniform(3.0, 9.5)
        alpha = int(rng.uniform(150, 240) * a)
        d.ellipse([x - s, y - s * 0.7, x + s, y + s * 0.7], fill=(*CORAL, alpha))

    # 冷青结构残线
    for i in range(5):
        y0 = 200 + i * 62
        d.line([(W - 320, y0), (W - 80 + int(40 * a), y0 + int(30 * a))],
               fill=(*CYAN, int(80 * (1 - a))), width=2)

    # 撕裂区珊瑚薄雾
    if a > 0.02:
        im = coral_tint(im, int(W * 0.34), W, amount=0.42 * a, feather=200)
        coral_wash(im, int(W * 0.34), W, strength=int(110 * a), feather=300)
        d = ImageDraw.Draw(im, 'RGBA')

    # 撕裂裂口：从左上到右下的珊瑚色断带
    if a > 0.1:
        pts = []
        for k in range(16):
            f = k / 15
            pts.append((lerp(W * 0.40, W * 0.94, f),
                        lerp(H * 0.30, H * 0.72, f) + math.sin(f * 7) * 26))
        d.line(pts, fill=(*CORAL, int(215 * a)), width=4, joint='curve')
        d.line([(x, y + 9) for x, y in pts], fill=(*CORAL, int(120 * a)), width=2, joint='curve')

    tag(d, W - 70, 96, '结构被破坏', 22, (*CORAL, int(250 * a if a > 0.15 else 0)), True, 'rm',
        plate_a=int(160 * max(a, 0.2)))
    return im


def shot12(p, t):
    """12 条件汇聚：低压、雷雨、旋转、水汽四条路径汇入中心"""
    im = cam(A['A05'], lerp(1.02, 1.10, ease_in_out(p)), 0.5, 0.5)
    d = ImageDraw.Draw(im, 'RGBA')

    cx, cy = W // 2, H // 2
    paths = [('低气压', -0.72, 0.55), ('雷雨', 0.62, 0.62), ('旋转', 0.90, -0.30), ('水汽', -0.62, -0.42)]
    for i, (label, ux, uy) in enumerate(paths):
        f = clamp((p - i * 0.16) / 0.5)
        if f <= 0:
            continue
        sx, sy = cx + ux * 560, cy + uy * 300
        ex, ey = cx + ux * 120, cy + uy * 78
        x = lerp(sx, ex, ease_in_out(f))
        y = lerp(sy, ey, ease_in_out(f))
        # 弯曲路径
        pts = []
        for s in range(20):
            fs = s / 19
            pts.append((lerp(sx, x, fs) + math.sin(fs * 3.1) * ux * 30,
                        lerp(sy, y, fs) + math.cos(fs * 3.1) * uy * 22))
        d.line(pts, fill=(*AMBER, int(200 * clamp(f * 2))), width=3, joint='curve')
        if f > 0.25:
            arrow(d, pts[-4], pts[-1], AMBER, width=1, head=13, alpha=225)
        tag(d, sx + ux * 26, sy + uy * 22, label, 19, (*FOG, 235), False, 'mm', plate_a=155)
    return im


def shot13(p, t):
    """13 逐步增强：扰动 → 低气压 → 热带风暴 → 台风"""
    im = soft_bg('A05', lerp(1.12, 1.05, ease_in_out(p)), 0.5, 0.46, k=0.42, blur=16, lift_k=0.8)
    d = ImageDraw.Draw(im, 'RGBA')

    stages = ['扰动', '热带低压', '热带风暴', '台风']
    y = int(H * 0.46)
    xs = [300, 540, 780, 1020]
    active = ease_in_out(clamp(p / 0.75)) * 4

    # 连线
    d.line([(xs[0], y), (xs[-1], y)], fill=(*CYAN, 70), width=2)
    passed = clamp(active / 3)
    d.line([(xs[0], y), (lerp(xs[0], xs[-1], passed), y)], fill=(*AMBER, 215), width=3)

    for i, (x, name) in enumerate(zip(xs, stages)):
        on = active >= i - 0.15
        r = 52 if on else 44
        if on:
            g, sc = glow_ring(x, y, r, r, AMBER, 16, 90)
            paste_scaled(im, g, sc, 16)
        d.ellipse([x - r, y - r, x + r, y + r],
                  outline=(*AMBER, 240) if on else (*CYAN, 90), width=3 if on else 2)
        d.text((x, y), f'0{i + 1}', font=mono(20),
               fill=(*AMBER, 235) if on else (*CYAN, 110), anchor='mm')
        tag(d, x, y + r + 32, name, 20, (*FOG, 240) if on else (*FOG, 120), on, 'mm', plate=False)

    tag(d, W // 2, 96, '系统逐步增强', 24, (*FOG, 245), True, 'mm', plate_a=160)
    return im


def shot14(p, t):
    """14 台风成熟：俯视结构完整，缓慢拉远"""
    im = cam(A['A05'], lerp(1.16, 1.02, ease_in_out(p)), 0.5, 0.5)
    d = ImageDraw.Draw(im, 'RGBA')

    cx, cy = W // 2, H // 2
    a = ease_out(clamp(p / 0.4))

    # 风眼
    r = 46
    d.ellipse([cx - r, cy - int(r * 0.8), cx + r, cy + int(r * 0.8)],
              outline=(*FOG, int(230 * a)), width=2)

    # 标注引线
    if p > 0.3:
        a2 = ease_out(clamp((p - 0.3) / 0.35))
        d.line([(cx + 60, cy - 50), (cx + 250, cy - 128)], fill=(*FOG, int(170 * a2)), width=1)
        tag(d, cx + 258, cy - 136, '风眼', 19, (*FOG, int(240 * a2)), False, 'lm', plate_a=int(150 * a2))
        d.line([(cx - 150, cy + 150), (cx - 330, cy + 206)], fill=(*FOG, int(170 * a2)), width=1)
        tag(d, cx - 338, cy + 214, '云墙与雨带', 19, (*FOG, int(240 * a2)), False, 'rm', plate_a=int(150 * a2))

    # 标题
    d.text((W // 2, 62), '台风', font=font(42, True), fill=(*FOG, int(250 * a)), anchor='mt')
    d.text((W // 2, 116), 'TYPHOON', font=mono(15), fill=(*CYAN, int(210 * a)), anchor='mt')
    return im


def shot15(p, t):
    """15 五个条件：逐项点亮，最后留一个未点亮的空位"""
    im = soft_bg('A05', lerp(1.10, 1.03, ease_in_out(p)), 0.5, 0.5, k=0.34, blur=18, lift_k=0.85)
    scrim(im, [112, 118, 806, 520], alpha=96, radius=22)
    d = ImageDraw.Draw(im, 'RGBA')

    items = ['温暖而有深度的海水', '充足的水汽', '初始扰动', '地球自转带来的偏转', '较弱的高空风切变']
    x0, y0 = 168, 168
    gap = 68
    for i, name in enumerate(items):
        on = p > 0.06 + i * 0.13
        y = y0 + i * gap
        col = AMBER if on else (*CYAN, 90)
        # 勾选点
        d.ellipse([x0 - 13, y - 13, x0 + 13, y + 13], outline=col, width=2)
        if on:
            d.line([(x0 - 5, y), (x0 - 1, y + 5)], fill=AMBER, width=3)
            d.line([(x0 - 1, y + 5), (x0 + 7, y - 6)], fill=AMBER, width=3)
        tag(d, x0 + 34, y, name, 25 if on else 23,
            (*FOG, 245) if on else (*FOG, 120), on, 'lm', plate=False)

    # 第六个空位：概率缺口
    y = y0 + 5 * gap
    d.rounded_rectangle([x0 - 14, y - 14, x0 + 14, y + 14], radius=5,
                        outline=(*CORAL, 190), width=2)
    d.text((x0, y), '?', font=font(20, True), fill=(*CORAL, 220), anchor='mm')
    tag(d, x0 + 34, y, '并不保证一定形成', 23, (*CORAL, 235), True, 'lm', plate=False)

    tag(d, W // 2, H - 122, '条件齐备，也不一定成台风', 26, (*FOG, 245), True, 'mm', plate_a=175)
    return im


def shot16(p, t):
    """16 登陆衰减：能量流断开，云墙松散，缓慢拉远"""
    im = cam(A['A07'], lerp(1.14, 1.01, ease_in_out(p)), 0.5, lerp(0.48, 0.52, p))
    d = ImageDraw.Draw(im, 'RGBA')

    # 能量流断开
    a = ease_in_out(clamp(p / 0.55))
    col = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    cd = ImageDraw.Draw(col)
    for y in range(int(H * 0.62), H):
        al = int(70 * (1 - a))
        cd.rectangle([(0, y), (W, y + 2)], fill=(*AMBER, al))
    blur_paste(im, col, 24)

    # 登陆侧珊瑚薄雾：表示系统被切断并衰减
    im = coral_tint(im, int(W * 0.36), W, amount=0.38 * a, feather=240)
    coral_wash(im, int(W * 0.42), W, strength=int(120 * a), feather=260)
    d = ImageDraw.Draw(im, 'RGBA')

    # 剩余能量条：由暖金转向暗珊瑚，条长衰减
    bx0, bx1 = W // 2 - 210, W // 2 + 210
    by = H - 132
    d.rounded_rectangle([bx0, by, bx1, by + 14], radius=7, outline=(*FOG, 100), width=1)
    w = int((bx1 - bx0 - 6) * (1 - a * 0.86))
    if w > 4:
        col = tuple(int(lerp(AMBER[i], CORAL[i], a)) for i in range(3))
        d.rounded_rectangle([bx0 + 3, by + 3, bx0 + 3 + w, by + 11], radius=5,
                            fill=(*col, 245))
    tag(d, W // 2, by - 30, '登陆后失去海洋的热量与水汽', 21, (*CORAL, 245), True, 'mm', plate_a=165)
    tag(d, W // 2, by + 44, '能量供给中断 → 迅速减弱', 18, (*FOG, 215), False, 'mm', plate_a=150)
    return im


SHOT_FN = [shot01, shot02, shot03, shot04, shot05, shot06, shot07,
           shot08, shot09, shot10, shot11, shot12, shot13, shot14, shot15, shot16]
