"""
场景层模板 · 每个科普项目只改这个文件

规则（写死，不要违反，否则会被 qc.py 打回）：
  1. 暖金 AMBER 只表示「能量 / 热量 / 正向流动」
  2. 暗珊瑚 CORAL 只表示「破坏 / 衰减 / 风险」
  3. 冷青 CYAN 表示「结构 / 水汽 / 风场」
  4. 一镜之内最多三种主色
  5. 每镜只承担一个动作：开始状态 → 一个主要动作 → 明确结束状态
  6. 代码里出现的所有中文、数字、箭头都由本文件画，绝不交给 AI 生成

接口：def shotNN(p, t) -> PIL.Image
  p 该镜头内的进度 0..1
  t 全片时间（秒），需要跨镜连续动画时用它

engine 提供的能力：
  画幅常量      W, H
  色板          BG, DEEP_SEA, CYAN, AMBER, CORAL, FOG
  资产          A['A01'] 取原生分辨率图；cam(图, zoom, cx, cy) 做摄影机裁切
  缓动          clamp / ease_out / ease_in / ease_in_out / lerp
  标注          tag(..., color=(...), align='lm') / arrow(...)
  光效          glow_ring + paste_scaled / blur_paste / coral_tint / scrim
  字体          font(size, bold=True) 中文 / mono(size) 数字
  背景          BG_IMG 深蓝渐变 / soft_bg(资产ID, zoom) 柔化云场
"""
from engine import *

# 4 镜示例：开场 → 机制 → 对比 → 结论
# 照这个结构替换成你自己的内容即可


def shot01(p, t):
    """开场：标题 + 缓慢推近的云场，交代主题"""
    im = cam(A['A01'], lerp(1.02, 1.09, ease_out(p)), 0.5, lerp(0.56, 0.46, p))
    d = ImageDraw.Draw(im, 'RGBA')

    a = int(255 * ease_out(clamp(p / 0.4)))
    d.text((92, 250), 'YOUR TOPIC', font=mono(15), fill=(*AMBER, int(a * 0.85)))
    d.text((90, 272), '在这里写中文标题', font=font(46, True), fill=(*FOG, a))
    d.line([(92, 342), (472, 342)], fill=(*CYAN, int(a * 0.5)), width=1)
    d.text((92, 354), '副标题  ·  关键词  ·  关键词',
           font=font(17), fill=(*FOG, int(a * 0.62)))
    return im


def shot02(p, t):
    """机制：一个上升箭头 + 两个标注，说明「某物从 A 变成 B」"""
    im = soft_bg('A03', lerp(1.06, 1.13, ease_in_out(p)), 0.5, lerp(0.52, 0.44, p))
    d = ImageDraw.Draw(im, 'RGBA')

    # 主要动作：箭头从下往上长出来
    a = ease_out(clamp(p / 0.6))
    arrow(d, (W // 2, H - 110), (W // 2, int(lerp(H - 110, 150, a))),
          AMBER, width=5, head=16, alpha=int(235 * a))

    if p > 0.3:
        a2 = ease_out(clamp((p - 0.3) / 0.4))
        tag(d, W // 2 + 30, H - 150, '起点状态', 20, (*FOG, int(235 * a2)))
        tag(d, W // 2 + 30, 170, '终点状态', 20, (*AMBER, int(245 * a2)), True)
    return im


def shot03(p, t):
    """对比：左右分屏，一侧正常（冷青），一侧受损（暗珊瑚）"""
    hw = W // 2
    left = cam(A['A06'], 1.25, 0.22, 0.5)
    right = cam(A['A06'], 1.25, 0.78, 0.5)
    im = Image.new('RGB', (W, H))
    im.paste(left.crop((0, 0, hw, H)), (0, 0))
    im.paste(right.crop((hw, 0, W, H)), (hw, 0))

    a = ease_in_out(clamp(p / 0.7))
    im = coral_tint(im, hw + 20, W, amount=0.42 * a, feather=200)
    d = ImageDraw.Draw(im, 'RGBA')
    d.line([(hw, 0), (hw, H)], fill=(*FOG, 70), width=1)

    tag(d, 100, H - 120, '正常一侧', 25, (*CYAN, 245), True)
    tag(d, 100, H - 88, '结构保持', 18, (*FOG, 215), False)
    tag(d, hw + 96, H - 120, '受损一侧', 25, (*CORAL, 245), True)
    tag(d, hw + 96, H - 88, '结构被破坏', 18, (*FOG, 215), False)
    return im


def shot04(p, t):
    """结论：柔化云场做底 + 逐条点亮的要点，最后给一句总结

    注意：纯渐变底对比度会掉到 20 以下，qc.py 会判不合格。
    信息镜也应当有一层柔化背景（soft_bg），画面才有空间感。
    """
    im = soft_bg('A03', lerp(1.10, 1.03, ease_in_out(p)), 0.5, 0.46, k=0.62, blur=10)
    scrim(im, [130, 150, 880, 470], alpha=96, radius=22)
    d = ImageDraw.Draw(im, 'RGBA')

    items = ['第一条要点', '第二条要点', '第三条要点']
    for i, name in enumerate(items):
        on = p > 0.06 + i * 0.14
        y = 210 + i * 78
        col = AMBER if on else (*CYAN, 90)
        if on:
            g, sc = glow_ring(168, y, 16, 16, AMBER, 10, 80)
            paste_scaled(im, g, sc, 10)
            d = ImageDraw.Draw(im, 'RGBA')
        if on:
            # 点亮 = 实心暖金圆点 + 左侧竖条：把「能量」语义真正画进画面
            d.ellipse([155, y - 13, 181, y + 13], fill=(*AMBER, 255))
            d.line([(138, y - 24), (138, y + 24)], fill=(*AMBER, 225), width=4)
        else:
            d.ellipse([155, y - 13, 181, y + 13], outline=col, width=2)
        tag(d, 210, y, name, 26, (*FOG, 245) if on else (*FOG, 120), on, 'lm', plate=False)
        if on:
            # 要点下方一条暖金程度条：既是信息层级，也把「能量」语义做成面
            bx0, bx1 = 210, 760
            barw = int((bx1 - bx0) * ease_out(clamp((p - (0.06 + i * 0.14)) / 0.35)))
            if barw > 6:
                d.rounded_rectangle([bx0, y + 22, bx0 + barw, y + 31], radius=4,
                                    fill=(*AMBER, 225))

    # 贯穿三个要点的暖金能量线：把「能量」从抽象概念变成画面里的主线
    grow = ease_in_out(clamp((p - 0.05) / 0.7))
    if grow > 0.02:
        y0, y1 = 210, 210 + 2 * 78
        y_end = lerp(y0, y1, grow)
        glow = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow)
        gd.line([(168, y0), (168, y_end)], fill=(*AMBER, 150), width=10)
        blur_paste(im, glow, 12, scale=4)
        d = ImageDraw.Draw(im, 'RGBA')
        d.line([(168, y0), (168, y_end)], fill=(*AMBER, 235), width=3)

    if p > 0.65:
        a = ease_out(clamp((p - 0.65) / 0.3))
        tag(d, W // 2, H - 158, '一句话总结', 28, (*AMBER, int(248 * a)), True, 'mm')
    return im


SHOT_FN = [shot01, shot02, shot03, shot04]
