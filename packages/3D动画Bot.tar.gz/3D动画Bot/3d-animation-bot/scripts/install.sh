#!/bin/bash
# 3D 动画 Bot · 一键装配脚本
# 用法：bash install.sh [工作目录]     （默认 ~/ai-video）
# 作用：装流水线代码、建配置骨架、检查依赖。可重复执行，不会覆盖已有密钥。
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${1:-$HOME/ai-video}"

echo "=========================================="
echo "  3D 动画 Bot · 环境装配"
echo "=========================================="
echo "  技能目录：$SKILL_DIR"
echo "  工作目录：$WORK"
echo ""

mkdir -p "$WORK"
cd "$WORK"

# ---------- 1) 装入流水线 ----------
cp -R "$SKILL_DIR/scripts/." "$WORK/"
rm -f "$WORK/install.sh"
echo "[1/4] ✓ 流水线代码已装入（run.py / assemble.py / adapters / selfcheck.py）"

# ---------- 2) 配置骨架 ----------
if [ ! -f "$WORK/config.yaml" ]; then
  cp "$SKILL_DIR/templates/config.example.yaml" "$WORK/config.yaml"
  echo "[2/4] ✓ 生成 config.yaml"
else
  echo "[2/4] · config.yaml 已存在，保留不动"
fi

if [ ! -f "$WORK/.env" ]; then
  cp "$SKILL_DIR/templates/.env.example" "$WORK/.env"
  echo "      ✓ 生成 .env（待填 API Key）"
else
  echo "      · .env 已存在，保留不动"
fi

# ---------- 3) 示例项目 ----------
if [ ! -d "$WORK/projects/示例" ]; then
  mkdir -p "$WORK/projects/示例"
  cp "$SKILL_DIR/templates/shots.example.yaml" "$WORK/projects/示例/shots.yaml"
  echo "[3/4] ✓ 生成示例项目 projects/示例/shots.yaml"
else
  echo "[3/4] · 示例项目已存在"
fi

[ -f "$WORK/.gitignore" ] || cat > "$WORK/.gitignore" <<'EOF'
.env
.autodl_token
.state.json
__pycache__/
projects/*/角色卡/
projects/*/场景卡/
projects/*/单镜片段/
EOF

# ---------- 4) 依赖检查 ----------
echo "[4/4] 检查依赖"
PY="$(command -v python3 || true)"
[ -n "$PY" ] || { echo "      ✗ 找不到 python3，请先安装 Python 3.9+"; exit 1; }
echo "      ✓ python3: $($PY -V 2>&1)"

$PY - <<'PYEOF'
import importlib, sys
need = {"yaml": "pyyaml", "requests": "requests", "edge_tts": "edge-tts"}
missing = []
for mod, pkg in need.items():
    try:
        importlib.import_module(mod)
        print(f"      ✓ {pkg}")
    except ImportError:
        print(f"      ✗ {pkg} 未安装")
        missing.append(pkg)
try:
    import imageio_ffmpeg
    print("      ✓ imageio-ffmpeg")
except ImportError:
    print("      ✗ imageio-ffmpeg 未安装")
    missing.append("imageio-ffmpeg")
if missing:
    print(f"\n      缺依赖，运行：{sys.executable} -m pip install " + " ".join(missing))
    sys.exit(1)
PYEOF

echo ""
echo "=========================================="
echo "  装配完成 ✓"
echo "=========================================="
echo ""
echo "下一步（3 件事）："
echo "  1. 填密钥：编辑 $WORK/.env"
echo "       IMAGE_API_KEY      ← 生图网关 Key"
echo "       AUTODL_TOKEN_FILE  ← AutoDL ComfyUI token 文件路径"
echo "       DOUBAO_TTS_API_KEY ← 豆包语音合成 Key（可选）"
echo "  2. 改配置：编辑 $WORK/config.yaml 填 base_url / model / workflow"
echo "  3. 自检：cd $WORK && python3 selfcheck.py"
echo ""
echo "试跑（不烧钱）："
echo "  cd $WORK && python3 run.py --project projects/示例 --stage all --dry-run"
