"""3D 动画流水线 · 三段 API 自检（不烧钱或极小成本）

用法：
  python3 selfcheck.py          # 检查配置完整性 + 语音真实合成一句
  python3 selfcheck.py --no-tts # 只做配置检查

说明：
  生图/视频 只做「配置是否就绪」检查，不真实调用（真实出片阶段才烧钱）。
  语音做一次真实合成，确认 Key 与端点可用（成本约几分钱）。
"""
import sys
from pathlib import Path

sys.path.insert(0, ".")
try:
    from adapters import base
except Exception as e:
    print(f"✗ 无法导入 adapters（请在 ~/ai-video 目录下运行）：{e}")
    sys.exit(1)


def check_image(cfg):
    c = cfg.get("image", {})
    ok = bool(c.get("base_url")) and bool(c.get("api_key")) and bool(c.get("model"))
    print(f"{'✓' if ok else '✗'} 生图  provider={c.get('provider')}  model={c.get('model')}  key={'已填' if c.get('api_key') else '缺失'}")
    return ok


def check_video(cfg):
    c = cfg.get("video", {})
    adl = c.get("autodl", {})
    tf = adl.get("token_file")
    has_token = bool(tf and Path(tf).exists() and Path(tf).read_text(encoding="utf-8").strip())
    print(f"{'✓' if has_token else '✗'} 视频  provider={c.get('provider')}  workflow={adl.get('workflow')}  token={'就绪' if has_token else f'缺失({tf})'}")
    return has_token


def check_tts(cfg):
    c = cfg.get("tts", {})
    prov = c.get("provider")
    has_key = bool(c.get("api_key"))
    print(f"{'✓' if (prov == 'edge_tts' or has_key) else '✗'} 语音  provider={prov}  voice={c.get('voice')}  key={'已填' if has_key else '缺失'}")
    return prov == "edge_tts" or has_key


def main():
    no_tts = "--no-tts" in sys.argv
    cfg = base.load_config(Path("config.yaml"))
    print("配置文件：config.yaml\n")
    results = [check_image(cfg), check_video(cfg), check_tts(cfg)]

    if not no_tts and cfg.get("tts", {}).get("provider") != "edge_tts":
        print("\n真实合成一句（验证豆包端点）…")
        from adapters import tts as tts_mod
        out = tts_mod.synth("你好，三D动画流水线自检通过。", "selfcheck_tts.mp3", cfg["tts"])
        size = Path(out).stat().st_size
        print(f"✓ 语音合成成功：{out}（{size} 字节）")
        Path(out).unlink()

    print("\n" + ("全部就绪，可以开跑 ✓" if all(results) else "有缺项，见上方 ✗ 项"))
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
