# 安装与升级 · mengwa-english-video 1.2.0

## 安装

1. 将包内 Skill 目录放到 `~/.agents/skills/mengwa-english-video/`；若解压目录名是 `skill-mengwa-english-video`，安装时改为 `mengwa-english-video`。
2. 需要 Python 3.9+ 与 ffmpeg；ffmpeg 可在 PATH，通过 `FFMPEG` 指定，或按当前实现使用 `imageio-ffmpeg`。
3. 新开会话确认 Skill 可发现。升级前保留旧版本和本地秘密配置，不把秘密放入分发包。

共享核心 `scripts/pipeline_core.py` 供项目与 Skill 入口使用。下文 CLI 已对照核心实现；能力与测试覆盖仍以实际验证为准，不因文档示例而宣称端到端通过。

## 密钥

将 `config/secrets.example.json` 复制为本地 `config/secrets.json` 并填值，不提交或打包真实密钥。

| 字段 | 用途 | 注册/管理 |
|---|---|---|
| `telangpuai_image_key` | 生图 | https://telangpuai.com/register?aff=QJQJ8HPXEE9M |
| `doubao_api_key` | 配音 | https://ark.volcengine.com/region:cn-beijing/subscription/agent-plan |
| `autodl_token` | 视频 | https://autodl.art/large-model/tokens |

环境变量：`TELANGPUAI_IMAGE_API_KEY`、`DOUBAO_API_KEY`、`AUTODL_TOKEN`，按当前实现优先于本地秘密文件。非秘密配置来源也需检查当前入口，避免旧硬编码默认值与项目配置不一致。

历史复刻鉴权错误或资源 403 只说明当时账号/接口权限，不代表所有账号均不支持，也不能证明女童音色不存在。核对资源和授权后再试，先确认预算。

## 可移植配置示例

共享核心从项目根目录的 `config.json` 读取非秘密配置，与默认值递归合并。不同项目使用各自配置，不复制原机器的绝对路径。以下字段已对照当前核心；配置示例不代表付费接口验证通过。

```json
{
  "voice": {
    "speaker": "zh_male_naiqimengwa_uranus_bigtts",
    "speed": 1.3,
    "speed_label": "利落1.3x"
  },
  "video": {
    "workflow": "minimax_h3_image_audio_to_video_v2_15s",
    "resolution": "768p竖",
    "expected_resolution": "768x1344",
    "duration": 15,
    "poll_timeout_sec": 900
  },
  "role": {
    "default_image": "assets/男宝1_奶油卷发小男主.png"
  }
}
```

示例使用包内默认角色；自有角色优先在台本 `role_image` 填项目相对路径或本机绝对路径。修改速度时同时使用与速度一致的 `speed_label`，避免混用旧音频目录。切换工作流必须一起核对分辨率枚举、预期尺寸和时长上限。密钥只放环境变量或秘密文件，不写入此示例。

## 离线冒烟检查

```bash
python3 ~/.agents/skills/mengwa-english-video/scripts/pipeline.py --help
python3 ~/.agents/skills/mengwa-english-video/scripts/image_gen.py --help
```

以上只运行帮助，不生成、不上传素材。生图、配音和视频均可能计费，不属于安装冒烟检查。离线集成测试命令待实现确认，不用真实生成代替测试。

## 付费生产前置条件

台本需用户明确批准后才能配音；用户实际试听批准且新角色/场景确认后才能出片。审批绑定具体台本、音频、图像和设置哈希，变更使受影响审批失效。安装说明不自动授予生成许可。

在自己的项目目录操作。以下按 S1 展示，其他片段逐段重复；HASH 使用对应阶段返回的真实哈希。不要把审批和生成拼成无人审核的一键命令。

```bash
P="$HOME/.agents/skills/mengwa-english-video/scripts/pipeline.py"
python3 "$P" hash --stage voice --台本 台本.json --only S1
# 停：用户批准该台本与配音设置后，才记录上一步的 HASH
python3 "$P" approve --stage voice --台本 台本.json --only S1 --hash HASH
python3 "$P" voice --台本 台本.json --only S1
python3 "$P" hash --stage video --台本 台本.json --only S1
# 停：用户实际试听批准、确认角色图后，记录 video 阶段的 HASH
python3 "$P" approve --stage video --台本 台本.json --only S1 --hash HASH
python3 "$P" video --台本 台本.json --only S1
python3 "$P" qc --台本 台本.json --only S1
```

voice 和 video 的 hash/approve 都每次只选一个片段，始终带 `--only S1`；S2 将上述流程中的 S1 换成 S2 后重新取哈希、审查和批准，不复用 S1 的 HASH。voice 指纹绑定该段文本与 voice 配置，哈希不是用户同意的替代品。

### 从旧版迁移

保留旧成片和旧音频作参考，不删除。旧音频缺少新核心 `voice-current` 来源记录，不能直接采用、静默批准或人工补写记录。需要进入新流程的片段必须逐段重新获取 voice 哈希，经用户批准重新配音；核心生成来源记录后，再实际试听、批准 video 并出片。重新配音可能计费，迁移本身不构成付费授权。已发布旧作品不必为了迁移而重做。

`video` 对已知任务自动继续查询/下载，正常恢复时不加 `--new-attempt`。仅当状态为失败、被拒或已完成，且用户明确同意重新付费生成时才用 `video ... --new-attempt`。提交状态 unknown/submitting 时，必须先向服务商确认任务 ID，再附接已有任务：

```bash
python3 "$P" reconcile --台本 台本.json --only S1 --task-id PROVIDER_CONFIRMED
python3 "$P" video --台本 台本.json --only S1
```

`reconcile` 不创建任务，不能填猜测的 ID。`qc --台本 台本.json` 检查全部所选音频和视频，失败返回非零；仍不证明发音、台词或口型合格。帮助能运行也不证明安装、配置或端到端生产通过。

## 验收和排错

- 单段、两段、选择题均以用户最新要求为准；保留批准内容，超长优先语义拆段。
- 13s 是保守目标，不是安全线；按工作流上限硬校验，未知时长/超上限不得静默提交。
- 技术 QC 需检查可解码、文件齐全、音视频流、尺寸、时长等并严格返回失败；人工试听和动态口型验收不可替代。
- 768×1344 是常见竖屏输出，不是精确 9:16；无字幕流不证明没有烧录文字。
- MP3/AAC 有损；源音轨替换需核对对齐与嘴形，不保证自动同步。
- 请求 WAV 却返回 MP3，先核参数结构与合法值；声音乱先比较源与成片，不凭采样率推断。
- 余额不足停止。充值后先确认原任务状态，仅补确实失败的片段，保留此前成功版本。
- 下载成功只代表有输出，不能宣称台词、声音、口型全部合格。

## 白名单打包

项目根目录执行已确认命令：

```bash
python3 tools/package_skill.py --out mengwa-english-video-v1.2.0.zip
```

打包器拒绝覆盖已有文件。旧包保留，需再次打包时换未占用的输出名；不使用递归 zip 整个目录的命令。

白名单仅包含必要代码（含共享核心）、文档、模板、批准资产和空密钥示例。排除真实密钥、任务日志、公网 URL 缓存、虚拟环境及生产输出。检查包清单并做干净目录离线安装测试后再分发，不用付费 API 验证包完整性。
