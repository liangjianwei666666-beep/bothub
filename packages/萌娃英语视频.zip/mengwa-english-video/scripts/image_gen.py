#!/usr/bin/env python3
"""萌娃英语教学 · 角色/场景生图（telangpuai gpt-image-2）—— 通用版。

用法：
  python3 image_gen.py --prompt "竖屏9:16, 写实萌娃小男孩半身正面像, ..." \
      --out /path/to/out.png [--size 1024x1792] [--input 已有图.png]

Key 来源（优先级）：环境变量 TELANGPUAI_IMAGE_API_KEY
  > 本 skill config/secrets.json 的 telangpuai_image_key
  > ~/.codex/telangpuai-image-key（若存在）

纯标准库实现（urllib + base64），跨平台，不依赖 osascript。
"""
import argparse, base64, json, os, sys, urllib.request, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)
SECRETS_FILE = os.path.join(SKILL_DIR, "config", "secrets.json")

ENDPOINT_GEN = "https://telangpuai.com/v1/images/generations"
ENDPOINT_EDIT = "https://telangpuai.com/v1/images/edits"
MODEL = "gpt-image-2"


def load_key():
    env = os.environ.get("TELANGPUAI_IMAGE_API_KEY", "").strip()
    if env:
        return env
    if os.path.exists(SECRETS_FILE):
        with open(SECRETS_FILE) as f:
            s = json.load(f)
        if s.get("telangpuai_image_key"):
            return s["telangpuai_image_key"]
    legacy = os.path.expanduser("~/.codex/telangpuai-image-key")
    if os.path.exists(legacy):
        with open(legacy) as f:
            return f.read().strip()
    return None


def parse_resp(raw):
    x = json.loads(raw)
    if not x.get("data") or not x["data"][0]:
        raise RuntimeError("接口成功但没有图片数据：" + raw[:300])
    return x["data"][0]


def main():
    ap = argparse.ArgumentParser(description="telangpuai gpt-image-2 生图/改图")
    ap.add_argument("--prompt", required=True)
    ap.add_argument("--input", default="", help="已有图片路径（改图模式）")
    ap.add_argument("--out", default="", help="输出 png 路径")
    ap.add_argument("--size", default="", help="如 1024x1792")
    args = ap.parse_args()

    key = load_key()
    if not key:
        sys.exit("缺少生图 Key：设 TELANGPUAI_IMAGE_API_KEY 或填入 config/secrets.json 的 telangpuai_image_key")
    if not args.out:
        args.out = os.path.join(os.getcwd(), f"image-{os.path.basename(__import__('tempfile').mkdtemp())}.png")
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    tmp = args.out + ".tmp"

    if args.input:
        if not os.path.exists(args.input):
            sys.exit(f"找不到待修改图片：{args.input}")
        # multipart/form-data 手动构造（与 curl -F 等价）
        boundary = "----tpu" + os.urandom(8).hex()
        parts = []
        def field(name, value):
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n".encode())
        def file_field(name, path):
            with open(path, "rb") as f:
                data = f.read()
            ctype = "image/png"
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{os.path.basename(path)}\"\r\nContent-Type: {ctype}\r\n\r\n".encode())
            parts.append(data)
            parts.append(b"\r\n")
        field("model", MODEL)
        field("prompt", args.prompt)
        file_field("image", args.input)
        if args.size:
            field("size", args.size)
        parts.append(f"--{boundary}--\r\n".encode())
        body = b"".join(parts)
        req = urllib.request.Request(ENDPOINT_EDIT, data=body, method="POST",
                                     headers={"Authorization": f"Bearer {key}", "Content-Type": f"multipart/form-data; boundary={boundary}"})
    else:
        payload = {"model": MODEL, "prompt": args.prompt}
        if args.size:
            payload["size"] = args.size
        body = json.dumps(payload).encode()
        req = urllib.request.Request(ENDPOINT_GEN, data=body, method="POST",
                                     headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})

    with urllib.request.urlopen(req, timeout=600) as r:
        data = parse_resp(r.read())

    if data.get("b64_json"):
        with open(tmp, "wb") as f:
            f.write(base64.b64decode(data["b64_json"]))
    elif data.get("url"):
        with urllib.request.urlopen(data["url"], timeout=600) as r:
            with open(tmp, "wb") as f:
                f.write(r.read())
    else:
        sys.exit("接口成功但没有图片数据")
    os.replace(tmp, args.out)
    if not os.path.getsize(args.out):
        sys.exit("图片文件为空")
    print(f"IMAGE_SAVED={os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
