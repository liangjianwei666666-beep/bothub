"""Shared production pipeline. No network is used by hash, approve or qc."""
import argparse
import base64
import contextlib
import copy
import hashlib
import json
import math
import mimetypes
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import urllib.error
import uuid

SKILL = Path(__file__).resolve().parent.parent
DEFAULTS = {
    'paths': {},
    'voice': {'endpoint': 'https://openspeech.bytedance.com/api/v3/plan/tts/unidirectional',
              'resource_id': 'seed-tts-2.0', 'speaker': 'zh_male_naiqimengwa_uranus_bigtts',
              'audio_params': {'format': 'wav', 'sample_rate': 48000, 'speech_rate': -2, 'loudness_rate': 2},
              'loudnorm': 'I=-16:TP=-1.5:LRA=12', 'speed': 1.3, 'speed_label': '利落1.3x'},
    'video': {'base': 'https://autodl.art/api/v1/comfyui/comfyui_workflow',
              'workflow': 'minimax_h3_image_audio_to_video_v2_15s', 'resolution': '768p竖',
              'expected_resolution': '768x1344', 'duration': 15, 'poll_interval_sec': 10,
              'poll_timeout_sec': 900, 'safe_retries': 3, 'output_tolerance_sec': 1.0,
              'param_mode': 'duration', 'audio_fit_silence': False},
    'role': {'default_image': 'assets/男宝1_奶油卷发小男主.png'}}


def merge(base, override):
    result = copy.deepcopy(base)
    for key, value in override.items():
        result[key] = merge(result[key], value) if isinstance(value, dict) and isinstance(result.get(key), dict) else value
    return result


def read_json(path):
    with open(path, encoding='utf-8') as handle:
        return json.load(handle)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    try:
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def publish(source, destination):
    """Archive existing usable output before atomically installing a checked file."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        archive = destination.parent / 'attempts' / uuid.uuid4().hex
        archive.mkdir(parents=True)
        shutil.copy2(destination, archive / destination.name)
    temp = destination.with_name('.' + uuid.uuid4().hex + destination.suffix)
    try:
        shutil.copyfile(source, temp)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


def safe_name(value):
    if not isinstance(value, str) or not value or value in ('.', '..') or '/' in value or '\\' in value:
        raise RuntimeError('Invalid episode/segment/label')
    return value


class Pipeline:
    def __init__(self, root):
        self.root = Path(root).resolve()
        path = self.root / 'config.json'
        self.config = merge(DEFAULTS, read_json(path) if path.exists() else {})
        self.state_root = self.root / '.pipeline'

    def resolve(self, path):
        p = Path(path).expanduser()
        return p if p.is_absolute() else self.root / p

    def ffmpeg(self):
        candidates = [os.environ.get('FFMPEG'), self.config['paths'].get('ffmpeg'), shutil.which('ffmpeg')]
        for candidate in candidates:
            if candidate and self.resolve(candidate).is_file():
                return str(self.resolve(candidate))
        try:
            import imageio_ffmpeg
            return imageio_ffmpeg.get_ffmpeg_exe()
        except ImportError:
            raise RuntimeError('ffmpeg missing; configure paths.ffmpeg or FFMPEG')

    def run(self, command):
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError('Media processing failed: ' + result.stderr[-1200:])
        return result.stderr

    def media(self, path, video=False, expected_duration=None, enforce_limit=True):
        if not Path(path).is_file() or Path(path).stat().st_size == 0:
            raise RuntimeError('Missing/empty media: ' + str(path))
        command = [self.ffmpeg(), '-hide_banner', '-xerror', '-err_detect', 'explode', '-i', str(path)]
        command += ['-map', '0:v:0', '-map', '0:a:0'] if video else ['-map', '0:a:0']
        text = self.run(command + ['-f', 'null', '-'])
        streams = [line for line in text.split('Output #')[0].splitlines() if 'Stream #' in line]
        if sum('Audio:' in line for line in streams) != 1:
            raise RuntimeError('Expected exactly one audio stream')
        match = re.search(r'Duration: (\d+):(\d+):([\d.]+)', text)
        if not match:
            raise RuntimeError('Unknown media duration')
        duration = int(match[1])*3600 + int(match[2])*60 + float(match[3])
        if not math.isfinite(duration) or duration <= 0:
            raise RuntimeError('Invalid media duration')
        limit = self.config['video']['duration']
        if not video and enforce_limit and duration > limit:
            raise RuntimeError('Audio exceeds model limit')
        if video:
            if sum('Video:' in line for line in streams) != 1 or any('Subtitle:' in line for line in streams):
                raise RuntimeError('Invalid video/subtitle streams')
            resolution = self.config['video']['expected_resolution']
            if not any(re.search(r'\b' + re.escape(resolution) + r'\b', line) for line in streams if 'Video:' in line):
                raise RuntimeError('Unexpected video resolution')
            tolerance = self.config['video']['output_tolerance_sec']
            if duration > limit + tolerance or (expected_duration is not None and (duration < expected_duration - .15 or duration > expected_duration + tolerance + 1)):
                raise RuntimeError('Video duration outside allowed bounds')
        elif duration > 13:
            print('Advisory: >13 seconds; not a quality verdict', flush=True)
        return duration

    def script(self, path, only=None):
        script = read_json(self.resolve(path))
        safe_name(script['episode'])
        segments = script['segments']
        ids = [safe_name(s['id']) for s in segments]
        if not ids or len(ids) != len(set(ids)):
            raise RuntimeError('Empty or duplicate segments')
        for seg in segments:
            safe_name(seg.get('label', seg['id']))
            if not isinstance(seg.get('text'), str) or not seg['text'].strip():
                raise RuntimeError('Missing segment text')
        selected = set(only.split(',')) if only else set(ids)
        if not selected <= set(ids):
            raise RuntimeError('Unknown --only segment')
        return script, [s for s in segments if s['id'] in selected]

    def voice_config(self, script):
        """本段生效的 voice 配置：全局 config.json 打底，台本级 script['voice'] 覆盖。

        为什么要台本级覆盖：旧的集（B14~B19）没有 voice 字段，指纹保持原值不变，
        音频来源记录不会因换件而失效；新系列（如 Ana 英文童声）自带一份 voice 配置，
        写进该集的 voice 指纹。
        """
        return merge(self.config['voice'], script.get('voice') or {})

    def audio(self, script, seg):
        directory = self.root / '02-音频' / ('正式分轨_' + script['episode'])
        if self.voice_config(script)['speed'] != 1:
            directory /= self.voice_config(script)['speed_label']
        return directory / (seg['id'] + '.mp3')

    def image(self, script):
        reference = script.get('role_image') or self.config['role']['default_image']
        path = self.resolve(reference)
        if not path.is_file() and Path(reference).parts[0] == 'assets':
            path = SKILL / reference
        if not path.is_file():
            raise RuntimeError('Missing reference image')
        return path

    def voice_record_path(self, script, seg):
        return self.state_root / script['episode'] / seg['id'] / 'voice-current.json'

    def require_current_audio(self, script, seg):
        path = self.voice_record_path(script, seg)
        if not path.exists():
            raise RuntimeError('Audio provenance missing; legacy audio requires regeneration after script approval')
        record = read_json(path)
        if record.get('voice_hash') != self.fingerprint('voice', script, seg) or record.get('audio_hash') != file_hash(self.audio(script, seg)):
            raise RuntimeError('Stale audio: text, voice configuration or audio changed; regenerate and review')

    def fingerprint(self, stage, script, seg):
        if stage == 'voice':
            return digest({'text': seg['text'], 'voice': self.voice_config(script)})
        self.require_current_audio(script, seg)
        return digest({'text': seg['text'], 'prompt': seg.get('prompt', ''),
                       'image': file_hash(self.image(script)), 'audio': file_hash(self.audio(script, seg)),
                       'video': self.config['video']})

    def approval(self, script, seg, stage, expected, approve=False):
        path = self.state_root / script['episode'] / 'approvals.json'
        record = read_json(path) if path.exists() else {}
        key = stage + ':' + seg['id']
        if approve:
            record[key] = {'hash': expected, 'approved_at': time.time()}
            atomic_json(path, record)
        elif record.get(key, {}).get('hash') != expected:
            raise RuntimeError('Approval missing/stale for ' + key + '; run hash then approve with --hash')

    @contextlib.contextmanager
    def lock(self, episode):
        import fcntl
        directory = self.state_root / episode
        directory.mkdir(parents=True, exist_ok=True)
        with open(directory / 'lock', 'a') as handle:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError('Another pipeline process owns this episode')
            try:
                yield
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)

    def secret(self, name):
        env = {'doubao_api_key': 'DOUBAO_API_KEY', 'autodl_token': 'AUTODL_TOKEN'}[name]
        value = os.environ.get(env, '').strip()
        if value:
            return value
        paths = self.config['paths']
        if name == 'doubao_api_key' and paths.get('doubao_config'):
            value = read_json(self.resolve(paths['doubao_config'])).get('api_key')
        elif name == 'autodl_token' and paths.get('autodl_token'):
            value = self.resolve(paths['autodl_token']).read_text().strip()
        else:
            path = SKILL / 'config' / 'secrets.json'
            value = read_json(path).get(name) if path.exists() else None
        if not value:
            raise RuntimeError('Missing credential: ' + env)
        return value

    def request(self, method, url, headers=None, data=None):
        attempts = self.config['video']['safe_retries'] if method == 'GET' else 1
        for attempt in range(max(1, attempts)):
            try:
                req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
                with urllib.request.urlopen(req, timeout=60) as response:
                    return response.read()
            except (urllib.error.URLError, TimeoutError, OSError):
                if attempt + 1 >= attempts:
                    raise
                time.sleep(min(2**attempt, 8))

    def upload(self, path):
        boundary = uuid.uuid4().hex
        data = ('--'+boundary+'\r\nContent-Disposition: form-data; name="files[]"; filename="asset'+Path(path).suffix+'"\r\nContent-Type: '+(mimetypes.guess_type(str(path))[0] or 'application/octet-stream')+'\r\n\r\n').encode()
        data += Path(path).read_bytes() + ('\r\n--'+boundary+'--\r\n').encode()
        response = self.request('POST', 'https://uguu.se/upload', {'Content-Type': 'multipart/form-data; boundary='+boundary}, data)
        return json.loads(response)['files'][0]['url']

    def voice(self, script, seg):
        fingerprint = self.fingerprint('voice', script, seg)
        self.approval(script, seg, 'voice', fingerprint)
        directory = self.state_root / script['episode'] / seg['id'] / ('voice-' + uuid.uuid4().hex)
        directory.mkdir(parents=True)
        atomic_json(directory / 'attempt.json', {'hash': fingerprint, 'state': 'submitting'})
        v = self.voice_config(script)
        source = directory / 'source.mp3'
        if v.get('provider') == 'edge_tts':
            # 原生英文童声（Ana 等）：与豆包无关，不取豆包密钥。
            self.edge_voice(seg['text'], source, v)
        else:
            key = self.secret('doubao_api_key')
            # Preserve the existing API payload contract in phase 1.
            payload = {'req_params': {'text': seg['text'], 'speaker': v['speaker']}, 'audio_params': v['audio_params']}
            raw = self.request('POST', v['endpoint'], {'Content-Type': 'application/json', 'X-Api-Key': key, 'X-Api-Resource-Id': v['resource_id'], 'X-Api-Request-Id': str(uuid.uuid4())}, json.dumps(payload).encode())
            chunks = []
            for line in raw.decode().splitlines():
                if not line.strip():
                    continue
                item = json.loads(line)
                if item.get('code') not in (0, 20000000):
                    raise RuntimeError('TTS returned an error; partial audio rejected')
                data = item.get('data')
                if isinstance(data, dict):
                    data = data.get('audio')
                if data:
                    chunks.append(base64.b64decode(data, validate=True))
            if not chunks:
                raise RuntimeError('Empty TTS response')
            source.write_bytes(b''.join(chunks))
        normal = directory / 'normal.mp3'
        fast = directory / 'fast.mp3'
        common = ['-ar', '48000', '-ac', '1', '-c:a', 'libmp3lame', '-b:a', '192k']
        self.run([self.ffmpeg(), '-y', '-i', str(source), '-af', 'loudnorm='+v['loudnorm']] + common + [str(normal)])
        self.run([self.ffmpeg(), '-y', '-i', str(normal), '-af', 'atempo='+str(v['speed'])] + common + [str(fast)])
        self.media(normal, enforce_limit=False)
        self.media(fast)
        base = self.root / '02-音频' / ('正式分轨_'+script['episode']) / (seg['id']+'.mp3')
        publish(normal, base)
        if v['speed'] != 1:
            publish(fast, self.audio(script, seg))
        atomic_json(self.voice_record_path(script, seg), {
            'voice_hash': fingerprint, 'audio_hash': file_hash(self.audio(script, seg)),
            'attempt': str(directory), 'created_at': time.time()})
        atomic_json(directory / 'attempt.json', {'hash': fingerprint, 'state': 'complete'})

    def edge_voice(self, text, destination, v):
        """edge-tts 合成（免密钥）。默认格式 audio-24khz-48kbitrate-mono-mp3。

        延迟导入：只用豆包的流水线不需要安装 edge-tts。
        """
        import asyncio
        import edge_tts

        async def synthesize():
            communicate = edge_tts.Communicate(text, v['edge_voice'],
                                               rate=v.get('edge_rate', '+0%'),
                                               pitch=v.get('edge_pitch', '+0Hz'))
            with open(destination, 'wb') as handle:
                async for chunk in communicate.stream():
                    if chunk['type'] == 'audio':
                        handle.write(chunk['data'])

        asyncio.run(synthesize())
        if not Path(destination).is_file() or Path(destination).stat().st_size == 0:
            raise RuntimeError('Empty TTS response')

    def fit_audio(self, source, destination):
        """（默认关闭）裁掉上传副本的首尾静音，使声音硬起音。

        假设来源：怀疑"开头软"影响采用率。2026-09-11 直接量剖面后被否掉——能被完整
        采用的 B17S1 与只能采用 69% 的 B18S1，开头 0.4s 相对能量都是 0.00~0.07，首个
        强峰都在 0.45~0.50s；裁切对 B18S1 只削掉 0.17s。故默认 false，保留开关仅为
        应对确有病理性长静音的音频。见 项目备忘.md。
        """
        trim = ('silenceremove=start_periods=1:start_duration=0:start_threshold=-45dB:detection=peak')
        self.run([self.ffmpeg(), '-y', '-i', str(source), '-af', trim+',areverse,'+trim+',areverse',
                  '-ar', '48000', '-ac', '1', '-c:a', 'libmp3lame', '-b:a', '192k', str(destination)])
        return destination

    def video(self, script, seg, new_attempt=False):
        v = self.config['video']
        token = self.secret('autodl_token')
        audio = self.audio(script, seg)
        directory = self.state_root / script['episode'] / seg['id']
        # 上传给模型的音频副本：可选裁掉首尾静音（audio_fit_silence）。裁切只作用于副本，
        # 交付音频不变；开关属于 config['video']，因此进入 video 指纹。
        upload_audio = audio
        if v.get('audio_fit_silence'):
            upload_audio = self.fit_audio(audio, directory / 'upload-audio.mp3')
        duration = self.media(upload_audio)
        fingerprint = self.fingerprint('video', script, seg)
        self.approval(script, seg, 'video', fingerprint)
        manifest = directory / 'task.json'
        state = read_json(manifest) if manifest.exists() else None
        if state and (new_attempt or state['hash'] != fingerprint):
            if state['state'] in ('submitting', 'unknown', 'submitted', 'ready'):
                raise RuntimeError('Unresolved task blocks new submission; resume/reconcile first')
            archive = directory / ('task-'+uuid.uuid4().hex+'.json')
            atomic_json(archive, state)
            state = None
        output = self.root / '03-视频素材' / ('正式分段_'+script['episode']) / (seg['id']+'_'+seg.get('label',seg['id'])+'.mp4')
        if state and state['state'] == 'complete' and output.exists() and file_hash(output) == state.get('output_hash'):
            self.media(output, video=True, expected_duration=duration)
            print('Already complete: '+str(output), flush=True)
            return
        if state and state['state'] in ('submitting', 'unknown'):
            raise RuntimeError('Unknown POST outcome: must reconcile task ID; automatic resubmit forbidden')
        if state and state['state'] in ('failed', 'rejected'):
            raise RuntimeError('Task failed/rejected; use --new-attempt after review')
        headers = {'Authorization': token, 'Content-Type': 'application/json'}
        if state is None:
            image_url = self.upload(self.image(script))
            audio_url = self.upload(upload_audio)
            length = min(v['duration'], math.ceil(duration))
            # 服务商两族工作流的入参语义不同（参数表见 GET /api/v1/comfyui/workflows/{workflow_id}）：
            #   duration       = v2 族：duration 是“视频时长”，ref_audio 选填（默认静音占位），可带 prompt/seed
            #   audio_duration = v1 “音频同步(自动对口型)”：audio_duration 是“音频截取时长”，ref_audio 必填，无 prompt/seed
            if v.get('param_mode') == 'audio_duration':
                body = {'ref_image_0': image_url, 'ref_audio_0': audio_url,
                        'audio_duration': length, 'resolution': v['resolution']}
            else:
                # 服务商默认 seed 固定：同输入重复提交会返回字节完全相同的成片，重试无意义。
                # 显式随机 seed 让每次尝试成为新采样。seed 只进任务记录，不进指纹（指纹代表用户批准的内容与设置）。
                seed = v.get('seed')
                if seed is None:
                    seed = int.from_bytes(os.urandom(4), 'big') % 2147483647
                body = {'prompt': seg.get('prompt') or 'Stable camera, natural lip sync, no text.', 'ref_image_0': image_url, 'ref_audio_0': audio_url, 'duration': length, 'resolution': v['resolution'], 'seed': seed}
            state = {'hash': fingerprint, 'state': 'submitting', 'request': body, 'workflow': v['workflow'], 'base': v['base'], 'created_at': time.time(), 'attempt': uuid.uuid4().hex}
            atomic_json(manifest, state)
            try:
                raw = self.request('POST', v['base']+'/'+v['workflow'], headers, json.dumps(body).encode())
                text = raw.decode('utf-8', 'replace')
                # 保存服务商原文：被拒/未知时拒绝原因只在这里，不存就无法复盘
                # （2026-09-11 B19 S2 被拒、事后无从查因，即因此失明）。
                state['response'] = text[:4000]
                response = json.loads(text)
                task_id = (response.get('data') or {}).get('task_id')
                if not task_id:
                    # A valid explicit rejection has no remote task. Ambiguous responses stay unknown.
                    state['state'] = 'rejected' if response.get('code') == 'BadRequest' else 'unknown'
                    atomic_json(manifest, state)
                    raise RuntimeError('Submission rejected/unknown; inspect task manifest: '+text[:800])
            except urllib.error.HTTPError as error:
                # 4xx = 服务商明确拒绝创建任务（余额不足、参数不合法等），此时不存在远端任务；
                # 5xx 或网关错误可能是“已创建但回执丢失”，仍按 unknown 处理并去核对。
                try:
                    refused = error.read().decode('utf-8', 'replace')
                except Exception:
                    refused = ''
                if refused:
                    state['response'] = refused[:4000]
                status = error.code if isinstance(error.code, int) else 0
                state['state'] = 'rejected' if 400 <= status < 500 else 'unknown'
                atomic_json(manifest, state)
                raise RuntimeError('Submission refused HTTP '+str(error.code)+': '+refused[:400])
            except Exception:
                if state['state'] == 'submitting':
                    state['state'] = 'unknown'
                atomic_json(manifest, state)
                raise
            state.update(task_id=task_id, state='submitted')
            atomic_json(manifest, state)
        deadline = time.monotonic() + v['poll_timeout_sec']
        while not state.get('url'):
            if time.monotonic() >= deadline:
                raise RuntimeError('Poll timeout; rerun video to resume known task')
            response = json.loads(self.request('GET', state['base']+'/result/'+state['task_id'], headers))
            data = response.get('data') or {}
            status = data.get('status')
            if status == 'SUCCESS':
                state.update(url=data['results'][0]['url'], state='ready')
                atomic_json(manifest, state)
            elif status == 'FAILED':
                state['state'] = 'failed'
                atomic_json(manifest, state)
                raise RuntimeError('Remote task failed')
            else:
                time.sleep(v['poll_interval_sec'])
        attempt = directory / state['attempt']
        attempt.mkdir(parents=True, exist_ok=True)
        temp = attempt / 'download.mp4'
        # Result URLs may point to third-party storage: never forward the gateway token.
        temp.write_bytes(self.request('GET', state['url']))
        self.media(temp, video=True, expected_duration=duration)
        publish(temp, output)
        state.update(state='complete', output=str(output), output_hash=file_hash(output))
        atomic_json(manifest, state)
        print('Complete (format QC only): '+str(output), flush=True)


def main(root=None, argv=None):
    parser = argparse.ArgumentParser(description='Approved, resumable media pipeline')
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('voice', 'video', 'qc', 'hash', 'approve', 'reconcile'):
        p = sub.add_parser(name)
        p.add_argument('--台本', required=True)
        p.add_argument('--only')
        if name in ('hash', 'approve'):
            p.add_argument('--stage', choices=('voice','video'), required=True)
        if name == 'approve':
            p.add_argument('--hash', required=True, help='Exact hash printed by hash; approve one segment at a time for video')
        if name == 'video':
            p.add_argument('--new-attempt', action='store_true')
        if name == 'reconcile':
            p.add_argument('--task-id', required=True, help='Provider-confirmed task ID for unknown submission; never creates a new task')
    args = parser.parse_args(argv)
    pipeline = Pipeline(root or Path.cwd())
    try:
        script, segments = pipeline.script(args.台本, args.only)
        with pipeline.lock(script['episode']):
            if args.command in ('hash','approve'):
                hashes = [(s, pipeline.fingerprint(args.stage, script, s)) for s in segments]
                if args.command == 'approve' and any(h != args.hash for _,h in hashes):
                    raise RuntimeError('Supplied hash does not match selected input(s)')
                for seg, fingerprint in hashes:
                    if args.command == 'approve':
                        pipeline.approval(script, seg, args.stage, fingerprint, approve=True)
                    print(seg['id']+' '+fingerprint)
                return 0
            if args.command == 'reconcile':
                if len(segments) != 1:
                    raise RuntimeError('Reconcile requires --only one segment')
                path = pipeline.state_root / script['episode'] / segments[0]['id'] / 'task.json'
                state = read_json(path)
                if state['state'] not in ('unknown','submitting'):
                    raise RuntimeError('Only unknown submission can be reconciled')
                state.update(task_id=args.task_id, state='submitted')
                atomic_json(path, state)
                return 0
            # Preflight ALL selected media and approvals before any paid call.
            pipeline.ffmpeg()
            if args.command == 'video':
                pipeline.secret('autodl_token')
            elif args.command == 'voice' and pipeline.voice_config(script).get('provider') != 'edge_tts':
                # edge-tts 免密钥；只有豆包路径需要密钥。
                pipeline.secret('doubao_api_key')
            for seg in segments:
                if args.command in ('voice','video'):
                    pipeline.approval(script, seg, args.command, pipeline.fingerprint(args.command, script, seg))
                if args.command in ('video','qc'):
                    pipeline.media(pipeline.audio(script,seg))
            for seg in segments:
                if args.command == 'voice':
                    pipeline.voice(script,seg)
                elif args.command == 'video':
                    pipeline.video(script,seg,args.new_attempt)
                else:
                    path = pipeline.root / '03-视频素材' / ('正式分段_'+script['episode']) / (seg['id']+'_'+seg.get('label',seg['id'])+'.mp4')
                    pipeline.media(path,video=True,expected_duration=pipeline.media(pipeline.audio(script,seg)))
                    print('Format QC passed (speech/lip sync not verified): '+str(path), flush=True)
            return 0
    except (RuntimeError, ValueError, KeyError, OSError) as error:
        print('ERROR: '+str(error), file=sys.stderr)
        return 1
