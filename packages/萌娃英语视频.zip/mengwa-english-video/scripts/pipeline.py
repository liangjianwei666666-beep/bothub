#!/usr/bin/env python3
"""Portable entry point; reads cwd/config.json and writes outputs under cwd."""
import sys
from pipeline_core import main

if __name__ == '__main__':
    sys.exit(main())
