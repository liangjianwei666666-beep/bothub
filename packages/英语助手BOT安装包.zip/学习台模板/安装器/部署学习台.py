#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""为一名学生部署独立英语学习台，拒绝覆盖已有目录。
用法：python3 部署学习台.py --grade '七年级上'
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.dirname(HERE)
PKG = os.path.dirname(TEMPLATE)
MODULES = ['01-知识点可视化', '02-游戏练习', '03-阶段测试与报告', '04-错题卡',
           '05-思辨', '06-元认知', '07-科创项目']


def copy_tree_no_overwrite(src, dst):
    os.makedirs(dst, exist_ok=True)
    for entry in os.listdir(src):
        s = os.path.join(src, entry)
        d = os.path.join(dst, entry)
        if os.path.isdir(s):
            copy_tree_no_overwrite(s, d)
        else:
            target = d
            if os.path.exists(target):
                stem, ext = os.path.splitext(entry)
                n = 2
                while os.path.exists(os.path.join(dst, '%s_%d%s' % (stem, n, ext))):
                    n += 1
                target = os.path.join(dst, '%s_%d%s' % (stem, n, ext))
            shutil.copy2(s, target)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--grade', required=True, help='如 七年级上、八年级下、高一上')
    ap.add_argument('--root', default='', help='已确认的目标绝对路径；未提供时使用当前用户桌面的英语-学生版')
    ap.add_argument('--launcher', default='英语导航', help='桌面入口名称；默认英语导航')
    ap.add_argument('--theme', default='纸墨', help='主题：纸墨/海蓝/森林/樱粉/糖果/墨绿/夜读')
    a = ap.parse_args()
    grade = a.grade.strip()
    if not grade:
        sys.exit('年级不能为空。')
    root = os.path.abspath(os.path.expanduser(a.root or os.path.join('~/Desktop', '英语-学生版')))
    if os.path.exists(root):
        sys.exit('目标目录已存在，拒绝覆盖：%s。请先检查后另选空目录。' % root)
    if not os.path.isdir(TEMPLATE):
        sys.exit('安装包缺少 学习台模板：' + TEMPLATE)

    os.makedirs(root)
    try:
        for name in os.listdir(TEMPLATE):
            src = os.path.join(TEMPLATE, name)
            if name in ('产出', '00-迁移包'):
                continue
            dst = os.path.join(root, name)
            if os.path.isdir(src):
                copy_tree_no_overwrite(src, dst)
            else:
                shutil.copy2(src, dst)
        pkg_dest = os.path.join(root, '00-迁移包')
        os.makedirs(pkg_dest, exist_ok=True)
        for name in ('英语年级知识库.json', '英语助手指令.md', '安装说明.md'):
            src = os.path.join(TEMPLATE, '00-迁移包', name)
            if os.path.isfile(src):
                shutil.copy2(src, os.path.join(pkg_dest, name))
        out_root = os.path.join(TEMPLATE, '产出')
        if os.path.isdir(out_root):
            for module in MODULES:
                src = os.path.join(out_root, module)
                if os.path.isdir(src):
                    copy_tree_no_overwrite(src, os.path.join(root, module))
        settings = {
            '年级': grade, '册次': '', '教材版本': '', '课本目录': [], '学生姓名': '',
            '来源': '英语助手 BOT 安装包',
            '状态': '已初始化，等待学生确认册次、教材版本与课本目录'
        }
        with open(os.path.join(root, '年级设置.json'), 'w', encoding='utf-8') as f:
            json.dump(settings, f, ensure_ascii=False, indent=2)
            f.write('\n')
        script = os.path.join(root, '建站.py')
        cmd = [sys.executable, script, '--root', root, '--subject', '英语', '--theme', a.theme]
        label = a.launcher or ('英语导航_' + grade)
        if sys.platform == 'darwin':
            cmd += ['--launcher', label]
        subprocess.run(cmd, check=True)
        updater = os.path.join(root, '_更新导航.py')
        if os.path.isfile(updater):
            subprocess.run([sys.executable, updater], check=True)
        missing = [m + '/index.html' for m in MODULES
                   if not os.path.isfile(os.path.join(root, m, 'index.html'))]
        if not os.path.isfile(os.path.join(root, 'index.html')):
            missing.append('index.html')
        if missing:
            sys.exit('部署后缺文件：' + ', '.join(missing))
        print('学习台目录：' + root)
        print('入口页：' + os.path.join(root, 'index.html'))
        print('桌面入口：' + (os.path.join(os.path.expanduser('~/Desktop'), label + '.app') if sys.platform == 'darwin' else '当前系统不创建 macOS .app'))
        for module in MODULES:
            count = sum(1 for f in os.listdir(os.path.join(root, module)) if f != 'index.html')
            print('%s：%d 个产出文件' % (module, count))
        print('自检：总入口与七板块 index.html 均存在')
        print('未验证：团队 Bot 是否创建、Instructions/工作目录是否成功设置；需主 Bot 使用自身权限核验。')
    except Exception:
        print('部署中断；部分目录已保留供检查，不自动删除：' + root, file=sys.stderr)
        raise


if __name__ == '__main__':
    main()
