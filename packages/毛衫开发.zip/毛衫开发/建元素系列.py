#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成「元素延展 · 开衫/背心系列」企划 JSON。
每个元素先登记它在现有款里的复用次数（数据），再挂到一个四维为 0 的格上（结构）。
锚点按标题从 styles.json 里查真值，不手写价格。
"""
import json
import os

BASE = os.path.dirname(os.path.abspath(__file__))
ITEMS = json.load(open(os.path.join(BASE, 'styles.json'), encoding='utf-8'))['items']
CAT_CN = {'PULLOVER- SWEATER': '套头', 'CARDIGAN SWEATER': '开衫', 'JACKET': '夹克'}
COL_CN = {'CREW': '圆领', 'V-NECK': 'V 领', 'POLO': 'POLO 领', 'TIE': '系带领', 'SHAWL': '披肩领',
          'BOAT- BATEAU': '一字领', 'ASYMMETRICAL': '不对称', 'TURTLE': '高领'}
SLV_CN = {'LONG SLEEVE': '长袖', 'SHORT SLEEVE': '短袖', '3-4 SLEEVE': '3/4 袖', 'SLEEVELESS': '无袖'}
DEC_CN = {'SOLID': '纯色', 'EMBELLISHED COMBO': '局部珠饰', 'LACE': '蕾丝'}


def anchor(sub):
    for r in ITEMS:
        if sub.lower() in r['title'].lower():
            return {'t': r['title'], 'cat': CAT_CN[r['category']],
                    'collar': COL_CN.get(r['collar'], r['collar']),
                    'sleeve': SLV_CN.get(r['sleeve'], r['sleeve']),
                    'deco': DEC_CN.get(r['decoration'], r['decoration']),
                    'price': r['price']}
    raise SystemExit('找不到锚点: ' + sub)


D = [
 dict(code='S1', name_cn='假两件系带领开衫', name_en='Twofer Tie-Neck Cardigan',
  cell=['CARDIGAN SWEATER', 'TIE', 'LONG SLEEVE', 'SOLID'], color='IVORY', band='核心',
  price_band='$69–79（建议零售带）', element='假两件（twofer）',
  element_note='现有 14 款假两件全部是套头，开衫 0 款；2026 季在售 9 款，是品牌复刻最多的结构之一。',
  anchors=[anchor('Long Sleeve Beaded Collar Twofer'), anchor('Long Sleeve Drop Shoulder Twofer')],
  change='把假两件的衬衫下摆与袖口搬进开衫，领口改成可系带，门襟单排扣。',
  why='假两件是品牌验证过最多次的结构，但 14 款全在套头。开衫做假两件的难点是前襟开合会打断「衬衫露出的层次」——所以把层次放在下摆和袖口，而不是门襟，门襟就能正常开合。',
  why_empty='这一格空的不是需求，是工艺：两种面料（针织+衬衫布）缩率不一致，下摆容易起浪，很多厂不愿接。',
  fabric='大身粘胶 65–85% + 尼龙；下摆与袖口拼衬衫料 100% 棉或棉涤混。两种料需先做同缩率测试，以打样确认为准。',
  craft='可拆卸系带（固定点加固）；下摆拼衬衫布；袖口翻边；门襟单排扣。',
  risk='两料缩率不一致会起浪——必须先做缩率测试再出样；系带固定点需加固，否则受力断。',
  diff='现有假两件 14 款全部是套头，没有开衫。',
  pairing='敞开穿在现有纯色套头外；系上带子可单穿当上衣。',
  en=dict(name_en='Twofer Tie-Neck Cardigan',
   line='The structure the brand repeats most — finally in a cardigan.',
   band_en='Core · $69–79',
   fabric='Body viscose 65–85% with nylon; shirting panels at hem and cuff in 100% cotton or a cotton blend. Both cloths need a shrink test before sampling.',
   craft='Detachable tie (reinforced anchor points); shirt fabric at hem and cuff; turn-back cuffs; single-breasted placket.',
   risk='Two cloths with different shrinkage will ripple — shrink test first, sampling second; the tie anchor must be reinforced.',
   diff='All 14 existing twofer styles are pullovers. There is no cardigan.',
   pairing='Worn open over an existing solid pullover; tied on its own as a top.')),

 dict(code='S2', name_cn='扇贝边短袖开衫', name_en='Scalloped Short-Sleeve Cardigan',
  cell=['CARDIGAN SWEATER', 'CREW', 'SHORT SLEEVE', 'SOLID'], color='BLACK', band='入门',
  price_band='$55–65（建议零售带）', element='扇贝钩边（scallop）',
  element_note='现有 13 款带扇贝边，其中 11 款在套头、只有 2 款在开衫；2026 季在售 9 款。',
  anchors=[anchor('Short Sleeve Scalloped Trim Polo'), anchor('Short Sleeve Open Pointelle Scalloped')],
  change='门襟与下摆做扇贝钩边，圆领、短袖、单排扣，去掉 polo 领。',
  why='扇贝边是品牌反复用的收口语言，但 13 款里 11 款在套头，开衫只有 2 款。短袖开衫是夏天的薄叠穿层，正好接住已买过短袖套头的客群。',
  why_empty='这一格空是因为短袖开衫售卖窗口短：单穿像内搭、外穿又太薄，所以品牌做得少。它的价值在叠穿，不在单穿。',
  fabric='粘胶 60–80% + 尼龙，细针距。钩边密度需打样确认，避免卷边。',
  craft='下摆与门襟扇贝钩边；扣眼避开扇贝峰；袖口窄罗纹。',
  risk='钩边卷边；扣眼与扇贝峰冲突是版房最常见返工点。',
  diff='现有扇贝边在套头或 polo 领开衫上，没有圆领短袖扇贝开衫。',
  pairing='搭现有象牙色短袖套头；敞开当薄外套穿。',
  en=dict(name_en='Scalloped Short-Sleeve Cardigan',
   line='A summer layering piece, built on the trim the range already sells.',
   band_en='Entry · $55–65',
   fabric='Viscose 60–80% with nylon, fine gauge. Crochet trim density to be confirmed on sampling to stop the edge curling.',
   craft='Scalloped crochet at hem and placket; buttonholes set clear of the scallop peaks; narrow rib cuffs.',
   risk='Curling trim; buttonholes clashing with scallop peaks is the most common correction at the pattern stage.',
   diff='Existing scalloped styles are pullovers or polo-collar cardigans. No crew short-sleeve scalloped cardigan.',
   pairing='Over an existing ivory short-sleeve pullover; worn open as a light layer.')),

 dict(code='S3', name_cn='流苏下摆一字领开衫', name_en='Fringe-Hem Bateau Cardigan',
  cell=['CARDIGAN SWEATER', 'BOAT- BATEAU', 'LONG SLEEVE', 'SOLID'], color='BROWN', band='核心',
  price_band='$69–79（建议零售带）', element='流苏（fringe）',
  element_note='现有 7 款带流苏，全部是套头，开衫 0 款；2026 季在售 6 款。',
  anchors=[anchor('Fringe Trim Textured Polo'), anchor('Short Sleeve Fringe Hem Cable')],
  change='流苏只做前片下摆，后片平收；一字领、长袖、前襟三粒扣。',
  why='流苏 7 款全在套头，开衫没有。开衫加流苏的风险是下摆拉拽门襟——所以只放前片、后片不放，重心前移但不塌肩。',
  why_empty='一字领本身吃肩宽、适配差，加上流苏拉拽，两个风险叠加，所以这格一直空。做法上必须先解决肩线。',
  fabric='粘胶 65–85% + 尼龙；流苏用同料裁条，垂坠感需打样确认。',
  craft='同料流苏裁条；后片下摆平收；一字领贴边；三粒扣。',
  risk='一字领肩宽适配差（退货主因）+ 流苏拉拽门襟，两个问题必须一起解。',
  diff='现有流苏全在套头下摆或袖口，没有开衫。',
  pairing='敞开配现有黑色或象牙内搭。',
  en=dict(name_en='Fringe-Hem Bateau Cardigan',
   line='Fringe moved to the front hem only, so the placket still hangs straight.',
   band_en='Core · $69–79',
   fabric='Viscose 65–85% with nylon; fringe cut from the same cloth. Drape to be confirmed on sampling.',
   craft='Self-fabric fringe strips at the front hem only; back hem plain; bound bateau neckline; three-button front.',
   risk='Bateau shoulders are a fit-sensitive area (a returns driver), and fringe adds pull on the placket — both have to be solved together.',
   diff='Existing fringe sits on pullover hems or cuffs. No cardigan.',
   pairing='Worn open over existing black or ivory layers.')),

 dict(code='S4', name_cn='珍珠领边 3/4 袖开衫', name_en='Pearl-Edge Three-Quarter Cardigan',
  cell=['CARDIGAN SWEATER', 'CREW', '3-4 SLEEVE', 'EMBELLISHED COMBO'], color='NAVY', band='核心',
  price_band='$79–89（建议零售带）', element='珍珠领边（pearly collar）',
  element_note='现有 16 款带珍珠工艺，是品牌最强 DNA；2026 季在售 12 款；其中开衫 5 款。',
  anchors=[anchor('Long Sleeve Pearly Peter Pan Collar'), anchor('Long Sleeve Pearly Collar Cardigan')],
  change='珍珠只走领圈细边一圈（不铺满、不加蝴蝶结），3/4 袖，圆领。',
  why='珍珠是品牌最强的元素，但开衫的珍珠不是整圈铺就是配蝴蝶结，工费堆得高。改成「一圈细边」保住了识别度，同时把工费压下来，能进核心价带。',
  why_empty='现有 13 款 3/4 袖里没有一件开衫——3/4 袖口收边容易松，加上领圈要承珠重，两个工艺点叠在一起就没人做。',
  fabric='粘胶 65–85% + 尼龙；领圈需加牵条承重，配比以打样确认为准。',
  craft='领圈单圈珍珠；3/4 袖口罗纹；扣位避开珍珠。',
  risk='珍珠洗涤脱落；领圈被珠重拉长——需要牵条＋加固缝。',
  diff='现有珍珠开衫是整圈珠或蝴蝶结，没有 3/4 袖款。',
  pairing='搭现有圆领长袖套头，敞开穿。',
  en=dict(name_en='Pearl-Edge Three-Quarter Cardigan',
   line='The range signature, reduced to one clean row of pearls.',
   band_en='Core · $79–89',
   fabric='Viscose 65–85% with nylon; the neckline needs a stabilizing tape to carry the bead weight. Blend confirmed on sampling.',
   craft='Single row of pearls at the neckline; three-quarter rib cuffs; buttons set clear of the pearls.',
   risk='Pearls lifting in wash; neckline stretching under bead weight — tape plus reinforced stitching.',
   diff='Existing pearl cardigans use a full collar of beads or a bow. No three-quarter sleeve version.',
   pairing='Worn open over an existing crew long-sleeve pullover.')),

 dict(code='S5', name_cn='蕾丝拼接 V 领开衫', name_en='Lace-Inset V-Neck Cardigan',
  cell=['CARDIGAN SWEATER', 'V-NECK', 'LONG SLEEVE', 'LACE'], color='GREEN', band='进阶',
  price_band='$89–99（建议零售带）', element='蕾丝内嵌（lace inset）',
  element_note='现有 10 款用蕾丝，其中开衫 5 款、且都是领口内层 inset；2026 季在售 9 款。',
  anchors=[anchor('Long Sleeve Lace Inset Collared Cardigan'), anchor('Long Sleeve Lace Twofer')],
  change='蕾丝片放到前襟两侧（整片拼接），V 领、长袖，内里加衬。',
  why='蕾丝是品牌在用的工艺，但现有开衫的蕾丝都做在「领口内层」这一小块。把蕾丝移到门襟两侧，是同一工艺的第二种用法，工艺风险不增加，但视觉效果完全不同。',
  why_empty='这一格空是因为蕾丝拼片在门襟受开合拉扯，拼缝容易起皱——所以必须加衬并把拼缝位置避开扣位。',
  fabric='底布粘胶 65–85% + 尼龙；蕾丝片用尼龙网布。拼缝牢固度与衬布选择需打样确认。',
  craft='前襟两侧蕾丝拼片；V 领门襟贴条；内里加衬；扣位避开设缝。',
  risk='拼缝起皱、蕾丝勾丝；衬布选错会让门襟发硬。',
  diff='现有蕾丝开衫只做领口内层 inset，没有门襟整片拼接。',
  pairing='内搭现有纯色套头，V 领露出层次。',
  en=dict(name_en='Lace-Inset V-Neck Cardigan',
   line='The same lace the range already uses — moved from the collar to the placket.',
   band_en='Elevated · $89–99',
   fabric='Ground viscose 65–85% with nylon; lace panels in nylon mesh. Seam strength and lining choice confirmed on sampling.',
   craft='Lace panels down both front edges; V-neck placket facing; lined; buttonholes placed clear of the seams.',
   risk='Puckering at the lace seam; snagging; the wrong lining will stiffen the placket.',
   diff='Existing lace cardigans use an inset at the collar only. No full placket panel.',
   pairing='Over an existing solid pullover, with the V showing the layer beneath.')),

 dict(code='V1', name_cn='绞花 POLO 开襟背心', name_en='Cable Polo Vest',
  cell=['CARDIGAN SWEATER', 'POLO', 'SLEEVELESS', 'SOLID'], color='BEIGE', band='核心',
  price_band='$59–69（建议零售带）', element='绞花（cable knit）',
  element_note='现有 12 款绞花，其中开衫 7 款、套头 5 款；2026 季在售 11 款。开襟背心 0 款。',
  anchors=[anchor('Tie Neck Whipstitch Cable Knit'), anchor('Long Sleeve Cable Knit Twofer')],
  change='绞花只做前身，侧缝平针；POLO 领座、无袖、前襟三粒扣。',
  why='绞花是品牌最强肌理，但 12 款全是有袖的套头或开衫。开襟背心是叠穿核心单品：一件能套在衬衫、twofer、连衣裙外面的东西，客群不用换穿衣习惯。',
  why_empty='开襟背心在这个品牌里几乎没做过（7 款背心里只有 2 款是开襟系带），空的原因是它更依赖内搭销售，单卖不动。',
  fabric='粘胶 60–80% + 尼龙；绞花组织需确认纱支与花型饱满度，以打样为准。',
  craft='前身绞花、侧缝平针；POLO 领座定型；三粒扣；袖窿包边。',
  risk='绞花吃纱（用量比平针高，需工厂核）；门襟与绞花对位。',
  diff='现有绞花 7 款开衫都有袖，没有开襟背心。',
  pairing='套在现有假两件套头外；或配同色系针织做整套。',
  en=dict(name_en='Cable Polo Vest',
   line='The range\'s strongest stitch, in the one layer it has never been cut as.',
   band_en='Core · $59–69',
   fabric='Viscose 60–80% with nylon; cable definition depends on yarn count and will be confirmed on sampling.',
   craft='Cable on the front body only, plain at the side seams; shaped polo collar; three buttons; bound armholes.',
   risk='Cable eats yarn (higher consumption than plain — the mill must quote); placket and cable must align.',
   diff='The seven existing cable cardigans all have sleeves. There is no open vest.',
   pairing='Over an existing twofer pullover; or as a set with same-tone knit bottoms.')),

 dict(code='V2', name_cn='镂空 V 领背心', name_en='Pointelle V-Neck Vest',
  cell=['PULLOVER- SWEATER', 'V-NECK', 'SLEEVELESS', 'SOLID'], color='GREY', band='入门',
  price_band='$49–59（建议零售带）', element='镂空点纹（pointelle）',
  element_note='现有 8 款镂空点纹，2026 季在售 6 款；无袖版只有 2 款（绣花、蕾丝各 1），纯色镂空背心 0 款。',
  anchors=[anchor('Open Knit Pointelle Scalloped Polo'), anchor('Flared Hem Open Pointelle')],
  change='镂空只做前身，后身密织；V 领贴边、下摆罗纹、无袖。',
  why='镂空点纹 8 款全在套头，无袖只有绣花和蕾丝两种。纯色镂空背心是把已验证的肌理放进最容易叠穿的品类，入门价带，试错成本最低。',
  why_empty='镂空背心空的原因是「透」——必须解决内衣问题才卖得动，所以要么加内衬、要么明确配同色打底。',
  fabric='粘胶 60–80% + 尼龙；镂空孔形与回弹需打样确认。',
  craft='前身镂空、后身密织；V 领贴边；下摆罗纹。',
  risk='镂空透内衣（需搭配说明或加薄衬）；孔形洗后变形。',
  diff='现有无袖套头是绣花 2 款、纯色 2 款，没有镂空。',
  pairing='内搭现有纯色短袖或长袖套头；也可以配吊带。',
  en=dict(name_en='Pointelle V-Neck Vest',
   line='A proven stitch in the lowest-risk category: an entry-price layering vest.',
   band_en='Entry · $49–59',
   fabric='Viscose 60–80% with nylon; stitch openness and recovery to be confirmed on sampling.',
   craft='Pointelle at the front body, plain at the back; V-neck binding; ribbed hem.',
   risk='Open stitch can show the underlayer — needs a styling note or a light lining; stitch distortion after wash.',
   diff='Existing sleeveless pullovers are embroidered (2) or solid (2). No pointelle.',
   pairing='Over an existing solid short or long-sleeve pullover; or a camisole.')),

 dict(code='V3', name_cn='水钻扇贝圆领背心', name_en='Rhinestone Scallop Vest',
  cell=['PULLOVER- SWEATER', 'CREW', 'SLEEVELESS', 'EMBELLISHED COMBO'], color='RED', band='进阶',
  price_band='$79–89（建议零售带）', element='水钻 + 扇贝（rhinestone / scallop）',
  element_note='现有 6 款水钻，其中 3 款是同一「水钻扇贝」长袖款的不同配色；2026 季在售 5 款。背心 0 款。',
  anchors=[anchor('Long Sleeve Rhinestone Scalloped Sweater In Black'), anchor('Short Sleeve Scalloped Trim Polo')],
  change='水钻沿圆领与下摆做扇贝排钻；无袖、收腰剪裁；去掉长袖。',
  why='水钻扇贝是唯一被品牌做成三个配色复刻的装饰组合（黑、红、灰），说明这个装饰方向被验证过。但只做过长袖。做成背心，珠工面积减半，单件成本降下来，是这条装饰线里最容易试的形态。',
  why_empty='背心做珠饰空的原因是领口要承钻重、且无袖让肩部结构更吃工艺，工厂报价容易超。',
  fabric='粘胶 65–85% + 尼龙；领口需加衬承重；具体以打样确认。',
  craft='原创扇贝排钻图（不沿用现有花稿）；领口加衬；下摆收边；收腰省道。',
  risk='钻脱落、领口承重变形、不可烘干；排钻图必须重画，不能沿用现有款。',
  diff='现有水钻扇贝全是长袖，没有背心。',
  pairing='敞开配现有开衫；或单穿配同色下装。',
  en=dict(name_en='Rhinestone Scallop Vest',
   line='The one embellishment the brand repeated in three colourways — cut as a vest so the bead cost halves.',
   band_en='Elevated · $79–89',
   fabric='Viscose 65–85% with nylon; the neckline needs an interlining for bead weight. Confirmed on sampling.',
   craft='New scallop rhinestone artwork (not adapted from existing styles); interlined neckline; bound hem; waist darts.',
   risk='Stone loss; neckline distortion under weight; no tumble drying. The artwork must be redrawn.',
   diff='Existing rhinestone scallop styles are all long sleeve. No vest.',
   pairing='Over an existing cardigan; or alone with same-tone bottoms.')),
]

plan = {
 'date': '2026-11-03',
 'series': '元素延展 · 开衫/背心',
 'why_today': ('这一批不是按空位抽的，是按「品牌自己复刻过什么」反推的：'
   '先数 2026 季在售款里每个细节出现了几次（珍珠领边 12、绞花 11、蝴蝶结 11、假两件 9、扇贝 9、蕾丝内层 9、镂空 6、流苏 6、水钻 5），'
   '再看这些细节落在哪些品类——于是发现假两件 14 款全在套头、开衫 0；流苏 7 款全在套头、开衫 0；扇贝 13 款里 11 款在套头。'
   '这些是品牌用真金白银复刻过的元素，只是没有进开衫/背心。所以本批 8 款：5 开衫 + 3 背心，每款挂一个已验证元素，'
   '每款都落在四维为 0 的格上，互不撞领型、不撞主色。背心 3 款是刻意的低试错：它依赖叠穿销售，单卖不动，所以只给 3 个不同价带。'),
 'designs': D,
}
os.makedirs(os.path.join(BASE, '今日企划'), exist_ok=True)
p = os.path.join(BASE, '今日企划', '企划_元素延展_2026-11-03.json')
json.dump(plan, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('已写入', p, '共', len(D), '款')
