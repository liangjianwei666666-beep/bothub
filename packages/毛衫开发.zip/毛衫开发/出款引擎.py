#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""毛衫延伸开发 · 出款引擎

职责（只做机器该做的）：
  1) 把 110 个参考款拆成 品类×领型×袖型×工艺 四维格，数出每格现有款数
  2) 算「空位 / 可做变体 / 拥挤」，并按邻接度给空位排序（邻接越多＝越可做）
  3) 按品类配额＋查重，抽出今日候选，避开已出款台账
  4) 给每个候选配 2 个基因来源锚点（同维度最多的参考款），供写卡用
  5) 校验并渲染今日企划 HTML

不做：写文案、定成本、承诺销量。文案由 Bot 按候选写。

用法：
  python3 出款引擎.py gap                       # 看空位池 Top 40
  python3 出款引擎.py pick --n 6                # 抽今日候选 -> 候选_YYYY-MM-DD.json
  python3 出款引擎.py check --date YYYY-MM-DD   # 校验当日企划（查重/配比/价格带）
  python3 出款引擎.py render --date YYYY-MM-DD  # 渲染 今日企划_YYYY-MM-DD.html
"""
import argparse
import collections
import datetime
import json
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
STYLES = os.path.join(BASE, 'styles.json')
LEDGER = os.path.join(BASE, '已出款台账.json')
OUTDIR = os.path.join(BASE, '今日企划')

CATS = ['PULLOVER- SWEATER', 'CARDIGAN SWEATER', 'JACKET']
CAT_CN = {'PULLOVER- SWEATER': '套头', 'CARDIGAN SWEATER': '开衫', 'JACKET': '夹克'}
COLLARS = ['CREW', 'V-NECK', 'POLO', 'TIE', 'SHAWL', 'BOAT- BATEAU', 'ASYMMETRICAL', 'TURTLE']
COLLAR_CN = {'CREW': '圆领', 'V-NECK': 'V 领', 'POLO': 'POLO 领', 'TIE': '系带领', 'SHAWL': '披肩领',
             'BOAT- BATEAU': '一字领', 'ASYMMETRICAL': '不对称', 'TURTLE': '高领'}
SLEEVES = ['LONG SLEEVE', 'SHORT SLEEVE', '3-4 SLEEVE', 'SLEEVELESS', 'CAP SLEEVE', 'DOLMAN SLEEVE']
SLEEVE_CN = {'LONG SLEEVE': '长袖', 'SHORT SLEEVE': '短袖', '3-4 SLEEVE': '3/4 袖', 'SLEEVELESS': '无袖',
             'CAP SLEEVE': '盖袖', 'DOLMAN SLEEVE': '斗篷袖'}
DECOS = ['SOLID', 'PRINT- PATTERN', 'EMBELLISHED COMBO', 'EMBROIDERED', 'LACE', 'ALLOVER EMBELLISHMENT']
DECO_CN = {'SOLID': '纯色', 'PRINT- PATTERN': '图案', 'EMBELLISHED COMBO': '局部珠饰',
           'EMBROIDERED': '刺绣', 'LACE': '蕾丝', 'ALLOVER EMBELLISHMENT': '全幅珠饰'}

# 色彩优先级：站在「现有款不拥挤」的一侧。WHITE 现有 31 款，排最后。
COLOR_ORDER = ['NAVY', 'GREEN', 'RED', 'BROWN', 'BLACK', 'IVORY', 'GREY', 'BEIGE', 'BLUSH', 'PINK', 'BLUE', 'YELLOW', 'WHITE']
COLOR_CN = {'NAVY': '午夜蓝', 'GREEN': '苔绿', 'RED': '酒红', 'BROWN': '棕', 'BLACK': '黑',
            'IVORY': '象牙', 'GREY': '灰', 'BEIGE': '米', 'BLUSH': '藕粉', 'PINK': '粉',
            'BLUE': '蓝', 'YELLOW': '黄', 'WHITE': '白'}

# 价格带（建议零售，美元）。现有 price 多为折扣价，只能当风向，不能当定价依据。
BANDS = [(45, 59, '入门'), (60, 79, '核心'), (80, 99, '进阶'), (100, 160, '形象')]


def norm(v):
    v = (v or '').strip()
    return '' if v == 'NOT APPLICABLE' else v


def load_items():
    with open(STYLES, encoding='utf-8') as f:
        d = json.load(f)
    items = []
    for r in d['items']:
        items.append({
            'title': r['title'], 'handle': r['handle'], 'category': r['category'],
            'collar': norm(r['collar']), 'sleeve': norm(r['sleeve']), 'decoration': norm(r['decoration']),
            'colorGroup': r['colorGroup'], 'price': r['price'], 'retail': r['retail'],
            'mainFabric': r['mainFabric'], 'silhouette': norm(r['silhouette']), 'desc': r['desc'],
        })
    return items, d['meta']


def cell_of(r):
    return (r['category'], r['collar'], r['sleeve'], r['decoration'])


def fiber_family(main_fabric):
    for k in ['VISCOSE', 'POLYESTER', 'COTTON', 'NYLON', 'ACRYLIC', 'WOOL', 'CASHMERE']:
        if k in (main_fabric or ''):
            return k
    return 'OTHER'


def build_space(items):
    """四维格计数 + 各维度边际计数"""
    cell = collections.Counter()
    for r in items:
        if not r['collar']:
            continue  # 领型缺失的 8 款不参与格子计算，避免造出假空位
        cell[cell_of(r)] += 1
    marg = {}
    for f in ['category', 'collar', 'sleeve', 'decoration', 'colorGroup']:
        marg[f] = collections.Counter(r[f] for r in items if not (f == 'collar' and not r['collar']))
    return cell, marg


def neighbors(cell):
    """改一个维度后仍在现有款里出现过的格子数 = 邻接度（越高越可做）"""
    cat, col, slv, dec = cell
    n = 0
    for v in CATS:
        if v != cat and (v, col, slv, dec) in SPACE:
            n += 1
    for v in COLLARS:
        if v != col and (cat, v, slv, dec) in SPACE:
            n += 1
    for v in SLEEVES:
        if v != slv and (cat, col, v, dec) in SPACE:
            n += 1
    for v in DECOS:
        if v != dec and (cat, col, slv, v) in SPACE:
            n += 1
    return n


def gap_pool(items):
    """所有 0 款格子，排序后返回"""
    occupied = set(SPACE)
    pool = []
    for cat in CATS:
        for col in COLLARS:
            for slv in SLEEVES:
                for dec in DECOS:
                    c = (cat, col, slv, dec)
                    if c in occupied:
                        continue
                    nb = neighbors(c)
                    if nb == 0:
                        continue  # 四邻全空＝结构上没支撑，先不进池
                    pool.append({'cell': c, 'neighbors': nb})
    # 排序：邻接度高＝可做；同分时夹克（最薄品类）与有工艺的优先
    def key(x):
        cat, col, slv, dec = x['cell']
        thin = {'JACKET': 3, 'CARDIGAN SWEATER': 1, 'PULLOVER- SWEATER': 0}[cat]
        craft = 2 if dec != 'SOLID' else 0
        return (-(x['neighbors'] * 2 + thin + craft), cat, col, slv, dec)
    pool.sort(key=key)
    return pool


def risk_flags(cell):
    """写卡时要主动交代的可行性疑点"""
    cat, col, slv, dec = cell
    flags = []
    if cat == 'JACKET' and slv in ('SLEEVELESS', 'DOLMAN SLEEVE'):
        flags.append('夹克配非常规袖型，结构需确认')
    if col == 'TURTLE' and cat == 'CARDIGAN SWEATER':
        flags.append('高领+开衫，领圈与前襟交接难')
    if col == 'SHAWL' and cat == 'PULLOVER- SWEATER':
        flags.append('披肩领套头：穿脱口要大，易松垮')
    if col == 'BOAT- BATEAU' and cat == 'CARDIGAN SWEATER':
        flags.append('一字领开衫：肩宽适配差，退货风险')
    if dec == 'ALLOVER EMBELLISHMENT':
        flags.append('全幅珠饰：成本高、克重重、不可水洗')
    if dec == 'LACE' and cat == 'JACKET':
        flags.append('夹克蕾丝拼接：牢固度与里布需确认')
    if slv == '3-4 SLEEVE':
        flags.append('3/4 袖口收边易松')
    return flags


def _pack(r, label):
    return {'label': label, 'title': r['title'], 'price': r['price'],
            'cat': CAT_CN[r['category']], 'collar': COLLAR_CN.get(r['collar'], r['collar']),
            'sleeve': SLEEVE_CN.get(r['sleeve'], r['sleeve']),
            'deco': DECO_CN.get(r['decoration'], r['decoration']),
            'color': r['colorGroup'], 'fabric': r['mainFabric']}


def anchors_for(cell, items):
    """按维度给锚点：领型来源 / 品类来源 / 工艺来源。比「共享维度最多」更好用，
    因为它指明这一款到底借了谁的那一个基因。"""
    cat, col, slv, dec = cell
    valid = [r for r in items if r['collar']]
    out = []

    def pick_first(pred):
        return next((r for r in valid if pred(r)), None)

    a = (pick_first(lambda r: r['collar'] == col and r['category'] == cat)
         or pick_first(lambda r: r['collar'] == col))
    if a:
        out.append(_pack(a, '领型来源'))
    b = (pick_first(lambda r: r['category'] == cat and r['decoration'] == dec and r['sleeve'] == slv)
         or pick_first(lambda r: r['category'] == cat and r['decoration'] == dec)
         or pick_first(lambda r: r['category'] == cat and r['collar'] == col))
    if b and all(x['title'] != b['title'] for x in out):
        out.append(_pack(b, '品类/工艺来源'))
    if dec != 'SOLID':
        c = pick_first(lambda r: r['decoration'] == dec and r['category'] == cat)
        if c and all(x['title'] != c['title'] for x in out):
            out.append(_pack(c, '工艺来源'))
    return out[:3]


# 空位为什么可能是空的：判断，不是数据。写卡时必须交代其中一条。
WHY_EMPTY = {
    ('JACKET',): '夹克只有 7 款，是三个品类里最薄的；价带高、开发投入大，所以格子空得多',
    ('TURTLE',): '高领在场合装里容易和珠宝/项链冲突，客群接受度偏保守',
    ('SHAWL',): '披肩领套头穿脱口必须开大，容易显松垮',
    ('BOAT- BATEAU',): '一字领吃肩宽，尺码适配差，退货率高',
    ('ASYMMETRICAL',): '斜襟对位难、裁剪耗损大，量产一致性差',
    ('TIE',): '系带领在场合装里偏「减龄」，和品牌成熟客群有张力',
    ('ALLOVER EMBELLISHMENT',): '整件珠饰工时长、克重重、不可水洗，客诉风险高',
    ('LACE',): '蕾丝拼接的拼缝与牢固度是量产的坑',
    ('EMBROIDERED',): '刺绣版费高、拉扯门襟易起皱，小批量不划算',
    ('3-4 SLEEVE',): '3/4 袖口收边容易松，且秋冬客群更偏长袖',
    ('SLEEVELESS',): '无袖针织在秋冬交付里售卖窗口短',
}


def why_empty_of(cell):
    out = []
    if cell[0] == 'JACKET':
        out.append(WHY_EMPTY[('JACKET',)])
    for k in [(cell[1],), (cell[3],), (cell[2],)]:
        if k in WHY_EMPTY:
            out.append(WHY_EMPTY[k])
    return '；'.join(out[:2]) if out else '该组合在现有 110 款里没有出现，原因未明，需判断'


def load_ledger():
    if not os.path.exists(LEDGER):
        return {'issued': []}
    with open(LEDGER, encoding='utf-8') as f:
        return json.load(f)


def save_ledger(led):
    with open(LEDGER, 'w', encoding='utf-8') as f:
        json.dump(led, f, ensure_ascii=False, indent=1)


def quota(n):
    """品类配额，按现有结构 63/40/7 的比例分，夹克保底 1 款（n>=5 时）"""
    if n <= 2:
        return {'PULLOVER- SWEATER': n, 'CARDIGAN SWEATER': 0, 'JACKET': 0}
    q = {'PULLOVER- SWEATER': 0, 'CARDIGAN SWEATER': 0, 'JACKET': 1 if n >= 5 else 0}
    rest = n - q['JACKET']
    q['PULLOVER- SWEATER'] = int(round(rest * 0.6))
    q['CARDIGAN SWEATER'] = rest - q['PULLOVER- SWEATER']
    return q


def band_for(cell, index):
    """按 品类×工艺 给建议零售带，不按序号硬铺。
    现有款 price 是折扣价（套头 25.97-69.99 / 开衫 31.99-55 / 夹克 55-149），
    所以这里给的是「建议零售带」，不是定价结论。"""
    cat, dec = cell[0], cell[3]
    if cat == 'JACKET':
        return '形象' if dec != 'SOLID' else '进阶'
    if cat == 'CARDIGAN SWEATER':
        return '形象' if dec == 'ALLOVER EMBELLISHMENT' else '核心'
    if dec in ('LACE', 'ALLOVER EMBELLISHMENT'):
        return '进阶'
    if cell[2] in ('SHORT SLEEVE', 'SLEEVELESS', 'CAP SLEEVE') and dec == 'SOLID':
        return '入门'
    return '核心' 


def pick(n):
    items, meta = load_items()
    pool = gap_pool(items)
    led = load_ledger()
    issued_cells = set(tuple(x['cell']) for x in led['issued'])

    q = quota(n)
    take = collections.Counter()
    colors = []
    picks = []
    color_order = COLOR_ORDER[:]

    for cand in pool:
        if len(picks) >= n:
            break
        cat = cand['cell'][0]
        if take[cat] >= q[cat]:
            continue
        if cand['cell'] in issued_cells:
            continue
        # 图案款每批最多 1 款：图案原创成本最高，也最容易和现有 39 款撞风格
        if cand['cell'][3] == 'PRINT- PATTERN' and any(p['cell'][3] == 'PRINT- PATTERN' for p in picks):
            continue
        # 同批次不重复领型；色彩不重复
        if any(p['cell'][1] == cand['cell'][1] for p in picks):
            continue
        color = next((c for c in color_order if c not in colors), None)
        if color is None:
            break
        idx = len(picks)
        picks.append({
            'cell': list(cand['cell']),
            'neighbors': cand['neighbors'],
            'anchors': anchors_for(cand['cell'], items),
            'risk_flags': risk_flags(cand['cell']),
            'why_empty': why_empty_of(cand['cell']),
            'suggest_color': color,
            'suggest_band': band_for(cand['cell'], idx),
            'cell_count': 0,
        })
        take[cat] += 1
        colors.append(color)

    return picks, {'meta': meta, 'quota': {CAT_CN[k]: v for k, v in q.items()}}


def do_gap(top):
    items, _ = load_items()
    pool = gap_pool(items)
    print('空位池（4 维全空且有邻接支撑）共 %d 格，按可做度排序前 %d：' % (len(pool), top))
    print('%-7s %-9s %-8s %-10s %s' % ('品类', '领型', '袖型', '工艺', '邻接'))
    for c in pool[:top]:
        cat, col, slv, dec = c['cell']
        print('%-7s %-9s %-8s %-10s %d  %s' % (cat[:6], col[:8], slv[:7], dec[:9], c['neighbors'],
                                               ' / '.join(risk_flags(c['cell'])) or ''))
    print()
    print('拥挤区（现有 ≥2 款，别碰）：')
    for cat in CATS:
        for col in COLLARS:
            for slv in SLEEVES:
                for dec in DECOS:
                    v = SPACE.get((cat, col, slv, dec), 0)
                    if v >= 2:
                        print('  %s %s %s %s = %d' % (CAT_CN[cat], COLLAR_CN[col], SLEEVE_CN[slv], DECO_CN[dec], v))


def do_pick(n, date):
    picks, ctx = pick(n)
    out = {'date': date, 'count': len(picks), 'ctx': ctx, 'picks': picks}
    os.makedirs(OUTDIR, exist_ok=True)
    path = os.path.join(OUTDIR, '候选_%s.json' % date)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print('今日候选 %d 款 -> %s' % (len(picks), path))
    for p in picks:
        cat, col, slv, dec = p['cell']
        print('\n[%s/%s/%s/%s] 邻接%d 建议色=%s 建议带=%s' % (
            cat, col, slv, dec, p['neighbors'], p['suggest_color'], p['suggest_band']))
        for a in p['anchors']:
            print('   锚点: %s (%s %s %s %s) $%.2f' % (a['title'][:52], a['cat'], a['collar'], a['sleeve'], a['deco'], a['price']))
        if p['risk_flags']:
            print('   疑点: ' + '；'.join(p['risk_flags']))


def do_check(date):
    items, _ = load_items()
    data = load_plan(date)
    led = load_ledger()
    issued = set(tuple(x['cell']) for x in led['issued'])
    ok = True
    seen = set()
    print('校验 %s：%d 款' % (date, len(data['designs'])))
    for d in data['designs']:
        c = tuple(d['cell'])
        cnt = SPACE.get(c, 0)
        dup_batch = c in seen
        dup_ledger = c in issued
        state = 'PASS'
        if cnt != 0:
            state = 'FAIL 与现有款撞格(%d)' % cnt
        elif dup_batch:
            state = 'FAIL 本批内重复'
        elif dup_ledger:
            state = 'FAIL 与台账重复'
        if state != 'PASS':
            ok = False
        seen.add(c)
        print('  %-4s %-8s %-7s %-6s %-9s %s' % (d['code'], d['name_cn'], CAT_CN[c[0]], COLLAR_CN.get(c[1], c[1]),
                                                 DECO_CN.get(c[3], c[3]), state))
    # 价格带与色彩覆盖
    bands = set(d['band'] for d in data['designs'])
    colors = [d['color'] for d in data['designs']]
    crafts = set(d['cell'][3] for d in data['designs'])
    cats = set(d['cell'][0] for d in data['designs'])
    print('  价格带覆盖: %s' % ' / '.join(sorted(bands)))
    print('  色彩分布: %s' % ', '.join('%s×%d' % (COLOR_CN.get(c, c), colors.count(c)) for c in sorted(set(colors))))
    print('  工艺种类: %d  品类: %s' % (len(crafts), ' '.join(CAT_CN[c] for c in cats)))
    checks = [
        ('全部为真空位', ok),
        ('价格带>=3档', len(bands) >= 3),
        ('主色不重复', len(colors) == len(set(colors))),
        ('品类>=2类', len(cats) >= 2),
        ('工艺>=3种', len(crafts) >= 3),
    ]
    print()
    for name, res in checks:
        print('  [%s] %s' % ('OK' if res else 'XX', name))
    return ok and all(r for _, r in checks)


def load_plan(date):
    path = os.path.join(OUTDIR, '企划_%s.json' % date)
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def esc(s):
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def do_render(date):
    """渲染交给 渲染.py，引擎只管选题与校验。"""
    import 渲染
    渲染.ITEMS = 渲染.load_items()
    print('内部版 ->', 渲染.render_internal(date))
    print('客户版 ->', 渲染.render_client(date))


def color_cn(c):
    return COLOR_CN.get(c, c)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd', choices=['gap', 'pick', 'check', 'render', 'commit'])
    ap.add_argument('--n', type=int, default=6)
    ap.add_argument('--date', default=datetime.date.today().isoformat())
    ap.add_argument('--top', type=int, default=40)
    args = ap.parse_args()

    global SPACE
    items, meta = load_items()
    SPACE, MARG = build_space(items)

    if args.cmd == 'gap':
        do_gap(args.top)
    elif args.cmd == 'pick':
        do_pick(args.n, args.date)
    elif args.cmd == 'check':
        ok = do_check(args.date)
        sys.exit(0 if ok else 1)
    elif args.cmd == 'render':
        do_render(args.date)
    elif args.cmd == 'commit':
        data = load_plan(args.date)
        led = load_ledger()
        have = set(tuple(x['cell']) for x in led['issued'])
        added = 0
        for d in data['designs']:
            c = tuple(d['cell'])
            if c in have:
                continue
            led['issued'].append({'date': args.date, 'code': d['code'], 'name': d['name_cn'],
                                  'cell': list(c), 'color': d['color']})
            added += 1
        save_ledger(led)
        print('台账 +%d 条，累计 %d 条 -> %s' % (added, len(led['issued']), LEDGER))


if __name__ == '__main__':
    main()
