#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""客户版英文渲染：客户是美国品牌，英文版才是对外的那个版本。
数字全部从 styles.json 现算，与中文客户版共用同一份 企划_日期.json。

用法：python3 渲染_en.py --date 2026-11-03
"""
import argparse
import os

import 渲染

BASE = 渲染.BASE
OUT = 渲染.OUT
esc = 渲染.esc

CAT_EN = {'PULLOVER- SWEATER': 'pullover', 'CARDIGAN SWEATER': 'cardigan', 'JACKET': 'jacket'}
COLLAR_EN = {'CREW': 'crew collar', 'V-NECK': 'V-neck', 'POLO': 'polo collar', 'TIE': 'tie neck',
             'SHAWL': 'shawl collar', 'BOAT- BATEAU': 'bateau neck', 'ASYMMETRICAL': 'asymmetric neckline',
             'TURTLE': 'turtleneck'}
SLEEVE_EN = {'LONG SLEEVE': 'long sleeve', 'SHORT SLEEVE': 'short sleeve', '3-4 SLEEVE': 'three-quarter sleeve',
             'SLEEVELESS': 'sleeveless', 'CAP SLEEVE': 'cap sleeve', 'DOLMAN SLEEVE': 'dolman sleeve'}
DECO_EN = {'SOLID': 'solid', 'PRINT- PATTERN': 'print', 'EMBELLISHED COMBO': 'placed embellishment',
           'EMBROIDERED': 'embroidery', 'LACE': 'lace', 'ALLOVER EMBELLISHMENT': 'allover beading'}
COLOR_EN = {'NAVY': 'navy', 'GREEN': 'moss green', 'RED': 'garnet', 'BROWN': 'cocoa', 'BLACK': 'black',
            'IVORY': 'ivory', 'WHITE': 'white', 'GREY': 'grey', 'BEIGE': 'beige', 'BLUE': 'blue',
            'PINK': 'pink', 'BLUSH': 'blush', 'YELLOW': 'yellow', 'RED ': 'garnet'}


def gap_sentence_en(cell, f):
    cat, col, slv, dec = cell
    collar = COLLAR_EN.get(col, col)
    s = 'The %s range holds %d styles, %d of them %s. ' % (CAT_EN[cat], f['cat_n'], f['collar_n'], collar)
    s += 'Combined as <em>%s + %s + %s</em>, the count is currently 0.' % (
        collar, SLEEVE_EN.get(slv, slv), DECO_EN.get(dec, dec))
    return s


def card_en(d):
    cat, col, slv, dec = d['cell']
    e = d['en']
    f = 渲染.facts_of(d['cell'], 渲染.ITEMS)
    facts = [
        ('Category · collar · sleeve', '%s · %s · %s' % (CAT_EN[cat], COLLAR_EN.get(col, col), SLEEVE_EN.get(slv, slv))),
        ('Craft', DECO_EN.get(dec, dec)),
        ('Colour', COLOR_EN.get(d['color'], d['color'])),
        ('Retail suggestion', e['band_en']),
        ('Fabric direction', e['fabric']),
        ('Sampling watch-outs', e['risk']),
    ]
    fact_html = ''.join('<p><span>%s</span>%s</p>' % (esc(k), esc(v)) for k, v in facts)
    notes = [
        ('Craft detail', e['craft']),
        ('Difference from your current range', e['diff']),
        ('How it groups', e['pairing']),
    ]
    note_html = ''.join('<li><b>%s:</b> %s</li>' % (esc(k), esc(v)) for k, v in notes)
    return '''<article class="card">
  <div class="chead">
    <div><p class="code">%s</p><h3>%s</h3><p class="en">%s</p></div>
    <div class="price">Retail suggestion<b>%s</b></div>
  </div>
  <p class="one">%s</p>
  %s
  <div class="gap">%s</div>
  <div class="facts">%s</div>
  <ul class="notes">%s</ul>
</article>''' % (esc(d['code']), esc(e['name_en']), esc(DECO_EN.get(dec, dec).capitalize() + ' knitwear direction'), esc(e['band_en']),
                 esc(e['line']),
                 ('<figure class="shot"><img src="%s" alt="%s"></figure>' % (esc(渲染.img_for(d['code'])), esc(e['name_en']))) if 渲染.img_for(d['code']) else '',
                 gap_sentence_en(d['cell'], f), fact_html, note_html)


def render(date, out_name=None):
    渲染.ITEMS = 渲染.load_items()
    plan = 渲染.load_plan(date)
    tpl = open(os.path.join(BASE, '模板_客户_en.html'), encoding='utf-8').read()
    label = plan.get('series_en') or ''
    if not label:
        cand = plan.get('series') or os.path.basename(date).replace('.json', '')
        label = cand if all(ord(c) < 128 for c in cand) else 'Knitwear Extension'
    html = tpl.replace('__DATE__', label).replace('__CARDS__', '\n'.join(card_en(d) for d in plan['designs']))
    path = os.path.join(OUT, out_name or ('Client_Proposal_%s.html' % os.path.basename(date).replace('.json', '')))
    open(path, 'w', encoding='utf-8').write(html)
    return path


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--date', required=True)
    ap.add_argument('--tag', default='')
    a = ap.parse_args()
    out = 'Client_Proposal_%s_%s.html' % (a.tag, a.date) if a.tag else None
    print('English client deck ->', render(a.date, out))
