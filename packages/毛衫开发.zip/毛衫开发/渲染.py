#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""渲染两个版本：
  内部版  —— 给用户自己看：空位、邻接、空位成因、打样风险、口径边界
  客户版  —— 给客户看：结构盘点（数字全部从数据现算，不写形容词）、方向、面料工艺、打样注意
两版共用同一份 企划_日期.json，不各自维护文案。

用法：
  python3 渲染.py --date 2026-11-03            # 两版都出
  python3 渲染.py --date 2026-11-03 --only client
"""
import argparse
import json
import os

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, '今日企划')

CAT_CN = {'PULLOVER- SWEATER': '套头', 'CARDIGAN SWEATER': '开衫', 'JACKET': '夹克'}
COLLAR_CN = {'CREW': '圆领', 'V-NECK': 'V 领', 'POLO': 'POLO 领', 'TIE': '系带领', 'SHAWL': '披肩领',
             'BOAT- BATEAU': '一字领', 'ASYMMETRICAL': '不对称', 'TURTLE': '高领'}
SLEEVE_CN = {'LONG SLEEVE': '长袖', 'SHORT SLEEVE': '短袖', '3-4 SLEEVE': '3/4 袖', 'SLEEVELESS': '无袖',
             'CAP SLEEVE': '盖袖', 'DOLMAN SLEEVE': '斗篷袖'}
DECO_CN = {'SOLID': '纯色', 'PRINT- PATTERN': '图案', 'EMBELLISHED COMBO': '局部珠饰',
           'EMBROIDERED': '刺绣', 'LACE': '蕾丝', 'ALLOVER EMBELLISHMENT': '全幅珠饰'}
COLOR_CN = {'NAVY': '午夜蓝', 'GREEN': '苔绿', 'RED': '酒红', 'BROWN': '棕', 'BLACK': '黑',
            'IVORY': '象牙', 'GREY': '灰', 'BEIGE': '米', 'BLUSH': '藕粉', 'PINK': '粉',
            'BLUE': '蓝', 'YELLOW': '黄', 'WHITE': '白'}


def esc(s):
    return (str(s) if s is not None else '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def color_cn(c):
    return COLOR_CN.get(c, c)


IMG_DIR = os.path.join(OUT, 'shots')


def img_for(code):
    """找 <CODE>-*.png；没有图就返回空串，页面照常出。"""
    if not os.path.isdir(IMG_DIR):
        return ''
    for f in sorted(os.listdir(IMG_DIR)):
        if f.upper().startswith(code.upper() + '-') and f.lower().endswith(('.png', '.jpg')):
            return 'shots/' + f
    return ''


def load_items():
    with open(os.path.join(BASE, 'styles.json'), encoding='utf-8') as f:
        return json.load(f)['items']


def plan_path_of(date):
    if date.endswith('.json'):
        return date
    return os.path.join(OUT, '企划_%s.json' % date)


def load_plan(date):
    with open(plan_path_of(date), encoding='utf-8') as f:
        return json.load(f)


def facts_of(cell, items):
    """结构盘点：数字全部现算，客户版和内部版共用"""
    cat, col, slv, dec = cell
    same_cat = [r for r in items if r['category'] == cat]
    same_cat_collar = [r for r in same_cat if (r['collar'] or '').strip() == col]
    same_cat_deco = [r for r in same_cat if (r['decoration'] or '').strip() == dec]
    exact = [r for r in items if r['category'] == cat and (r['collar'] or '').strip() == col
             and (r['sleeve'] or '').strip() == slv and (r['decoration'] or '').strip() == dec]
    colors = [r['colorGroup'] for r in same_cat]
    prices = [r['price'] for r in same_cat if r['price']]
    return {
        'cat_n': len(same_cat),
        'collar_n': len(same_cat_collar),
        'deco_n': len(same_cat_deco),
        'exact_n': len(exact),
        'min_price': min(prices) if prices else 0,
        'max_price': max(prices) if prices else 0,
        'top_color': max(set(colors), key=colors.count) if colors else '',
        'top_color_n': colors.count(max(set(colors), key=colors.count)) if colors else 0,
    }


def gap_sentence(cell, f):
    cat, col, slv, dec = cell
    parts = []
    parts.append('贵司%s共 %d 款' % (CAT_CN[cat], f['cat_n']))
    if f['collar_n'] == 0:
        parts.append('其中%s为 0 款' % COLLAR_CN.get(col, col))
    else:
        parts.append('其中%s %d 款' % (COLLAR_CN.get(col, col), f['collar_n']))
    parts.append('「%s + %s + %s」这一组合目前仍是 0' % (
        COLLAR_CN.get(col, col), SLEEVE_CN.get(slv, slv), DECO_CN.get(dec, dec)))
    return '，'.join(parts) + '。'


def internal_card(d):
    cat, col, slv, dec = d['cell']
    f = facts_of(d['cell'], ITEMS)
    anchors = ''.join(
        '<li><b>%s</b>：%s <span class="m">%s %s %s %s · $%.2f</span></li>' % (
            esc(a.get('label', '参考')), esc(a['t']), esc(a['cat']), esc(a['collar']),
            esc(a['sleeve']), esc(a['deco']), a['price'])
        for a in d['anchors'])
    rows = [
        ('基因来源', '<ul>%s</ul>' % anchors),
        ('改了什么', esc(d['change'])),
        ('为什么这样改', esc(d['why'])),
        ('空位成因', '<span class="warntext">%s</span>' % esc(d['why_empty'])),
        ('结构盘点', esc('现有：%s %d 款 / %s %d 款 / 四维组合 %d 款；同品类价格 %.2f–%.2f' % (
            COLLAR_CN.get(col, col), f['collar_n'], DECO_CN.get(dec, dec), f['deco_n'],
            f['exact_n'], f['min_price'], f['max_price']))),
        ('目标价带', esc(d['price_band'])),
        ('面料建议', esc(d['fabric'])),
        ('工艺要点', esc(d['craft'])),
        ('打样风险', esc(d['risk'])),
        ('搭配逻辑', esc(d['pairing'])),
        ('与现有款差异', esc(d['diff'])),
    ]
    trs = ''.join('<tr><th>%s</th><td%s>%s</td></tr>' % (
        k, ' class="warn"' if k == '空位成因' else '', v) for k, v in rows)
    shot = img_for(d['code'])
    figure = '<figure class="shot"><img src="%s" alt="%s"></figure>' % (esc(shot), esc(d['name_cn'])) if shot else ''
    return '''<article class="card">
  <div class="col"><div>
  <header><span class="code">%s</span><h3>%s</h3></header>
  <p class="en">%s</p>
  <p class="genes">%s · %s · %s · %s · 主色 %s</p>
  </div>%s</div>
  <table>%s</table>
</article>''' % (esc(d['code']), esc(d['name_cn']), esc(d['name_en']),
                 esc(CAT_CN[cat]), esc(COLLAR_CN.get(col, col)), esc(SLEEVE_CN.get(slv, slv)),
                 esc(DECO_CN.get(dec, dec)), esc(color_cn(d['color'])), figure, trs)


def client_card(d):
    cat, col, slv, dec = d['cell']
    f = facts_of(d['cell'], ITEMS)
    facts = [
        ('品类 / 领型 / 袖型', '%s · %s · %s' % (CAT_CN[cat], COLLAR_CN.get(col, col), SLEEVE_CN.get(slv, slv))),
        ('工艺', DECO_CN.get(dec, dec)),
        ('主色', color_cn(d['color'])),
        ('建议零售带', d['price_band']),
        ('面料方向', d['fabric']),
        ('打样注意', d['risk']),
    ]
    fact_html = ''.join('<p><span>%s</span>%s</p>' % (esc(k), esc(v)) for k, v in facts)
    return '''<article class="card">
  <div class="chead">
    <div><p class="code">%s</p><h3>%s</h3><p class="en">%s</p></div>
    <div class="price">建议零售带<b>%s</b></div>
  </div>
  <p class="one">%s</p>
  %s
  <div class="gap">%s</div>
  <div class="facts">%s</div>
  <ul class="notes">
    <li><b>工艺要点：</b>%s</li>
    <li><b>与贵司现有款的区别：</b>%s</li>
    <li><b>搭配建议：</b>%s</li>
  </ul>
</article>''' % (esc(d['code']), esc(d['name_cn']), esc(d['name_en']), esc(d['band']),
                 esc(d['client_line']),
                 ('<figure class="shot"><img src="%s" alt="%s"></figure>' % (esc(img_for(d['code'])), esc(d['name_cn']))) if img_for(d['code']) else '',
                 gap_sentence(d['cell'], f), fact_html,
                 esc(d['craft']), esc(d['diff']), esc(d['pairing']))


def render_internal(date, out_name=None):
    plan = load_plan(date)
    tpl = open(os.path.join(BASE, '模板_内部.html'), encoding='utf-8').read()
    cards = '\n'.join(internal_card(d) for d in plan['designs'])
    colors = []
    for d in plan['designs']:
        colors.append(d['color'])
    color_story = '、'.join('%s %d 款' % (color_cn(c), colors.count(c)) for c in dict.fromkeys(colors))
    chips = ''.join('<span class="chip">%s</span>' % esc(x) for x in [
        '本批 %d 款' % len(plan['designs']),
        '色彩故事：' + color_story,
        '价格带 ' + ' / '.join(sorted(set(d['band'] for d in plan['designs']))),
        '全部为数据真空位',
    ])
    label = plan.get('series') or os.path.basename(date).replace('.json', '')
    html = (tpl.replace('__DATE__', label).replace('__COUNT__', str(len(plan['designs'])))
               .replace('__CHIPS__', chips).replace('__CARDS__', cards)
               .replace('__WHY_TODAY__', esc(plan['why_today'])))
    path = os.path.join(OUT, out_name or ('今日企划_%s.html' % os.path.basename(date).replace('.json', '')))
    open(path, 'w', encoding='utf-8').write(html)
    return path


def render_client(date, out_name=None):
    plan = load_plan(date)
    tpl = open(os.path.join(BASE, '模板_客户.html'), encoding='utf-8').read()
    cards = '\n'.join(client_card(d) for d in plan['designs'])
    label = plan.get('series') or os.path.basename(date).replace('.json', '')
    html = tpl.replace('__DATE__', label).replace('__CARDS__', cards)
    path = os.path.join(OUT, out_name or ('客户推款包_%s.html' % os.path.basename(date).replace('.json', '')))
    open(path, 'w', encoding='utf-8').write(html)
    return path


ITEMS = load_items()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--date', required=True)
    ap.add_argument('--only', choices=['internal', 'client'])
    ap.add_argument('--tag', default='')
    a = ap.parse_args()
    tag = a.tag
    if a.only != 'client':
        print('内部版 ->', render_internal(a.date, '系列_%s_%s.html' % (tag or '出款', a.date) if tag else None))
    if a.only != 'internal':
        print('客户版 ->', render_client(a.date, '客户推款包_%s_%s.html' % (tag, a.date) if tag else None))


if __name__ == '__main__':
    main()
