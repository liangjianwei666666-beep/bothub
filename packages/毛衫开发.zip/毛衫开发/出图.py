#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按企划 JSON 批量出款图（TelangpuAI）。

- 提示词从企划数据自动拼：品类/领型/袖型/工艺/主色 + 电商 ghost-mannequin 规格
- 不用模型人、不套品牌名，只描述结构，避免照搬参考款
- 默认 low 先试构图，选中再用 --quality high / max 出片
- 同一款重跑会覆盖同名文件，不产生垃圾文件

用法：
  python3 出图.py --codes S1,S2 --quality low
  python3 出图.py --codes S1 --quality high
  python3 出图.py --all --quality low          # 整个企划全出
"""
import argparse
import json
import os
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
IMG = os.path.expanduser('~/.dsh/bot/workspace/bin/img')
OUT = os.path.join(BASE, '今日企划', 'shots')

CAT_EN = {'PULLOVER- SWEATER': 'pullover sweater', 'CARDIGAN SWEATER': 'cardigan sweater', 'JACKET': 'knit jacket'}
COLLAR_PHRASE = {'CREW': 'crew neckline', 'V-NECK': 'V neckline', 'POLO': 'polo collar with narrow stand',
                 'TIE': 'tie-neck closure with detachable tie', 'SHAWL': 'shawl collar',
                 'BOAT- BATEAU': 'bateau neckline', 'ASYMMETRICAL': 'single asymmetric shoulder line',
                 'TURTLE': 'double-layer fold-over turtleneck'}
SLEEVE_PHRASE = {'LONG SLEEVE': 'long sleeves', 'SHORT SLEEVE': 'short sleeves',
                 '3-4 SLEEVE': 'three-quarter sleeves', 'SLEEVELESS': 'sleeveless, no sleeves',
                 'CAP SLEEVE': 'cap sleeves', 'DOLMAN SLEEVE': 'dolman sleeves'}
CRAFT_PHRASE = {'SOLID': 'plain knit, no pattern', 'PRINT- PATTERN': 'jacquard pattern, original artwork',
                'EMBELLISHED COMBO': 'placed pearl and rhinestone embellishment at the neckline and hem',
                'EMBROIDERED': 'tonal embroidery at the front', 'LACE': 'lace panels inserted down the front',
                'ALLOVER EMBELLISHMENT': 'fully beaded surface, allover beadwork'}
COLOR_PHRASE = {'NAVY': 'deep navy', 'GREEN': 'moss green', 'RED': 'garnet red', 'BROWN': 'cocoa brown',
                'BLACK': 'black', 'IVORY': 'ivory', 'GREY': 'heather grey', 'BEIGE': 'beige',
                'WHITE': 'off-white', 'BLUE': 'dusty blue', 'PINK': 'soft pink', 'BLUSH': 'blush'}


def newest_plan():
    d = os.path.join(BASE, '今日企划')
    if not os.path.isdir(d):
        return ''
    files = [os.path.join(d, f) for f in os.listdir(d) if f.startswith('企划_') and f.endswith('.json')]
    return max(files, key=os.path.getmtime) if files else ''


def prompt_for(d):
    cat, col, slv, dec = d['cell']
    parts = [
        "E-commerce ghost-mannequin product photo of a women's occasion knitwear %s." % CAT_EN[cat],
        "Structure: %s, %s, %s." % (COLLAR_PHRASE.get(col, col.lower()),
                                    SLEEVE_PHRASE.get(slv, slv.lower()),
                                    'open front with buttons' if cat == 'CARDIGAN SWEATER' else 'pull-on'),
        "Craft: %s." % CRAFT_PHRASE.get(dec, dec.lower()),
        "Colour: %s." % COLOR_PHRASE.get(d['color'], d['color'].lower()),
        "Detail: %s." % d['en']['craft'].split(';')[0].strip().rstrip('.'),
        "Upright, front view, no model, no hanger, subtle body shape inside the garment.",
        "Soft studio lighting, clean warm-white seamless background.",
        "Crisp knit texture visible, luxury contemporary womenswear lookbook style, high detail.",
    ]
    return ' '.join(parts)


def run_one(d, quality, model, size):
    os.makedirs(OUT, exist_ok=True)
    out = os.path.join(OUT, '%s-%s.png' % (d['code'], d['name_en'].lower().replace(' ', '-').replace('/', '-')))
    cmd = [IMG, '--prompt', prompt_for(d), '--model', model, '--quality', quality,
           '--size', size, '--out', out]
    r = subprocess.run(cmd, capture_output=True, text=True)
    saved = ''
    for line in (r.stdout or '').splitlines():
        if line.startswith('IMAGE_SAVED='):
            saved = line.split('=', 1)[1]
    if r.returncode != 0 or not saved:
        print('  FAIL %s %s' % (d['code'], (r.stderr or r.stdout or '')[-160:].strip()))
        return None
    print('  OK   %s -> %s' % (d['code'], saved))
    return saved


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plan', default='')
    ap.add_argument('--codes', default='')
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--quality', default='low')
    ap.add_argument('--model', default='gpt-image-2')
    ap.add_argument('--size', default='1024x1536')
    ap.add_argument('--dry-run', action='store_true')
    a = ap.parse_args()

    plan_path = a.plan or newest_plan()
    if not plan_path:
        print('没找到企划 JSON，先跑：python3 出款引擎.py pick --n 6')
        return
    print('企划文件:', plan_path)
    plan = json.load(open(plan_path, encoding='utf-8'))
    want = set(c.strip().upper() for c in a.codes.split(',') if c.strip())
    todo = [d for d in plan['designs'] if a.all or d['code'].upper() in want]
    if not todo:
        print('没有匹配的款，用 --codes 或 --all')
        return
    print('计划出图 %d 款（model=%s quality=%s size=%s）' % (len(todo), a.model, a.quality, a.size))
    if a.dry_run:
        for d in todo:
            print('\n[%s]\n%s' % (d['code'], prompt_for(d)))
        return
    ok = 0
    for d in todo:
        print('[%s] %s' % (d['code'], d['name_en']))
        if run_one(d, a.quality, a.model, a.size):
            ok += 1
    print('\n完成 %d/%d，输出目录 %s' % (ok, len(todo), OUT))


if __name__ == '__main__':
    main()
