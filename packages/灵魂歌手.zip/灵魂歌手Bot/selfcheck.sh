#!/usr/bin/env bash
# 灵魂歌手 Bot · 安装自检
# 用法：bash selfcheck.sh [工作目录]
# 只读检查：不调用任何生成接口、不碰浏览器、不打印密钥值。
set -uo pipefail

PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILLS="${SOUL_SKILLS:-$HOME/.agents/skills}"

# 工作目录：参数 > .last-work > 默认值；再以安装报告里的实际值为准
WORK="${1:-}"
if [ -z "$WORK" ] && [ -f "$PKG/.last-work" ]; then WORK="$(cat "$PKG/.last-work")"; fi
if [ -z "$WORK" ] && [ -f "$HOME/Desktop/音乐创作/.install-last-work" ]; then
  WORK="$(cat "$HOME/Desktop/音乐创作/.install-last-work")"
fi
if [ -z "$WORK" ] && [ -n "${SOUL_WORK:-}" ] && [ -f "$SOUL_WORK/.install-last-work" ]; then
  WORK="$(cat "$SOUL_WORK/.install-last-work")"
fi
if [ -z "$WORK" ]; then WORK="${SOUL_WORK:-$HOME/Desktop/音乐创作}"; fi

REPORT="$WORK/安装报告.json"
if [ -f "$REPORT" ]; then
  W2="$(sed -n 's/.*"workDir": *"\(.*\)".*/\1/p' "$REPORT" | head -1)"
  [ -n "$W2" ] && WORK="$W2"
  if [ -z "${SOUL_SKILLS:-}" ]; then
    S2="$(sed -n 's/.*"skillsDir": *"\(.*\)".*/\1/p' "$REPORT" | head -1)"
    [ -n "$S2" ] && SKILLS="$S2"
  fi
fi

SKILL_LIST="five-platform-publish micro-song lyric-story-mv lyric-loop-video cover-publish ai-video-pipeline autodl-video kie-models character-consistency"

find_node() {
  if command -v node >/dev/null 2>&1; then command -v node; return; fi
  cand="$(ls -d "$HOME"/.nvm/versions/node/*/bin/node /opt/homebrew/bin/node /usr/local/bin/node "$HOME"/.volta/bin/node 2>/dev/null | sort -V | tail -1)"
  if [ -n "$cand" ] && [ -x "$cand" ]; then printf '%s\n' "$cand"; fi
  return 0
}

FAIL=0
FILEFAIL=0
DEPFAIL=0
pass() { printf '  ✓ %s\n' "$*"; }
fail() { printf '  ✗ %s\n' "$1"; FAIL=$((FAIL+1));
         case "${2:-}" in file) FILEFAIL=$((FILEFAIL+1));; dep) DEPFAIL=$((DEPFAIL+1));; esac; }
warn() { printf '  ~ %s\n' "$*"; }

printf '==========================================\n'
printf '  灵魂歌手 Bot · 安装自检\n'
printf '==========================================\n'
printf '  工作目录：%s\n  技能目录：%s\n\n' "$WORK" "$SKILLS"

# ---------- 1. 目录与工作台 ----------
printf '[1/5] 工作目录\n'
for d in projects assets out publish; do
  [ -d "$WORK/$d" ] && pass "目录 $d/" || fail "缺目录 $d/" file
done

BENCH="$WORK/灵魂歌手工作台.html"
if [ -f "$BENCH" ]; then
  pass "工作台存在（$(wc -c < "$BENCH" | tr -d ' ') 字节）"
  if grep -q "window.DB" "$BENCH"; then pass "工作台数据块 window.DB 在"; else fail "工作台缺 window.DB，文件可能损坏"; fi
  EXT="$(grep -oE '<(script|link)[^>]+(src|href)="https?://[^"]+' "$BENCH" | wc -l | tr -d ' ')"
  if [ "$EXT" = "0" ]; then pass "工作台自包含（无外链 script/css）"; else warn "工作台引用 $EXT 个外部资源，离线可能打不开"; fi
else
  fail "缺工作台 $BENCH" file
fi

# ---------- 2. 技能 ----------
printf '\n[2/5] 技能\n'
for s in $SKILL_LIST; do
  if [ -f "$SKILLS/$s/SKILL.md" ]; then
    pass "$s"
  else
    fail "$s 未安装" file
  fi
done
# five-platform-publish 的关键脚本
FP="$SKILLS/five-platform-publish"
if [ -d "$FP" ]; then
  for f in SKILL.md scripts/fill.js scripts/probe.js scripts/selftest.js scripts/lib.js scripts/ego/lib.mjs platforms/xiaohongshu.md; do
    [ -e "$FP/$f" ] && pass "$f" || fail "five-platform-publish 缺 $f" file
  done
  if grep -rq "/Users/" "$FP" 2>/dev/null; then
    warn "five-platform-publish 里仍有原作者绝对路径（说明装的不是分发版）"
  else
    pass "five-platform-publish 无原作者路径残留"
  fi
fi

# ---------- 3. 运行时依赖 ----------
printf '\n[3/5] 运行时\n'
NODE_BIN="$(find_node)"; if [ -n "$NODE_BIN" ]; then pass "node $("$NODE_BIN" -v)（$NODE_BIN）"; else fail "缺 node（发布/生图脚本需要）" dep; fi
if command -v python3 >/dev/null 2>&1; then pass "python3 $(python3 -V 2>&1 | awk '{print $2}')"; else warn "缺 python3（部分流水线脚本需要）"; fi
FF=""
for c in "$HOME/bin/ffmpeg" /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg /usr/bin/ffmpeg; do
  [ -x "$c" ] && FF="$c" && break
done
if [ -n "$FF" ]; then pass "ffmpeg $FF"; else fail "缺 ffmpeg（剪辑/字幕烧录需要）" dep; fi
if [ -d "$WORK/node_modules/playwright-core" ]; then pass "playwright-core 已装（发布脚本可用）"; else
  warn "没有 $WORK/node_modules/playwright-core（发布脚本需要：cd $WORK && npm i playwright-core）"
fi

# ---------- 4. 密钥 ----------
printf '\n[4/5] 密钥（只看有没有，不打印值）\n'
ENVF="$WORK/.env"
if [ -f "$ENVF" ]; then
  pass "$ENVF 存在"
  for k in KIE_API_KEY IMAGE_API_KEY AUTODL_API_KEY; do
    v="$(grep -E "^[[:space:]]*(export )?$k=" "$ENVF" 2>/dev/null | tail -1 | sed 's/^[^=]*=//; s/^["'\'']//; s/["'\'']$//')"
    if [ -n "$v" ]; then
      pass "$k 已填（song.py / adapters 会自动读这个文件）"
    elif [ -n "$(eval "printf '%s' \"\${$k:-}\"")" ]; then
      pass "$k 来自当前 shell 环境变量"
    else
      warn "$k 未填（用到对应环节前再配）"
    fi
  done
else
  warn "没有 $ENVF（出歌/出画面之前必须填）"
fi

# ---------- 5. 安装报告 ----------
printf '\n[5/5] 安装报告\n'
if [ -f "$WORK/安装报告.json" ]; then
  pass "安装报告存在：$WORK/安装报告.json"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$WORK/安装报告.json" <<'PY' && pass "安装报告 JSON 合法" || fail "安装报告 JSON 解析失败" file
import json,sys
json.load(open(sys.argv[1],encoding='utf-8'))
PY
  fi
else
  warn "没有安装报告（可能没跑过 install.sh）"
fi

printf '\n==========================================\n'
if [ "$FAIL" = "0" ]; then
  printf '  自检通过（0 项失败）\n'
  printf '  仍未验证：真实生成接口、五个平台的登录态与发布链路。\n'
  exit 0
else
  printf '  自检有 %s 项失败（文件 %s 项 / 依赖 %s 项）\n' "$FAIL" "$FILEFAIL" "$DEPFAIL"
  if [ "$FILEFAIL" -gt 0 ]; then
    printf '  · 文件类的失败：重跑安装补文件 —— bash "%s/install.sh" --force（会先备份已有技能）\n' "$PKG"
  fi
  if [ "$DEPFAIL" -gt 0 ]; then
    printf '  · 依赖类的失败：装依赖，不要用 --force 治 —— macOS: brew install node ffmpeg；或把已有 node 的 bin 目录加进 PATH\n'
  fi
  printf '  · 密钥类（~）不是失败：用到哪个环节再填 %s 里的对应项。\n' "$WORK/.env"
  exit 1
fi
