---
name: micro-song
description: 做十几二十秒的短歌（梗歌/民谣/生活小窍门/职场吐槽）。当用户说「做首短歌」「十几秒的歌」「梗歌」「民谣短歌」「竞争对手那种」「恭喜发财那种」「生活小窍门那种」「AI 写首歌」时使用。覆盖：Kie 音乐接口（credits/submit/poll）→歌词与 style prompt 写法→生成两版候选→选版→配画面（口型 MV 或静帧）→字幕；含单次计费、唯一 task_id、不得重复提交等成本纪律。
compatibility: macOS, Python 3.9+, Kie API 密钥在 ~/.config/kie/api-key
metadata:
  author: local
  version: "1.0.0"
  derived_from: "恭喜发财_民谣短歌、生活小窍门_短歌、竞争对手_短歌（Kie V6 实测）"
---

# 短歌 · micro-song

**一句话：15–25 秒，一段词，一个梗，一次生成两版候选。**

这类片子是工作区里**单位成本最低、发布最快**的形态：一句梗 + 一把吉他 + 20 秒。

---

## 1. 成本纪律（先看这条）

- 一次提交出 **2 个候选**，**只提交一次**。`music_job.json` 存在就**不许再提交**（会重复扣点）。
- 提交前查余额（`credits`），提交后记一条余额差——**余额差不等于账单明细**，别当成精确账单。
- 实测：恭喜发财 527.5 → 503.5 点，**24 点/次**（两版候选）。以此为预算参考。

```bash
cd 项目/短歌
python3 kie_music.py credits
python3 kie_music.py submit     # 生成 music_job.json（有就不许再跑）
python3 kie_music.py poll       # 成功 → music_result.json
```

本技能的 `scripts/song.py` 就是这套实现的整理版（密钥从 `$KIE_API_KEY`、`~/.config/kie/api-key` 或工作目录的 `.env` 读，不写进 job 文件）。

---

## 2. 歌词写法

- **4–6 行，每行 5–12 字**，总字数控制在 **60 字以内**（20 秒的容量）。
- **前三行正经铺垫，最后一行翻**——这是「竞争对手」「生活小窍门」的共同结构：

```
今天在马路上看到了小学同学
他佝偻着背正在捡矿泉水瓶子
心里很不是滋味
想不到昔日的伙伴
如今竟然成了竞争对手
```

- 最后一行要**押回前文**，落点才响。
- 不要在一句里塞两层意思。

## 3. style prompt 写法（英文，最重要的部分）

结构：**时长+语种+风格 → 人声 → 配器 → BPM → 情绪走向 → 结尾 → 咬字要求 → 禁止项**

```
24-second Mandarin Chinese comedic storytelling micro-song. Warm male melodic
singing, clear natural Mandarin diction, light acoustic guitar, soft bass,
restrained brushed drums, 110 BPM. Start vocals immediately with no intro.
First three lines sound sincerely wistful; fourth line builds anticipation.
Brief dramatic pause before the final punchline, delivered with dry deadpan
comic resignation and a playful final chord. Sing all supplied words exactly
once in order, complete within 23 seconds. No added words or repetition.
```

**三句必写**（否则必出问题）：
1. `Start vocals immediately with no intro` —— 否则前 5 秒是纯伴奏。
2. `Sing all supplied words exactly once in order, no added words or repetition` —— 否则会重复副歌。
3. `complete within {N-1} seconds` —— 否则唱到窗外。

**negative_tags 必写**：`long intro, instrumental break, repeated lyrics, extra lyrics, English adlibs, shouting, long outro`。

## 4. 参数

```json
{
  "custom_mode": true, "instrumental": false, "model": "V6",
  "duration": 20,
  "title": "恭喜发财",
  "lyrics": "...",
  "style": "...",
  "negative_tags": "...",
  "vocal_gender": "m",
  "style_weight": 0.85,
  "weirdness_constraint": 0.15,
  "variety": 1
}
```

- `duration` 设 **20–25**，实际出音会比设定的短 0–2 秒，按真实时长剪。
- `style_weight 0.85` / `weirdness 0.15` 是实测好用的组合（够稳，又不会唱成念白）。

---

## 5. 选版

拿到两版，**先量再听**：
```bash
# 两版的时长/响度对比
for f in audio/kie_option_*.mp3; do echo $f; ffprobe -v error -show_entries format=duration -of csv=p=0 $f; done
```
选版标准（按优先级）：
1. **第一句一开口就唱**（没有冗长前奏）
2. 最后一句**完整唱完**，没有截断
3. 咬字清楚（Mandarin diction）
4. 时长刚好

> ASR 只能辅助定位，同音字会认错；**最终必须人工试听**。

---

## 6. 配画面

| 形态 | 做法 | 成本 |
|---|---|---|
| 纯歌词卡 | 深色底 + 逐句大字 + 波形 | 0 |
| 静帧 MV | 一张主视觉 + Ken Burns + 歌词 | 0 |
| 口型 MV | 关键帧 → H3 用**原曲音频**驱动口型 → 见 `lyric-story-mv` | 高 |
| 循环素材 | 6 秒素材循环 5 轮 + 歌词字幕（见 `lyric-loop-video`） | 0 |

**15 秒 MV 的分镜模板**（恭喜发财实测）：
0–3s 环境中景 → 3–7.7s 缓推到脸 → 7.7–9.4s 切手指拨弦特写 → 9.4–15s 回脸部近景，最后一句苦笑，13.02s 后闭嘴。

---

## 7. 验收

- [ ] 所有歌词**完整唱出来**，没漏没重复
- [ ] 前 1 秒就有声音（没有长前奏）
- [ ] 结尾完整收住（不截断）
- [ ] 字幕与演唱对齐（人工）
- [ ] 成片 −16 LUFS
- [ ] **记录 task_id 与余额差**，不重复提交

**脚本**：`scripts/song.py`（credits / submit / poll 三合一，带重复提交保护）。
