#!/usr/bin/env python3
"""短歌生成：credits / submit / poll（Kie 音乐，带重复提交保护）。

用法（在项目目录里）：
  python3 song.py init --title 标题 --lyrics 歌词.txt --style 风格.txt [--duration 20]
  python3 song.py credits
  python3 song.py submit      # 只允许提交一次
  python3 song.py poll        # 成功后写 music_result.json

密钥：~/.config/kie/api-key（不写进任何 job 文件）。
"""
import argparse
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path.cwd()
JOB = HERE / "music_job.json"
RESULT = HERE / "music_result.json"
CFG = HERE / "music_config.json"
BASE = "https://api.kie.ai"

NEG = ("long intro, instrumental break, repeated lyrics, extra lyrics, "
       "English adlibs, shouting, long outro")


def work_dir():
    """工作目录：$SOUL_WORK，默认 ~/Desktop/音乐创作（安装脚本建的就是它）。"""
    return Path(os.environ.get("SOUL_WORK") or (Path.home() / "Desktop/音乐创作"))


def key():
    k = os.environ.get("KIE_API_KEY")
    if k:
        return k.strip()
    p = Path.home() / ".config/kie/api-key"
    if p.exists():
        v = p.read_text().strip()
        if v:
            return v
    # 分发版新增：读工作目录的 .env（安装脚本生成的那个文件）
    envf = work_dir() / ".env"
    if envf.exists():
        for line in envf.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("#") or "=" not in line:
                continue
            kk, vv = line.split("=", 1)
            if kk.strip().replace("export ", "") == "KIE_API_KEY":
                vv = vv.strip().strip("\"'")
                if vv:
                    return vv
    raise SystemExit(
        "找不到 Kie key：$KIE_API_KEY / ~/.config/kie/api-key / %s 都没有" % (work_dir() / ".env"))


def req(path, body=None):
    k = key()
    r = urllib.request.Request(
        BASE + path, data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "Bearer " + k, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(r, timeout=90) as f:
            d = json.load(f)
    except urllib.error.HTTPError as e:
        msg = e.read().decode()[:300].replace(k, "[REDACTED]")
        raise SystemExit(f"Kie HTTP {e.code}: {msg}")
    if d.get("code") != 200:
        raise SystemExit(f"Kie code {d.get('code')}: {str(d.get('msg',''))[:300]}")
    return d.get("data")


def cmd_init(a):
    lyrics = Path(a.lyrics).read_text(encoding="utf-8").strip()
    style = Path(a.style).read_text(encoding="utf-8").strip()
    lines = [x for x in lyrics.splitlines() if x.strip()]
    cfg = {
        "base_url": BASE,
        "input": {
            "custom_mode": True, "instrumental": False, "model": "V6",
            "duration": a.duration,
            "title": a.title,
            "lyrics": "\n".join(lines),
            "style": style,
            "negative_tags": a.negative or NEG,
            "vocal_gender": a.gender,
            "style_weight": 0.85,
            "weirdness_constraint": 0.15,
            "variety": 1,
        },
    }
    CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    warn = []
    if len(lyrics.replace("\n", "")) > 60:
        warn.append(f"歌词 {len(lyrics.replace(chr(10),''))} 字，20 秒可能唱不完（建议 ≤60）")
    if len(lines) > 6:
        warn.append(f"{len(lines)} 行，建议 4–6 行")
    for must in ("immediately", "exactly once", "within"):
        if must not in style:
            warn.append(f"style 里缺「{must}」——容易出长前奏/重复/超时")
    print(f"写入 {CFG}")
    for w in warn:
        print("⚠️ ", w)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    i = sub.add_parser("init")
    i.add_argument("--title", required=True)
    i.add_argument("--lyrics", required=True, help="歌词 txt，一行一句")
    i.add_argument("--style", required=True, help="英文 style prompt txt")
    i.add_argument("--duration", type=int, default=20)
    i.add_argument("--gender", default="m")
    i.add_argument("--negative", default=None)

    sub.add_parser("credits")
    sub.add_parser("submit")
    sub.add_parser("poll")

    a = ap.parse_args_for = ap.parse_args()

    if a.cmd == "init":
        return cmd_init(a)
    if a.cmd == "credits":
        print("credits:", req("/api/v1/chat/credit"))
        return
    if a.cmd == "submit":
        if JOB.exists():
            raise SystemExit("已存在 music_job.json —— 不要重复提交（会重复扣点）。"
                             "先 poll；确需重做请手动重命名旧 job。")
        if not CFG.exists():
            raise SystemExit(f"缺 {CFG}，先运行 init")
        cfg = json.loads(CFG.read_text(encoding="utf-8"))
        JOB.write_text(json.dumps({"state": "submitting"}, ensure_ascii=False), encoding="utf-8")
        data = req("/api/v1/jobs/createTask",
                   {"model": "ai-music-api/generate", "input": cfg["input"]})
        tid = data.get("taskId") or data.get("task_id")
        if not tid:
            JOB.write_text(json.dumps({"state": "no_task_id", "response": data},
                                      ensure_ascii=False, indent=2), encoding="utf-8")
            raise SystemExit("没拿到 task_id，先检查返回再决定是否重提")
        JOB.write_text(json.dumps({"task_id": tid, "state": "submitted"},
                                  ensure_ascii=False, indent=2), encoding="utf-8")
        print("已提交 task_id =", tid)
        return
    # poll
    if not JOB.exists():
        raise SystemExit("没有 music_job.json，先 submit")
    job = json.loads(JOB.read_text(encoding="utf-8"))
    tid = job.get("task_id")
    if not tid:
        raise SystemExit("job 里没有 task_id，先看 music_job.json")
    data = req("/api/v1/jobs/recordInfo?" + urllib.parse.urlencode({"taskId": tid}))
    state = data.get("state")
    print("state:", state, data.get("failMsg") or "")
    if state == "success":
        raw = data.get("resultJson") or "{}"
        res = json.loads(raw) if isinstance(raw, str) else raw
        RESULT.write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
        items = res.get("data") or []
        print(f"成功 {len(items)} 条候选 → {RESULT}")
        for i, it in enumerate(items, 1):
            print(f"  候选{i}: {it.get('duration')}s  {it.get('audio_url','')[:70]}")


if __name__ == "__main__":
    main()
