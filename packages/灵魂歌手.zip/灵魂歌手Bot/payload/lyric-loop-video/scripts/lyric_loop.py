#!/usr/bin/env python3
"""循环底片 + 歌词字幕片：一条 5–15 秒的循环画面铺满整首歌，歌词逐句上屏。

三条子命令，对应《机器越来越像人_30秒》和《还没完成》踩过的坑：

  lyrics   ASR 识别结果 + 歌词原文 → 逐句时间线 → 字幕.ass + 时间线.json
           带「同音字容错匹配」：不按段数硬对齐（ASR 会幻觉、会跳英文词），
           而是按字做序列匹配，覆盖率低于阈值直接报错，不让字幕错位蒙混过关。
  seam     测循环素材的接点质量：比较尾帧与首帧，给出建议的回绕方式
           （尾部截掉多少帧 + 交叉淡化秒数），并直接生成一份可循环的底片。
  render   底片 -stream_loop → 歌词字幕 → 按歌曲时长出片。

示例
  python3 lyric_loop.py lyrics --asr asr_1.json --lyrics 歌词.txt --out .
  python3 lyric_loop.py seam --video 循环底片.mp4 --out 循环底片_fixed.mp4
  python3 lyric_loop.py render --loop 循环底片_fixed.mp4 --song music/audio/kie_option_1.mp3 \\
        --ass 字幕.ass --out 成片.mp4
"""
import argparse
import json
import difflib
import re
import shutil
import subprocess
import sys
from pathlib import Path

DIRS = ["~/bin", "~/local/bin", "/opt/homebrew/bin", "/usr/local/bin"]


def tool(name):
    p = shutil.which(name)
    if p:
        return p
    for d in DIRS:
        c = Path(d).expanduser() / name
        if c.exists():
            return str(c)
    sys.exit(f"找不到 {name}：export PATH=\"$HOME/bin:$HOME/local/bin:$PATH\"")


CJK = re.compile(r"[\u4e00-\u9fffA-Za-z0-9]")


def clean(s):
    return "".join(CJK.findall(s))


def norm(s):
    """简体 + 常见异体统一，避免 著/着 这类同字不同形拉低覆盖率。"""
    try:
        import zhconv
        s = zhconv.convert(s, "zh-cn")
    except Exception:
        pass
    return s.replace("著", "着")


def read_lyrics(path):
    raw = Path(path).read_text()
    lines = []
    for ln in raw.splitlines():
        ln = ln.strip()
        if not ln or ln.startswith("[") or ln.startswith("#"):
            continue
        lines.append(ln)
    return lines


# ------------------------------------------------------------------ lyrics
def asr_words(asr, drop_title=True):
    """把 ASR 结果摊成 (char, start, end) 序列；滤掉幻觉标题与纯英文 token。"""
    heard, times = "", []
    for seg in asr.get("segments", []):
        text = seg.get("text", "") or ""
        if drop_title and ("一生一世的美好" in text or "字幕by" in text.lower()):
            continue                       # Whisper 在纯音乐上最常见的幻觉
        words = seg.get("words") or [{"word": text, "start": seg.get("start", 0),
                                      "end": seg.get("end", 0)}]
        for w in words:
            tok = (w.get("word") or "").strip()
            if not tok or re.fullmatch(r"[A-Za-z\s'’-]+", tok):
                continue                   # 乐器名之类的英文垃圾
            chars = clean(norm(tok))
            if not chars:
                continue
            s, e = w["start"], w["end"]
            for i, c in enumerate(chars):
                heard += c
                times.append((s + (e - s) * i / len(chars),
                              s + (e - s) * (i + 1) / len(chars)))
    return heard, times


def cmd_lyrics(a):
    asr = json.loads(Path(a.asr).read_text())
    lines = read_lyrics(a.lyrics)
    heard, times = asr_words(asr, drop_title=not a.keep_title)
    if not times:
        sys.exit("ASR 里没有可用的人声字，先确认它识别的是这首歌（背景音乐版识别不出歌词）")
    target = "".join(clean(norm(x)) for x in lines)
    sm = difflib.SequenceMatcher(None, target, heard, autojunk=False)
    mapping = {}
    for blk in sm.get_matching_blocks():
        for i in range(blk.size):
            mapping[blk.a + i] = blk.b + i
    cov = len(mapping) / max(1, len(target))
    print(f"歌词字符覆盖率 {cov:.1%}  (原文 {len(target)} 字 / 识别 {len(heard)} 字)")
    if cov < a.min_cov:
        sys.exit(f"覆盖率 {cov:.1%} 低于 {a.min_cov:.0%}：ASR 与歌词对不上，"
                 "多半是选错了候选或歌词被唱漏，不要强行出字幕")
    rows, offset = [], 0
    for line in lines:
        n = len(clean(norm(line)))
        hits = [mapping[k] for k in range(offset, offset + n) if k in mapping]
        offset += n
        if not hits:
            print(f"  ! 整句没匹配上：{line}")
            continue
        rows.append({"text": line, "start": round(times[min(hits)][0], 2),
                     "end": round(times[max(hits)][1], 2)})
    if a.trim:
        t = a.trim
        rows = [r for r in rows if r["start"] >= t[0] and r["end"] <= t[1]+0.5]
        for r in rows:
            r["start"] -= t[0]
            r["end"] -= t[0]
    # 收尾：每句往后延一点，但绝不越到下一句开头
    for i, r in enumerate(rows):
        nxt = rows[i + 1]["start"] if i + 1 < len(rows) else None
        want = r["end"] + a.tail
        r["end"] = round(min(want, nxt - 0.03) if nxt else want, 2)
        if r["end"] <= r["start"]:
            r["end"] = round(r["start"] + 0.4, 2)

    out = Path(a.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    (out / "歌词时间线.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    write_ass(rows, out / "字幕.ass", a.font, a.size, a.y, a.title, a.title_y)
    print(f"→ {out/'歌词时间线.json'}  {len(rows)} 句")
    print(f"→ {out/'字幕.ass'}")
    for r in rows:
        print(f"  {r['start']:6.2f}–{r['end']:6.2f}  {r['text']}")
    if a.cut:
        print("提醒：这是 ASR 自动定位，不是人工校对；出片前要对着歌听一遍咬字")


def ts(t):
    return f"0:{int(t//60):02d}:{t%60:05.2f}"


def write_ass(rows, path, font, size, y, title=None, title_y=630):
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Lyric,{font},{size},&H002C302F,&H002C302F,&H00E8EBEF,&H00000000,-1,0,0,0,100,100,1,0,1,0,0,5,65,65,0,1
Style: Title,{font},{int(size*0.95)},&H00354034,&H00354034,&H00000000,&H00000000,-1,0,0,0,100,100,2,0,1,0,0,5,50,50,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    body = []
    if title:
        body.append(f"Dialogue: 0,0:00:00.00,9:59:59.00,Title,,0,0,0,,"
                    f"{{\\pos(540,{title_y})}}" + title.replace("\n", "\\N"))
    for r in rows:
        text = r["text"].rstrip("，。？、")
        if len(text) > 15 and "，" in text:
            text = text.replace("，", "\\N", 1)
        body.append(f"Dialogue: 1,{ts(r['start'])},{ts(r['end'])},Lyric,,0,0,0,,"
                    f"{{\\pos(540,{y})}}{text}")
    Path(path).write_text(head + "\n".join(body) + "\n")


# ------------------------------------------------------------------ seam
def probe(path, stream=None):
    sel = ["-select_streams", stream] if stream else []
    out = subprocess.check_output([tool("ffprobe"), "-v", "error", *sel,
                                   "-show_entries",
                                   "stream=width,height,r_frame_rate,nb_frames:format=duration",
                                   "-of", "json", str(path)], text=True)
    return json.loads(out)


def cmd_seam(a):
    src = Path(a.video).expanduser()
    meta = probe(src, "v:0")
    st = meta["streams"][0]
    fr = st["r_frame_rate"].split("/")
    fps = float(fr[0]) / float(fr[1]) if len(fr) == 2 else float(fr[0])
    dur = float(meta["format"]["duration"])
    # 取尾帧与首帧各 3 帧，实测差异（含 a 的候选裁剪点数）
    tmp = Path(a.tmp or "/tmp/lyric_loop_seam")
    tmp.mkdir(parents=True, exist_ok=True)
    def grab(t, name):
        p = tmp / f"{name}.png"
        subprocess.run([tool("ffmpeg"), "-y", "-v", "error", "-ss", f"{t:.3f}",
                        "-i", str(src), "-frames:v", "1",
                        "-vf", "scale=135:240", str(p)], check=True)
        return p

    first = grab(0.0, "first")
    try:
        from PIL import Image, ImageChops
    except ImportError:
        sys.exit("需要 Pillow：pip3 install pillow")
    A = Image.open(first).convert("L")
    rows = []
    for back in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]:
        t = max(0.0, dur - 0.05 - back)
        B = Image.open(grab(t, f"last{back}")).convert("L")
        diff = sum(ImageChops.difference(A, B).getdata()) / (A.width * A.height)
        rows.append((back, t, round(diff, 2)))
    rows.sort(key=lambda r: r[2])
    best = rows[0]
    print(f"素材 {src.name}: {dur:.3f}s @ {fps:g}fps  建议回绕")
    for back, t, d in rows:
        print(f"  尾部退回 {back:.1f}s (取到 {t:.2f}s)  首尾差异 {d:6.2f}"
              f"{'  ← 最佳' if back == best[0] else ''}")
    # 差异 <3 已经接近无缝（0–255 均值），3–12 需要淡化，>12 说明景别变了
    if best[2] < 3:
        fade, note = 0.0, "接点已经很接近，直接 -stream_loop 即可"
    elif best[2] < 12:
        fade = round(min(0.35, max(0.15, best[2] / 40)), 2)
        note = f"接点有差，用 {fade}s 交叉淡化"
    else:
        fade = 0.4
        note = ("首尾景别明显不同（可能不是真循环素材）：0.4s 淡化只是遮羞布，"
                "更好的做法是重新生成素材或改用镜像对称")
    print("→ " + note)
    if a.out:
        cut = dur - best[0]
        out = Path(a.out).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        if fade <= 0:
            cmd = [tool("ffmpeg"), "-y", "-v", "error", "-i", str(src),
                   "-t", f"{cut:.3f}", "-an", "-c:v", "libx264", "-preset", "fast",
                   "-crf", "18", "-pix_fmt", "yuv420p", str(out)]
            subprocess.run(cmd, check=True)
        else:
            # 回绕段：把头部 fade 秒叠到尾部，接点处就成了完整的交叉淡化
            fc = (f"[0:v]trim=start={fade}:end={cut - fade:.3f},setpts=PTS-STARTPTS[main];"
                  f"[0:v]trim=start={cut - fade:.3f},setpts=PTS-STARTPTS[tail];"
                  f"[0:v]trim=start=0:end={fade},setpts=PTS-STARTPTS[head];"
                  f"[tail][head]xfade=transition=fade:duration={fade}:offset=0[w];"
                  f"[main][w]concat=n=2:v=1:a=0[v]")
            subprocess.run([tool("ffmpeg"), "-y", "-v", "error", "-i", str(src),
                            "-filter_complex", fc, "-map", "[v]", "-an",
                            "-c:v", "libx264", "-preset", "fast", "-crf", "18",
                            "-pix_fmt", "yuv420p", str(out)], check=True)
        print(f"→ 已出可循环底片 {out}  ({cut:.2f}s)")


def measure_loudness(path, dur, fade):
    """单遍解码测整段响度（含收尾淡出），给二遍补偿用。"""
    af = f"atrim=duration={dur:.3f}"
    if fade > 0 and dur > fade + 0.2:
        af += f",afade=t=out:st={dur-fade:.3f}:d={fade}"
    mm = subprocess.run([tool("ffmpeg"), "-hide_banner", "-nostats", "-i", str(path),
                         "-af", af + ",loudnorm=print_format=json", "-f", "null", "-"],
                        capture_output=True, text=True).stderr
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", mm, re.S)
    if not m:
        return None
    d = json.loads(m.group(0))
    return (float(d["input_i"]), float(d["input_tp"]),
            float(d["input_lra"]), float(d["input_thresh"]))


def af_filter(song, dur, fade, target):
    """二遍法：先量实际响度，再整体加减增益到目标，并守住真峰值。

    单遍 loudnorm 会按「预期响度」动态压缩，静音/循环素材上实测常差 1–2 LU，
    达不到 −16 LUFS 的交付线；二遍法实测 3 个时长全部落在 ±0.2 LU。
    """
    af = f"atrim=duration={dur:.3f}"
    if fade > 0 and dur > fade + 0.2:
        af += f",afade=t=out:st={dur-fade:.3f}:d={fade}"
    meas = measure_loudness(song, dur, fade)
    if not meas:
        return af + f",loudnorm=I={target}:TP=-1.5:LRA=11"
    i, tp, lra, thresh = meas
    gain = target - i
    if tp + gain > -1.5:               # 不许爆真峰
        gain = -1.5 - tp
    return af + f",volume={gain:.2f}dB"


# ------------------------------------------------------------------ render
def cmd_render(a):
    loop = Path(a.loop).expanduser()
    song = Path(a.song).expanduser()
    out = Path(a.out).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)
    dur = a.duration or float(subprocess.check_output(
        [tool("ffprobe"), "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(song)], text=True).strip())
    vf = []
    if a.speed:                       # 只改画面速度，不动音频；音频会因此脱拍，慎用
        vf.append(f"setpts={a.speed}*PTS")
    vf.append(f"fps={a.fps}")
    vf.append("scale=1080:1920:force_original_aspect_ratio=decrease,"
              "pad=1080:1920:(ow-iw)/2:(oh-ih)/2")
    if a.ass:
        ap_ = Path(a.ass).expanduser()
        if not ap_.exists():
            sys.exit(f"字幕文件不存在：{ap_}")
        vf.append(f"ass={ap_}")       # 路径里不能有引号/冒号，字幕放英文名目录更稳
    cmd = [tool("ffmpeg"), "-y", "-v", "error", "-stream_loop", "-1", "-i", str(loop),
           "-i", str(song), "-map", "0:v", "-map", "1:a",
           "-vf", ",".join(vf), "-t", f"{dur:.3f}",
           "-af", af_filter(song, dur, a.fade, a.target),
           "-c:v", "libx264", "-preset", "fast", "-crf", "18",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
           "-movflags", "+faststart", str(out)]
    subprocess.run(cmd, check=True)
    # 交付核对：解码无错、响度、时长
    chk = subprocess.run([tool("ffmpeg"), "-v", "error", "-i", str(out), "-f", "null", "-"],
                         capture_output=True, text=True)
    mm = subprocess.run([tool("ffmpeg"), "-hide_banner", "-i", str(out), "-af",
                         "loudnorm=print_format=summary", "-f", "null", "-"],
                        capture_output=True, text=True).stderr
    lufs = re.search(r"Input Integrated:\s+(-?[\d.]+)", mm)
    tp = re.search(r"Input True Peak:\s+(-?[\d.]+)", mm)
    real = float(subprocess.check_output(
        [tool("ffprobe"), "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(out)], text=True).strip())
    print(f"成片 {out}  {real:.2f}s  解码退出码 {chk.returncode}")
    if lufs:
        print(f"响度 {lufs.group(1)} LUFS  真峰值 {tp.group(1) if tp else '?'} dBTP"
              "（目标 −16 / ≤−1.0）")
    if chk.stderr.strip():
        print("解码告警：" + chk.stderr.strip()[:300])
    print("画面是循环底片，整片外观重复是设计如此；但歌曲本身有起止，不要说音频无缝循环")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("lyrics", help="ASR + 歌词原文 → 字幕时间线")
    p.add_argument("--asr", required=True, help="whisper 风格 json（含 segments/words）")
    p.add_argument("--lyrics", required=True)
    p.add_argument("--out", default=".")
    p.add_argument("--min-cov", type=float, default=0.85)
    p.add_argument("--tail", type=float, default=0.25, help="每句延后秒数")
    p.add_argument("--trim", type=float, nargs=2, metavar=("START", "END"),
                   help="只用歌曲的一段（节选）")
    p.add_argument("--font", default="Hiragino Sans GB")
    p.add_argument("--size", type=int, default=60)
    p.add_argument("--y", type=int, default=1370)
    p.add_argument("--title", default="")
    p.add_argument("--title-y", type=int, default=630)
    p.add_argument("--keep-title", action="store_true", help="不滤 ASR 幻觉标题")
    p.add_argument("--cut", action="store_true", help=argparse.SUPPRESS)
    p.set_defaults(fn=cmd_lyrics)

    p = sp.add_parser("seam", help="测循环接点并出可循环底片")
    p.add_argument("--video", required=True)
    p.add_argument("--out", default="")
    p.add_argument("--tmp", default="")
    p.set_defaults(fn=cmd_seam)

    p = sp.add_parser("render", help="循环底片 + 字幕 + 歌 → 成片")
    p.add_argument("--loop", required=True)
    p.add_argument("--song", required=True)
    p.add_argument("--ass", default="")
    p.add_argument("--title", default="")
    p.add_argument("--out", required=True)
    p.add_argument("--duration", type=float, default=0)
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--fade", type=float, default=0.6)
    p.add_argument("--target", type=float, default=-16.0, help="目标 LUFS")
    p.add_argument("--speed", type=float, default=0,
                   help="画面速度系数（如 1.043），会改变循环周期，非必要不用")
    p.set_defaults(fn=cmd_render)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
