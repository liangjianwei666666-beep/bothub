---
name: autodl-video
description: 通过 AutoDL Art 的 ComfyUI API 生成视频（MiniMax-H3 多图多音频生视频工作流）。支持最多 9 张参考图 + 3 段参考音频、1–15 秒、480p/768p 横竖方。当用户需要图生视频、首帧生成视频、让分镜关键帧动起来、给短剧出视频片段时使用此 skill。
---

# autodl-video · 图生视频

AutoDL Art（autodl.art）把 ComfyUI 工作流包成了异步 API。当前用的工作流是 **MiniMax-H3 多图多音频生视频（升级画质）**。

## 一句话用法

```bash
bash "$HOME/.agents/skills/autodl-video/scripts/video_gen.sh" \
  --prompt "描述动作/镜头运动" \
  --image 首帧.png \
  --duration 2 --resolution 768p竖 \
  --out 输出/shot-1.mp4
```

## 命令速查

| 命令 | 作用 |
|---|---|
| `video_gen.sh --help` | 完整用法 |
| `video_gen.sh --probe <workflow_id>` | 拉取该工作流的**官方参数表** |
| `video_gen.sh --list-workflows` | 列出已知工作流 |
| `video_gen.sh --prompt ... --image ... --dry-run` | 只检查参数和请求体大小，不提交 |

### 选项

| 选项 | 说明 |
|---|---|
| `-p, --prompt` | 视频提示词，**必填**。重点是**动作 + 镜头运动 + 场景变化** |
| `-i, --image` | 参考图，可重复，**最多 9 张**。第 1 张建议是首帧 |
| `-a, --audio` | 参考音频，可重复，最多 3 段（mp3/wav/flac/mp4） |
| `-d, --duration` | 秒数 **1–15**，默认 5 |
| `-r, --resolution` | `480p竖` / `768p竖` / `480p横` / `768p横` / `480p(1:1)` / `768p(1:1)`，默认 `768p竖` |
| `-o, --out` | 输出 mp4 路径 |
| `-w, --workflow` | 工作流 ID，默认 `minimax_h3_zm_u24` |
| `--seed` | 随机种子，同参数同种子结果相近 |
| `--max-edge` | 传给模型的图最大边，默认 1536 |
| `--no-wait` | 只提交，打印 `TASK_ID` 后退出 |
| `--dry-run` | 不提交，只打印参数 |

`--dry-run` 会输出 `WORKFLOW=... DURATION=... RESOLUTION=... IMAGES=N AUDIOS=N PAYLOAD=x.xMB`，提交成功后输出 `TASK_ID=...`，下载完成输出 `VIDEO_SAVED=<绝对路径>`。

## 凭证

按顺序找：

1. `--key` 参数
2. 环境变量 `$AUTODL_VIDEO_KEY` / `$AUTODL_TOKEN`
3. `~/.codex/autodl-video-key`
4. `~/.config/autodl/video-key`

URL 同理：`--base-url` → `$AUTODL_VIDEO_URL` → `~/.codex/autodl-video-url` → `https://autodl.art`

**永远不要把 key 打印出来。**

## 接口行为（实测）

**两步异步：**

```
POST /api/v1/comfyui/comfyui_workflow/{workflow_id}      → 立刻返回 task_id
GET  /api/v1/comfyui/comfyui_workflow/result/{task_id}   → 轮询取结果
```

Header 是 `Authorization: <token>`（**裸 token，不是 `Bearer`**；两种写法服务端都收）。

**图片用 data URL 直传就行**，不需要图床：
`"ref_image_0": "data:image/jpeg;base64,..."`
（`/api/v1/file/before_upload` 那条上传通道要**用户登录态**，ComfyUI 分组的 token 走不通——别在那上面浪费时间。）

返回的 `results[].url` 是**带签名的临时地址，24 小时过期**，必须立刻下载。

**实测耗时**：提交 1 秒，768p 竖屏 1 秒视频生成约 50 秒。

**计费**（点数）：480p 20 点 / 768p 30 点；低峰期 480p 10 点 / 768p 20 点。

## 和短剧流水线怎么接

`pixelnova-prompts` 的 `pn-storyboard` 负责把分镜表变成**关键帧提示词**（图像侧）。本 skill 负责把关键帧变成视频（视频侧）。

**两个模型吃两套不相交的积木**：

| 侧 | 吃的积木 |
|---|---|
| 图像侧（telangpuai / gpt-image-2.5-flare） | 景别、视角、焦段透视、构图、视觉风格、图像滤镜 |
| 视频侧（本 skill） | **动作设计、动作节奏、运镜、节奏转场** |
| 两侧共有 | 动态光影、人物表演、影视风格、叙事意图、连续性约束 |

所以**视频提示词要把「运镜 + 动作设计 + 动作节奏 + 节奏转场」写进来**，图像提示词里不需要。`pn-storyboard build --format json` 输出的 `video` 段就是给这里的。

**首帧必须按运镜的 t=0 取景**：推近要给更宽的首帧、右移要在右侧留出走位空间。`pn_storyboard.py` 会自动把这条写进关键帧提示词（`【运镜首帧】` 块）。

### 典型串联

```bash
P="$HOME/.agents/skills/pixelnova-prompts/scripts"
V="$HOME/.agents/skills/autodl-video/scripts"

# 1. 分镜表 → 关键帧提示词（JSON，含 video 段）
bash "$P/pn-storyboard" build 分镜表.csv --project project.json --format json --out 输出JSON

# 2. 出关键帧（图像侧）
bash "$HOME/.agents/skills/telangpuai-imagegen/scripts/image_gen.sh" \
  --model gpt-image-2.5-flare --quality high --size 864x1536 \
  --prompt "<第 N 镜关键帧提示词>" \
  --input refs/style-anchor.png --input refs/ma-face.png \
  --out shots/shot-N.png

# 3. 关键帧 → 视频（视频侧）
bash "$V/video_gen.sh" \
  --prompt "<第 N 镜的运镜+动作+节奏描述>" \
  --image shots/shot-N.png \
  --duration 2 --resolution 768p竖 \
  --out 视频/shot-N.mp4
```

图片用 `864x1536` 是 9:16 的精确尺寸（gpt-image-2.5-flare 下 `1024x1536` 其实是 2:3，错的）。视频选 `768p竖` 保持同一画幅。

## 出片之后：拉片验收（别跳过）

**生成式出片最常见的失败不是黑屏，是「没动」。** 模型返回的片段时长、画面都正常，机位却纹丝不动——
2 秒的慢推和 2 秒的静止帧，在手机上看不出差别。

`video-shots` 把成片拆成逐镜表，并用**运镜实测对账门**当场拦这一向：声称推 / 拉 / 摇 / 移而实测帧间变化接近 0 → 点名。

```bash
export PATH="$HOME/bin:/usr/bin:/bin:/usr/sbin:/sbin"   # 本机必需
cd <项目>/拉片
S=~/.agents/skills/video-shots/scripts/video-shots.mjs

node "$S" seed   成片.mp4 --threshold 0.18 --track track.json --title "<片名>" > shots.json
node "$S" frames shots.json --video 成片.mp4 --dir frames
node "$S" validate shots.json --track track.json --frames frames
node "$S" render shots.json --html --track track.json --frames frames --video 成片.mp4 > shots-report.html
```

### 三个本机要点

1. **阈值要下调。** 默认 `0.3` 在 AI 生成的慢片 / 暗调素材上大面积漏刀。
   **用已知镜数反推**：出了 N 个片段，成片就该有 N 镜。
   > 实测《长鹅》62.79s / 19 镜 → `0.45: 11 镜`、`0.3: 15 镜`、**`0.18: 19 镜`**。

2. **读不了图时，运镜以实测 `motion` 为准。** strong 类运镜实测 < 1.5 直接降级为 `static`。
   方向（推 / 拉 / 摇）在 AI 片段上**无法用算法复原**（帧间内容本身在变），照设计意图填并声明未核验。

3. **没试听就别写 `audio`。** 片段自带模型合成的环境音，但没听过就不能写「风声」——那是编造。

### 顺手做的交叉验证

把每个片段的真实时长累积起来，和检出的切点逐个比：**±0.05 秒内对得上，这张表就可信**。
> 实测《长鹅》：19 个切点与真实剪辑点偏差 ≤0.01 秒。

完整口径见 `digital-human-video` §9。

## 注意

- **参考图上限 9 张**（图像侧 gpt-image-2.5-flare 是 16 张，别搞混）
- 请求体会内联所有图片的 base64。工具默认把图压到最大边 1536 的 JPEG（q90），9 张约 3–4MB。超过 40MB 会告警
- 视频生成**比图像慢一个数量级**（50 秒 vs 5 秒），批量跑要算总时长
- 拿到 URL 后**尽快下载**，24 小时过期
- 同一工作流的入参随工作流不同而变，换工作流先用 `--probe` 拉参数表
