#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
video-frames · 从视频里等间隔抽帧，便于用视觉模型验收生成的视频

依赖 imageio_ffmpeg（自带静态 ffmpeg 二进制），不需要系统装 ffmpeg。
"""

import argparse
import os
import re
import subprocess
import sys


def ffmpeg_exe():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        for p in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg", "/usr/bin/ffmpeg"):
            if os.path.isfile(p):
                return p
    print("找不到 ffmpeg。装一下：pip3 install --user imageio-ffmpeg", file=sys.stderr)
    sys.exit(3)


def probe(ff, path):
    """返回 (duration_sec, width, height, fps)"""
    r = subprocess.run([ff, "-hide_banner", "-i", path], capture_output=True, text=True)
    txt = r.stderr
    dur = w = h = fps = None
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.\d+)", txt)
    if m:
        dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    m = re.search(r"Video:.*?,\s*(\d+)x(\d+)", txt)
    if m:
        w, h = int(m.group(1)), int(m.group(2))
    m = re.search(r"(\d+(?:\.\d+)?)\s*fps", txt)
    if m:
        fps = float(m.group(1))
    return dur, w, h, fps


def main():
    ap = argparse.ArgumentParser(description="从视频等间隔抽帧")
    ap.add_argument("video")
    ap.add_argument("-n", "--count", type=int, default=6, help="抽几帧（默认 6）")
    ap.add_argument("-o", "--outdir", help="输出目录（默认视频同目录下的 <名字>-frames/）")
    ap.add_argument("-s", "--width", type=int, default=720, help="输出帧宽度（默认 720）")
    ap.add_argument("--sheet", action="store_true", help="额外拼一张 2 列网格总览图")
    a = ap.parse_args()

    if not os.path.isfile(a.video):
        print("视频不存在: %s" % a.video, file=sys.stderr)
        return 2

    ff = ffmpeg_exe()
    dur, w, h, fps = probe(ff, a.video)
    outdir = a.outdir or (os.path.splitext(a.video)[0] + "-frames")
    os.makedirs(outdir, exist_ok=True)

    print("视频: %s" % os.path.basename(a.video))
    if dur:
        print("  时长 %.2f 秒   %sx%s   %s fps" % (dur, w, h, fps if fps else "?"))
    if w and h:
        r = w / float(h)
        exact = "9:16" if abs(r - 9 / 16.0) < 0.002 else ("精确 %.4f" % r)
        print("  宽高比 %.4f  (%s)" % (r, exact))

    n = max(1, a.count)
    base = os.path.splitext(os.path.basename(a.video))[0]
    made = []
    for i in range(n):
        # 避开首尾各 5%，均匀分布
        frac = (i + 0.5) / n
        t = (dur or 1.0) * frac if dur else 0
        dst = os.path.join(outdir, "%s-f%02d-%0.2fs.png" % (base, i + 1, t))
        cmd = [ff, "-hide_banner", "-loglevel", "error", "-ss", "%.3f" % t,
               "-i", a.video, "-frames:v", "1", "-vf", "scale=%d:-2" % a.width, "-y", dst]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0 and os.path.isfile(dst):
            made.append((t, dst))
            print("  帧 %d  @%5.2fs  %s" % (i + 1, t, os.path.abspath(dst)))
        else:
            print("  帧 %d  @%5.2fs  失败: %s" % (i + 1, t, (r.stderr or "")[:120]), file=sys.stderr)

    if a.sheet and made:
        try:
            from PIL import Image
            cols = 2
            rows = (len(made) + cols - 1) // cols
            ims = [Image.open(p) for _, p in made]
            cw = max(i.width for i in ims)
            ch = max(i.height for i in ims)
            sheet = Image.new("RGB", (cols * cw, rows * ch), (20, 20, 20))
            for k, im in enumerate(ims):
                sheet.paste(im, ((k % cols) * cw, (k // cols) * ch))
            sp = os.path.join(outdir, "%s-sheet.png" % base)
            sheet.save(sp)
            print("SHEET=%s" % os.path.abspath(sp))
        except Exception as e:
            print("拼图失败: %s" % e, file=sys.stderr)

    print("FRAMES_DIR=%s  (%d 帧)" % (os.path.abspath(outdir), len(made)))
    return 0 if made else 1


if __name__ == "__main__":
    sys.exit(main())
