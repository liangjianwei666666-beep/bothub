#!/usr/bin/env bash
# autodl-video · 入口包装（和 telangpuai-imagegen 的 image_gen.sh 用法对齐）
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="${PYTHON:-python3}"
command -v "$PY" >/dev/null 2>&1 || { echo "找不到 python3" >&2; exit 3; }
exec "$PY" "$DIR/comfyui_video.py" "$@"
