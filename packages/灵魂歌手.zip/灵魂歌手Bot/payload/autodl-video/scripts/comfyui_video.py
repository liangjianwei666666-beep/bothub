#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
autodl-video · AutoDL Art ComfyUI 视频生成客户端

工作流 minimax_h3_zm_u24 = MiniMax-H3 多图多音频生视频（升级画质）
  · 最多 9 张参考图 + 3 段参考音频
  · 时长 1–15 秒
  · 分辨率 480p/768p × 竖/横/方

上传协议（实测）：
  图片/音频直接以 data URL 传参即可，无需图床。
  （/api/v1/file/before_upload 那条路要用户登录态，ComfyUI 分组的 token 走不通）
"""

import argparse
import base64
import io
import json
import os
import sys
import time
import urllib.request
import urllib.error

DEFAULT_BASE = "https://autodl.art"
DEFAULT_WORKFLOW = "minimax_h3_zm_u24"

# 纯文生视频工作流：不需要参考图（不写名字就是没图）。
# 之前这里无条件要求 --image，把 minimax_h3_lightx2v_no_pic 卡死了。
TEXT_ONLY_WORKFLOWS = {"minimax_h3_lightx2v_no_pic"}
MAX_IMAGES, MAX_AUDIOS = 9, 3
RESOLUTIONS = ["480p竖", "768p竖", "480p横", "768p横", "480p(1:1)", "768p(1:1)"]


# ── key 解析 ────────────────────────────────────────────────
def find_key(explicit=None):
    if explicit:
        return explicit.strip()
    env = os.environ.get("AUTODL_VIDEO_KEY") or os.environ.get("AUTODL_TOKEN")
    if env:
        return env.strip()
    codex = os.environ.get("CODEX_HOME") or os.path.join(os.path.expanduser("~"), ".codex")
    for p in (os.path.join(codex, "autodl-video-key"),
              os.path.join(os.path.expanduser("~"), ".config", "autodl", "video-key")):
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8") as f:
                    t = f.read().strip()
                if t:
                    return t
            except OSError:
                pass
    return None


def find_base(explicit=None):
    if explicit:
        return explicit.rstrip("/")
    env = os.environ.get("AUTODL_VIDEO_URL")
    if env:
        return env.rstrip("/")
    codex = os.environ.get("CODEX_HOME") or os.path.join(os.path.expanduser("~"), ".codex")
    p = os.path.join(codex, "autodl-video-url")
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as f:
                t = f.read().strip()
            if t:
                return t.rstrip("/")
        except OSError:
            pass
    return DEFAULT_BASE


# ── 媒体 → data URL ────────────────────────────────────────
def _jpeg_data_url(path, max_edge=1536, quality=90):
    from PIL import Image
    im = Image.open(path)
    if im.mode not in ("RGB", "L"):
        im = im.convert("RGB")
    else:
        im = im.convert("RGB")
    w, h = im.size
    if max(w, h) > max_edge:
        s = max_edge / float(max(w, h))
        im = im.resize((max(1, int(w * s)), max(1, int(h * s))), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=quality, optimize=True)
    raw = buf.getvalue()
    return "data:image/jpeg;base64," + base64.b64encode(raw).decode(), len(raw), im.size


def _audio_data_url(path, max_bytes=8 * 1024 * 1024):
    raw = open(path, "rb").read()
    if len(raw) > max_bytes:
        raise ValueError("音频 %s 有 %.1fMB，超过 %.0fMB 上限" %
                         (os.path.basename(path), len(raw) / 1048576.0, max_bytes / 1048576.0))
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    mime = {"mp3": "audio/mpeg", "wav": "audio/wav", "flac": "audio/flac",
            "mp4": "audio/mp4", "m4a": "audio/mp4"}.get(ext, "audio/mpeg")
    return "data:%s;base64," % mime + base64.b64encode(raw).decode(), len(raw)


# ── HTTP ───────────────────────────────────────────────────
def _req(url, token, method="GET", payload=None, timeout=120):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", token)
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:400]
        raise RuntimeError("HTTP %s: %s" % (e.code, body))


def cmd_list(base, token):
    wfs = [
        ("minimax_h3_zm_u24", "H3多图多音频生视频(升级画质)", "9 图 + 3 音频，1–15 秒，480p/768p"),
        ("minimax_h3_lightx2v_v5", "MiniMax H3 视频模型", "轻量版"),
        ("minimax_h3_lightx2v_no_pic", "H3 文生视频", "纯文字，无需参考图"),
    ]
    print("已知工作流（可用 --probe 逐个拉取官方参数表）:\n")
    for uid, name, note in wfs:
        print("  %-30s %s\n  %-30s %s\n" % (uid, name, "", note))
    print("拉取官方参数表：  video_gen.sh --probe <workflow_id>")


def cmd_probe(base, token, wf):
    d = _req("%s/api/v1/comfyui/workflows/%s" % (base, wf), token, timeout=40)
    if d.get("code") != "Success":
        print("失败:", d, file=sys.stderr)
        return 1
    d = d["data"]
    print("工作流: %s" % d.get("name"))
    print("UUID  : %s" % d.get("uuid"))
    print("说明  : %s" % (d.get("description") or "").strip())
    if d.get("billing_config"):
        print("计费  : %s" % json.dumps(d["billing_config"], ensure_ascii=False))
    print("\n参数表:")
    for k, v in (d.get("input_rules") or {}).items():
        bits = []
        if v.get("required"):
            bits.append("必填")
        if "default" in v and not str(v["default"]).startswith("default_local_path"):
            bits.append("默认=%s" % str(v["default"])[:24])
        if "min" in v:
            bits.append("范围=%s~%s" % (v.get("min"), v.get("max")))
        if "min_length" in v:
            bits.append("长度=%s~%s" % (v.get("min_length"), v.get("max_length")))
        if v.get("options"):
            bits.append("选项=%s" % ",".join(str(o.get("label")) for o in v["options"]))
        print("  %-16s %-9s %s" % (k, v.get("type"), "  ".join(bits)))
    return 0


# ── 主流程 ─────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--prompt", "-p")
    ap.add_argument("--image", "-i", action="append", default=[])
    ap.add_argument("--audio", "-a", action="append", default=[])
    ap.add_argument("--duration", "-d", type=int, default=None)
    ap.add_argument("--resolution", "-r", default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--out", "-o")
    ap.add_argument("--workflow", "-w", default=DEFAULT_WORKFLOW)
    ap.add_argument("--base-url")
    ap.add_argument("--key")
    ap.add_argument("--max-edge", type=int, default=1536)
    ap.add_argument("--quality", type=int, default=90)
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--interval", type=int, default=6)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--list-workflows", action="store_true")
    ap.add_argument("--probe", metavar="WORKFLOW_ID")
    ap.add_argument("--no-wait", action="store_true")
    ap.add_argument("-h", "--help", action="store_true")
    a = ap.parse_args()

    if a.help:
        print(__doc__)
        print("""用法:
  video_gen.sh --prompt "描述" --image 首帧.png [--image 图2 ...] [选项]

选项:
  -p, --prompt TEXT       视频生成提示词（必填）
  -i, --image PATH        参考图，可重复，最多 9 张（第 1 张建议是首帧）
  -a, --audio PATH        参考音频，可重复，最多 3 段
  -d, --duration N        时长秒数 1-15（默认 5）
  -r, --resolution S      480p竖 / 768p竖 / 480p横 / 768p横 / 480p(1:1) / 768p(1:1)
  -o, --out PATH          输出 mp4 路径（默认 ./video-<时间戳>.mp4）
  -w, --workflow ID       工作流 ID（默认 minimax_h3_zm_u24）
      --seed N            随机种子
      --base-url URL      默认 https://autodl.art
      --key TOKEN         覆盖 token（默认读 $AUTODL_VIDEO_KEY 或 ~/.codex/autodl-video-key）
      --max-edge N        传给模型的图最大边，默认 1536
      --dry-run           只打印将要提交的参数，不真的提交
      --no-wait           只提交，不等待结果（打印 task_id 后退出）
      --list-workflows    列出已知工作流
      --probe ID          拉取某工作流的官方参数表
""")
        return 0

    base = find_base(a.base_url)
    token = find_key(a.key)

    if a.list_workflows:
        return cmd_list(base, token)
    if a.probe:
        if not token:
            print("缺少 token", file=sys.stderr); return 2
        return cmd_probe(base, token, a.probe)

    if not token:
        print("找不到 token。请设置 $AUTODL_VIDEO_KEY，或写入 ~/.codex/autodl-video-key", file=sys.stderr)
        return 2
    if not a.prompt:
        print("缺少 --prompt", file=sys.stderr); return 2
    if not a.image and a.workflow not in TEXT_ONLY_WORKFLOWS:
        print("缺少 --image（工作流 %s 至少要 1 张参考图；"
              "纯文生视频请用 -w minimax_h3_lightx2v_no_pic）" % a.workflow, file=sys.stderr); return 2
    if a.image and a.workflow in TEXT_ONLY_WORKFLOWS:
        print("工作流 %s 是纯文生视频，不接受参考图" % a.workflow, file=sys.stderr); return 2
    if len(a.image) > MAX_IMAGES:
        print("参考图最多 %d 张，收到 %d 张" % (MAX_IMAGES, len(a.image)), file=sys.stderr); return 2
    if len(a.audio) > MAX_AUDIOS:
        print("参考音频最多 %d 段，收到 %d 段" % (MAX_AUDIOS, len(a.audio)), file=sys.stderr); return 2
    if a.duration is not None and not (1 <= a.duration <= 15):
        print("时长必须在 1~15 秒之间", file=sys.stderr); return 2
    if a.resolution and a.resolution not in RESOLUTIONS:
        print("分辨率必须是: %s" % " / ".join(RESOLUTIONS), file=sys.stderr); return 2

    body = {"prompt": a.prompt}
    if a.duration is not None:
        body["duration"] = a.duration
    if a.resolution:
        body["resolution"] = a.resolution
    if a.seed is not None:
        body["seed"] = a.seed

    total = 0
    for idx, p in enumerate(a.image):
        if not os.path.isfile(p):
            print("参考图不存在: %s（第 %d 张）" % (p, idx + 1), file=sys.stderr); return 2
        try:
            durl, n, size = _jpeg_data_url(p, a.max_edge, a.quality)
        except ImportError:
            print("需要 Pillow 来压缩图片：pip3 install --user Pillow", file=sys.stderr); return 3
        except Exception as e:
            print("处理参考图失败 %s: %s" % (p, e), file=sys.stderr); return 3
        body["ref_image_%d" % idx] = durl
        total += n
        print("  参考图 [%d] %-34s %dx%d  %.0fKB" % (idx + 1, os.path.basename(p), size[0], size[1], n / 1024.0))
    for idx, p in enumerate(a.audio):
        if not os.path.isfile(p):
            print("参考音频不存在: %s" % p, file=sys.stderr); return 2
        durl, n = _audio_data_url(p)
        body["ref_audio_%d" % idx] = durl
        total += n
        print("  参考音频 [%d] %-32s %.0fKB" % (idx + 1, os.path.basename(p), n / 1024.0))

    payload_mb = len(json.dumps(body)) / 1048576.0
    print("\nWORKFLOW=%s  DURATION=%ss  RESOLUTION=%s  IMAGES=%d  AUDIOS=%d  PAYLOAD=%.1fMB"
          % (a.workflow, body.get("duration", 5), body.get("resolution", "768p竖"),
             len(a.image), len(a.audio), payload_mb))
    if payload_mb > 40:
        print("警告: 请求体 %.0fMB 偏大，可能被拒。降低 --max-edge 或 --quality。" % payload_mb)

    if a.dry_run:
        print("IMAGE_DRY_RUN=1")
        return 0

    url = "%s/api/v1/comfyui/comfyui_workflow/%s" % (base, a.workflow)
    print("\n提交任务 …")
    try:
        r = _req(url, token, method="POST", payload=body, timeout=300)
    except Exception as e:
        print("提交失败: %s" % e, file=sys.stderr); return 4
    if r.get("code") != "Success":
        print("提交被拒: %s" % json.dumps(r, ensure_ascii=False)[:500], file=sys.stderr)
        if "RequestParameterIsWrong" in str(r.get("code")):
            print("提示: 缺少必填参数 %s" % r.get("msg"), file=sys.stderr)
        return 4
    tid = r["data"]["task_id"]
    print("TASK_ID=%s  status=%s" % (tid, r["data"].get("status")))
    if a.no_wait:
        return 0

    qurl = "%s/api/v1/comfyui/comfyui_workflow/result/%s" % (base, tid)
    t0 = time.time()
    res = None
    while time.time() - t0 < a.timeout:
        time.sleep(a.interval)
        try:
            d = _req(qurl, token, timeout=60).get("data") or {}
        except Exception as e:
            print("  查询出错（忽略）: %s" % e); continue
        st = d.get("status")
        print("  [%4ds] %s" % (int(time.time() - t0), st))
        if st in ("SUCCESS", "completed"):
            res = d.get("results") or []
            break
        if st in ("FAILED", "failed", "ERROR"):
            print("任务失败: %s" % json.dumps(d, ensure_ascii=False)[:500], file=sys.stderr)
            return 5

    if not res:
        print("超时未拿到结果（task_id=%s，可用 --no-wait 重试或稍后查）" % tid, file=sys.stderr)
        return 6

    out = a.out or ("video-%s.mp4" % time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    saved = []
    for i, x in enumerate(res):
        u = x.get("url")
        if not u:
            continue
        dst = out if len(res) == 1 else (os.path.splitext(out)[0] + "-%d" % (i + 1) + os.path.splitext(out)[1])
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=600) as rr, open(dst, "wb") as f:
                while True:
                    chunk = rr.read(262144)
                    if not chunk:
                        break
                    f.write(chunk)
        except Exception as e:
            print("下载失败 %s: %s" % (u[:100], e), file=sys.stderr); return 7
        sz = os.path.getsize(dst)
        saved.append(dst)
        print("VIDEO_SAVED=%s  (%.0fKB)" % (os.path.abspath(dst), sz / 1024.0))
    if not saved:
        print("结果里没有可下载的视频 URL", file=sys.stderr); return 7
    print("TASK_ID=%s  总耗时=%ds" % (tid, int(time.time() - t0)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
