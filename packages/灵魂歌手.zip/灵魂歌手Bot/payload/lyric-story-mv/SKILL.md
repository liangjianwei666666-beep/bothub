---
name: lyric-story-mv
description: 剧情 MV / 唱歌口型片。当用户说「音乐MV」「唱歌的片子」「剧情MV」「影子不撒谎那种」「恭喜发财MV那种」「跟着歌走的口型」「歌词对画面」时使用。覆盖：选歌/节选→歌词时间线→分镜按句切→图生视频用参考音频驱动口型→按音乐切点剪辑→字幕→响度；含「音乐先定稿再出画面」「原声弃用」「口型不能宣称精确通过」三条规则。
compatibility: macOS, Python 3.9+, AutoDL H3（支持参考音频）, Kie 音乐, ffmpeg/ffprobe 在 ~/bin
metadata:
  author: local
  version: "1.0.0"
  derived_from: "影子不撒谎_剧情MV试片（56.86s·8镜）、恭喜发财_民谣短歌/MV（15s 口型 MV）"
---

# 剧情 MV · 唱歌口型 · lyric-story-mv

**一句话：歌先定，画面跟着歌走；口型靠参考音频，不靠猜。**

两条形态：

| 形态 | 例子 | 关键 |
|---|---|---|
| **剧情 MV** | 影子不撒谎 56.86s | 人物**不对着镜头唱**，画面演剧情，歌是旁白 |
| **口型 MV** | 恭喜发财 15s | 人物**对着镜头唱**，用原曲音频驱动嘴型 |

---

## 1. 铁律

1. **音乐先定稿**（选好哪一版、切好哪一段），再开始出画面。音乐一改，整片全部重剪。
2. **每条视频的原声弃用**（剧情 MV），或**保留同一条音轨**（口型 MV）——不许混。
3. **口型未逐帧验证就不能宣称「精确对上」**。要说「用参考音频驱动，需人工试看」。
4. 歌词时间轴用 ASR 辅助定位，**不能替代人工试听**（同音字常错）。

---

## 2. 剧情 MV 流程

```
选歌 → 节选（检查波形与句尾，不能切掉字）
  ↓ 歌词时间线（start/end 每句）
  ↓ 分镜：按歌词的「情绪句」切，一句一镜或两镜
  ↓ 关键帧（同一空间、同一角色）
  ↓ H3 图生视频（4–10 秒/镜，不对口型）
  ↓ 按音乐切点拼接（入出点对齐句尾）
  ↓ 烧字幕（歌词）→ −16 LUFS
```

### 2.1 节选
影子不撒谎：原曲 158.83 秒，取「第二次副歌 74.91–85.57 + 112.63–158.83 = 56.86 秒」。
- **切点检查波形**，不能切在字中间；
- 允许小幅移动边界，**宁可多留 0.2 秒尾音**。

### 2.2 分镜写法（8 镜范例）

| 镜 | 时段 | 画面 | 制作重点 |
|---|---|---|---|
| T01 | 0–4 | 挥手赶影子，影子不走 | **先做 4 秒技术试拍**，验证设定 |
| T02 | 4–10.66 | 手慢慢垂下 | 侧脸 + 影子反应，避免同时复杂表演 |
| T03 | 10.66–17 | 移开椅子留空位 | 真实物件运动，不要凭空消失 |
| T04 | 17–24 | 拉出第二把椅子 | 桌椅为核心道具，反复出现 |
| T05 | 24–31 | 倒第二杯茶 | 手部近景，避免液体穿模 |
| T06 | 31–39 | 坐下、影子抬头 | 接纳用动作呈现，不用拥抱 |
| T07 | 39–47 | 同构图、关系改变 | 固定机位便于控制 |
| T08 | 47–56.86 | 两只杯子两把椅子 | 尾奏留白，不加结语 |

### 2.3 「影子/非人物体」的提示词写法
关键是把**禁止项**写死：
```
Shadow is a flat grey silhouette on the wall — no body, no smoke, no eyes,
no monster features. It never stands up, never imitates the man, never becomes
a solid person. One real man only.
```

---

## 3. 口型 MV 流程（15 秒范例）

1. **曲先出**（Kie 音乐，见 `micro-song`），选一版。
2. 用 **ASR** 拿到逐句时间（辅助，需人工核对咬字）。
3. 关键帧：人物脸**必须清晰无遮挡**，嘴部不能被道具挡。
4. H3 视频：**把原曲音频作为参考音频传入**，提示词明确：
```
Reference audio 1 is the only and exact vocal track: drive the lips and jaw from
its actual phonemes, syllables, pauses and breaths. Do not sing a different
melody, do not change the words, do not generate narration. This is singing,
not speaking. Mouth must be clearly visible and unobstructed whenever the face
is in frame. No static photo zoom as a substitute for real performance.
```
5. 提示词里**写出逐句时间戳**（「1.08–4.62 唱……；13.02 后闭嘴」），模型会更准。
6. 字幕**后期加**，不要烧进生成画面。

---

## 4. 剪辑

- 拼接用**硬切**，按音乐切点对齐；转场只在有换场意图处用。
- 剧情 MV：`assemble.py` 按帧数写死每镜（24fps），`timeline.json` 记录入出点。
- 影子不撒谎的剪辑里有两处靠**选段+降速**修问题（T04/T07），没有重新生成——**先想办法用现有素材救**。

## 5. 验收

- [ ] 歌曲完整、无断音、无爆音
- [ ] 画面切换落在音乐节拍/句尾
- [ ] 歌词字幕与演唱对齐（人工试听）
- [ ] 角色前后一致、道具连续
- [ ] 剧情 MV：无声也能看懂关系变化
- [ ] 口型 MV：**未逐帧验证就写明未验证**
- [ ] −16 LUFS，解码无错

**脚本**：`scripts/music_section.py`（按歌词时间轴节选 + 拼接 + 导出歌词 SRT）。
