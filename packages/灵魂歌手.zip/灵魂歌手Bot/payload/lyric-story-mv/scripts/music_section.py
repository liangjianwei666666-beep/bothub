#!/usr/bin/env python3
"""按歌词时间轴节选 + 拼接音乐段，并导出歌词 SRT。

用法：
  python3 music_section.py --song 原曲.mp3 --lyrics 歌词时间线.json \
      --keep 74.91-85.57 --keep 112.63-158.83 --out 歌曲_试片节选.wav

歌词时间线.json: [{"start": 74.9, "end": 78.2, "text": "..."}, ...]（按原曲时间）

输出：
  - 拼接后的音频（保音高，不重编码速率）
  - 同名 .srt（歌词已平移到拼接后的时间轴）
  - 同名 .json（新时间轴，供剪辑脚本用）
"""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def exe(name):
    for c in (shutil.which(name), str(Path.home() / f"bin/{name}"),
              str(Path.home() / f"local/bin/{name}"), f"/opt/homebrew/bin/{name}"):
        if c and Path(c).exists():
            return c
    raise SystemExit(f'找不到 {name}；export PATH="$HOME/bin:$PATH"')


FF = exe("ffmpeg")


def srt_t(t):
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    sec = t % 60
    return f"{h:02d}:{m:02d}:{sec:06.3f}".replace(".", ",")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--song", required=True)
    ap.add_argument("--lyrics", default=None)
    ap.add_argument("--keep", action="append", required=True,
                    help="要保留的区间 start-end（秒），可重复；按给出顺序拼接")
    ap.add_argument("--out", default="歌曲_节选.wav")
    ap.add_argument("--fade", type=float, default=0.02, help="每段端点淡化秒数")
    a = ap.parse_args()

    spans = []
    for k in a.keep:
        s, e = k.split("-")
        spans.append((float(s), float(e)))
    tmp = Path(tempfile.mkdtemp())

    parts = []
    for i, (s, e) in enumerate(spans):
        o = tmp / f"{i}.wav"
        d = e - s
        af = (f"atrim=start={s}:end={e},asetpts=PTS-STARTPTS,"
              f"afade=t=in:st=0:d={a.fade},"
              f"afade=t=out:st={max(0, d - a.fade):.3f}:d={a.fade}")
        subprocess.run([FF, "-y", "-v", "error", "-i", a.song, "-af", af,
                        "-ar", "48000", "-ac", "2", str(o)], check=True)
        parts.append(o)

    lst = tmp / "l.txt"
    lst.write_text("".join(f"file '{p}'\n" for p in parts), encoding="utf-8")
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([FF, "-y", "-v", "error", "-f", "concat", "-safe", "0",
                    "-i", str(lst), "-c:a", "pcm_s16le", str(out)], check=True)

    # 偏移映射
    offsets, acc = [], 0.0
    for s, e in spans:
        offsets.append((s, e, acc))
        acc += e - s
    total = acc

    def remap(t):
        for s, e, off in offsets:
            if s <= t <= e:
                return off + (t - s)
        return None

    if a.lyrics:
        lines = json.loads(Path(a.lyrics).read_text(encoding="utf-8"))
        new = []
        for ln in lines:
            s = remap(float(ln["start"]))
            e = remap(float(ln["end"]))
            if s is None or e is None or e <= s:
                continue      # 这句被切掉了，跳过
            new.append({"start": round(s, 2), "end": round(e, 2),
                        "text": ln["text"]})
        base = out.with_suffix("")
        base.with_suffix(".json").write_text(
            json.dumps(new, ensure_ascii=False, indent=2), encoding="utf-8")
        base.with_suffix(".srt").write_text(
            "\n\n".join(f"{i+1}\n{srt_t(x['start'])} --> {srt_t(x['end'])}\n{x['text']}"
                        for i, x in enumerate(new)), encoding="utf-8")
        print(f"歌词 {len(lines)} 句 → 保留 {len(new)} 句")
        dropped = len(lines) - len(new)
        if dropped:
            print(f"⚠️ {dropped} 句落在切口上被丢弃，检查切点是否切掉了字")

    print(f"✅ {out}  总长 {total:.2f}s  片段 {len(spans)}")


if __name__ == "__main__":
    main()
