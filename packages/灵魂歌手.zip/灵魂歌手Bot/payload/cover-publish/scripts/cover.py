#!/usr/bin/env python3
"""竖版/横版封面成套出：3:4 + 4:3，标题自动排版，抽帧选帧，贴字规范检查。

子命令
  frames   从成片按时间点抽帧，自动挑「清晰、有信息量、没人脸居中压字位」的候选
  layout   一张底图 → 3:4 与 4:3 两张封面（模糊补边 + 底部渐变 + 标题 + 角标）
  aicover  组装 AI 一体生成（带字）的提示词：一条 prompt 出带中文字的完整封面
  check    检查封面规格与字幕安全区（尺寸、比例、标题字高、边缘留白）

示例
  python3 cover.py frames --video 成片/晴雨_成片.mp4 --out 封面/抽帧 --count 6
  python3 cover.py layout --base 封面/抽帧/03.jpg --title "她画了八年" \
        --sub "一个人也能做动画" --tag "AI 创作 · 手绘" --out 封面/她画了八年
  python3 cover.py aicover --title "还没完成" --sub "也是一种完成" --out 封面/prompt.txt
  python3 cover.py check --file 封面/她画了八年_3x4.png

字体默认 /System/Library/Fonts/Hiragino Sans GB.ttc（本机实测中文可用）。
"""
# --- 依赖自检（缺库时说人话，不甩 traceback）
try:
    import PIL
except ImportError:
    raise SystemExit("PIL 没装：pip3 install pillow")
import argparse
import json
import math
import shutil
import sys
from pathlib import Path

FFMPEG_CANDS = ["~/bin", "~/local/bin", "/opt/homebrew/bin", "/usr/local/bin"]


def tool(name):
    p = shutil.which(name)
    if p:
        return p
    for d in FFMPEG_CANDS:
        c = Path(d).expanduser() / name
        if c.exists():
            return str(c)
    sys.exit(f"找不到 {name}：请 export PATH=\"$HOME/bin:$HOME/local/bin:$PATH\"")


FONT = "/System/Library/Fonts/Hiragino Sans GB.ttc"
FONT_BOLD = "/System/Library/Fonts/Hiragino Sans GB.ttc"


# ---------------------------------------------------------------- frames
def probe_duration(video):
    out = __import__("subprocess").check_output(
        [tool("ffprobe"), "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(video)], text=True).strip()
    return float(out)


def sharpness_and_interest(img):
    """清晰度（拉普拉斯能量的近似）+ 主体占比，用来排序候选帧。"""
    from PIL import ImageFilter, ImageStat
    g = img.convert("L")
    edges = g.filter(ImageFilter.FIND_EDGES)
    sharp = ImageStat.Stat(edges).mean[0]
    # 中心 60% 区域的亮度标准差：太低说明是空镜/纯色，做封面没信息量
    w, h = g.size
    center = g.crop((int(w * .2), int(h * .2), int(w * .8), int(h * .8)))
    detail = ImageStat.Stat(center).stddev[0]
    return sharp, detail


def cmd_frames(a):
    from PIL import Image
    import subprocess
    video = Path(a.video).expanduser()
    dur = probe_duration(video)
    out = Path(a.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    n = a.count
    # 避开片头片尾各 5%（片头常有黑场/标题，片尾常有渐黑）
    lo, hi = dur * a.start_ratio, dur * (1 - a.end_ratio)
    rows = []
    for i in range(n):
        t = lo + (hi - lo) * (i / max(1, n - 1))
        f = out / f"{i:02d}.jpg"
        subprocess.run([tool("ffmpeg"), "-y", "-v", "error", "-ss", f"{t:.2f}",
                        "-i", str(video), "-frames:v", "1", "-q:v", "2", str(f)],
                       check=True)
        im = Image.open(f)
        sharp, detail = sharpness_and_interest(im)
        # 底部 25% 是封面放标题的区，太亮会压不住白字
        w, h = im.size
        bottom = Image.open(f).convert("L").crop((0, int(h * .72), w, h))
        from PIL import ImageStat
        rows.append({"file": str(f), "t": round(t, 2),
                     "sharp": round(sharp, 1), "detail": round(detail, 1),
                     "bottom_luma": round(ImageStat.Stat(bottom).mean[0], 1)})
    rows.sort(key=lambda r: (r["sharp"] / (max(r["sharp"], 1e-6)) +
                             r["detail"] / (max(r["detail"], 1e-6))), reverse=True)
    report = out / "抽帧报告.json"
    report.write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    print(f"{len(rows)} 帧 → {out}")
    for r in rows[:5]:
        print(f"  {Path(r['file']).name}  t={r['t']:6.2f}s  清晰 {r['sharp']:6.1f}  "
              f"信息量 {r['detail']:5.1f}  底部亮度 {r['bottom_luma']:5.1f}"
              f"{'  ← 首选' if r is rows[0] else ''}")
    if rows and rows[0]["bottom_luma"] > 170:
        print("  提示：首选帧底部偏亮，标题建议加暗底或改用深色字")
    print(f"报告: {report}")


# ---------------------------------------------------------------- layout
def fit_lines(text, font, draw, max_w):
    """中文按字宽折行，标点不出现在行首。"""
    no_head = "，。、；：？！）」』】"
    lines, cur = [], ""
    for ch in text:
        trial = cur + ch
        if draw.textlength(trial, font=font) > max_w and cur:
            if ch in no_head:            # 句号之类不甩到下一行
                cur = trial
                lines.append(cur)
                cur = ""
                continue
            lines.append(cur)
            cur = ch
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def make_layout(base, out_png, size, title, sub, tag, card=False, accent=(255, 213, 74)):
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    W, H = size
    bg = Image.open(base).convert("RGB")
    # 底层模糊铺满（比例失真被模糊掩盖），上层原图完整贴入不裁不拉
    fill = bg.resize((W, int(W * bg.height / bg.width)), Image.LANCZOS)
    if fill.height < H:
        fill = bg.resize((int(H * bg.width / bg.height), H), Image.LANCZOS)
    fill = fill.resize((W, H), Image.LANCZOS).filter(ImageFilter.GaussianBlur(46))
    canvas = fill.copy()
    s = min(W / bg.width, H / bg.height)
    main = bg.resize((max(1, int(bg.width * s)), max(1, int(bg.height * s))), Image.LANCZOS)
    canvas.paste(main, ((W - main.width) // 2, (H - main.height) // 2))

    # 底部渐变暗底：给标题撑住对比度
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    band = int(H * 0.46)
    for y in range(H - band, H):
        k = (y - (H - band)) / band
        od.line([(0, y), (W, y)], fill=(8, 12, 24, int(225 * k ** 1.25)))
    canvas = Image.alpha_composite(canvas.convert("RGBA"), ov).convert("RGB")

    d = ImageDraw.Draw(canvas)
    margin = int(W * 0.07)
    max_w = W - margin * 2
    # 字号随画幅缩放：3:4 的 1080 宽对应 104px，4:3 的 1440 宽不应更大
    base_px = int(min(W, H * 0.75) * 0.098)
    f_title = ImageFont.truetype(FONT_BOLD, base_px)
    f_sub = ImageFont.truetype(FONT, int(base_px * 0.46))
    f_tag = ImageFont.truetype(FONT, int(base_px * 0.34))

    tl = fit_lines(title, f_title, d, max_w)
    sl = fit_lines(sub, f_sub, d, max_w) if sub else []
    lh_t = int(base_px * 1.28)
    lh_s = int(base_px * 0.46 * 1.55)
    block_h = len(tl) * lh_t + (len(sl) * lh_s + int(base_px * .3) if sl else 0)
    y = H - margin - block_h

    if card:   # 标题卡片：一条半透明色条衬托
        from PIL import ImageDraw as ID
        strip = Image.new("RGBA", (W, block_h + int(base_px * .8)), accent + (46,))
        canvas = Image.alpha_composite(canvas.convert("RGBA"), strip.convert("RGBA")
                                       if strip.size == canvas.size else
                                       Image.new("RGBA", canvas.size, (0, 0, 0, 0)))
        canvas = canvas.convert("RGB")
        d = ImageDraw.Draw(canvas)

    stroke = max(3, base_px // 14)
    for line in tl:
        tw = d.textlength(line, font=f_title)
        d.text(((W - tw) / 2, y), line, font=f_title, fill=accent,
               stroke_width=stroke, stroke_fill=(30, 18, 4))
        y += lh_t
    if sl:
        y += int(base_px * .3)
        for line in sl:
            tw = d.textlength(line, font=f_sub)
            d.text(((W - tw) / 2, y), line, font=f_sub, fill=(255, 243, 196),
                   stroke_width=max(2, stroke // 2), stroke_fill=(20, 16, 8))
            y += lh_s
    if tag:
        tw = d.textlength(tag, font=f_tag)
        d.text(((W - tw) / 2, margin * 0.6), tag, font=f_tag,
               fill=(255, 255, 255), stroke_width=max(2, stroke // 3),
               stroke_fill=(24, 30, 44))
    canvas.save(out_png, "PNG")
    return canvas.size


def cmd_layout(a):
    out = Path(a.out).expanduser()
    if out.suffix.lower() in (".png", ".jpg") and a.aspect == "both":
        stem = out.with_suffix("")
    else:
        stem = out
        out.parent.mkdir(parents=True, exist_ok=True)
    made = []
    aspects = ["3x4", "4x3"] if a.aspect == "both" else [a.aspect]
    for asp in aspects:
        size = (1080, 1440) if asp == "3x4" else (1440, 1080)
        p = Path(f"{stem}_{asp}.png")
        p.parent.mkdir(parents=True, exist_ok=True)
        make_layout(a.base, p, size, a.title, a.sub, a.tag, card=a.card)
        made.append(p)
        print(f"{p}  {size[0]}x{size[1]}")
    return made


# ---------------------------------------------------------------- aicover
AICOVER_TMPL = """{desc}
Vertical poster / thumbnail cover, strict 3:4 aspect ratio.

Composition:
- Top 15%: small brand label strip with the text "{tag}".
- Middle: the main subject, large and emotionally clear, centered, cropped naturally.
- Bottom 35%: headline block in Chinese, two lines maximum.

Text to render, exactly as written, no other characters:
headline: 「{title}」
{extra}Typography: bold heavy sans-serif Chinese, high contrast, thick outline or a solid color band behind the text so it stays readable on a phone thumbnail at 25% size.
Color: {palette}.

Rules:
- Render ONLY the Chinese characters given above. No gibberish letters, no extra words, no English, no watermark, no logo, no border frame, no UI mockup.
- Keep the bottom third calm and uncluttered; no busy detail behind the headline.
- 3:4 portrait, 1080x1440 or larger, sharp, print-like quality.
"""


def cmd_aicover(a):
    extra = f'subline: 「{a.sub}」\n' if a.sub else ""
    desc = a.desc or "A clean, high-quality illustration for a Chinese short-video cover."
    text = AICOVER_TMPL.format(desc=desc, tag=a.tag or "", title=a.title,
                               sub=a.sub or "", extra=extra, palette=a.palette)
    text += ("\n注意：AI 一体生成带字封面，中文字形常写错。出图后必须逐字核对标题，"
             "错字就重出或用 layout 子命令在干净底图上后贴字。\n")
    p = Path(a.out).expanduser() if a.out else None
    if p:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
        print(f"{p}")
    else:
        print(text)


# ---------------------------------------------------------------- check
def cmd_check(a):
    from PIL import Image
    bad = []
    files = [Path(x).expanduser() for x in a.file]
    for f in files:
        if not f.exists():
            bad.append(f"{f} 不存在（相对路径按当前目录解析，用绝对路径最稳）")
            print(f"{f.name}: 缺少文件")
            continue
        im = Image.open(f)
        W, H = im.size
        r = W / H
        ok34, ok43 = abs(r - 0.75) < 0.006, abs(r - 4 / 3) < 0.006
        kind = "3:4" if ok34 else ("4:3" if ok43 else f"{r:.3f} ✗比例不对")
        line = f"{f.name}: {W}x{H} {kind} {im.mode}"
        if im.mode != "RGB":
            bad.append(f"{f.name} 不是 RGB（RGB={im.mode}），上传平台可能变色")
        if not (ok34 or ok43):
            bad.append(f"{f.name} 比例 {r:.3f}，应为 0.75 或 1.333")
        if W < 1000:
            bad.append(f"{f.name} 宽 {W}px 偏小，3:4 建议 ≥1080 宽")
        print(line)
    if bad:
        print("\n需要修：")
        for b in bad:
            print("  - " + b)
    else:
        print("\n全部通过")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)

    p = sp.add_parser("frames", help="从成片抽帧并排序")
    p.add_argument("--video", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--count", type=int, default=8)
    p.add_argument("--start-ratio", type=float, default=0.05)
    p.add_argument("--end-ratio", type=float, default=0.05)
    p.set_defaults(fn=cmd_frames)

    p = sp.add_parser("layout", help="底图 → 3:4 / 4:3 封面")
    p.add_argument("--base", required=True)
    p.add_argument("--title", required=True)
    p.add_argument("--sub", default="")
    p.add_argument("--tag", default="")
    p.add_argument("--out", required=True)
    p.add_argument("--aspect", default="both", choices=["both", "3x4", "4x3"])
    p.add_argument("--card", action="store_true", help="标题下加半透明色条")
    p.set_defaults(fn=cmd_layout)

    p = sp.add_parser("aicover", help="生成 AI 带字封面提示词")
    p.add_argument("--title", required=True)
    p.add_argument("--sub", default="")
    p.add_argument("--tag", default="")
    p.add_argument("--desc", default="")
    p.add_argument("--palette", default="warm cream background, charcoal ink, one accent color")
    p.add_argument("--out", default="")
    p.set_defaults(fn=cmd_aicover)

    p = sp.add_parser("check", help="检查封面尺寸/比例/模式")
    p.add_argument("--file", nargs="+", required=True)
    p.set_defaults(fn=cmd_check)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
