---
name: five-platform-publish
description: 把一条竖屏成片发布到五个平台（小红书 / 视频号 / 抖音 / X / YouTube）并回后台核对。当用户说「发布」「发布到五个平台」「分发」「发小红书 / 视频号 / 抖音 / X / YouTube」「多平台发布」「上传视频」「发布台账」时使用。覆盖：素材与文案齐备 → 带登录态的调试 Chrome → 逐平台上传填表 → 声明与封面 → 发布后核对与链接 → 台账落账；含五平台实测入口/选择器、closed shadow DOM 那一关、以及 12 条踩坑。
---

# 五平台发布（five-platform-publish）

一条竖屏成片要发到 **小红书 / 视频号 / 抖音 / X / YouTube**。本技能把五条链路固定成一条流水线：
**素材与文案齐备 → 带登录态的调试 Chrome → 逐平台上传填表 → 声明与封面 → 发布后回后台核对 → 台账落账**。

> 入口、选择器、坑，来自 2026-10-21 的一次完整实测（《你所浪费的今天》14 秒竖屏，五平台都发出去了），
> 并逐条对过当天留下的脚本与日志（`.publish-tools/` 207 个文件）与当天台账 `灵魂歌手工作台.html`。
> **每条关键说法都标了来源；拿不准的地方直接写了「未验证」。**
> 平台前端会改版，每次开跑先 `node scripts/probe.js` 校准，别硬信旧选择器。

## 0 六条硬纪律

1. **不代登录**。Bot 只驱动「用户已登录」的浏览器；登录页开出来让用户自己扫码/输密码，用户说「好了」再动手。
2. **文案先过用户**。标题、正文、话题、封面一次给全，用户说发才发。
3. **关键步骤失败就不许发布**。上传没成功、封面没传上、AI 声明没勾上、正文回读不符 —— 一律拦住。
   `fill.js` 是**两段式**：第一段只填（绝不点发布）→ `publishGate()` 判 blocker → 通过了才执行第二段点发布。
   默认只填不发；要发得显式加 `--publish`，要硬闯 blocker 得再加 `--force`。
   **「视频没传上就点发布」是最丢人的错，所以这条写进了代码顺序，不是写在文档里。**
4. **发布后必须回后台核对**：标题、话题是不是真话题、封面是不是我们那张、可见性/声明/位置。
   「点了发布按钮」不算发布成功。
5. **核对不了就如实说**。小红书/视频号/抖音的永久链接后台拿不到，就让用户从 App 复制，**绝不编链接**。
6. **一个平台发完核对完，再发下一个**。五个一起发，出错时不知道错在哪。

## 1 素材与文案清单（开跑前必须齐）

| 项 | 要求 |
|---|---|
| 成片 | 1080×1920 / H.264 + AAC，**带字幕**那条；无字幕原版留着做 A/B |
| 封面 | 3:4 1080×1440 JPG（做法见 `cover-publish` 技能） |
| 标题 | 小红书 ≤20 字；抖音标题独立一行；YouTube ≤100 字符；X 标题+两句+话题 |
| 正文/简介 | 每平台一份，写进项目的 `publish/` 目录，**一次给用户过目** |
| 话题 | 每平台 3–5 个，写法见 `platforms/*.md` |
| 位置/声明 | 视频号按 IP 自动填位置（中国账号走代理会出现外国城市）→ 必须清；抖音勾「**内容由AI生成**」（没空格，照抄） |

**封面不是「五个平台共用一张」**：小红书（xhs_cover_up2.js）和视频号（sph_cover.js）当天用的是同一张
`封面_小红书_3x4.jpg`；YouTube 走手动上传（文案文件里写明缩略图「不传也行」）；抖音那次归档里没有任何封面步骤。

## 2 开一个带登录态的调试 Chrome

> **本机装了 ego lite 时，优先走 ego 原生版**（`scripts/ego/`）：直接驱动用户真实浏览器，
> 登录态就是用户自己的，**不复制 Chrome 配置、不需要 9222 端口**。
> 用法见 [scripts/ego/README.md](scripts/ego/README.md)。
> 下面这套（复制配置 + 9222 调试 Chrome）保留为备选。

```bash
export PUB_PROJECT=~/Desktop/音乐创作                    # 装了 playwright-core 的项目目录
SKILL=~/.agents/skills/five-platform-publish             # 或 <项目>/skills/five-platform-publish

bash $SKILL/scripts/open-session.sh                      # 复制用户 Chrome 配置 → 起 --remote-debugging-port=9222
node $SKILL/scripts/selftest.js                          # 自检：本地假页面验一遍 lib.js（25 项，不用登录）
node $SKILL/scripts/probe.js --open-login                # 五站登录态自检；未登录的把登录页开到前台
node $SKILL/scripts/probe.js --keep                      # 只看当前标签页、不导航（该站没开标签则仍会新开）
```

实测要点：

- **用配置副本**，不碰用户日常 profile：副本放项目 `.publish-tools/chrome-profile/`。
  ⚠️ 这一步会把用户 Chrome 的 cookie/登录态一并复制过去；**正因为如此，纪律是「让用户在这个副本窗口里自己登录」，Bot 不代登录**。
- 副本里的 cookie **当天已失效**（小红书被弹回登录页、视频号跳登录页）→ 要让用户重新扫码一次，
  登完**别关窗口**，五个站共用同一窗口，后面连续发都靠它。
- 沙箱环境必须加 `--no-sandbox`，否则 `sandbox initialization failed: Operation not permitted`（chrome.log 里能看到）。
- 之后所有脚本用 `chromium.connectOverCDP('http://127.0.0.1:9222')` 接管，**不要再起第二个浏览器**。
- 发完问用户「窗口关不关」——留着＝下次不用重新登录。

## 3 五个平台

详细步骤、选择器、逐条命令在各自文档里：

| 平台 | 入口 | 文档 | 当天结果 |
|---|---|---|---|
| 小红书（你的小红书账号） | `creator.xiaohongshu.com/publish/publish` | [platforms/xiaohongshu.md](platforms/xiaohongshu.md) | ✅ 发出；**发布按钮在 closed shadow DOM** |
| 视频号（你的视频号） | `channels.weixin.qq.com/platform/post/create` | [platforms/shipinhao.md](platforms/shipinhao.md) | ✅ 发出；表单在 iframe 里 |
| 抖音 | `creator.douyin.com/creator-micro/content/upload` | [platforms/douyin.md](platforms/douyin.md) | ✅ 发出；已声明「内容由AI生成」 |
| X（@你的X账号） | `x.com/compose/post` | [platforms/x.md](platforms/x.md) | ✅ 发出（重发过一次，主页复核后确认） |
| YouTube（你的YouTube频道名） | `studio.youtube.com` | [platforms/youtube.md](platforms/youtube.md) | ⚠️ **上传不稳**，改用户手动传 |

> 括号里的账号名来自用户提供/当日后台显示；**归档脚本里没有留存账号名**（只有 YouTube 的 channel id 反复出现）。
> 换账号时以 `probe.js` 实际读到的页面为准，别照抄。

## 4 通用招式（这五站全靠这几招）

1. **能不用 `locator.click()` 就不用**。这种重前端页面上它会超时（当天 X 的 `[data-testid="tweetButton"]`
   出现过 `Timeout 30000ms exceeded`，日志把原因截断了，**真实原因没留下**；台账把「点不到 Post」归因于
   「话题联想下拉没关掉，要先按 Esc」）。
   稳的做法：`evaluate` 取 `getBoundingClientRect()` 中心 → `page.mouse.click(x, y)`。
   **但按钮被 toast/遮罩盖住时坐标点击会打空**——那种情况用 `element.click()` 直接触发（抖音当天就是这么过的）。
2. **找「文字按钮」**：遍历 `document.querySelectorAll('*')`，取 `innerText.trim() === '发布'` 且
   `children.length === 0` 的叶子节点（class 名全是哈希，`getByRole` 常匹配不到，中文按钮文字很稳）。
   ⚠️ **它穿不透 shadow DOM**：小红书的发布按钮在 `<xhs-publish-btn>` 的 **closed** shadow root 里，
   `innerText` 和 `page.locator` 都看不见它 —— 那里必须用 CDP 通道：
   `DOM.getDocument{pierce:true}` 遍历到节点 → `DOM.getBoxModel` 取坐标 → `mouse.click`（`lib.js` 的 `clickViaCDP`）。
3. **iframe 里的元素没有 mouse**（视频号整张表单在 iframe 里）：frame 内坐标 + iframe 偏移 ＝ 页面坐标，
   再用 `page.mouse.click()`。`clickText(page, t, {frame})` 已换算好；**iframe 会重新挂载，每步重新取 frame**。
4. **每个 `evaluate` 都包 retry**：标签在渲染/导航时会抛 `Execution context was destroyed`，这不是页面坏了。
5. **别用固定 sleep 等上传**：轮询状态文本 / 百分比（`重新上传|上传完成|100%`，X 那边是**等百分比消失**）。
6. **每步截图**存 `.publish-tools/<平台>_<步骤>.png`。事后核对、跟用户解释，全靠这些图。
7. **改文本框后必须回读校验**：`Meta+A` 全选偶发不生效，直接把新内容拼在旧内容后面。
   改前 `click(x, y, {clickCount: 3})` 再 `Meta+A`，写完回读，不符就重来（`typeInto(..., {verify})` 已内置）。
8. **发布按钮先 `scrollIntoView({block:'center'})`**：按钮在视口外时坐标点击必打空。

## 5 发布后核对清单（逐项打勾，缺一项不算完成）

| 检查 | 怎么看 |
|---|---|
| 标题完整 | 回后台列表/详情读一遍，不是看我们填了什么 |
| 话题是真话题 | 小红书回读编辑器 `innerHTML` 数 `a` 标签；抖音/视频号看话题有没有变色/可点 |
| 封面是我们那张 | 后台列表缩略图 + 小红书「封面质量评估」提示 |
| 可见性 | 视频号「公开」、YouTube「公开」、抖音「审核中」都正常，实事求是写状态 |
| 声明 | 抖音已选「内容由AI生成」；视频号「原创审核中」= 账号默认（这个账号所有视频都有），不是本次勾的 |
| 位置 | 视频号不能出现外国城市名 |
| 链接 | 能拿到就写链接；拿不到的写「后台没找到复制入口」并说明让用户从 App 取 |

## 6 坑清单（12 条，均来自当天的脚本/日志/台账）

1. **小红书发布按钮在 `<xhs-publish-btn>` 的 closed shadow root 里**：`innerText` / `page.locator` /
   `shadowRoot` 都拿不到（当天 find_pub/find_pub2/find_pub3 连试三次都没找到；shadow.js 的探测结果是 `closed shadow`）。
   要 CDP `DOM.getDocument{pierce:true}` + `DOM.getBoxModel` 取坐标再点。
2. **小红书别用固定坐标**：当天用 (730,700) 点过两次、还探过一排坐标都没中；页面高度一变就点在按钮缝隙里。
3. **小红书「设置封面」打开的是封面编辑器弹窗**：页面上那个按钮会被遮罩挡住，上传入口在弹窗里。
4. **小红书账号若有「原创声明」开关**，读 `checked` 确认状态，别假设默认值。
5. **视频号整张表单在 iframe**（`/micro/content/post/create`）里，外层 DOM 什么都抓不到；iframe 会重新挂载，每步重新取。
6. **视频号「上传封面」的热区在文字上方约 40px 的 + 号**，不在文字上。
7. **视频号会按 IP 自动填位置**（当天填成「华盛顿」），必须改成「不显示位置」；改完回读确认。
8. **视频号短标题是独立输入框**（`input[placeholder*="短标题"]`），描述 ≠ 短标题。
9. **抖音先关引导弹窗**（「我知道了」），否则遮罩挡住表单。
10. **抖音「自主声明」文案没有空格**：是「内容由AI生成」。要先滚到「请选择自主声明」点开再选，选完回读确认不再是「请选择」。
11. **抖音发布按钮被 toast 遮挡时**，坐标点击会打空 → 用 `element.click()` 直接触发（台账原话）。
12. **YouTube Studio 的上传不稳**：当天 03:31 有一次成功渲染对话框并真的开始上传（7%），但同一批脚本在别的时刻
    又找不到「选择文件」，还常被页面导航打断。**能走通，但不稳定，别再反复重试**——上传交给用户手动拖，
    Bot 用编辑页 `/video/<id>/edit` 改标题/说明并核对（这条自动化是稳的）。

## 7 脚本

```bash
SKILL=~/.agents/skills/five-platform-publish
export PUB_PROJECT=~/Desktop/音乐创作

bash $SKILL/scripts/open-session.sh            # 起调试 Chrome（复制配置 + 9222）
node $SKILL/scripts/selftest.js                # 自检 lib.js（本地假页面，含 closed shadow / 双 iframe / 发布闸门）：25/25
node $SKILL/scripts/probe.js --open-login      # 登录态自检（--open-login 把登录页开到前台）
node $SKILL/scripts/probe.js xhs sph           # 只查指定站；--keep 表示只看当前标签页、不导航

# 填表：默认只填不发（第一段）
node $SKILL/scripts/fill.js xhs --spec $SKILL/spec/xhs.json
# 看过截图、用户确认后，加 --publish：先判 blocker，通过才点发布（第二段）
node $SKILL/scripts/fill.js xhs --spec $SKILL/spec/xhs.json --publish
# 有 blocker 但确认无害才硬发
node $SKILL/scripts/fill.js dy --spec $SKILL/spec/dy.json --publish --force
```

`spec/` 里放的是**当天那条片子的真实参数**（`video`/`cover` 相对 `PUB_PROJECT` 解析，文件都在），当模板改。
`--spec` 的路径按顺序找：**当前目录 → 技能包目录/`spec/` → `PUB_PROJECT`**，所以上面用 `$SKILL/spec/xxx.json` 最稳。

```json
{
  "video": "output/20261021_温情民谣短歌_你所浪费的今天/成片_你所浪费的今天_14秒_MV_字幕版.mp4",
  "cover": "output/20261021_温情民谣短歌_你所浪费的今天/publish/封面_小红书_3x4.jpg",
  "title": "你所浪费的今天，是他奢望的明天",
  "shortTitle": "你所浪费的今天",
  "body": "正文……\n第二段……",
  "tags": ["AI音乐", "原创民谣", "治愈文案", "情绪短片"],
  "declareAI": true,
  "hideLocation": true
}
```

**默认只填不发**：填完截图给你（和用户）看，确认后才加 `--publish`。这是故意的——发布不可逆。

### 小红书「图文笔记」（多图）走另一条脚本

上面的 `fill.js`（旧版）和 `scripts/ego/fill.mjs` 都只处理**视频**。小红书图文（多图 + 标题 + 正文 + 话题）用
**`scripts/ego/note.mjs`**，命令 JSON 里加 `note: true`，spec 用 `spec/notes/xhs-*.json`：

```bash
CMD=~/Desktop/音乐创作/.publish-tools/ego-cmd.json
echo '{"note":true,"spec":"spec/notes/_template.json","preflightOnly":true}' > $CMD   # 只跑前置检查（不碰浏览器）
echo '{"note":true,"spec":"spec/notes/_template.json"}' > $CMD                          # 只填不发
echo '{"note":true,"spec":"spec/notes/_template.json","publish":true}' > $CMD           # 闸门通过才发
ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/note.mjs")'
```

spec 字段：`images`（数组，按序，第 1 张当封面）/ `baseDir` / `title`（≤20 字）/ `body` /
`tags` / `bannedWords`（命中即 blocker）/ `declareOriginal`。
细节与「已验证 / 未验证」见 [scripts/ego/README.md](scripts/ego/README.md) 第 2.3、5 节。

## 8 落账

发完写进项目里的新媒体工作台（`灵魂歌手工作台.html` → 发布台账视图；数据内联在页面里，改完点「导出 data.js」）。
每条至少记：平台 / 账号 / 标题 / 状态 / 时间 / 链接 / 文案文件路径 / 封面路径 / 当次的坑。

要回填 48 小时的播放点赞，用 `media-detail` 技能（按链接读各平台数据）。

## 9 相关技能

- `cover-publish`：出 3:4 + 4:3 封面、发布作战卡（本技能的上一环）
- `micro-song` / `lyric-story-mv`：出歌与 MV（本技能的上一环）
- `media-detail`：发布后读平台数据（本技能的下一环）
- `browse` / `browser-skill`：无登录态页面的读取与截图
