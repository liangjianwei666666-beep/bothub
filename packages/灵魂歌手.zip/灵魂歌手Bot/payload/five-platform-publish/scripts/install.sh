#!/usr/bin/env bash
# 把本技能装进 DSH 的技能库目录（默认 ~/.agents/skills）。
#   bash scripts/install.sh
#   SKILLS_DIR=~/.dsh/skills bash scripts/install.sh
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST_ROOT="${SKILLS_DIR:-$HOME/.agents/skills}"
DEST="$DEST_ROOT/five-platform-publish"

mkdir -p "$DEST_ROOT"
if [ -d "$DEST" ]; then
  echo "已存在，先备份到 $DEST.bak"
  rm -rf "$DEST.bak"
  cp -R "$DEST" "$DEST.bak"
fi
rm -rf "$DEST"
mkdir -p "$DEST"
cp -R "$HERE/SKILL.md" "$HERE/platforms" "$HERE/scripts" "$HERE/spec" "$DEST/"
chmod +x "$DEST/scripts/"*.sh
echo "已安装：$DEST"
ls -R "$DEST" | head -30
echo
echo "下次会话起，技能库里会出现 five-platform-publish。"
echo "脚本里若找不到 playwright-core，设 PUB_PROJECT=<装了 playwright-core 的项目目录>。"
