'use strict';
/**
 * five-platform-publish / lib.js
 *
 * 五平台发布通用工具。三条真实教训决定了它的样子：
 *   1) 小红书发布按钮在 <xhs-publish-btn> 的 **closed shadow root** 里 ——
 *      document.querySelectorAll / innerText / page.locator 都看不见它，只能用 CDP 穿透（clickViaCDP）。
 *   2) 这些站 class 名全是哈希，但**可见的中文按钮文字**很稳（前提是它不在 closed shadow 里）。
 *   3) locator.click() 在这种重前端页面上容易超时或被遮挡 —— 统一走 rect/boxModel + mouse.click。
 *
 * 依赖 playwright-core：在项目目录里 `npm i playwright-core`，或设 PUB_PW=<playwright-core 目录>。
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const CDP = process.env.PUB_CDP || 'http://127.0.0.1:9222';
const SHOTS = process.env.PUB_SHOTS || path.join(process.cwd(), '.publish-tools');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

/** playwright-core 可能在别处装着（技能目录被拷到 ~/.agents/skills 后就找不到项目的 node_modules） */
function resolvePlaywright() {
  const roots = [];
  if (process.env.PUB_PW) roots.push(process.env.PUB_PW);
  for (const start of [__dirname, process.cwd()]) {
    let dir = start;
    for (let i = 0; i < 8; i++) {
      roots.push(path.join(dir, 'node_modules', 'playwright-core'));
      const up = path.dirname(dir);
      if (up === dir) break;
      dir = up;
    }
  }
  roots.push(path.join(os.homedir(), 'Desktop', '音乐创作', 'node_modules', 'playwright-core'));
  const tried = [];
  for (const r of roots) {
    try {
      return require(r);
    } catch (e) {
      tried.push(r);
    }
  }
  throw new Error(
    '找不到 playwright-core。在项目目录执行 `npm i playwright-core`，或设 PUB_PW=<path>。已试过：\n  ' +
      tried.join('\n  ')
  );
}
const { chromium } = resolvePlaywright();

/* ─────────────── 连接与取页 ─────────────── */

async function connect(cdpUrl = CDP) {
  let b;
  try {
    b = await chromium.connectOverCDP(cdpUrl);
  } catch (e) {
    throw new Error(
      `连不上 ${cdpUrl}。先跑 scripts/open-session.sh 起调试 Chrome（并让用户在窗口里登录）。原因：${e.message}`
    );
  }
  const ctx = b.contexts()[0] || (await b.newContext());
  return { b, ctx };
}

async function tab(ctx, urlPart, { open = null, waitMs = 5000 } = {}) {
  let p = ctx.pages().find((x) => x.url().includes(urlPart));
  if (!p && open) {
    p = await ctx.newPage();
    await p.goto(open, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    await sleep(waitMs);
  }
  if (!p) throw new Error(`没找到标签页：${urlPart}`);
  await p.bringToFront().catch(() => {});
  return p;
}

function frame(page, urlPart) {
  return page.frames().find((f) => f.url().includes(urlPart)) || null;
}

/** iframe 在页面里的偏移（页面坐标 = frame 内坐标 + 这个偏移）。 */
async function iframeOffset(page, srcPart) {
  return await page.evaluate((part) => {
    const i = [...document.querySelectorAll('iframe')].find((x) => (x.src || '').includes(part));
    if (!i) return null;
    const r = i.getBoundingClientRect();
    return [r.x, r.y];
  }, srcPart);
}

/**
 * 找 frame 对应的那个顶层 iframe 的偏移（页面坐标 = frame 内坐标 + 这个偏移）。
 * 配对规则（必须稳，视频号整条链路都靠它）：
 *   · 顶层 iframe 的 DOM 顺序 == 主 frame 的子 frame 顺序，先按序号取；
 *   · 如果该序号位置就是同源 iframe（或全页只有一个同源 iframe），就用它，避免序号被别的 iframe 挤偏。
 * 嵌套 iframe（frame 的 parentFrame 不是主 frame）不在这里处理，返回 null。
 */
async function frameOffsetOf(page, fr) {
  if (!fr) return null;
  const frames = page.frames().filter((f) => f.parentFrame && f.parentFrame() === page.mainFrame());
  const idx = frames.indexOf(fr);
  if (idx < 0) return null;
  let origin = '';
  try {
    const o = new URL(fr.url()).origin;
    if (o && o !== 'null') origin = o;
  } catch (e) {
    origin = '';
  }
  return await page.evaluate(
    ({ n, origin }) => {
      const els = [...document.querySelectorAll('iframe')];
      let cand = n;
      if (origin) {
        const hits = els.map((e, i) => [e, i]).filter(([e]) => (e.src || '').startsWith(origin));
        // 同源只有一个 → 明确；有多个就用序号（别拿第一个凑数，那正是错位的原因）
        if (hits.length === 1) cand = hits[0][1];
      }
      const el = els[cand];
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return [r.x, r.y];
    },
    { n: idx, origin }
  );
}

/* ─────────────── 定位与点击 ─────────────── */

/**
 * 轻 DOM 里的「文字按钮」定位：innerText 精确等于（或包含）text 的叶子节点 → 中心坐标。
 * 限制（实测踩过）：**穿不透 shadow DOM，closed shadow root 更不可能**。
 * 小红书发布按钮就在 closed shadow 里 → 那里必须用 clickViaCDP()。
 */
async function rectIn(scope, text, { exact = true, nth = 0 } = {}) {
  return await scope.evaluate(
    ({ t, exact, nth }) => {
      const hits = [];
      document.querySelectorAll('*').forEach((e) => {
        if (e.children.length) return;
        const s = (e.innerText || '').trim();
        if (!s) return;
        if (exact ? s !== t : !s.includes(t)) return;
        const r = e.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) hits.push([Math.round(r.x + r.width / 2), Math.round(r.y + r.height / 2)]);
      });
      return hits[nth] || null;
    },
    { t: text, exact, nth }
  );
}

async function rectOf(scope, selector, { nth = 0 } = {}) {
  return await scope.evaluate(
    ({ sel, nth }) => {
      const els = [...document.querySelectorAll(sel)].filter((e) => {
        const r = e.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      const e = els[nth];
      if (!e) return null;
      const r = e.getBoundingClientRect();
      return [Math.round(r.x + r.width / 2), Math.round(r.y + r.height / 2)];
    },
    { sel: selector, nth }
  );
}

/** 把元素滚进视口中央——按钮在视口外时坐标点击会打空。和 rectIn 一样：**穿不透 shadow DOM**。 */
async function scrollInto(scope, text, exact = true) {
  return await scope.evaluate(
    ({ t, exact }) => {
      const el = [...document.querySelectorAll('*')].find((e) => {
        if (e.children.length) return false;
        const s = (e.innerText || '').trim();
        return exact ? s === t : s.includes(t);
      });
      if (!el) return false;
      el.scrollIntoView({ block: 'center' });
      return true;
    },
    { t: text, exact }
  );
}

/**
 * 点「文字按钮」（轻 DOM）。不用 locator.click()：实测在 X 上会超时 30s，
 * 在被遮挡时也会打空；走 rect + mouse.click 更可控。
 */
async function clickText(page, text, { frame: fr = null, exact = true, dy = 0, nth = 0, clickCount = 1, scroll = true } = {}) {
  const scope = fr || page;
  if (scroll) await scrollInto(scope, text, exact).catch(() => {});
  const r = await rectIn(scope, text, { exact, nth });
  if (!r) return false;
  let [x, y] = r;
  if (fr) {
    const off = await frameOffsetOf(page, fr);
    if (off) {
      x += off[0];
      y += off[1];
    }
  }
  await page.mouse.click(x, y + dy, { clickCount });
  return true;
}

/**
 * ★ CDP 穿透点击：能点进 **shadow DOM（含 closed shadow root）**。
 * 小红书发布按钮（xhs-publish-btn 内部）只能靠这条通道 —— 轻 DOM 方法找不到它。
 *
 * ⚠️ 默认**不跨 iframe**（crossFrame=false）：CDP 给的是该节点在自己 frame 里的坐标，
 * 直接拿去 page.mouse.click 会点错地方。iframe 里的元素请用 clickText/clickSel 的 {frame} 参数（会加偏移）。
 * 返回点击坐标 [x, y]，没找到返回 null。
 */
async function clickViaCDP(
  ctx,
  page,
  text,
  {
    nodeNames = ['BUTTON', 'A', 'DIV', 'SPAN', 'INPUT', 'YTPC-BUTTON'],
    className = null,
    nth = 0,
    click = true,
    crossFrame = false,
  } = {}
) {
  const client = await ctx.newCDPSession(page);
  try {
    const { root } = await client.send('DOM.getDocument', { depth: -1, pierce: true });
    const want = (text || '').replace(/\s+/g, '');
    const hits = [];
    const textOf = (n, depth = 0) => {
      if (!n || depth > 8) return '';
      if (n.nodeType === 3) return n.nodeValue || '';
      let s = '';
      for (const c of n.children || []) s += textOf(c, depth + 1);
      return s;
    };
    (function walk(n) {
      if (!n) return;
      if (nodeNames.includes(n.nodeName)) {
        const attrs = {};
        for (let i = 0; i < (n.attributes || []).length; i += 2) attrs[n.attributes[i]] = n.attributes[i + 1];
        const okText = want ? textOf(n).replace(/\s+/g, '') === want : true;
        const okClass = className ? (attrs.class || '').includes(className) : true;
        if (okText && okClass) hits.push(n);
      }
      for (const c of n.children || []) walk(c);
      for (const s of n.shadowRoots || []) walk(s);
      if (crossFrame && n.contentDocument) walk(n.contentDocument);
    })(root);
    const target = hits[nth];
    if (!target) return null;
    const { model } = await client.send('DOM.getBoxModel', { nodeId: target.nodeId });
    const q = model.content; // [x1,y1,x2,y2,x3,y3,x4,y4]
    const x = Math.round((q[0] + q[2] + q[4] + q[6]) / 4);
    const y = Math.round((q[1] + q[3] + q[5] + q[7]) / 4);
    if (click) await page.mouse.click(x, y);
    return [x, y];
  } catch (e) {
    log('clickViaCDP 失败：', e.message.split('\n')[0]);
    return null;
  } finally {
    await client.detach().catch(() => {});
  }
}

/** 点一个已知选择器（rect 中心）；传 frame 时自动加 iframe 偏移。 */
async function clickSel(page, selector, { nth = 0, clickCount = 1, frame: fr = null } = {}) {
  const r = await rectOf(fr || page, selector, { nth });
  if (!r) return false;
  const off = fr ? await frameOffsetOf(page, fr) : null;
  await page.mouse.click(r[0] + (off ? off[0] : 0), r[1] + (off ? off[1] : 0), { clickCount });
  return true;
}

/* ─────────────── 读取、等待、重试 ─────────────── */

/** 重试包裹：标签在渲染/导航中 evaluate 会抛异常。arg 用于给页面函数传一个参数。 */
async function evalRetry(page, fn, { arg, tries = 8, every = 1500, label = '' } = {}) {
  let lastErr = null;
  for (let i = 0; i < tries; i++) {
    try {
      return arg === undefined ? await page.evaluate(fn) : await page.evaluate(fn, arg);
    } catch (e) {
      lastErr = e;
    }
    await sleep(every);
  }
  if (lastErr) log(`evalRetry 失败${label ? '（' + label + '）' : ''}：`, lastErr.message.split('\n')[0]);
  return null;
}

/** 反复取值直到「真值」（返回 null 不算成功，会继续等）；适合等元素出现。 */
async function waitFor(page, fn, { arg, tries = 10, every = 1500, label = '' } = {}) {
  for (let i = 0; i < tries; i++) {
    try {
      const v = arg === undefined ? await page.evaluate(fn) : await page.evaluate(fn, arg);
      if (v) return v;
    } catch (e) {
      /* 页面忙，继续等 */
    }
    await sleep(every);
  }
  log(`waitFor 超时${label ? '（' + label + '）' : ''}`);
  return null;
}

async function text(scope) {
  try {
    return await scope.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
  } catch (e) {
    return '';
  }
}

/** 读输入框/可编辑元素的当前值（回读校验用）。 */
async function readText(page, selector, { frame: fr = null } = {}) {
  const scope = fr || page;
  try {
    return await scope.evaluate((sel) => {
      const e = document.querySelector(sel);
      if (!e) return null;
      if (e.value !== undefined && e.value !== null && e.value !== '') return e.value;
      return e.innerText || '';
    }, selector);
  } catch (e) {
    return null;
  }
}

async function waitForText(scope, re, { tries = 25, every = 4000, label = '' } = {}) {
  for (let i = 0; i < tries; i++) {
    const t = await text(scope);
    if (re.test(t)) return { ok: true, text: t };
    await sleep(every);
  }
  const t = await text(scope);
  log(`waitForText 超时${label ? '（' + label + '）' : ''}：`, t.slice(0, 160));
  return { ok: false, text: t };
}

async function shot(page, name) {
  try {
    fs.mkdirSync(SHOTS, { recursive: true });
    const f = path.join(SHOTS, `${name}.png`);
    await page.screenshot({ path: f });
    log('shot', f);
    return f;
  } catch (e) {
    log('截图失败', e.message.slice(0, 80));
    return null;
  }
}

/* ─────────────── 上传文件 ─────────────── */

/**
 * 跨 shadow DOM / iframe 找 file input 并塞文件（视频号、抖音靠这个）。
 * accept 传 null 表示不限类型（X 的成功脚本没有按 accept 过滤）。
 */
async function uploadViaCDP(ctx, page, file, { accept = 'video' } = {}) {
  if (!fs.existsSync(file)) throw new Error(`文件不存在：${file}`);
  const client = await ctx.newCDPSession(page);
  try {
    const { root } = await client.send('DOM.getDocument', { depth: -1, pierce: true });
    let target = null;
    (function walk(n) {
      if (!n || target) return;
      if (n.nodeName === 'INPUT') {
        const a = {};
        for (let i = 0; i < (n.attributes || []).length; i += 2) a[n.attributes[i]] = n.attributes[i + 1];
        if (a.type === 'file' && (!accept || (a.accept || '').includes(accept))) target = n;
      }
      for (const c of n.children || []) {
        walk(c);
        if (target) return;
      }
      for (const s of n.shadowRoots || []) {
        walk(s);
        if (target) return;
      }
      if (n.contentDocument) walk(n.contentDocument);
    })(root);
    if (!target) {
      log(`没找到 accept 含 "${accept}" 的 file input`);
      return false;
    }
    await client.send('DOM.setFileInputFiles', { nodeId: target.nodeId, files: [file] });
    log('已通过 CDP 塞入文件', path.basename(file));
    return true;
  } finally {
    await client.detach().catch(() => {});
  }
}

/** 传视频：先按 accept=video 找，找不到再放宽到任意 file input。 */
async function uploadVideo(ctx, page, file) {
  return (await uploadViaCDP(ctx, page, file, { accept: 'video' })) || (await uploadViaCDP(ctx, page, file, { accept: null }));
}

/** 点某个控件后接住系统文件选择框。 */
async function withFileChooser(page, clickFn, file, { timeout = 15000 } = {}) {
  const fc = page.waitForEvent('filechooser', { timeout }).catch(() => null);
  await clickFn();
  const chooser = await fc;
  if (!chooser) {
    log('没等到 filechooser');
    return false;
  }
  await chooser.setFiles(file);
  log('已通过 filechooser 塞入文件', path.basename(file));
  return true;
}

/* ─────────────── 打字与话题 ─────────────── */

/**
 * 点进去再打字（contenteditable 用 fill() 无效）。
 * clear 时三击 + Meta+A 双保险；给了 verify（选择器）就**回读校验**，不符再试一轮。
 */
async function typeInto(page, target, str, { delay = 12, clear = false, frame: fr = null, verify = null, tries = 2 } = {}) {
  const off = fr ? await frameOffsetOf(page, fr) : null;
  const ox = off ? off[0] : 0;
  const oy = off ? off[1] : 0;
  const attempts = verify ? tries : 1;
  let last = '';
  for (let i = 0; i < attempts; i++) {
    if (typeof target === 'string') {
      const r = await rectOf(fr || page, target);
      if (!r) return false;
      await page.mouse.click(r[0] + ox, r[1] + oy, clear ? { clickCount: 3 } : {});
    } else if (Array.isArray(target)) {
      await page.mouse.click(target[0] + ox, target[1] + oy, { clickCount: 3 });
    }
    await sleep(500);
    if (clear) {
      await page.keyboard.press('Meta+A');
      await sleep(250);
      await page.keyboard.press('Backspace');
      await sleep(300);
    }
    await page.keyboard.type(str, { delay });
    if (!verify) return true;
    await sleep(700);
    last = (await readText(page, verify, { frame: fr })) || '';
    if (last.replace(/\s+/g, '') === String(str).replace(/\s+/g, '')) return true;
    log(`回读不符（第 ${i + 1}/${attempts} 次）：${last.slice(0, 50)}`);
  }
  return false;
}

/** 逐条加话题：打 #话题 → 等联想 → Enter → 空格（不加空格下一个 # 会粘上）。 */
async function addTags(page, tags, { delay = 60, wait = 1400 } = {}) {
  for (const t of tags) {
    await page.keyboard.type('#' + t, { delay });
    await sleep(wait);
    await page.keyboard.press('Enter');
    await sleep(500);
    await page.keyboard.type(' ', { delay: 20 });
  }
}

/**
 * 等上传完成的统一门：
 *   · done 命中、busy 不命中才算完成（光看「发布」这种一直存在的词会恒真 —— 抖音踩过）；
 *   · requireSeen 用于「先看到进度、再看到它消失」（X 的百分比就是这样）。没看到过就不算完成。
 */
async function waitForUploadDone(scope, { done, busy, requireSeen = null, tries = 30, every = 4000, label = '' } = {}) {
  let sawSeen = !requireSeen;
  for (let i = 0; i < tries; i++) {
    const t = await text(scope);
    if (requireSeen && requireSeen.test(t)) sawSeen = true;
    if (done.test(t) && !busy.test(t) && sawSeen) return { ok: true, text: t, rounds: i + 1 };
    await sleep(every);
  }
  const t = await text(scope);
  log(`waitForUploadDone 超时${label ? '（' + label + '）' : ''}：`, t.slice(0, 160));
  return { ok: false, text: t, sawSeen };
}

/**
 * ★ 发布闸门：**先填完、判完 blocker，才决定要不要点发布**。
 * 违规顺序（先点发布再判 blocker）等于没有门 —— 这是这份技能里最重要的一行逻辑。
 */
function publishGate({ blockers = [], doPublish = false, force = false } = {}) {
  if (!doPublish) return { allowed: false, publish: false, reason: '只填不发（默认）' };
  if (blockers.length && !force) return { allowed: false, publish: false, reason: 'blockers: ' + blockers.join('；') };
  return { allowed: true, publish: true, reason: force && blockers.length ? '有 blocker，但 --force 硬发' : 'ok' };
}

module.exports = {
  CDP,
  SHOTS,
  sleep,
  log,
  chromium,
  connect,
  tab,
  frame,
  iframeOffset,
  frameOffsetOf,
  rectIn,
  rectOf,
  scrollInto,
  clickText,
  clickViaCDP,
  clickSel,
  evalRetry,
  waitFor,
  text,
  readText,
  waitForText,
  waitForUploadDone,
  publishGate,
  shot,
  uploadViaCDP,
  uploadVideo,
  withFileChooser,
  typeInto,
  addTags,
};

if (require.main === module) {
  (async () => {
    log('playwright-core OK');
    log('CDP:', CDP);
    try {
      const b = await chromium.connectOverCDP(CDP);
      const ctx = b.contexts()[0];
      log('连上了，标签页数:', ctx.pages().length);
      for (const p of ctx.pages()) log('  -', p.url().slice(0, 90));
      await b.close();
    } catch (e) {
      log('连不上调试 Chrome（先跑 scripts/open-session.sh）:', e.message.split('\n')[0]);
    }
  })();
}
