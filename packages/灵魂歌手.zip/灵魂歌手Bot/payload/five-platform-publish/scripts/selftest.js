'use strict';
/**
 * lib.js 的离线自检：起一个本地 Chrome + 假页面，把真正依赖的每一招各验一遍。
 *
 *   node scripts/selftest.js
 *
 * 不需要登录、不碰任何平台。重点覆盖当天/复核踩过的坑：
 *   · 小红书那种「按钮在 closed shadow root 里」—— 只有 CDP 通道点得到（clickViaCDP）
 *   · 两个同源 iframe 时的坐标换算（视频号后台不止一个 iframe，序号错位就会点空）
 *   · CDP 通道**不跨 iframe**（跨了就会点错地方）
 *   · 发布闸门 publishGate（blocker 必须真的拦住发布）
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'pub-selftest-'));
process.env.PUB_SHOTS = path.join(TMP, 'shots');

const L = require('./lib.js');

const PAGE = `<!doctype html><meta charset="utf-8">
<body style="font:16px sans-serif;padding:40px">
  <button id="publish">发布</button>
  <input id="title" placeholder="标题" />
  <div id="ed" contenteditable="true" style="border:1px solid #ccc;height:60px"></div>
  <input id="file" type="file" accept="video/*" />
  <div id="host"></div>
  <iframe id="frA" src="frameA.html" style="width:400px;height:150px;border:1px solid #999"></iframe>
  <iframe id="frB" src="frameB.html" style="width:400px;height:150px;border:1px solid #999"></iframe>
  <script>
    window.__clicked = 0;
    document.getElementById('publish').addEventListener('click', () => { window.__clicked++; });
    window.__files = 0;
    document.getElementById('file').addEventListener('change', e => { window.__files = e.target.files.length; });
    // 关键：closed shadow root 里的按钮（小红书发布按钮的同款结构）
    window.__shadowClicked = 0;
    const sr = document.getElementById('host').attachShadow({ mode: 'closed' });
    sr.innerHTML = '<button id="inner" style="padding:8px 20px">发布笔记</button>';
    sr.querySelector('#inner').addEventListener('click', () => { window.__shadowClicked++; });
    setTimeout(() => {
      const d = document.createElement('div');
      d.id = 'later';
      d.textContent = '迟到的元素';
      document.body.appendChild(d);
    }, 1500);
  </script>
</body>`;

const FRAME_A = `<!doctype html><meta charset="utf-8">
<body style="font:16px sans-serif;padding:20px">
  <button id="a">直接发表</button>
  <div class="input-editor" contenteditable="true" style="border:1px solid #ccc;height:50px"></div>
  <script>window.__frameClicked = 0; document.getElementById('a').addEventListener('click', () => { window.__frameClicked++; });</script>
</body>`;

// 第二个 iframe：用来验证「两个同源 iframe 时不会点错」
const FRAME_B = `<!doctype html><meta charset="utf-8">
<body style="font:16px sans-serif;padding:20px">
  <button id="b">第二帧按钮</button>
  <script>window.__frameClicked = 0; document.getElementById('b').addEventListener('click', () => { window.__frameClicked++; });</script>
</body>`;

const results = [];
function check(name, ok, extra = '') {
  results.push({ name, ok: !!ok });
  console.log(`${ok ? '✅' : '❌'} ${name}${extra ? '  ' + extra : ''}`);
}
function pure(name, ok, extra = '') {
  check(name, ok, extra);
}

(async () => {
  // ── 纯逻辑：发布闸门（不需要浏览器） ──
  const g = L.publishGate.bind(L);
  pure('publishGate：有 blocker + --publish → 拦住', g({ blockers: ['视频没传上'], doPublish: true }).allowed === false);
  pure('publishGate：无 blocker + --publish → 放行', g({ blockers: [], doPublish: true }).allowed === true);
  pure('publishGate：--force 才能硬发', g({ blockers: ['x'], doPublish: true, force: true }).allowed === true);
  pure('publishGate：默认只填不发', g({ blockers: [], doPublish: false }).publish === false);

  fs.writeFileSync(path.join(TMP, 'page.html'), PAGE);
  fs.writeFileSync(path.join(TMP, 'frameA.html'), FRAME_A);
  fs.writeFileSync(path.join(TMP, 'frameB.html'), FRAME_B);
  const video = path.join(TMP, 'fake.mp4');
  fs.writeFileSync(video, 'nope');

  const chrome = process.env.CHROME_BIN || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
  if (!fs.existsSync(chrome)) {
    console.error('找不到 Chrome：' + chrome + '（用 CHROME_BIN 指定）');
    process.exit(1);
  }
  const ctx = await L.chromium.launchPersistentContext(path.join(TMP, 'profile'), {
    executablePath: chrome,
    headless: true,
    viewport: { width: 1280, height: 900 },
    args: ['--no-sandbox', '--allow-file-access-from-files', '--disable-blink-features=AutomationControlled'],
  });
  const page = ctx.pages()[0] || (await ctx.newPage());
  await page.goto('file://' + path.join(TMP, 'page.html'), { waitUntil: 'domcontentloaded' });
  await L.sleep(800);

  // 轻 DOM
  check('rectIn 找到「发布」叶子节点', !!(await L.rectIn(page, '发布')));
  const clicked = await L.clickText(page, '发布');
  check('clickText 点到轻 DOM 按钮', clicked && (await page.evaluate(() => window.__clicked)) === 1);

  // closed shadow root
  check('rectIn 穿不透 closed shadow（预期就是找不到）', (await L.rectIn(page, '发布笔记')) === null);
  const box = await L.clickViaCDP(ctx, page, '发布笔记');
  await L.sleep(300);
  const sc = await page.evaluate(() => window.__shadowClicked);
  check('clickViaCDP 穿透 closed shadow root 并点中', !!box && sc === 1, `box=${JSON.stringify(box)} clicked=${sc}`);

  // CDP 通道默认不跨 iframe
  const cross = await L.clickViaCDP(ctx, page, '第二帧按钮');
  check('clickViaCDP 默认不跨 iframe（跨了会点错坐标）', cross === null, `返回 ${JSON.stringify(cross)}`);

  // 输入 + 回读
  await L.typeInto(page, '#title', '标题测试', { clear: true, verify: '#title' });
  check('typeInto 填输入框 + 回读校验', (await page.inputValue('#title')) === '标题测试');
  await page.evaluate(() => { document.getElementById('title').value = '旧的脏数据'; });
  const okClear = await L.typeInto(page, '#title', '第二版标题', { clear: true, verify: '#title' });
  check('typeInto clear 能清掉旧值（不会拼接）', okClear && (await page.inputValue('#title')) === '第二版标题');

  await L.clickSel(page, '#ed');
  await page.keyboard.type('第一行', { delay: 5 });
  check('contenteditable 打字', (await page.evaluate(() => document.getElementById('ed').innerText)).includes('第一行'));

  // iframe：两个同源 iframe 时各自点对
  const frA = L.frame(page, 'frameA.html');
  const frB = L.frame(page, 'frameB.html');
  check('frame() 拿到两个 iframe', !!frA && !!frB);
  if (frA && frB) {
    const offA = await L.frameOffsetOf(page, frA);
    const offB = await L.frameOffsetOf(page, frB);
    check(
      'frameOffsetOf 两个 iframe 拿到各自偏移（没错位）',
      !!offA && !!offB && JSON.stringify(offA) !== JSON.stringify(offB),
      `A=${JSON.stringify(offA)} B=${JSON.stringify(offB)}`
    );

    const okA = await L.clickText(page, '直接发表', { frame: frA });
    await L.sleep(300);
    const aHit = await frA.evaluate(() => window.__frameClicked);
    const bHitAfterA = await frB.evaluate(() => window.__frameClicked);
    check('clickText{frame:frameA} 点中 A 且没碰到 B', okA && aHit === 1 && bHitAfterA === 0, `A=${aHit} B=${bHitAfterA}`);

    const okB = await L.clickText(page, '第二帧按钮', { frame: frB });
    await L.sleep(300);
    const bHit = await frB.evaluate(() => window.__frameClicked);
    check('clickText{frame:frameB} 点中 B（第二个同源 iframe）', okB && bHit === 1, `B=${bHit}`);

    await L.typeInto(page, '.input-editor', '视频号正文', { frame: frA });
    const ed = await frA.evaluate(() => document.querySelector('.input-editor').innerText);
    check('typeInto 在 iframe 里打字', ed.includes('视频号正文'));
  }

  // 上传
  const up = await L.uploadVideo(ctx, page, video);
  await L.sleep(600);
  const files = await page.evaluate(() => window.__files);
  check('uploadVideo 塞入文件', up && files === 1, `files=${files}`);

  // 读取 / 等待 / 截图
  check('text() 读页面文本', (await L.text(page)).includes('发布'));
  check('waitForText 命中', (await L.waitForText(page, /发布/, { tries: 2, every: 200 })).ok);
  check('waitFor 等到迟到元素', (await L.waitFor(page, () => document.getElementById('later') && 'yes', { tries: 6, every: 500 })) === 'yes');
  check('evalRetry 支持传参', (await L.evalRetry(page, (v) => document.body.innerText.includes(v), { arg: '发布', tries: 3, every: 300 })) === true);
  const wd = await L.waitForUploadDone(page, { done: /发布/, busy: /上传中/, requireSeen: /迟到/, tries: 3, every: 200 });
  check('waitForUploadDone：done+busy+requireSeen 三者都对才算完成', wd.ok === true);
  const wd2 = await L.waitForUploadDone(page, { done: /发布/, busy: /上传中/, requireSeen: /永远不出现的词/, tries: 2, every: 200 });
  check('waitForUploadDone：requireSeen 没出现就不算完成', wd2.ok === false);
  const shot = await L.shot(page, 'selftest');
  check('shot() 落截图', !!shot && fs.existsSync(shot));

  await ctx.close();

  const bad = results.filter((x) => !x.ok);
  console.log(`\n通过 ${results.length - bad.length}/${results.length}`);
  if (bad.length) {
    console.log('失败项：' + bad.map((b) => b.name).join(' / '));
    process.exit(1);
  }
  console.log('临时目录：' + TMP + '（可删）');
})().catch((e) => {
  console.error('自检崩了：', e.message);
  process.exit(1);
});
