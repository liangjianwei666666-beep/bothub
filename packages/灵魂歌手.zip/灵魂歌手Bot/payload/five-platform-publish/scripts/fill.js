'use strict';
/**
 * 五平台填表 / 发布。**两段式**：
 *
 *   第一段 fill()：上传、填表、选声明、清位置、回读校验 —— 绝不点发布。
 *   第二段：L.publishGate() 判 blocker → 通过了才走 pub() 点发布。
 *
 * 为什么必须分两段：上一版把发布点击写在流程里、跑完才打印「已拒绝发布」——
 * 那是事后补记的假门，内容早就发出去了。
 *
 *   node scripts/fill.js xhs --spec $SKILL/spec/xhs.json            # 只填（默认）
 *   node scripts/fill.js xhs --spec $SKILL/spec/xhs.json --publish  # 填完、门通过才发
 *   ... --publish --force                                           # 明知有 blocker 也发
 */
const fs = require('fs');
const path = require('path');
const L = require('./lib.js');
const { sleep, log } = L;

const ROOT = process.env.PUB_PROJECT || process.cwd();
const SKILL_DIR = path.resolve(__dirname, '..');
const FLOWS = ['xhs', 'sph', 'dy', 'x', 'yt'];
const SPH_FRAME = '/micro/content/post/create';

const absMedia = (p) => (p && !path.isAbsolute(p) ? path.join(ROOT, p) : p);

/** spec 路径：绝对路径直接用；相对路径依次在 cwd、技能包 spec/、PUB_PROJECT 下找。 */
function resolveSpec(file) {
  if (path.isAbsolute(file)) return file;
  const tries = [path.resolve(process.cwd(), file), path.join(SKILL_DIR, file), path.join(SKILL_DIR, 'spec', path.basename(file)), path.join(ROOT, file)];
  for (const t of tries) if (fs.existsSync(t)) return t;
  throw new Error(`找不到 spec：${file}\n找过：\n  ${tries.join('\n  ')}`);
}

function loadSpec(file) {
  const p = resolveSpec(file);
  const s = JSON.parse(fs.readFileSync(p, 'utf8'));
  for (const k of ['video', 'cover']) if (s[k]) s[k] = absMedia(s[k]);
  log('spec:', p);
  return s;
}

function out(platform) {
  return { platform, blockers: [], warnings: [], steps: {} };
}

const head = (str, n = 8) => String(str || '').replace(/\s+/g, '').slice(0, n);

/* ─────────────── 视频号：等 frame（会重新挂载，每步都重新取） ─────────────── */

async function waitFrame(page, part, { tries = 15, every = 2000 } = {}) {
  for (let i = 0; i < tries; i++) {
    const f = L.frame(page, part);
    if (f) return f;
    await sleep(every);
  }
  return null;
}

/** 直接触发 element.click()：被 toast/遮罩挡住时坐标点击会打空（抖音实测）。 */
async function jsClick(page, text) {
  return await page.evaluate((t) => {
    const el = [...document.querySelectorAll('button,div,span,a')].find((e) => {
      if (e.children.length) return false;
      if ((e.innerText || '').trim() !== t) return false;
      return e.getBoundingClientRect().width > 0;
    });
    if (!el) return false;
    el.click();
    return true;
  }, text);
}

/* ─────────────── 小红书 ─────────────── */

async function fillXhs({ ctx, page, s, o }) {
  if (s.video) {
    o.steps.upload = await L.uploadVideo(ctx, page, s.video);
    if (!o.steps.upload) o.blockers.push('视频没传上去（找不到 file input）');
    const w = await L.waitForText(page, /填写标题|正文|添加话题|上传完成/, { label: '小红书上传' });
    o.steps.uploaded = w.ok;
    if (!w.ok) o.blockers.push('上传后没等到表单（上传可能没完成）');
  }
  if (s.title) {
    o.steps.title = await L.typeInto(page, 'input.d-text[placeholder*="标题"]', s.title, {
      clear: true,
      verify: 'input.d-text[placeholder*="标题"]',
    });
    if (!o.steps.title) o.blockers.push('标题没写进去或回读不符');
  }
  if (s.body) {
    await L.clickSel(page, 'div.tiptap');
    await sleep(500);
    for (const line of String(s.body).split('\n')) {
      await page.keyboard.type(line, { delay: 8 });
      await page.keyboard.press('Enter');
    }
    await L.addTags(page, s.tags || [], { wait: 1200 });
    const got = (await L.readText(page, 'div.tiptap')) || '';
    o.steps.bodyReadback = got.slice(0, 60);
    if (!got.replace(/\s+/g, '').includes(head(s.body))) o.blockers.push('正文回读不符（可能没打进去）');
  }
  if (s.cover) {
    await L.clickText(page, '设置封面');
    await sleep(2500);
    // 弹窗里的上传入口：先按文字点，再兜底用 CDP 直接塞图片文件
    let ok = await L.withFileChooser(page, () => L.clickText(page, '上传'), s.cover);
    if (!ok) ok = await L.withFileChooser(page, () => L.clickText(page, '+'), s.cover);
    if (!ok) {
      const set = await L.uploadViaCDP(ctx, page, s.cover, { accept: 'image' });
      ok = !!set;
    }
    o.steps.cover = ok;
    if (!ok) o.blockers.push('封面没传上（会发成默认首帧）');
    await sleep(6000); // 平台要跑「封面效果评估」
  }
  o.steps.readback = await L.evalRetry(
    page,
    () => {
      const t = document.querySelector('input.d-text[placeholder*="标题"]');
      const ed = document.querySelector('div.tiptap');
      return {
        title: t ? t.value : null,
        topicLinks: ed ? ed.querySelectorAll('a').length : null,
        editor: ed ? ed.innerText.replace(/\s+/g, ' ').slice(0, 120) : null,
        hasShadowHost: !!document.querySelector('xhs-publish-btn'),
      };
    },
    { label: '小红书回读' }
  );
  await L.shot(page, 'xhs_filled');
}

async function pubXhs({ ctx, page, s, o }) {
  // ★ 发布按钮在 <xhs-publish-btn> 的 closed shadow root 里：轻 DOM 找不到，必须走 CDP
  let box = await L.clickViaCDP(ctx, page, '发布');
  o.steps.publishVia = box ? 'cdp' : null;
  if (!box && (await L.clickText(page, '发布'))) {
    o.steps.publishVia = 'innerText(不可靠)';
    o.warnings.push('CDP 没找到发布按钮，退回到 innerText 点击——请人工确认点的是发布键');
  }
  if (!o.steps.publishVia) o.warnings.push('没点到「发布」按钮');
  await sleep(9000);
  o.steps.after = { url: page.url(), text: (await L.text(page)).slice(0, 200) };
  await L.shot(page, 'xhs_published');
  if (!o.steps.after.url.includes('note-manager') && !/发布成功|已发布/.test(o.steps.after.text)) {
    o.warnings.push('点完发布后 URL/文案都没变化，请人工核对是否真的发出去了');
  }
}

/* ─────────────── 视频号 ─────────────── */

async function fillSph({ ctx, page, s, o }) {
  if (s.video) {
    o.steps.upload = await L.uploadVideo(ctx, page, s.video);
    if (!o.steps.upload) o.blockers.push('视频没传上去');
    const f = await waitFrame(page, SPH_FRAME);
    if (!f) o.blockers.push('没等到发布 iframe（/micro/content/post/create）');
    else {
      const w = await L.waitForUploadDone(f, {
        done: /重新上传|上传完成|100%|删除/,
        busy: /上传中|解析中|上传中…/,
        label: '视频号上传',
      });
      o.steps.uploaded = w.ok;
      if (!w.ok) o.blockers.push('上传状态没出现（可能没传完）');
    }
  }
  if (s.body) {
    const f = await waitFrame(page, SPH_FRAME);
    if (!f) o.blockers.push('描述：iframe 不在');
    else {
      await L.clickSel(page, '.input-editor', { frame: f });
      await sleep(600);
      for (const line of String(s.body).split('\n')) {
        await page.keyboard.type(line, { delay: 10 });
        await page.keyboard.press('Enter');
      }
      await L.addTags(page, s.tags || [], { wait: 1600 });
      const got = await L.evalRetry(f, () => (document.querySelector('.input-editor') || {}).innerText || '');
      o.steps.bodyReadback = String(got).slice(0, 60);
      if (!String(got).replace(/\s+/g, '').includes(head(s.body))) o.blockers.push('描述回读不符');
    }
  }
  if (s.shortTitle) {
    const f = await waitFrame(page, SPH_FRAME);
    if (f) {
      o.steps.shortTitle = await L.typeInto(page, 'input[placeholder*="短标题"]', s.shortTitle, {
        clear: true,
        verify: 'input[placeholder*="短标题"]',
        frame: f,
      });
      if (!o.steps.shortTitle) o.blockers.push('短标题回读不符');
    }
  }
  if (s.cover) {
    const f = await waitFrame(page, SPH_FRAME);
    if (f) {
      // 真正的热区在「上传封面」文字上方约 40px 的 + 号
      let ok = await L.withFileChooser(page, () => L.clickText(page, '上传封面', { frame: f, dy: -40 }), s.cover);
      if (!ok) ok = await L.withFileChooser(page, () => L.clickText(page, '上传封面', { frame: f }), s.cover);
      o.steps.cover = ok;
      if (!ok) o.blockers.push('封面没传上');
      await sleep(4000);
    }
  }
  if (s.hideLocation !== false) {
    const f = await waitFrame(page, SPH_FRAME);
    if (f) {
      o.steps.location = await hideLocation(page, f);
      // 位置选择器本身就不稳，判不准就交给人工看截图，不硬拦
      if (o.steps.location === 'check-manually') o.warnings.push('位置可能没清干净（外国城市），请看截图确认');
    }
  }
  {
    const f = await waitFrame(page, SPH_FRAME);
    o.steps.readback = f
      ? await L.evalRetry(
          f,
          () => {
            const ed = document.querySelector('.input-editor');
            const st = document.querySelector('input[placeholder*="短标题"]');
            const loc = document.body.innerText.match(/位置[：:\s]*([^\s|]{2,12})/);
            return {
              shortTitle: st ? st.value : null,
              editor: ed ? ed.innerText.replace(/\s+/g, ' ').slice(0, 160) : null,
              locationText: loc ? loc[1] : null,
            };
          },
          { label: '视频号回读' }
        )
      : null;
    const lt = o.steps.readback && o.steps.readback.locationText;
    // 只看位置字段本身，不扫全文（正文里出现国家名不该误报）
    if (lt && !/不显示|中国|北京|上海|广东|深圳|杭州/.test(lt)) {
      o.warnings.push(`位置字段显示「${lt}」，人工确认要不要清`);
    }
  }
  await L.shot(page, 'sph_filled');
}

/** 清掉平台按 IP 自动填的位置。这一行是实测里最不稳的一步，失败就交人工。 */
async function hideLocation(page, fr) {
  const t = await L.text(fr);
  if (!/位置/.test(t)) return 'no-location-field';
  await L.clickText(page, '位置', { frame: fr, exact: false });
  await sleep(2000);
  const picked = await L.clickText(page, '不显示位置', { frame: fr, exact: false });
  await sleep(1200);
  const after = await L.text(fr);
  return picked && /不显示位置/.test(after) ? 'cleared' : 'check-manually';
}

async function pubSph({ page, o }) {
  const f = await waitFrame(page, SPH_FRAME);
  o.steps.publish = f ? (await L.clickText(page, '直接发表', { frame: f })) || (await L.clickText(page, '发表', { frame: f })) : false;
  if (!o.steps.publish) o.warnings.push('没点到「直接发表」');
  await sleep(10000);
  o.steps.after = { url: page.url(), text: (await L.text(page)).slice(0, 200) };
  await L.shot(page, 'sph_published');
}

/* ─────────────── 抖音 ─────────────── */

async function fillDy({ ctx, page, s, o }) {
  if (await L.clickText(page, '我知道了')) {
    await sleep(800);
    o.steps.dismissedToast = true;
  }
  if (s.video) {
    o.steps.upload = await L.uploadVideo(ctx, page, s.video);
    if (!o.steps.upload) o.blockers.push('视频没传上去');
    // 判据必须带「不再有上传中/解析中」，且不能只认「发布」（那个字一进页面就有）
    const w = await L.waitForUploadDone(page, {
      done: /重新上传|作品描述|填写作品/,
      busy: /上传中|解析中/,
      label: '抖音上传',
    });
    o.steps.uploaded = w.ok;
    if (!w.ok) o.blockers.push('上传后没等到填写表单');
  }
  if (s.title) {
    o.steps.title = await L.typeInto(page, 'input[placeholder*="作品标题"]', s.title, {
      clear: true,
      verify: 'input[placeholder*="作品标题"]',
    });
    if (!o.steps.title) o.blockers.push('标题回读不符');
  }
  if (s.body) {
    await L.clickSel(page, 'div[contenteditable="true"]');
    await sleep(500);
    for (const line of String(s.body).split('\n')) {
      await page.keyboard.type(line, { delay: 10 });
      await page.keyboard.press('Enter');
    }
    await L.addTags(page, s.tags || [], { wait: 1400 });
    const got = (await L.evalRetry(page, () => (document.querySelector('div[contenteditable="true"]') || {}).innerText || '')) || '';
    o.steps.bodyReadback = String(got).slice(0, 60);
    if (!String(got).replace(/\s+/g, '').includes(head(s.body))) o.blockers.push('简介回读不符');
  }
  // 用户要求：AI 内容必须声明。**默认就声明**，除非 spec 明确写 declareAI:false
  if (s.declareAI !== false) {
    o.steps.aiDeclare = await declareAI(page);
    if (!o.steps.aiDeclare) o.blockers.push('「内容由AI生成」自主声明没选上');
  }
  o.steps.readback = await L.evalRetry(
    page,
    () => {
      const t = document.querySelector('input[placeholder*="作品标题"]');
      const d = document.querySelector('div[contenteditable="true"]');
      return {
        title: t ? t.value : null,
        desc: d ? d.innerText.replace(/\s+/g, ' ').slice(0, 160) : null,
        aiDeclared: !document.body.innerText.includes('请选择自主声明'),
      };
    },
    { label: '抖音回读' }
  );
  await L.shot(page, 'dy_filled');
}

async function declareAI(page) {
  await page.evaluate(() => {
    const el = [...document.querySelectorAll('*')].find((e) => (e.innerText || '').trim() === '请选择自主声明');
    if (el) el.scrollIntoView({ block: 'center' });
  });
  await sleep(800);
  await L.clickText(page, '请选择自主声明');
  await sleep(1800);
  // 归档里的真实文案没有空格：「内容由AI生成」
  const picked = (await L.clickText(page, '内容由AI生成')) || (await L.clickText(page, '内容由 AI 生成'));
  await sleep(1500);
  const t = await L.text(page);
  return picked && !t.includes('请选择自主声明');
}

async function pubDy({ page, o }) {
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => (x.innerText || '').trim() === '发布');
    if (b) b.scrollIntoView({ block: 'center' });
  });
  await sleep(800);
  // 台账实测：发布按钮被 toast 遮挡时坐标点击会打空 → element.click() 直接触发
  o.steps.publishVia = (await jsClick(page, '发布')) ? 'js' : (await L.clickText(page, '发布')) ? 'mouse' : null;
  if (!o.steps.publishVia) o.warnings.push('没点到「发布」按钮');
  await sleep(9000);
  o.steps.after = { url: page.url(), text: (await L.text(page)).slice(0, 200) };
  await L.shot(page, 'dy_published');
}

/* ─────────────── X ─────────────── */

async function fillX({ ctx, page, s, o }) {
  if (s.video) {
    o.steps.upload = await L.uploadVideo(ctx, page, s.video);
    if (!o.steps.upload) o.blockers.push('视频没传上去');
    // 归档做法：先看到上传百分比，再等它消失（Post/发帖 一进页面就有，不能当信号）
    const w = await L.waitForUploadDone(page, {
      done: /Post|发帖/,
      busy: /\d{1,3}%/,
      requireSeen: /\d{1,3}%/,
      label: 'X 上传',
    });
    o.steps.uploaded = w.ok;
    if (!w.ok) o.blockers.push(w.sawSeen ? 'X 上传百分比一直没消失' : 'X 上传没看到进度（可能没开始）');
  }
  if (s.body) {
    o.steps.typed = await L.typeInto(page, 'div.public-DraftEditor-content', s.body, { delay: 12 });
    if (!o.steps.typed) o.blockers.push('没点进 X 的编辑器');
    else {
      const got = (await L.readText(page, 'div.public-DraftEditor-content')) || '';
      o.steps.bodyReadback = String(got).slice(0, 60);
      if (!String(got).replace(/\s+/g, '').includes(head(s.body))) o.blockers.push('X 正文回读不符');
    }
  }
  await L.shot(page, 'x_filled');
}

async function pubX({ page, s, o }) {
  // 台账实测：打完话题/正文后必须先 Esc 关掉联想下拉，否则点不到 Post
  await page.keyboard.press('Escape').catch(() => {});
  await sleep(1200);
  const disabled = await L.evalRetry(page, () => {
    const b = document.querySelector('[data-testid="tweetButton"]');
    return b ? b.getAttribute('aria-disabled') : 'missing';
  });
  if (disabled === 'true' || disabled === 'missing') o.warnings.push(`Post 按钮不可点（aria-disabled=${disabled}）`);
  o.steps.publishClicked = await L.clickSel(page, '[data-testid="tweetButton"]');
  if (!o.steps.publishClicked) o.warnings.push('没点到 Post 按钮');
  await sleep(12000);
  o.steps.after = { url: page.url() };
  await L.shot(page, 'x_published');
  await page.goto('https://x.com/home', { waitUntil: 'domcontentloaded' }).catch(() => {});
  await sleep(8000);
  o.steps.homeText = (await L.text(page)).slice(0, 300);
  await L.shot(page, 'x_home_check');
  const first = head(String(s.body || '').split('\n')[0], 10);
  if (first && !o.steps.homeText.replace(/\s+/g, '').includes(first)) {
    o.warnings.push('主页时间线里没看到刚发的内容，请人工确认');
  }
}

/* ─────────────── YouTube（只做「改文案 + 保存 + 回读」） ─────────────── */

async function fillYt({ page, s, o }) {
  if (!s.url) throw new Error('YouTube 需要一个编辑页 url：https://studio.youtube.com/video/<id>/edit');
  await page.goto(s.url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  await sleep(12000); // Studio 首屏很慢
  const boxes = await L.waitFor(
    page,
    () => {
      const a = [...document.querySelectorAll('div#textbox')].filter((e) => e.getBoundingClientRect().width > 0);
      if (a.length < 2) return null;
      return a.map((e) => {
        const r = e.getBoundingClientRect();
        return [Math.round(r.x + r.width / 2), Math.round(r.y + Math.min(20, r.height / 2))];
      });
    },
    { tries: 10, every: 2000, label: 'YouTube #textbox' }
  );
  if (!boxes) {
    o.blockers.push('找不到 div#textbox（Studio 没加载完或改版）');
    await L.shot(page, 'yt_error');
    return;
  }
  o.steps.readbackBefore = await L.evalRetry(page, () =>
    [...document.querySelectorAll('div#textbox')].map((e) => (e.innerText || '').replace(/\s+/g, ' ').slice(0, 60))
  );
  if (s.title) {
    // 三击 + Meta+A 双保险 + 回读；归档那次标题被拼成两段，就是因为全选没生效
    const ok = await L.typeInto(page, boxes[0], s.title, { clear: true, delay: 12 });
    await sleep(1200);
    o.steps.title = await L.evalRetry(page, () => document.querySelectorAll('div#textbox')[0].innerText);
    if (!ok || (o.steps.title || '').replace(/\s+/g, '') !== String(s.title).replace(/\s+/g, '')) {
      o.blockers.push(`标题回读不符：${(o.steps.title || '').slice(0, 50)}`);
    }
  }
  if (s.body) {
    await L.typeInto(page, boxes[1], '', {});
    await sleep(500);
    await page.keyboard.type('测试', { delay: 80 }); // 探针：确认真的点进说明框
    await sleep(1000);
    const probe = await L.evalRetry(page, () => [...document.querySelectorAll('div#textbox')].map((e) => e.innerText));
    if (!probe || !(probe[1] || '').includes('测试')) {
      o.blockers.push('说明框点不进去（Studio 偶发，重跑一次通常就好）');
    } else {
      await page.keyboard.press('Meta+A');
      await sleep(300);
      await page.keyboard.press('Backspace');
      await sleep(400);
      for (const line of String(s.body).split('\n')) {
        await page.keyboard.type(line, { delay: 8 });
        await page.keyboard.press('Enter');
      }
      await sleep(1500);
      o.steps.descReadback = await L.evalRetry(page, () => (document.querySelectorAll('div#textbox')[1] || {}).innerText);
      if (!String(o.steps.descReadback || '').replace(/\s+/g, '').includes(head(s.body, 10))) {
        o.blockers.push('说明回读不符');
      }
    }
  }
  await L.shot(page, 'yt_filled');
}

async function pubYt({ page, o }) {
  o.steps.saved = await L.clickText(page, '保存');
  if (!o.steps.saved) o.warnings.push('没点到「保存」');
  await sleep(8000);
  await L.shot(page, 'yt_saved');
  await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
  await sleep(12000);
  o.steps.readbackAfter = await L.evalRetry(page, () =>
    [...document.querySelectorAll('div#textbox')].map((e) => (e.innerText || '').replace(/\s+/g, ' ').slice(0, 120))
  );
  await L.shot(page, 'yt_after_reload');
}

/* ─────────────── 主流程 ─────────────── */

const TABS = {
  xhs: ['creator.xiaohongshu.com', 'https://creator.xiaohongshu.com/publish/publish'],
  sph: ['channels.weixin.qq.com', 'https://channels.weixin.qq.com/platform/post/create'],
  dy: ['creator.douyin.com', 'https://creator.douyin.com/creator-micro/content/upload'],
  x: ['x.com', 'https://x.com/compose/post'],
  yt: ['studio.youtube.com', 'https://studio.youtube.com'],
};
const FILL = { xhs: fillXhs, sph: fillSph, dy: fillDy, x: fillX, yt: fillYt };
const PUB = { xhs: pubXhs, sph: pubSph, dy: pubDy, x: pubX, yt: pubYt };

(async () => {
  const argv = process.argv.slice(2);
  const platform = argv.find((a) => FLOWS.includes(a)); // 顺序随便，只认已知平台名
  const specArg = argv.indexOf('--spec');
  const specFile = specArg >= 0 ? argv[specArg + 1] : null;
  const doPublish = argv.includes('--publish');
  const force = argv.includes('--force');

  if (!platform || !specFile) {
    console.error('用法：node scripts/fill.js <xhs|sph|dy|x|yt> --spec <spec.json> [--publish] [--force]');
    process.exit(1);
  }
  const s = loadSpec(specFile);
  const { b, ctx } = await L.connect();
  const [part, open] = TABS[platform];
  let page;
  if (platform === 'yt' && s.url) {
    page = ctx.pages().find((p) => p.url().includes('/edit')) || (await ctx.newPage());
  } else {
    page = await L.tab(ctx, part, { open });
  }
  const o = out(platform);
  log(`平台 ${platform}${doPublish ? '（填完判门，通过才发）' : '（只填不发）'}`);

  // ── 第一段：只填，绝不点发布 ──
  await FILL[platform]({ ctx, page, s, o });

  // ── 闸门：这里才决定要不要点发布 ──
  const gate = L.publishGate({ blockers: o.blockers, doPublish, force });
  o.gate = gate;
  if (gate.allowed) {
    log('闸门通过，开始发布');
    await PUB[platform]({ ctx, page, s, o });
    o.published = true;
  } else if (doPublish) {
    o.refusedPublish = true;
    log('⛔ 闸门拦住：', gate.reason);
  }

  console.log('\n=== 结果 ===');
  console.log(JSON.stringify(o, null, 2));

  if (o.blockers.length) console.log('⚠️ blocker：\n- ' + o.blockers.join('\n- '));
  if (o.warnings.length) console.log('提示：\n- ' + o.warnings.join('\n- '));
  if (o.refusedPublish) console.log('⛔ 有 blocker，**发布没执行**（页面停在填好的状态）。修好后重跑，或确认无害后加 --force。');
  else if (o.published) console.log('已点发布：去后台核对（标题/话题/封面/可见性/声明/位置）。');
  else console.log('只填了没发：看 .publish-tools/ 里的截图，确认后加 --publish。');
  await b.close();
  process.exit(o.refusedPublish ? 2 : 0);
})().catch((e) => {
  console.error('失败：', e.message);
  process.exit(1);
});
