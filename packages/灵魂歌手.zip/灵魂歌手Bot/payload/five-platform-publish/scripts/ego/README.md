# five-platform-publish / scripts/ego —— ego lite 浏览器原生版

**这是一套新增脚本，不改动旧版 `scripts/lib.js`、`fill.js`、`probe.js`、`open-session.sh`、`selftest.js`。**
旧版继续可用（它走「复制用户 Chrome 配置 + 端口 9222 的调试 Chrome」）；
本版直接驱动用户的**真实日常浏览器 ego lite**（`/Applications/ego lite.app`，CLI `~/.local/bin/ego-browser`），
登录态就是用户自己的，不再复制/修改任何 Chrome 配置。

```
scripts/ego/
  lib.mjs      ego 原生原语层（对应旧版 lib.js）
  fill.mjs     逐平台「只填不发 / 填完过闸门再发」（对应旧版 fill.js）
  probe.mjs    五站登录态自检（只读，对应旧版 probe.js）
  README.md    本文件
```

| 旧版（playwright-core + 9222 调试 Chrome） | 本版（ego lite） |
|---|---|
| `L.connect()` → `chromium.connectOverCDP` | `await taskSpace("五平台发布")` 恢复同一空间（实测 spaceId=3） |
| `ctx.pages()` / `ctx.newPage()` | `task.tabs()` / `task.pages()` / `task.page(label)` / `task.adopt()` |
| `frame(page, url)` + `frameOffsetOf` + `clickText({frame})` | ego 的元素动作**自动回退到 frame 里找**；iframe 文本用同源 `contentDocument` 读 |
| `ctx.newCDPSession(page)` | `page.cdp(method, params)` |
| `DOM.getDocument{depth:-1,pierce:true`} 递归 `children` | `DOM.getFlattenedDocument{depth:-1,pierce:true}` + `parentId` 反查（更稳，见踩坑 3） |
| `page.evaluate` | 一样，但**看不到 Node 侧闭包变量**（见踩坑 4） |
| `page.screenshot({path})` | 一样 |
| `node scripts/fill.js xhs --spec ... --publish --force` | 命令 JSON（**argv/环境变量都传不进来**，见下） |

---

## 1 参数传递：实测结论（重点）

ego 指南说脚本不继承 shell 环境变量。我把 argv / env / stdin / 相对 import 四件事都实测了一遍：

```bash
# 实验：FOO=bar PUB_X=1 ego-browser nodejs <<'EOF' … EOF
{ "argv": ["/Applications/ego lite.app/…/ego Helper (Node)"],   ← 只有 1 项，就是 node helper 自己
  "argvLen": 1,
  "envKeys": ["MallocNanoZone","USER","COMMAND_MODE","__CFBundleIdentifier","PATH","LOGNAME",
              "SSH_AUTH_SOCK","HOME","SHELL","TMPDIR","__CF_USER_TEXT_ENCODING","XPC_SERVICE_NAME",
              "XPC_FLAGS","MACH_PORT_RENDEZVOUS_PEER_VALDATION"],
  "FOO": null, "PUB_X": null,                                   ← 自定义变量一个都没进来
  "cwd": "/",                                                   ← 不是你的工作目录
  "node": "v24.22.1" }
```

再测 `ego-browser nodejs -e '<script>' alpha beta`：`argv` 仍然只有 1 项、`FOO` 仍然是 `null`。
**结论：`--flag` 和环境变量都不行。** 唯一的入参通道是**绝对路径的命令 JSON**：

```
~/Desktop/音乐创作/.publish-tools/ego-cmd.json
```

```json
{
  "platform": "xhs",                       // xhs | sph | dy | x | yt
  "spec": "spec/xhs.json",                 // 绝对路径，或相对 PUB_PROJECT（~/Desktop/音乐创作）
  "publish": false,                        // ★ 默认 false = 只填不发
  "force": false,                          // ★ 有 blocker 也要硬发才写 true
  "preflightOnly": false,                  // true = 只跑前置检查，连浏览器都不碰
  "selftest": false,                       // true = 跑 closed shadow 自检（不需要 platform）
  "rehearse": false,                       // true = 跑两段式闸门彩排（本地 fixture）
  "probe": { "platforms": ["xhs","sph"], "navigate": true, "openLogin": false }   // 只给 probe.mjs 用
}
```

### 怎么调用脚本：两种形式，实测差异

| 形式 | 相对 import（`import "./lib.mjs"`） | 结论 |
|---|---|---|
| `ego-browser nodejs -e 'await import("file:///绝对路径/x.mjs")'` | ✅ 可用（`import.meta.url` 是真文件路径） | **推荐** |
| `ego-browser nodejs < /绝对路径/x.mjs` | ❌ 失败：`Cannot find module '//rel-lib.mjs' imported from //[eval2]` | 也能跑 |
| heredoc `<<'EOF' … EOF` | ❌ 同上 | 也能跑 |

为了让**两种形式都能跑**，入口脚本（`fill.mjs`/`probe.mjs`）没有用静态 `import`，而是：

```js
let L;
try   { L = await import("./lib.mjs"); }                 // -e 'await import(file://…)' 走这条
catch { L = await import(`${EGO_DIR_FALLBACK}/lib.mjs`); } // < 重定向走这条（base 是 //[eval2]）
```

推荐命令（绝对路径，ASCII，无双引号，壳不会改坏它）：

```bash
export PATH="$HOME/.local/bin:$PATH"
EGO=~/.agents/skills/five-platform-publish/scripts/ego
ego-browser nodejs -e "await import(\"file://$EGO/probe.mjs\")"     # ← 双引号版本，注意转义
# 或直接写死（最省事，不用变量）：
ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/probe.mjs")'
```

> **另一个实测事实**：脚本里 `console.log` / `console.error` **全部落到 stderr**，stdout 是空的。
> 所以在 DSH 这边看到的每行前面都有 `[error]` 前缀 —— 那是 DSH 给 stderr 加的，不是脚本自己打的。

---

## 2 四个脚本怎么跑

### 2.1 `probe.mjs` —— 五站登录态自检（只读）

```bash
ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/probe.mjs")'
```

* 逐个打开五站后台入口，三态判断：`✅ 已登录 / ❌ 未登录 / ❔ 不确定`，并把截图存到 `SHOTS_DIR`。
* 判断用**平台专属 DOM 信号**优先（例：X 看 `[data-testid="tweetButton"]`），文本匹配只作兜底。
  为什么：X 的中文界面把 `Post/Home` 翻译成「邮政/家」，纯文本匹配第一版判成了「不确定」。
* **不登录、不扫码、不点任何发布相关按钮。** 未登录就如实报，然后停。
* 退出码：`0` 五站都 ✅；`2` 有 ❌ 或 ❔；`1` 意外错误。

### 2.2 `fill.mjs` —— 逐平台填表 / 发布

```bash
ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/fill.mjs")'
```

跑什么由命令 JSON 决定：

```bash
CMD=~/Desktop/音乐创作/.publish-tools/ego-cmd.json

# ① 只跑前置检查（不碰浏览器）
echo '{"platform":"xhs","spec":"spec/xhs.json","preflightOnly":true}' > $CMD

# ② 只填不发（默认）
echo '{"platform":"xhs","spec":"spec/xhs.json"}' > $CMD

# ③ 填完判闸门，通过才发
echo '{"platform":"xhs","spec":"spec/xhs.json","publish":true}' > $CMD

# ④ 有 blocker 也要硬发
echo '{"platform":"xhs","spec":"spec/xhs.json","publish":true,"force":true}' > $CMD

# ⑤ 自检：CDP 穿透 closed shadow root（不碰真站点）
echo '{"selftest":true}' > $CMD

# ⑥ 彩排：两段式闸门顺序（本地 fixture，不碰真站点）
echo '{"rehearse":true}' > $CMD
```

**一次只跑一个平台**：命令 JSON 里只有一个 `platform`。发完核对完再改 JSON 跑下一个。

### 2.3 `note.mjs` —— 小红书「图文笔记」（多图）★ 2026-10-28 新增

`fill.mjs` 的 spec 是**视频**模型（`video` / 单文件上传），小红书图文是「多张图 + 标题 + 正文 + 话题」，
上传入口、必填字段、回读信号都不同。图文走这一条，命令 JSON 多一个 `note: true`：

```bash
CMD=~/Desktop/音乐创作/.publish-tools/ego-cmd.json
echo '{"note":true,"spec":"spec/notes/_template.json","preflightOnly":true}' > $CMD   # ① 只跑前置检查
echo '{"note":true,"spec":"spec/notes/_template.json"}' > $CMD                          # ② 只填不发（默认）
echo '{"note":true,"spec":"spec/notes/_template.json","publish":true}' > $CMD           # ③ 判闸门，通过才发
echo '{"noteSelftest":true,"spec":"spec/notes/_template.json"}' > $CMD                  # ④ 本地 fixture 自检
```

* spec 在 `spec/notes/`：`images`（数组，按顺序，第 1 张即封面）、`baseDir`（相对图片的基准目录）、
  `title`（≤20 字）、`body`、`tags`（3-5 个）、`bannedWords`（命中即 blocker）、`declareOriginal`。
* 前置检查会拦住：缺 spec / 缺图 / 图数不在 1-18 / 图不是 1080×1440（3:4）/ 标题超 20 字 / 正文超 1000 字 /
  **命中禁用词**。第三张之后的事（真上传）在这之前不会发生。
* 上传三条路线：`page.setInputFiles('input[type=file][accept*="image"]')` → `input[type=file]` →
  CDP `DOM.setFileInputFiles`（多文件，穿 shadow/iframe）。
  **塞进去 ≠ 上传成功**：还要等到「标题输入框出现」或「blob 图片在页面上」才算过，否则记 blocker。
* 正文是 tiptap（contenteditable），只能 `keyboard.type`；话题走 `addTags`（打完等联想 → Enter → 补空格）。
* 发布按钮同视频那条，走 `clickViaCDP('发布')` 穿 `<xhs-publish-btn>` 的 closed shadow。

### 2.4 退出码

| 码 | 含义 | 能不能重跑 |
|---|---|---|
| `0` | 正常：只填完成（且没有 blocker），或发布成功 | 只填可以；**发布成功不要重跑** |
| `2` | 闸门拦住 / 有 blocker 未过（**没有发布**） | 可以，修好后重跑 |
| `3` | 前置检查没过（spec 缺失、视频/封面文件不存在、编码不对） | 可以，补好文件再跑 |
| `1` | 意外错误 | 看报错 |

> `force` 硬闯发布成功后**故意返回 0**：退出非零会让上层重跑，一重跑就是**重复发布**。

---

## 3 ★ 两段式发布闸门（顺序写在代码里）

```
第 0 段  前置检查    spec 文件 / 必填字段 / 视频·封面文件 / 编码分辨率 / 目标页是否打开
                     → hard blocker（缺 spec、缺文件）直接 exit 3，连上传都不做
第 1 段  只填        上传视频 → 填标题正文话题 → 选声明 → 清位置 → 逐项回读校验
                     ★ 这一段里**没有任何一行点发布**
第 2 段  发布        publishGate() 判 blocker → 放行才执行发布
```

`lib.mjs` 里的判据（`publishGate`）：

| 命令 | blocker | 结果 |
|---|---|---|
| `publish:false` | 有/没有 | **一律不点发布** |
| `publish:true` | 没有 | 放行，执行发布 |
| `publish:true` | 有 | **拒绝发布**，打印 blocker，退出 2 |
| `publish:true, force:true` | 有 | 硬发，并标记 `gate.forced=true` |

blocker 至少覆盖（都在 `fill.mjs` 里逐条判）：视频没上传成功、封面没上传成功、正文回读与 spec 不符、
抖音「内容由AI生成」自主声明没选中、视频号位置是外国城市名；另外把「前置检查的编码/分辨率不对」也放进了闸门 blocker（`force` 可越）。

---

## 4 截图

每步一张，绝对路径：

```
~/Desktop/音乐创作/.publish-tools/ego/<平台>_<两位序号>_<步骤>.png
```

例：`xhs_01_page.png`、`xhs_03_title.png`、`xhs_06_filled.png`、`xhs_07_published.png`、
`probe` 用 `<平台>_probe.png`，自检/彩排用 `selftest_closed_shadow.png` / `rehearse_gate.png`。

> 本次交付的会话里，模型**看不了图片**（模型不支持图像输入），
> 所以下面所有「已验证」都是靠 DOM 文本 / CDP 节点 / 计数器这类可文本化证据得出的，**不是靠看图**。

---

## 5 已验证 / 未验证（如实分档，没跑过的一律写未验证）

### ✅ 已验证（本机真实跑过）

| 项 | 证据 |
|---|---|
| argv / env / cwd / console 去向 | 上面第 1 节的实测 JSON |
| 三种调用形式与相对 import | `<` / heredoc 报 `Cannot find module '//rel-lib.mjs' …//[eval2]`；`-e import` 通过 |
| `DOM.getFlattenedDocument` 需要先 `DOM.enable` | 不 enable 直接报 `Error: DOM agent hasn't been enabled` |
| **CDP 穿透 closed shadow root 点击** | `selftest`：轻 DOM `host.shadowRoot=null`、`button` 数 0；CDP 扁平表里找到 `#text「发布」`→ `BUTTON`；`getBoxModel` 取 `[69,173]`；`mouse.click` 后 `clicked=true`。3/3 ✅ |
| `uploadVideo` 路线 1 `page.setInputFiles` | 彩排：fixture file input 收到 1 个文件（真视频） |
| `setFilesViaCDP` 兜底路线 | 彩排：`DOM.setFileInputFiles` 成功 |
| `typeInto` 三击 + Meta+A + 回读校验 | 彩排：回读「闸门彩排标题」一致 |
| **两段式闸门顺序**（`publishGate` + 真 `main()`） | 4 场景见下表 |
| 前置检查 4 类失败 | spec 不存在 / 视频不存在 / 缺必填字段 / 编码不对 → 全部 exit 3 + 中文报错 |
| 前置检查 5 平台正常路径 | xhs / dy / sph / x / yt 全 ✅ exit 0（真实施工片 13.7MB，`h264/aac/1080x1920/14.55s`） |
| `probe.mjs` 五站真实登录态 | 见下 |
| **小红书图文路径 `note.mjs`（本地 fixture）** | 2026-10-28：`noteSelftest` **11/11 ✅** —— 前置检查拦住空图集、真样本 9 张 1080×1440 全过、点「上传图文」切面板、9 张图进 file input、标题/正文回读一致、填充零 blocker、闸门三场景（默认不发 / 有 blocker 拒绝 / force 才发）、CDP 点在 closed shadow 里的真「发布」按钮（published 0→1）、禁用词表命中「诊断/主页领」 |
| 小红书图文前置检查（真 spec，不碰浏览器） | 2026-10-28：`preflightOnly` 对 `spec/notes/_template.json` 全过 exit 0（9 张图 / 17 字标题 / 277 字正文 / 13 个禁用词零命中） |

**闸门 4 场景（跑的是真的 `fill.mjs main()`，fixture 里的「保存」按钮被点没被点用 `window.name` 留痕）**

| 场景 | publish | force | blocker | 第二段真的跑了吗 | 退出码 |
|---|---|---|---|---|---|
| 1 | false | false | 有 | **没有**（`window.name` 仍是空） | 2 |
| 2 | true | false | 有 | **没有**（`window.name` 仍是空，`refusedPublish=true`） | 2 |
| 3 | true | – | 无 | **跑了**（`window.name=SAVED-BY-PHASE-2`，`published=true`） | 0 |
| 4 | true | true | 有 | **跑了**（`forced=true`，带「不要再重跑」告警） | 0 |

**probe.mjs 真实输出（2026-10-25 17:52）**

```
✅ 小红书　 已登录　正文出现后台特征（账号 深圳在地心理咨询）
❌ 视频号　 未登录　URL 是登录页（含 "login.html"）
✅ 抖音　　 已登录　DOM 信号：创作者中心发布页文案在
✅ X　　　  已登录　DOM 信号：发布框和 Post 按钮都在（data-testid）（账号 穆贾比 @穆贾比19028）
✅ YouTube　已登录　DOM 信号：Studio 外壳元素在（ytcp-*）（账号 你的YouTube频道名）
```

> 顺带纠正旧文档一处：`platforms/xiaohongshu.md` 写的账号是「你的小红书账号（来自用户提供/当日后台显示）」，
> 实际页面读到的账号名是 **深圳在地心理咨询**。旧文档自己标了「归档脚本里没有留存账号名」，以本次实测为准。

### ❌ 未验证（没跑过，不许当结论用）

| 项 | 为什么没验证 |
|---|---|
| **真的发一条**（五平台 `fill`+`pub` 全链路） | 验收明确要求「不要真正上传/发表」。本版**一次都没有**对真平台上传过视频，也没有点过任何发布/保存按钮 |
| 小红书 closed shadow 发布按钮在**真实页面**上的存在与点击 | 上传页渲染完整时（body 文本 233 字、CDP 扁平表 990 节点）页面上**根本没有** `xhs-publish-btn` 宿主、没有 `xhs-*` 自定义元素、没有等于「发布」的文本节点 —— 这个按钮要**真上传一条视频**之后才渲染。机制在 fixture 上验证过，真页面这一步未验证 |
| 视频号整套：iframe 元素动作自动回退、短标题、封面 `+` 热区、位置控件 | 视频号**未登录**，`post/create` 被弹回 `login.html`（页面只有 `open.weixin.qq.com/connect/qrconnect` 的扫码 iframe）。实测登录页上：无 `位置` 字样、无 `input[placeholder*="短标题"]`、无 `.input-editor` |
| 抖音「自主声明」控件 | 上传页（未选视频）上实测：无「自主声明」、无「请选择自主声明」、无「内容由AI生成」、无作品标题输入框、无 `contenteditable`；只有 1 个 `input[type=file]`。**这个控件要选完视频才出现**，未验证 |
| X 上传百分比门 / 点 Post / 发完回主页复核 | 没上传过 |
| YouTube 真实 Studio 编辑页改标题说明 | 没跑（fixture 上跑通了流程，真 Studio 未验证） |
| 视频号「位置是外国城市名」的判定 | 白名单逻辑写好了，但没有真实样本可测（未登录进不去表单） |
| 发布后核对：标题/话题是否真话题/封面/可见性/声明/位置 | 没发布过 |
| 各平台上传完成的具体轮询判据（`done`/`busy` 正则） | 参数照抄旧版当天实测，但没在真平台重跑过 |
| **小红书图文：真站点上的多图上传** | 只跑过本地 fixture + 前置检查。**真页面还没上传过一张图**：`上传图文` 标签的真实文案/选择器、图片 file input 的真实 `accept`、上传中的进度信号、图文页发布按钮的实际文本（可能不是「发布」而是「发布笔记」），全部未实测 → 第一次真跑必须**只填不发**，先看截图再谈发布 |
| 小红书图文的「原创声明」开关 | 代码只读 `checked` 状态、不做假设，但真页面上有没有这个开关、默认值是什么，未验证 |

---

## 6 踩坑（都是这次实际踩到的，不是抄来的）

1. **argv 和环境变量都传不进 ego 脚本**：`process.argv.length === 1`，自定义 env 一个都没有，`cwd === "/"`。
   → 一切输入走绝对路径的命令 JSON；一切文件路径写绝对路径。
2. **`console.log` 走 stderr**，stdout 是空的。
3. **`DOM.getFlattenedDocument` / `DOM.getBoxModel` 之前必须先 `DOM.enable`**，否则报
   `Error: DOM agent hasn't been enabled`。旧版 `lib.js` 里第一句是 `DOM.getDocument`，而它**恰好会顺带 enable**，
   所以这个坑在旧代码里看不出来 —— 直接改用 `getFlattenedDocument` 就会炸。
4. **`page.evaluate(fn)` 看不到 Node 侧的闭包变量**：函数源码是被送进页面执行的。
   第一版把 `UI_WORDS` 常量放在 Node 侧，页面里 `ReferenceError` 被 `catch` 吞掉 → 账号名**永远读不到**，
   查了半天才发现。要传的东西必须走 `page.evaluate(fn, arg)` 的第二参数（JSON 可序列化）。
   同理，返回值里**不能含函数**（`bodyHas: (x) => …` 这种会让整次 evaluate 失败）。
5. **ego 的 Node 运行时里起本地 http server 会卡死**：`server.listen()` 的回调不触发（实测卡住 2 分钟）。
   → fixture 一律用 `data:text/html;charset=utf-8,` + `encodeURIComponent`，`page.goto` 能正常打开。
6. **小红书的 SPA 在 `readyState=complete` 之后还有约 10 秒 `body.innerText` 是空的**。
   固定等 7 秒会把它判成「不确定」、账号名也读不到。
   → `probe.mjs` 现在轮询到「登录墙 / DOM 信号 / 正文够长且有后台特征」为止（`pageReady`）。
7. **CDP 的 `nodeId` 不能跨 round 用**：每次点击/查找都重新 `DOM.getFlattenedDocument`。
   `cdpFind()`/`clickViaCDP()` 是自包含的一次性调用。
8. **CDP 给的是节点在自己 frame 里的坐标**，跨 iframe 直接用 `page.mouse.click` 会点错地方。
   → 视频号（整张表在 iframe 里）走 ego 自己的元素动作（自动回退到 frame 找），**不用** CDP 坐标。
9. **`page.waitForFileChooser()` 的 promise 会悬空**：点击失败时它还在等，超时后变成 unhandled rejection，
   可能把进程带崩。→ 拿到 promise 立刻挂 `.catch(() => {})`。
10. **`force` 硬闯发布成功后不能退非零**：上层看到非零会重跑，重跑＝重复发布。
11. **本机没有 ffprobe**，只有 `~/local/bin/ffmpeg`（x86_64）。
    → 用 `ffmpeg -i` 读流信息（它无输出文件时退出码非零，从 `stderr` 取文本），解析 `Video:` / `Audio:` / `WxH`。
12. **小红书发布按钮的 closed shadow** 是本技能的看家坑（旧版 12 条坑里的第 1 条），
    本版用 `getFlattenedDocument{pierce:true}` + `parentId` 反查替代旧版的 `children` 递归，
    在 fixture 上验证通过；真页面上的那一步见「未验证」。

---

## 7 纪律（写进代码，不是写进文档）

* **不代登录、不扫码**：未登录就报未登录，让用户自己登，登完重跑 `probe.mjs`。
* **不发表任何内容**，除非命令 JSON 里 `publish:true` **且**闸门放行。
* **不点发布按钮**（默认路径下 `PUB[]` 根本不会被调用）。
* **不删用户的标签页**：已有标签复用；未纳管的先 `task.adopt()`；只关自己建的临时页（自检/彩排页）。
* **不复制/修改用户 Chrome 配置**（这正是本版相对旧版最大的差别）。
* **不调用 `task.finish()`**：`五平台发布` 空间（id=3）是长期复用的，探测/填表跑完都留着。
* **`taskSpace("五平台发布")` 恢复，不新建**空间。
