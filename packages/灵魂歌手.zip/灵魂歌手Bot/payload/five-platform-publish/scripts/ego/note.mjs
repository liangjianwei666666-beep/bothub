/**
 * five-platform-publish / scripts/ego/note.mjs
 * ─────────────────────────────────────────────────────────────
 * 小红书「图文笔记」（多图）发布 —— fill.mjs 的图文补充。
 *
 * 为什么单独一份：fill.mjs 的 spec 是视频模型（video / cover / 单文件上传），
 * 小红书图文是「多张图 + 标题 + 正文 + 话题」，上传入口、必填校验、回读信号都不同。
 * 图文笔记（一组图 + 标题正文话题）走这一条。
 *
 * 复用 lib.mjs 的原语（CDP 穿 closed shadow、多段回读、闸门），不改 lib/fill。
 *
 * ── 命令 JSON（和 fill.mjs 同一个文件，ego 脚本只能从这里读参数）──
 *   ~/Desktop/音乐创作/.publish-tools/ego-cmd.json
 *
 *   { "note": true, "spec": "spec/notes/_template.json" }                      // 只填不发（默认）
 *   { "note": true, "spec": "spec/notes/_template.json", "publish": true }     // 填完判闸门，通过才发
 *   { "note": true, "spec": "spec/notes/_template.json", "preflightOnly": true } // 只跑前置检查，不碰浏览器
 *   { "noteSelftest": true }                                                // 本地 fixture 自检，不碰真站点
 *
 * ── 跑法 ──
 *   ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/note.mjs")'
 *
 * 硬纪律（与 fill.mjs 一致）：
 *   · 默认绝不点发布；publish:true 且闸门放行才点；有 blocker 要 force 才硬闯。
 *   · 不代登录、不扫码。登录态不对就停下报出来。
 *   · 关键步骤（图片没传上 / 标题回读不符 / 正文回读不符 / 命中禁用词）一律记 blocker，不许带病发布。
 */

const EGO_DIR_FALLBACK = decodeURIComponent(new URL(".", import.meta.url).pathname).replace(/\/$/, "");

let L;
try { L = await import("./lib.mjs"); } catch { L = await import(`${EGO_DIR_FALLBACK}/lib.mjs`); }

const fs = await import("node:fs");
const path = await import("node:path");

const { sleep, log, warn, line, norm, head, shot, shotter, EXIT, PLATFORMS } = L;

/* ─────────────── 常量 ─────────────── */

const XHS_URL = PLATFORMS.xhs.url;
/** 图文笔记上限：小红书单篇最多 18 张图。 */
const MAX_IMAGES = 18;
/** 标题上限 20 字（平台硬限，超了会被截）。 */
const MAX_TITLE = 20;
/** 封面尺寸口径：3:4 1080×1440。 */
const EXPECT_W = 1080, EXPECT_H = 1440;

/* ─────────────── spec ─────────────── */

function resolveImages(s, specFile) {
  const raw = Array.isArray(s.images) ? s.images.filter(Boolean) : [];
  const bases = [];
  if (s.baseDir) bases.push(path.isAbsolute(s.baseDir) ? s.baseDir : path.join(L.PUB_PROJECT, s.baseDir));
  bases.push(path.dirname(specFile || "."), L.PUB_PROJECT);
  return raw.map((f) => {
    if (path.isAbsolute(f)) return f;
    for (const b of bases) {
      const t = path.join(b, f);
      if (fs.existsSync(t)) return t;
    }
    return path.join(bases[0] || L.PUB_PROJECT, f);
  });
}

/** 读 PNG/JPEG 宽高，不依赖任何 npm 包（ego 的 node 里没有 sharp/jimp）。 */
function imageSize(file) {
  try {
    const b = fs.readFileSync(file);
    if (b.length > 24 && b[0] === 0x89 && b.toString("ascii", 1, 4) === "PNG") {
      return { ok: true, width: b.readUInt32BE(16), height: b.readUInt32BE(20), kind: "png" };
    }
    if (b.length > 4 && b[0] === 0xff && b[1] === 0xd8) {
      let i = 2;
      while (i + 9 < b.length) {
        if (b[i] !== 0xff) { i++; continue; }
        const marker = b[i + 1];
        const len = b.readUInt16BE(i + 2);
        if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
          return { ok: true, width: b.readUInt16BE(i + 7), height: b.readUInt16BE(i + 5), kind: "jpeg" };
        }
        i += 2 + len;
      }
      return { ok: false, error: "JPEG 里没找到 SOF 段" };
    }
    return { ok: false, error: "不是 PNG/JPEG" };
  } catch (e) {
    return { ok: false, error: String(e.message).split("\n")[0] };
  }
}

/** 禁用词命中：预热期不通广，命中就是 blocker（不是 warning）。 */
function bannedHits(text, words) {
  const hits = [];
  const src = String(text || "");
  for (const w of words || []) {
    if (w && src.includes(w)) hits.push(w);
  }
  return hits;
}

/**
 * 前置检查（**上传之前**跑，逐项打印；不碰浏览器就能出的结论都在这里）。
 *   hardBlockers → 缺 spec / 缺图：无解，直接停；
 *   gateBlockers → 尺寸不对、标题超字、命中禁用词：默认拦住，force 可硬闯。
 */
function preflightNote({ spec, specFile, images, pageOpen = null }) {
  const checks = [];
  const add = (name, ok, detail, level = "gate") => checks.push({ name, ok, detail, level });

  add("平台合法", true, `小红书图文（${XHS_URL}）`, "hard");
  add("spec 文件存在", !!specFile, specFile || "（没读到 spec 文件路径）", "hard");

  const miss = ["images", "title", "body"].filter((k) => {
    const v = spec ? spec[k] : undefined;
    return v === undefined || v === null || v === "" || (Array.isArray(v) && v.length === 0);
  });
  add("spec 必填字段齐全", miss.length === 0, miss.length ? `缺：${miss.join(", ")}` : "images / title / body 都在", "hard");

  // 图
  const n = images.length;
  add(`图片张数 1-${MAX_IMAGES}`, n >= 1 && n <= MAX_IMAGES, n ? `${n} 张` : "一张都没有", "hard");

  const missing = images.filter((f) => !fs.existsSync(f));
  add("每张图都存在", missing.length === 0, missing.length ? `缺 ${missing.length} 张：${missing.slice(0, 3).join("、")}${missing.length > 3 ? " …" : ""}` : `${n} 张都在`, "hard");

  const badDims = [];
  const dims = [];
  for (const f of images) {
    if (!fs.existsSync(f)) continue;
    const s = imageSize(f);
    if (!s.ok) { badDims.push(`${path.basename(f)}：${s.error}`); continue; }
    dims.push(`${path.basename(f)} ${s.width}×${s.height}`);
    if (s.width !== EXPECT_W || s.height !== EXPECT_H) badDims.push(`${path.basename(f)} 是 ${s.width}×${s.height}`);
  }
  add(`每张图都是 ${EXPECT_W}×${EXPECT_H}（3:4）`, badDims.length === 0, badDims.length ? badDims.slice(0, 4).join("；") : `${n} 张全对（第 1 张当封面）`, "gate");

  // 文字
  const title = String(spec && spec.title || "");
  add(`标题 ≤ ${MAX_TITLE} 字`, title.length > 0 && title.length <= MAX_TITLE, `${title.length} 字：${title}`, "gate");

  const body = String(spec && spec.body || "");
  add("正文非空且 ≤ 1000 字", body.length > 0 && body.length <= 1000, `${body.length} 字`, "gate");
  if (body.length > 0 && body.length < 300) add("正文 300-500 字（建议）", false, `${body.length} 字，偏短`, "warn");

  const tags = (spec && spec.tags) || [];
  add("话题 3-5 个", tags.length >= 3 && tags.length <= 5, `${tags.length} 个：${tags.map((t) => "#" + t).join(" ")}`, "warn");

  // 禁用词（预热期红线）
  const words = (spec && spec.bannedWords) || [];
  if (words.length) {
    const all = [title, body, ...tags].join("\n");
    const hits = bannedHits(all, words);
    add("预热期禁用词", hits.length === 0, hits.length ? `命中：${hits.join("、")}` : `已查 ${words.length} 个词，没命中`, "gate");
  }

  if (pageOpen !== null) add("目标页已在空间里打开", !!pageOpen, pageOpen ? "是" : "否（会导航/新建一个页面再继续）", "info");

  return {
    checks,
    hardBlockers: checks.filter((c) => !c.ok && c.level === "hard").map((c) => `${c.name}：${c.detail}`),
    gateBlockers: checks.filter((c) => !c.ok && c.level === "gate").map((c) => `${c.name}：${c.detail}`),
    warnings: checks.filter((c) => !c.ok && c.level === "warn").map((c) => `${c.name}：${c.detail}`),
    dims,
  };
}

function printPreflightNote(pf) {
  line("");
  line("──── 前置检查（图文） ────");
  for (const c of pf.checks) line(`${c.ok ? "✅" : c.level === "warn" ? "○" : "❌"} ${c.name}：${c.detail}`);
  if (pf.hardBlockers.length) line(`hard blocker ${pf.hardBlockers.length} 条（无解，force 也不能闯）`);
  else if (pf.gateBlockers.length) line(`gate blocker ${pf.gateBlockers.length} 条（默认拦住，force 可硬闯）`);
  else line("全过");
}

/* ─────────────── 多图上传 ─────────────── */

/** lib.setFilesViaCDP 只收单文件；图文要一次塞 N 张（CDP 本身支持 files 数组）。 */
async function setFilesViaCDPMulti(page, files, { accept = "image" } = {}) {
  const bad = files.filter((f) => !fs.existsSync(f));
  if (bad.length) return { ok: false, error: `文件不存在：${bad.slice(0, 2).join("、")}` };
  try {
    await page.cdp("DOM.enable").catch(() => {});
    const flat = await page.cdp("DOM.getFlattenedDocument", { depth: -1, pierce: true });
    const inputs = ((flat && flat.nodes) || []).filter((n) => n.nodeName === "INPUT");
    const fileInputs = inputs.filter((n) => {
      const a = L.attrsOf(n);
      return a.type === "file";
    });
    const pick =
      fileInputs.find((n) => String(L.attrsOf(n).accept || "").includes(accept)) ||
      fileInputs.find((n) => {
        const a = String(L.attrsOf(n).accept || "");
        return a === "" || a.includes("image") || a.includes("jpg") || a.includes("png");
      });
    if (!pick) return { ok: false, error: `CDP 没找到 accept 含 "${accept}" 的 file input（页面上一共 ${fileInputs.length} 个文件口）` };
    await page.cdp("DOM.setFileInputFiles", { nodeId: pick.nodeId, files });
    return { ok: true, via: "cdp DOM.setFileInputFiles", nodeId: pick.nodeId, count: files.length };
  } catch (e) {
    return { ok: false, error: String(e.message).split("\n")[0] };
  }
}

/**
 * 上传多图。三条路线，按顺序，**任何一条成功都要再用 DOM 信号确认**（塞进去 ≠ 上传成功）：
 *   1) `page.setInputFiles('input[type=file][accept*="image"]')`（ego 会回退到 iframe）；
 *   2) `page.setInputFiles('input[type=file]')`；
 *   3) CDP `DOM.setFileInputFiles`（多文件，穿 shadow/iframe DOM）。
 */
async function uploadImages(page, files) {
  const ok = files.filter((f) => fs.existsSync(f));
  const errs = [];
  for (const sel of ['input[type=file][accept*="image"]', "input[type=file]"]) {
    try {
      await page.setInputFiles(sel, ok, { timeout: 15000 });
      return { ok: true, via: `page.setInputFiles(${sel})`, count: ok.length };
    } catch (e) {
      errs.push(String(e.message).split("\n")[0]);
    }
  }
  const cdp = await setFilesViaCDPMulti(page, ok, { accept: "image" });
  if (cdp.ok) return { ok: true, via: cdp.via, count: ok.length };
  errs.push(cdp.error);
  return { ok: false, count: ok.length, error: errs.filter(Boolean).join(" / ") };
}

/** 图文上传完成的 DOM 信号：图片在页面上了，或者填写表单已经出现。 */
async function readNoteUploadState(page) {
  return await L.evalRetry(page, () => {
    const imgs = [...document.querySelectorAll("img")].filter((i) => {
      const s = i.currentSrc || i.src || "";
      return s.startsWith("blob:") || /xhs|sns-img/.test(s);
    });
    return {
      blobImages: imgs.length,
      thumbCandidates: document.querySelectorAll('[class*="img-container"],[class*="imgContainer"],[class*="pic"],.upload-item').length,
      titleInput: !!document.querySelector('input.d-text[placeholder*="标题"]'),
      editor: !!document.querySelector("div.tiptap"),
      text: document.body.innerText.replace(/\s+/g, " ").slice(0, 160),
    };
  }, undefined, { label: "图文上传状态" });
}

/* ─────────────── 第一段：只填 ─────────────── */

async function fillNote({ page, s, o, snap, images }) {
  // 1) 切到「上传图文」（默认落点是上传视频）
  const switched = (await L.jsClick(page, "上传图文", { tag: "div,span,li,button,a" })) || (await L.jsClick(page, "图文", { tag: "div,span,li,button,a" }));
  o.steps.switchTab = { ok: !!switched };
  if (!switched) warn("没点到「上传图文」标签 —— 继续按图文流程试（有的版本默认就是图文页）");
  await sleep(1500);
  await snap("note_tab");

  // 2) 上传 N 张图
  const up = await uploadImages(page, images);
  o.steps.upload = up;
  if (!up.ok) o.blockers.push(`图片没上传成功：${up.error || "未知原因"}`);

  // 上传后必须等到「填写标题」出现 —— 那才是图真的进了编辑器
  let st = null;
  for (let i = 0; i < 20; i++) {
    st = await readNoteUploadState(page);
    if (st && (st.titleInput || st.blobImages > 0)) break;
    await sleep(3000);
  }
  o.steps.uploaded = st;
  if (!st || (!st.titleInput && st.blobImages === 0)) {
    o.blockers.push(`图片没上传成功（等了 60s，没等到图片/填写表单；页面文字：${String(st && st.text || "").slice(0, 60)}）`);
  }
  await snap("note_uploaded");

  // 3) 标题
  if (s.title) {
    const r = await L.typeInto(page, 'input.d-text[placeholder*="标题"]', s.title, {
      clear: true,
      verify: 'input.d-text[placeholder*="标题"]',
      tries: 3,
    });
    o.steps.title = r;
    if (!r.ok) o.blockers.push(`标题没写进去或回读与 spec 不符：${r.reason || r.readback}`);
    await snap("note_title");
  }

  // 4) 正文 + 话题（tiptap 是 contenteditable：fill() 无效，只能 keyboard.type）
  if (s.body) {
    await L.egoClick(page, "div.tiptap", { label: "点进正文编辑器" });
    await sleep(600);
    for (const ln of String(s.body).split("\n")) {
      if (ln) await page.keyboard.type(ln, { delay: 8 });
      await page.keyboard.press("Enter");
    }
    await L.addTags(page, s.tags || [], { wait: 1200 });
    const got = String((await L.readText(page, "div.tiptap")) || "");
    o.steps.bodyReadback = norm(got).slice(0, 80);
    if (!norm(got).includes(head(s.body))) o.blockers.push("正文回读与 spec 不符（可能没打进去）");
    await snap("note_body");
  }

  // 5) 只读回读：标题 / 话题是否被识别成真话题（数 <a>）/ 图数 / 发布按钮在不在 closed shadow 里
  o.steps.readback = await L.evalRetry(page, () => {
    const t = document.querySelector('input.d-text[placeholder*="标题"]');
    const ed = document.querySelector("div.tiptap");
    const h = document.querySelector("xhs-publish-btn");
    return {
      title: t ? t.value : null,
      titleLen: t && t.value ? t.value.length : null,
      topicLinks: ed ? ed.querySelectorAll("a").length : null,
      editor: ed ? ed.innerText.replace(/\s+/g, " ").slice(0, 120) : null,
      blobImages: [...document.querySelectorAll("img")].filter((i) => String(i.src || "").startsWith("blob:")).length,
      hasShadowHost: !!h,
      hostShadowRoot: h ? (h.shadowRoot ? "open" : "null(closed)") : "no-host",
    };
  }, undefined, { label: "图文回读" });
  const rb = o.steps.readback || {};
  if (rb.titleLen && rb.titleLen > MAX_TITLE) o.blockers.push(`标题回读 ${rb.titleLen} 字，超过 ${MAX_TITLE} 字上限`);
  if (rb.topicLinks !== null && s.tags && s.tags.length && rb.topicLinks < 1) {
    o.warnings.push("回读到 0 个话题链接 —— 话题可能只是文字，没被识别成真话题（发布前人工看一眼）");
  }

  // 6) 禁用词（第二道：填完之后按页面上真实文字再查一遍）
  const words = s.bannedWords || [];
  if (words.length) {
    const third = await L.readText(page, "div.tiptap").catch(() => "");
    const hits = bannedHits([rb.title, third].join("\n"), words);
    if (hits.length) o.blockers.push(`页面上命中预热期禁用词：${hits.join("、")}`);
  }

  // 7) 原创声明（有就读状态，别假设默认值）
  o.steps.declare = await L.evalRetry(page, () => {
    const box = [...document.querySelectorAll('input[type=checkbox], .d-switch, [class*="switch"]')];
    const original = box.find((e) => /原创/.test((e.closest("label") || e.parentElement || e).innerText || ""));
    if (!original) return { found: false };
    const inp = original.matches("input") ? original : original.querySelector("input");
    return { found: true, checked: inp ? !!inp.checked : null, text: (original.closest("label") || original).innerText.replace(/\s+/g, " ").slice(0, 40) };
  }, undefined, { label: "原创声明" });
}

/* ─────────────── 第二段：发布（只有闸门放行才走到这） ─────────────── */

async function publishNote({ page, o, snap }) {
  // 按钮在视口外时坐标点击必打空 —— 先滚到中间
  const before = { url: await page.url().catch(() => ""), text: (await L.textOf(page, { tries: 2 })).slice(0, 80) };
  await L.evalRetry(page, () => {
    const host = document.querySelector("xhs-publish-btn");
    if (host && host.scrollIntoView) host.scrollIntoView({ block: "center" });
    else window.scrollTo(0, document.body.scrollHeight);
    return true;
  }, undefined, { label: "滚到发布按钮" }).catch(() => {});
  await sleep(800);

  const hit = await L.clickViaCDP(page, "发布", { label: "小红书：点发布（穿 closed shadow）" });
  o.steps.publishClick = hit;
  if (!hit) {
    o.blockers.push("发布按钮没点到（CDP 没在 closed shadow 里找到「发布」）");
    await snap("publish_miss");
    return;
  }
  await sleep(5000);
  const after = { url: await page.url().catch(() => ""), text: (await L.textOf(page, { tries: 3 })).slice(0, 120) };
  o.steps.publishAfter = after;
  const moved = after.url !== before.url || /发布成功|已发布|笔记管理/.test(after.text);
  if (!moved) {
    o.warnings.push(`点了发布但 URL/文案没变化（可能弹了二次确认或校验）：${after.url.slice(0, 90)}`);
  }
  await snap("note_published");
}

/* ─────────────── 自检（本地 fixture，不碰真站点） ─────────────── */

const NOTE_FIXTURE = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><title>fpb-note-selftest</title>
<style>body{font-family:sans-serif;padding:32px}
input.d-text,div.tiptap{display:block;margin:10px 0;padding:10px;font-size:16px;min-width:420px;border:1px solid #999}
div.tiptap{min-height:120px}
.tab{display:inline-block;padding:6px 12px;border:1px solid #999;margin-right:8px;cursor:pointer}
#imagePanel{display:none}</style></head><body>
<h1>小红书图文彩排台（本地 fixture）</h1>
<div class="tab" id="tabVideo">上传视频</div><div class="tab" id="tabImage">上传图文</div>
<input type="file" accept="video/mp4" id="fv">
<div id="imagePanel">
  <input type="file" accept="image/png,image/jpeg" id="fi" multiple>
  <input class="d-text" id="title" placeholder="填写标题">
  <div class="tiptap" id="ed" contenteditable="true">旧内容</div>
</div>
<xhs-publish-btn id="h"></xhs-publish-btn>
<script>
  window.__log = { tab: "", files: 0, fileNames: [], published: 0, title: "", body: "" };
  document.getElementById("tabImage").addEventListener("click", function () {
    document.getElementById("imagePanel").style.display = "block";
    window.__log.tab = "image";
  });
  document.getElementById("fi").addEventListener("change", function (e) {
    window.__log.files = e.target.files.length;
    window.__log.fileNames = [].map.call(e.target.files, function (f) { return f.name; });
  });
  var sr = document.getElementById("h").attachShadow({ mode: "closed" });
  sr.innerHTML = '<button id="p">发布</button>';
  sr.querySelector("#p").addEventListener("click", function () {
    window.__log.published += 1;
    window.__log.title = document.getElementById("title").value;
    window.__log.body = document.getElementById("ed").innerText.replace(/\\s+/g, " ").trim();
  });
</script>
</body></html>`;

async function noteSelftest(cmd) {
  const results = [];
  const check = (name, ok, detail) => {
    results.push({ name, ok: !!ok, detail });
    line(`${ok ? "✅" : "❌"} ${name}：${detail}`);
  };

  const specFile = L.resolveSpec(cmd.spec || "spec/notes/_template.json") || "(默认路径不存在，用内置造样本)";
  let images = [];
  let spec = null;
  try {
    const r = L.loadSpec(cmd.spec || "spec/notes/_template.json");
    spec = r.spec;
    images = resolveImages(spec, r.file);
  } catch {
    const dir = cmd.baseDir || ""; // 分发版：样例图目录由命令 JSON 的 baseDir 指定
    images = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => /^A1_\d+.*\.png$/.test(f)).sort().map((f) => path.join(dir, f)) : [];
    spec = { title: "自检标题", body: "自检正文", tags: ["测试"], images };
  }

  const task = await L.resumeSpace();
  let page = null;
  let scratch = false;
  try {
    page = await task.newPage();
    scratch = true;
  } catch {
    page = task.page("p1");
  }
  line(`自检页：${page.label}${scratch ? "（临时页，跑完关掉）" : "（复用 p1）"}`);

  try {
    await page.goto("data:text/html;charset=utf-8," + encodeURIComponent(NOTE_FIXTURE), { waitUntil: "domcontentloaded", timeout: 30000 });
    await sleep(600);

    // ── 1) 前置检查真的能拦住缺图 ──
    const pfBad = preflightNote({ spec: { title: "t", body: "b", images: [] }, specFile, images: [] });
    check("前置检查能拦住「一张图都没有」", pfBad.hardBlockers.length > 0, pfBad.hardBlockers.join("；"));

    const pf = preflightNote({ spec, specFile, images });
    check("前置检查对真样本全过（尺寸/张数/标题/禁用词）", pf.hardBlockers.length === 0 && pf.gateBlockers.length === 0, `${images.length} 张图；${pf.gateBlockers.concat(pf.hardBlockers).join("；") || "无 blocker"}`);

    // ── 2) 走一遍真实填充（用真图、真原语） ──
    const o = { platform: "xhs-note", blockers: [], warnings: [], steps: {}, wroteAt: new Date().toISOString() };
    const snap = async () => {};
    await fillNote({ page, s: spec, o, snap, images });
    const log1 = await page.evaluate(() => window.__log);
    // 回读一律读页面真值（__log.title/body 只在点发布时才写，不能拿来当回读）
    const dom1 = await page.evaluate(() => ({
      title: document.getElementById("title").value,
      body: document.getElementById("ed").innerText.replace(/\s+/g, " ").trim(),
    }));

    check("点「上传图文」真的切到图文面板", log1.tab === "image", `tab=${log1.tab}`);
    check(`多图上传：${images.length} 张都进了 file input`, log1.files === images.length, `fixture 收到 ${log1.files} 张：${log1.fileNames.slice(0, 3).join("、")}${log1.files > 3 ? " …" : ""}`);
    check("标题写进去并回读一致", norm(dom1.title) === norm(spec.title), `回读「${dom1.title}」`);
    check("正文写进去并回读一致（含话题）", dom1.body.includes(norm(spec.body).slice(0, 12)), `正文前 40 字「${dom1.body.slice(0, 40)}」，含 ${(spec.tags || []).filter((t) => dom1.body.includes("#" + t)).length}/${(spec.tags || []).length} 个话题`);
    check("填充阶段没有 blocker", o.blockers.length === 0, o.blockers.join("；") || "无");

    // ── 3) 两段式闸门：三种场景在图文路径上也要对 ──
    const before = await page.evaluate(() => window.__log);
    const realBlocker = "造出来的假 blocker（验证闸门）";

    const g1 = L.publishGate({ blockers: [realBlocker], publish: false, force: false });
    if (g1.allowed) await publishNote({ page, o, snap });
    const a1 = await page.evaluate(() => window.__log);
    check("场景1 默认 publish=false：不点发布", !g1.allowed && a1.published === before.published, `${g1.reason}｜published ${before.published}→${a1.published}`);

    const g2 = L.publishGate({ blockers: [realBlocker], publish: true, force: false });
    if (g2.allowed) await publishNote({ page, o, snap });
    const a2 = await page.evaluate(() => window.__log);
    check("场景2 publish=true 有 blocker 无 force：拒绝且没点", !g2.allowed && a2.published === before.published, `${g2.reason}｜published 仍 ${a2.published}`);

    const g3 = L.publishGate({ blockers: [realBlocker], publish: true, force: true });
    if (g3.allowed) await publishNote({ page, o, snap });
    const a3 = await page.evaluate(() => window.__log);
    check("场景3 force 才硬发，且真的点中了 closed shadow 里的「发布」", g3.allowed && a3.published === before.published + 1, `published ${a2.published}→${a3.published}；回读标题「${a3.title}」`);

    // ── 4) 禁用词真的在跑 ──
    const hits = bannedHits("正文里写了主页领一次口语诊断", ["诊断", "主页领", "价格"]);
    check("禁用词表真的能命中（诊断/主页领）", hits.length === 2, `命中 ${hits.join("、")}`);

    await shot(page, "note_selftest");

    line("");
    line("──── 小红书图文自检汇总 ────");
    for (const r of results) line(`${r.ok ? "✅" : "❌"} ${r.name}`);
    const ok = results.every((r) => r.ok);
    line(`结论：${ok ? "✅ 图文路径可用（多图上传 / 标题正文回读 / 闸门 / CDP 穿 closed shadow 点发布 都对）" : "❌ 有断言没过"}`);
    line(`通过 ${results.filter((r) => r.ok).length}/${results.length}`);
    return ok;
  } finally {
    if (scratch) await page.close().catch(() => {});
  }
}

/* ─────────────── 主流程 ─────────────── */

function printHelp(reason) {
  if (reason) line(`⛔ ${reason}`);
  line("");
  line("note.mjs 用法（小红书图文；参数从这个 JSON 读）：");
  line(`  命令 JSON：${L.CMD_FILE}`);
  line(`  {`);
  line(`    "note": true,`);
  line(`    "spec": "spec/notes/_template.json",   // 绝对路径，或相对 ${L.PUB_PROJECT}`);
  line(`    "publish": false,                 // ★ 默认 false = 只填不发`);
  line(`    "force": false,                   // ★ 有 blocker 也要硬发才写 true`);
  line(`    "preflightOnly": false,           // true = 只跑前置检查，不碰页面`);
  line(`    "noteSelftest": true              // true = 本地 fixture 自检（不需要 note/platform）`);
  line(`  }`);
  line("");
  line("跑法：");
  line(`  ego-browser nodejs -e 'await import("file://${L.EGO_DIR}/note.mjs")'`);
  line("");
}

function printResult(o) {
  line("");
  line("──── 结果 ────");
  line(`平台：${o.platform}　spec：${o.specFile || "（无）"}`);
  line(`blocker：${o.blockers.length} 条　warning：${o.warnings.length} 条`);
  for (const b of o.blockers) line(`  ⛔ ${b}`);
  for (const w of o.warnings) line(`  ⚠️ ${w}`);
  line(`步骤：${JSON.stringify(o.steps, null, 2)}`);
  line(`发布：${o.published ? "已点发布（去后台核对！）" : o.refusedPublish ? "闸门拦住，没发" : "只填没发"}`);
  line(`记录时间：${o.wroteAt}`);
}

async function main() {
  const cmd = L.loadCommand();
  if (!cmd) {
    printHelp(`没有命令 JSON：${L.CMD_FILE}`);
    process.exit(EXIT.ERROR);
  }
  line(`命令 JSON：${L.CMD_FILE}`);
  line(JSON.stringify(cmd, null, 2));

  /* ── 自检模式（本地 fixture，不碰真站点） ── */
  if (cmd.noteSelftest) {
    line("");
    line("──── 小红书图文自检（本地 fixture，不碰任何真站点） ────");
    const ok = await noteSelftest(cmd);
    process.exit(ok ? EXIT.OK : EXIT.ERROR);
  }

  if (!cmd.note) {
    printHelp("命令 JSON 里没有 note:true（这条只管小红书图文；视频走 fill.mjs）");
    process.exit(EXIT.ERROR);
  }

  /* ── 第 0 段 A：不碰浏览器就能查的 ── */
  let spec = null;
  let specFile = null;
  try {
    const r = L.loadSpec(cmd.spec);
    spec = r.spec;
    specFile = r.file;
    line(`spec：${specFile}`);
  } catch (e) {
    line("");
    line(`⛔ ${String(e.message).split("\n")[0]}`);
    line("⛔ 找不到 spec 文件：发布参数不全，直接停下（退出码 3），没有碰浏览器。");
    process.exit(EXIT.PREFLIGHT);
  }
  const images = resolveImages(spec, specFile);
  line(`图片：${images.length} 张（第 1 张当封面）`);
  for (const f of images) line(`  · ${path.basename(f)}${fs.existsSync(f) ? "" : "  ← 不存在"}`);
  if (spec.tags) line(`话题：${spec.tags.map((t) => "#" + t).join(" ")}`);

  const early = preflightNote({ spec, specFile, images, pageOpen: null });
  printPreflightNote(early);
  if (early.hardBlockers.length) {
    line("⛔ 前置检查没过（缺 spec / 缺图这级别无解，force 也不能硬闯）：");
    for (const b of early.hardBlockers) line(`  - ${b}`);
    process.exit(EXIT.PREFLIGHT);
  }
  if (cmd.preflightOnly) {
    line(`只跑前置检查（preflightOnly=true）：${early.gateBlockers.length ? "有 ❌ 项，退出码 3" : "全过，退出码 0"}`);
    process.exit(early.gateBlockers.length ? EXIT.PREFLIGHT : EXIT.OK);
  }

  /* ── 第 0 段 B：目标页 ── */
  const task = await L.resumeSpace();
  const tabs = await L.listTabs(task);
  const open = tabs.find((t) => t.url.includes(PLATFORMS.xhs.tabPart));
  line(`目标页：${open ? `已打开（${open.label || "未纳管"} ${open.url.slice(0, 80)}）` : "未打开（下面会导航/新建一个页面）"}`);

  const pf = preflightNote({ spec, specFile, images, pageOpen: !!open });
  const o = { platform: "xhs-note", specFile, preflight: pf.checks, blockers: [], warnings: [], steps: {}, wroteAt: new Date().toISOString() };
  o.blockers.push(...pf.gateBlockers);
  o.warnings.push(...pf.warnings);
  if (pf.gateBlockers.length) warn(`前置检查有 ${pf.gateBlockers.length} 条 gate blocker（默认拦住，force 可硬闯）`);

  const { page } = await L.openPlatformPage(task, "xhs", { navigate: true });
  const snap = shotter(page, "xhnote");
  await snap("page");

  // 登录态自检：没登录就停，不代登录（硬纪律）
  const bodyText = (await L.textOf(page, { tries: 3 })) || "";
  const loggedOut = /扫码登录|请登录|登录后|立即登录|手机号登录/.test(bodyText);
  if (loggedOut) {
    o.blockers.push("小红书后台是未登录状态 —— 请用户自己在浏览器里扫码登录，登完重跑（不代登录）");
    printResult(o);
    process.exit(EXIT.GATE);
  }
  const account = (bodyText.match(/创作服务平台\s+(\S{1,15})/) || [])[1] || null;
  log(`账号：${account || "（没读到，以页面为准）"}`);

  log(`小红书图文${cmd.publish ? "：填完判门，通过才发" : "：只填不发（默认）"}`);

  /* ── 第 1 段：只填，绝不点发布 ── */
  try {
    await fillNote({ page, s: spec, o, snap, images });
  } catch (e) {
    o.blockers.push(`填表阶段异常：${String(e.message).split("\n")[0]}`);
    await snap("error");
  }

  /* ── 闸门 ── */
  const gate = L.publishGate({ blockers: o.blockers, publish: !!cmd.publish, force: !!cmd.force });
  o.gate = gate;
  if (gate.allowed) {
    log(`闸门通过（${gate.reason}），开始第二段：发布`);
    try {
      await publishNote({ page, o, snap });
      o.published = true;
    } catch (e) {
      o.blockers.push(`发布阶段异常：${String(e.message).split("\n")[0]}`);
      await snap("publish_error");
    }
  } else if (cmd.publish) {
    o.refusedPublish = true;
    log(`⛔ 闸门拦住：${gate.reason}`);
  }

  printResult(o);
  line(`截图目录：${L.SHOTS_DIR.replace(/ego\/?$/, "ego/")}`);

  // 硬闯发布过之后绝不能再退非零（上层重跑＝重复发布）
  if (o.published && gate.forced) {
    line("");
    line(`⚠️ 这次是 force 硬闯发布的（${o.blockers.length} 条 blocker 被越过）。退出码 0 —— **不要再重跑**，否则重复发布。`);
    process.exit(EXIT.OK);
  }
  if (o.blockers.length) {
    line("");
    line(`⛔ blocker 未过（${o.blockers.length} 条）→ 退出码 2`);
    line(o.refusedPublish ? "⛔ 有 blocker，**发布没有执行**（页面停在填好的状态）。修好后重跑，或确认无害后把 force 改成 true。" : "⛔ 只填阶段就有 blocker，先看上面的清单和截图。");
    process.exit(EXIT.GATE);
  }
  if (o.published) {
    line("已点发布：**去后台逐项核对**（标题/封面/话题/可见性）——「点了发布按钮」不算发布成功。");
  } else if (cmd.publish) {
    line("命令里 publish=true 但闸门没放行（见上）。");
  } else {
    line(`只填了没发。截图在 ${L.SHOTS_DIR}/，确认后把命令 JSON 的 publish 改成 true 再跑。`);
  }
  process.exit(EXIT.OK);
}

main().catch((e) => {
  line("");
  line(`⛔ 失败：${String(e && e.message ? e.message : e).split("\n")[0]}`);
  process.exit(EXIT.ERROR);
});
