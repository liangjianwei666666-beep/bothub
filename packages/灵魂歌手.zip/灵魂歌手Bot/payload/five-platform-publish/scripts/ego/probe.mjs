/**
 * five-platform-publish / scripts/ego/probe.mjs
 * ─────────────────────────────────────────────────────────────
 * 五站登录态自检（**只读**，ego lite 原生版；新增，不动旧版 scripts/probe.js）。
 *
 * 纪律：
 *   · 只看，不登录、不扫码、不点任何发布相关的按钮；
 *   · 复用同一个 taskSpace「五平台发布」（实测 id=3），**不新建、不 finish**；
 *   · 已有标签就复用；未纳管的标签先 adopt（不关用户的标签）。
 *
 * 三态判断：✅ 已登录 / ❌ 未登录 / ❔ 不确定（不确定就人工看截图，不硬猜）。
 *
 * 怎么跑（可选参数同样只能从命令 JSON 读，argv/env 传不进来）：
 *   ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/probe.mjs")'
 *
 *   可选命令 JSON（不写就是全查 + 导航）：
 *   { "probe": { "platforms": ["xhs","sph"], "navigate": true, "openLogin": false } }
 *
 * 退出码：0 = 五站都 ✅；2 = 有 ❌ 或 ❔（需要人处理）；1 = 意外错误。
 */

const EGO_DIR_FALLBACK = decodeURIComponent(new URL(".", import.meta.url).pathname).replace(/\/$/, "");
let L;
try {
  L = await import("./lib.mjs");
} catch {
  L = await import(`${EGO_DIR_FALLBACK}/lib.mjs`);
}
const { log, line, sleep, shot, openPlatformPage, EXIT } = L;

/** 各平台额外特征（减少误判）。 */
const EXTRA_HINTS = {
  xhs: /创作服务平台|发布笔记|上传视频/,
  sph: /视频号|发表动态|动态管理/,
  dy: /创作者中心|抖音创作|作品发布/,
  x: /发帖|Post|为你推荐|发生了什么事/,
  yt: /Studio|频道信息中心|我的频道/,
};

/**
 * 平台专属的 DOM 登录信号 —— 比纯文本匹配稳得多。
 * 实测教训：X 的中文界面里导航项被翻译成「邮政 / 家 / 探索」，纯文本匹配判不出来（第一次跑成了 ❔），
 * 改成看 [data-testid="tweetButton"] 这种结构信号就稳了。
 */
const DOM_SIGNALS = {
  x: () => {
    const ed = document.querySelector('[data-testid="tweetTextarea_0"], div.public-DraftEditor-content');
    const btn = document.querySelector('[data-testid="tweetButton"], [data-testid="tweetButtonInline"]');
    if (ed && btn) return "发布框和 Post 按钮都在（data-testid）";
    if (ed) return "发布框在（public-DraftEditor-content）";
    return null;
  },
  xhs: () => {
    if (/上传视频|发布笔记/.test(document.body.innerText) && document.querySelector("input[type=file]")) return "上传页文案 + file input 都在";
    return null;
  },
  dy: () => (/作品发布|发布视频|作品描述|上传视频/.test(document.body.innerText) ? "创作者中心发布页文案在" : null),
  yt: () => {
    if (document.querySelector("ytcp-app, ytcp-navigation-drawer, ytcp-entity-page-header, #masthead")) return "Studio 外壳元素在（ytcp-*）";
    if (/频道信息中心|我的频道/.test(document.body.innerText)) return "Studio 文案在";
    return null;
  },
  sph: () => {
    if (location.href.includes("login.html")) return null;
    return /发表动态|动态管理|发表/.test(document.body.innerText) ? "视频号后台文案在" : null;
  },
};

/** 三态判断。 */
async function judge(page, key) {
  const meta = L.PLATFORMS[key];
  const url = await page.url().catch(() => "");
  const text = await L.textOf(page);
  const pw = await page
    .evaluate(() => [...document.querySelectorAll("input[type=password]")].filter((e) => e.getBoundingClientRect().width > 0).length)
    .catch(() => 0);
  const domSignal = await page.evaluate(DOM_SIGNALS[key]).catch(() => null);
  const evidence = { url, title: await page.title().catch(() => ""), text: text.slice(0, 200), visiblePasswordInputs: pw, domSignal: domSignal || null };

  if (meta.loginPart && url.includes(meta.loginPart)) return { state: "no", why: `URL 是登录页（含 "${meta.loginPart}"）`, evidence };
  if (pw > 0) return { state: "no", why: "页面上有可见的密码输入框", evidence };
  if (domSignal) return { state: "yes", why: `DOM 信号：${domSignal}`, evidence };
  if (L.LOGIN_HINTS.test(text) && !EXTRA_HINTS[key].test(text)) return { state: "no", why: "正文出现登录话术且没有后台特征", evidence };
  if (meta.backend.test(text) || EXTRA_HINTS[key].test(text)) return { state: "yes", why: "正文出现后台特征", evidence };
  return { state: "unknown", why: "没看到明显特征，请看截图确认", evidence };
}

/**
 * 尽力读账号名/频道名（读不到就 null，绝不编）。元素读法 + 文本行读法双保险。
 *
 * ⚠️ 实测踩坑：`page.evaluate(fn)` 是**把函数源码送进页面执行**的，
 * 它**看不到 Node 侧的闭包变量**（第一版把 UI_WORDS 放在外面，页面里 ReferenceError，
 * 被 catch 吞掉 → 账号名永远读不到，还查了半天）。所以 UI_WORDS 必须当参数传进去。
 */
const UI_WORDS = [
  "创作服务平台", "发布笔记", "上传视频", "上传图文", "写长文", "发播客", "首页", "笔记管理", "数据看板",
  "活动中心", "笔记灵感", "创作学院", "创作百科", "草稿箱", "我的频道", "频道信息中心", "信息中心", "内容",
  "数据分析", "社区", "字幕", "创收", "自定义", "音频库", "设置", "发送反馈", "作品发布", "内容管理",
  "数据中心", "收入变现", "创作服务", "发布视频", "发布图文", "发布文章", "主页", "探索", "通知", "加载中，请稍候...",
];

async function accountOf(page, key) {
  const probes = {
    x: () => {
      const btn = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
      if (btn && btn.innerText.trim()) return btn.innerText.replace(/\s+/g, " ").trim();
      const m = document.body.innerText.match(/@[A-Za-z0-9_\u4e00-\u9fa5]{2,30}/);
      return m ? m[0] : null;
    },
    yt: () => {
      const el = document.querySelector("#channel-name, ytcp-account-details, #account-name");
      if (el && el.innerText.trim()) return el.innerText.replace(/\s+/g, " ").trim().slice(0, 60);
      const lines = document.body.innerText.split("\n").map((s) => s.trim()).filter(Boolean);
      const i = lines.findIndex((l) => l === "我的频道");
      if (i >= 0 && lines[i + 1]) return lines[i + 1].slice(0, 40);
      return null;
    },
    xhs: (words) => {
      const ok = (t) => t && t.length <= 20 && !words.includes(t);
      // 元素读法优先：实测账号名在 .user-info / .name-box 里（值形如「深圳在地心理咨询」）
      const el = [...document.querySelectorAll('[class*="user-info"], [class*="avatar"], [class*="user"]')]
        .map((e) => (e.innerText || "").trim())
        .find(ok);
      if (el) return el;
      const lines = document.body.innerText.split("\n").map((s) => s.trim()).filter(Boolean);
      const i = lines.findIndex((l) => l === "创作服务平台");
      for (let j = i + 1; i >= 0 && j < Math.min(i + 6, lines.length); j++) if (ok(lines[j])) return lines[j].slice(0, 20);
      return null;
    },
    dy: (words) => {
      const el = [...document.querySelectorAll('[class*="user-info"], [class*="avatar"], [class*="nickname"]')]
        .map((e) => (e.innerText || "").trim())
        .find((t) => t && t.length <= 20 && !words.includes(t));
      return el || null;
    },
    sph: (words) => {
      const el = [...document.querySelectorAll('[class*="account"], [class*="nickname"]')]
        .map((e) => (e.innerText || "").trim())
        .find((t) => t && t.length <= 20 && !words.includes(t));
      return el || null;
    },
  };
  try {
    const v = await page.evaluate(probes[key], UI_WORDS);
    return v || null;
  } catch {
    return null;
  }
}

/**
 * 等页面真的渲染出来（**不固定 sleep**）。
 * 实测教训：小红书的 SPA 在 `readyState=complete` 之后还有 ~10 秒 `body.innerText` 是**空的**，
 * 早先固定等 7 秒会判成「不确定」，账号名也读不到。所以这里轮询到「出现登录墙 / 出现 DOM 信号 /
 * 正文够长且有后台特征」为止。
 */
async function pageReady(page, key, { tries = 14, every = 3000 } = {}) {
  const meta = L.PLATFORMS[key];
  for (let i = 0; i < tries; i++) {
    const url = await page.url().catch(() => "");
    if (meta.loginPart && url.includes(meta.loginPart)) return { settled: "login-url", url, rounds: i + 1 };
    const pw = await page
      .evaluate(() => [...document.querySelectorAll("input[type=password]")].filter((e) => e.getBoundingClientRect().width > 0).length)
      .catch(() => 0);
    if (pw > 0) return { settled: "password-input", url, rounds: i + 1 };
    const sig = await page.evaluate(DOM_SIGNALS[key]).catch(() => null);
    if (sig) return { settled: "dom-signal", url, sig, rounds: i + 1 };
    const t = await L.textOf(page);
    if (t.length > 80 && (meta.backend.test(t) || EXTRA_HINTS[key].test(t))) return { settled: "text", url, rounds: i + 1 };
    await sleep(every);
  }
  return { settled: "timeout", rounds: tries };
}

async function probeOne(task, key, { navigate }) {
  const meta = L.PLATFORMS[key];
  const { page, url } = await openPlatformPage(task, key, { navigate, force: navigate, waitMs: 2000 });
  const ready = await pageReady(page, key);
  const v = await judge(page, key);
  const account = v.state === "yes" ? await accountOf(page, key) : null;
  const icon = v.state === "yes" ? "✅" : v.state === "no" ? "❌" : "❔";
  const label = v.state === "yes" ? "已登录" : v.state === "no" ? "未登录" : "不确定";

  line("");
  line(`${icon} ${meta.name}（${key}）${label} —— ${v.why}`);
  line(`   URL   : ${v.evidence.url.slice(0, 130)}`);
  line(`   TITLE : ${v.evidence.title.slice(0, 90)}`);
  line(`   就绪  : ${ready.settled}（第 ${ready.rounds} 轮）`);
  line(`   账号  : ${account || "（页面上没读到，不编）"}`);
  line(`   TEXT  : ${v.evidence.text.slice(0, 150)}`);
  const file = await shot(page, `${key}_probe`);
  line(`   截图  : ${file || "（截图失败）"}`);

  return { key, name: meta.name, account, screenshot: file, ready: ready.settled, ...v };
}

async function main() {
  const cmd = L.loadCommand();
  const p = (cmd && (cmd.probe || cmd)) || {};
  const keys = (p.platforms && p.platforms.length ? p.platforms : L.PLATFORM_KEYS).filter((k) => {
    if (!L.PLATFORMS[k]) {
      line(`⛔ 未知平台 "${k}"，可选：${L.PLATFORM_KEYS.join(" / ")}`);
      process.exit(EXIT.ERROR);
    }
    return true;
  });
  const navigate = p.navigate !== false;
  const openLogin = p.openLogin === true;

  line("──── 五平台登录态自检（只读；不登录、不扫码、不点发布） ────");
  line(`查这些：${keys.join(" / ")}｜${navigate ? "会导航到各站后台入口" : "只看当前标签页（不导航）"}`);

  const task = await L.resumeSpace();
  const results = [];
  for (const k of keys) {
    try {
      results.push(await probeOne(task, k, { navigate }));
    } catch (e) {
      const msg = String(e.message).split("\n")[0];
      line(`❌ ${L.PLATFORMS[k].name} 探测失败：${msg}`);
      results.push({ key: k, name: L.PLATFORMS[k].name, state: "unknown", why: `探测异常：${msg}` });
    }
  }

  line("");
  line("──── 汇总 ────");
  for (const r of results) {
    const icon = r.state === "yes" ? "✅" : r.state === "no" ? "❌" : "❔";
    const label = r.state === "yes" ? "已登录" : r.state === "no" ? "未登录" : "不确定";
    line(`${icon} ${r.name}${`　`.slice(0, Math.max(1, 6 - r.name.length))} ${label}　${r.why}${r.account ? `（账号 ${r.account}）` : ""}`);
  }
  const no = results.filter((r) => r.state === "no").map((r) => r.name);
  const unknown = results.filter((r) => r.state === "unknown").map((r) => r.name);
  if (no.length) line(`需要用户自己登录：${no.join("、")} —— 本脚本不代登录；用户登好后重跑一次。`);
  if (unknown.length) line(`不确定、需要人工看截图：${unknown.join("、")}`);
  if (!no.length && !unknown.length) line("五站都就绪，可以开跑 fill.mjs。");
  line(`截图目录：${L.SHOTS_DIR}/（文件名 <平台>_probe.png）`);
  line("注意：本次探测**没有**调用 task.finish()，「五平台发布」空间留给下次直接用。");

  process.exit(no.length || unknown.length ? EXIT.GATE : EXIT.OK);
}

main().catch((e) => {
  line("");
  line(`⛔ 失败：${String(e && e.message ? e.message : e).split("\n")[0]}`);
  process.exit(EXIT.ERROR);
});
