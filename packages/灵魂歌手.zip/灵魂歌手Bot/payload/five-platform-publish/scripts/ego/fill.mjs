/**
 * five-platform-publish / scripts/ego/fill.mjs
 * ─────────────────────────────────────────────────────────────
 * 逐平台「只填不发 / 填完过闸门再发」。ego lite 原生版（**新增**，不动旧版 scripts/fill.js）。
 *
 * ★★ 两段式发布闸门 —— 顺序写进代码，不是写在文档里 ★★
 *   第 0 段：前置检查（spec / 文件 / 编码 / 目标页），有 hard blocker 直接停，连上传都不做；
 *   第 1 段：只填（上传、填表、选声明、清位置、回读校验）—— **这一段里没有一行点发布**；
 *   第 2 段：只有命令 JSON 里显式 "publish": true，才走 publishGate()；
 *          门判完 blocker，通过了才执行发布；有 blocker 且没有 "force": true → 拒绝发布并非零退出。
 *   （上一版把发布点击写在流程里、跑完才打印「已拒绝发布」—— 那是事后补记的假门。别再那样写。）
 *
 * ★ 一次只跑一个平台：命令 JSON 里的 platform 只有一个，发完核对完再跑下一个。
 * ★ 探测/填表过程中**绝不调用 task.finish()**：「五平台发布」空间是长期复用的。
 *
 * 怎么跑（实测：argv / 环境变量都传不进 ego 脚本，相对 import 在 `<` 模式下会坏）：
 *
 *   cat > ~/Desktop/音乐创作/.publish-tools/ego-cmd.json <<'JSON'
 *   { "platform": "xhs", "spec": "spec/xhs.json", "publish": false, "force": false }
 *   JSON
 *   export PATH="$HOME/.local/bin:$PATH"
 *   ego-browser nodejs -e 'await import("file://$HOME/.agents/skills/five-platform-publish/scripts/ego/fill.mjs")'
 *
 * 退出码：0 正常；1 意外错误；2 闸门拦住 / 有 blocker 未过；3 前置检查没过。
 */

const EGO_DIR_FALLBACK = decodeURIComponent(new URL(".", import.meta.url).pathname).replace(/\/$/, "");
let L;
try {
  L = await import("./lib.mjs"); // 用 -e 'await import(file://…)' 跑时走这条
} catch {
  L = await import(`${EGO_DIR_FALLBACK}/lib.mjs`); // 用 `<` / heredoc 跑时 base 是 //[eval2]，退回绝对路径
}
const { sleep, log, warn, line, norm, head, shot, shotter, EXIT } = L;

/* ─────────────── 平台常量 ─────────────── */

const TABS = {
  xhs: L.PLATFORMS.xhs.url,
  sph: L.PLATFORMS.sph.url,
  dy: L.PLATFORMS.dy.url,
  x: L.PLATFORMS.x.url,
  yt: "https://studio.youtube.com",
};

/** 视频号整张表单在这个 iframe 里（外层 DOM 抓不到，ego 的动作会自动回退到 frame 找）。 */
const SPH_FRAME_PART = "/micro/content/post/create";

/* ─────────────── 小工具 ─────────────── */

function out(platform) {
  return { platform, blockers: [], warnings: [], steps: {}, wroteAt: new Date().toISOString() };
}

/** 点某个控件后接住系统文件选择框（ego 原生 waitForFileChooser）。 */
async function withChooser(page, selector, file, { timeout = 15000 } = {}) {
  let pending = null;
  try {
    pending = page.waitForFileChooser({ timeout });
    const r = await L.egoClick(page, selector, { timeout: 6000 });
    if (!r.ok) {
      pending.catch(() => {});
      return { ok: false, error: `点不到「${selector}」：${r.error}` };
    }
    const chooser = await pending;
    const res = await chooser.setFiles(file);
    return { ok: true, dialog: res && res.dialog };
  } catch (e) {
    if (pending) pending.catch(() => {});
    return { ok: false, error: String(e.message).split("\n")[0] };
  }
}

/** 同一份技能里最常犯的错：只看「发布」这种一直存在的词。这里强制 done+busy 两个都要给。 */
const busyOf = (t) => /上传中|解析中|正在上传|处理中|Uploading/.test(t);

/* ─────────────── 小红书 ─────────────── */

async function fillXhs({ page, s, o, snap }) {
  if (s.video) {
    const up = await L.uploadVideo(page, s.video, { clickTarget: "text=上传视频" });
    o.steps.upload = up;
    if (!up.ok) o.blockers.push(`视频没上传成功：${up.error || "未知原因"}`);
    const w = await L.waitForText(page, /填写标题|正文|添加话题|上传完成|重新上传|上传成功/, { tries: 30, every: 4000, label: "小红书上传" });
    o.steps.uploaded = w.ok;
    if (!w.ok) o.blockers.push("视频没上传成功（上传后没等到填写表单）");
    await snap("uploaded");
  }

  if (s.title) {
    const r = await L.typeInto(page, 'input.d-text[placeholder*="标题"]', s.title, {
      clear: true,
      verify: 'input.d-text[placeholder*="标题"]',
      tries: 3,
    });
    o.steps.title = r;
    if (!r.ok) o.blockers.push(`标题没写进去或回读与 spec 不符：${r.reason || r.readback}`);
    await snap("title");
  }

  if (s.body) {
    await L.egoClick(page, "div.tiptap", { label: "点进正文编辑器" });
    await sleep(600);
    for (const ln of String(s.body).split("\n")) {
      await page.keyboard.type(ln, { delay: 8 });
      await page.keyboard.press("Enter");
    }
    await L.addTags(page, s.tags || [], { wait: 1200 });
    const got = String((await L.readText(page, "div.tiptap")) || "");
    o.steps.bodyReadback = norm(got).slice(0, 80);
    if (!norm(got).includes(head(s.body))) o.blockers.push("正文回读与 spec 不符（可能没打进去）");
    await snap("body");
  }

  if (s.cover) {
    await L.egoClick(page, "text=设置封面", { label: "打开封面编辑器" });
    await sleep(2500);
    // 弹窗里的上传入口：先按文字点，再兜底用 CDP 直接塞图片文件
    let r = await withChooser(page, "text=上传", s.cover);
    if (!r.ok) r = await withChooser(page, "text=+", s.cover);
    if (!r.ok) {
      const c = await L.setFilesViaCDP(page, s.cover, { accept: "image" });
      r = c.ok ? { ok: true, via: c.via } : c;
    }
    o.steps.cover = r;
    if (!r.ok) o.blockers.push(`封面没上传成功（会发成默认首帧）：${r.error || "未知原因"}`);
    await sleep(6000); // 平台要跑「封面效果评估」——这里等的是外部评估，没有可轮询的 DOM 信号
    await snap("cover");
  }

  // 只读回读：标题 / 话题是否被识别成真话题 / closed shadow 里到底有没有发布按钮
  o.steps.readback = await L.evalRetry(page, () => {
    const t = document.querySelector('input.d-text[placeholder*="标题"]');
    const ed = document.querySelector("div.tiptap");
    return {
      title: t ? t.value : null,
      topicLinks: ed ? ed.querySelectorAll("a").length : null,
      editor: ed ? ed.innerText.replace(/\s+/g, " ").slice(0, 120) : null,
      hasShadowHost: !!document.querySelector("xhs-publish-btn"),
      hostShadowRoot: (() => {
        const h = document.querySelector("xhs-publish-btn");
        return h ? (h.shadowRoot ? "open" : "null(closed)") : "no-host";
      })(),
      lightDomPublishButton: [...document.querySelectorAll("*")].filter((e) => !e.children.length && (e.innerText || "").trim() === "发布").length,
    };
  }, undefined, { label: "小红书回读" });

  // ★ 只读：用 CDP 穿透 closed shadow root 找发布按钮（不点！点了就是发布）
  try {
    const found = await L.cdpFind(page, "发布");
    o.steps.publishButtonViaCDP = { hits: found.hits.length, flatNodes: found.total, sample: found.hits.slice(0, 3).map((h) => ({ nodeName: h.nodeName, up: h.up, text: h.text })) };
    if (!found.hits.length) o.warnings.push("CDP 没在小红书页面上找到「发布」按钮（可能还在上传页/表单没渲染完）");
  } catch (e) {
    o.steps.publishButtonViaCDP = { error: String(e.message).split("\n")[0] };
    o.warnings.push(`CDP 查发布按钮失败：${String(e.message).split("\n")[0]}`);
  }

  await snap("filled");
}

async function pubXhs({ page, o, snap }) {
  // ★ 发布按钮在 <xhs-publish-btn> 的 closed shadow root 里：轻 DOM 找不到，必须走 CDP
  const hit = await L.clickViaCDP(page, "发布", { label: "小红书发布（CDP 穿透）" });
  o.steps.publishVia = hit ? "cdp" : null;
  o.steps.publishBox = hit ? hit.box : null;
  if (!hit) {
    const fallback = await L.clickText(page, "发布", { label: "小红书发布（轻 DOM 兜底）" });
    if (fallback) {
      o.steps.publishVia = "innerText(不可靠)";
      o.warnings.push("CDP 没找到发布按钮，退回到 innerText 点击 —— 请人工确认点的是不是发布键");
    } else {
      o.warnings.push("没点到「发布」按钮");
    }
  }
  await sleep(9000);
  const url = await page.url();
  const t = await L.textOf(page);
  o.steps.after = { url, text: t.slice(0, 200) };
  await snap("published");
  if (!/note-manager|published|success/.test(url) && !/发布成功|已发布|审核中/.test(t)) {
    o.warnings.push("点完发布后 URL/文案都没变化，请人工核对是否真的发出去了");
  }
}

/* ─────────────── 视频号（整张表单在 iframe 里） ─────────────── */

/** 同源 iframe：直接从顶层文档拿 contentDocument 读文本（读不到返回 null）。 */
async function frameText(page, part = SPH_FRAME_PART) {
  return await L.evalRetry(page, (p) => {
    const f = [...document.querySelectorAll("iframe")].find((i) => (i.src || "").includes(p)) || document.querySelector("iframe");
    const d = f && f.contentDocument;
    return d ? d.body.innerText.replace(/\s+/g, " ") : null;
  }, part, { tries: 4, every: 1200, label: "读视频号 iframe 文本" });
}

async function frameQueryText(page, sel, part = SPH_FRAME_PART) {
  return await L.evalRetry(page, ({ p, sel }) => {
    const f = [...document.querySelectorAll("iframe")].find((i) => (i.src || "").includes(p)) || document.querySelector("iframe");
    const d = f && f.contentDocument;
    if (!d) return { found: false, reason: "拿不到 iframe contentDocument（可能是跨进程 iframe）" };
    const el = d.querySelector(sel);
    if (!el) return { found: false, reason: `iframe 里没有 ${sel}` };
    return {
      found: true,
      value: el.value !== undefined && el.value !== null ? el.value : null,
      text: el.innerText !== undefined ? el.innerText.replace(/\s+/g, " ").slice(0, 200) : null,
      bodyText: d.body.innerText.replace(/\s+/g, " ").slice(0, 300),
    };
  }, { p: part, sel }, { tries: 3, every: 1200, label: `读视频号 ${sel}` });
}

/** 只读：视频号位置字段现在是什么。 */
async function readSphLocation(page) {
  const t = await frameText(page);
  if (!t) return { ok: false, reason: "拿不到 iframe 文本" };
  const m = t.match(/位置[：:\s]*([^\s|｜]{2,14})/);
  return { ok: true, locationText: m ? m[1] : null, raw: t.slice(0, 300) };
}

/** 中国大陆地名白名单 + 「不显示位置」。命中即安全，没命中就按「外国城市」拦下来。 */
const CN_PLACE =
  /^(不显示位置|不显示|中国|中国·?[\u4e00-\u9fa5]{2,8}|北京|上海|天津|重庆|河北|山西|辽宁|吉林|黑龙江|江苏|浙江|安徽|福建|江西|山东|河南|湖北|湖南|广东|海南|四川|贵州|云南|陕西|甘肃|青海|台湾|内蒙古|广西|西藏|宁夏|新疆|香港|澳门|深圳|广州|杭州|南京|成都|武汉|西安|苏州|长沙|郑州|青岛|厦门|福州|济南|合肥|昆明|大连|沈阳|哈尔滨|长春|石家庄|太原|南昌|贵阳|南宁|兰州|海口|三亚|无锡|宁波|温州|佛山|东莞|珠海|中山|常州|徐州|烟台|洛阳|保定|唐山)/;

async function hideSphLocation(page) {
  const before = await readSphLocation(page);
  if (!before.ok) return { ok: false, state: "cant-read", before, blocker: `读不到视频号位置字段：${before.reason}` };

  // 先看是不是本来就不显示
  if (before.locationText && /不显示/.test(before.locationText)) {
    return { ok: true, state: "already-hidden", before, after: before.locationText };
  }

  // 点位置 → 选「不显示位置」（ego 的动作会自动回退到 iframe 里找）
  const opened = await L.egoClick(page, 'text=位置', { timeout: 8000 });
  await sleep(1500);
  const picked = await L.egoClick(page, 'text=不显示位置', { timeout: 8000 });
  await sleep(1500);
  const after = await readSphLocation(page);
  const afterText = after.locationText || "";
  const good = picked.ok && (afterText === "" || /不显示/.test(afterText));
  return { ok: good, state: good ? "cleared" : "not-cleared", before: before.locationText, after: afterText, opened: opened.ok, picked: picked.ok };
}

async function fillSph({ page, s, o, snap }) {
  if (s.video) {
    const up = await L.uploadVideo(page, s.video, { clickTarget: "text=上传" });
    o.steps.upload = up;
    if (!up.ok) o.blockers.push(`视频没上传成功：${up.error || "未知原因"}`);
    // 轮询状态文本 / 百分比，不用固定 sleep
    const w = await L.waitForUploadDone(page, {
      done: /重新上传|上传完成|100%|删除/,
      busy: /上传中|解析中|上传中…/,
      tries: 40,
      every: 4000,
      label: "视频号上传",
    });
    o.steps.uploaded = { ok: w.ok, rounds: w.rounds };
    if (!w.ok) o.blockers.push("视频没上传成功（没等到「重新上传/上传完成/100%」）");
    await snap("uploaded");
  }

  if (s.shortTitle) {
    // 短标题是**独立输入框**，描述 ≠ 短标题
    const r = await L.typeInto(page, 'input[placeholder*="短标题"]', s.shortTitle, {
      clear: true,
      verify: 'input[placeholder*="短标题"]',
      tries: 3,
    });
    o.steps.shortTitle = r;
    if (!r.ok) o.blockers.push(`短标题回读与 spec 不符：${r.reason || r.readback}`);
    await snap("short_title");
  }

  if (s.body) {
    const clicked = await L.egoClick(page, ".input-editor", { label: "点进视频号描述" });
    if (!clicked.ok) o.blockers.push(`点不进视频号描述框：${clicked.error}`);
    await sleep(600);
    for (const ln of String(s.body).split("\n")) {
      await page.keyboard.type(ln, { delay: 10 });
      await page.keyboard.press("Enter");
    }
    await L.addTags(page, s.tags || [], { wait: 1600 });
    const got = await frameQueryText(page, ".input-editor");
    o.steps.bodyReadback = got && got.found ? norm(got.text).slice(0, 80) : `(读不到：${got && got.reason})`;
    if (!got || !got.found || !norm(got.text).includes(head(s.body))) o.blockers.push("描述回读与 spec 不符");
    await snap("body");
  }

  if (s.cover) {
    // 已知坑：真正的热区在「上传封面」文字上方约 40px 的 + 号；先试文字本身
    let r = await withChooser(page, "text=上传封面", s.cover);
    if (!r.ok) {
      // snapshot 兜底（**未验证**）：整页快照里找 iframe 的 ref，再用 subtree 聚焦到那个 frame 里找「+」。
      // 按 ego 文档 scope:"subtree" 必须带 root（iframe 的 ref），所以先 full_page 再 subtree。
      const full = await page.snapshot({ scope: "full_page" }).catch(() => null);
      let plusRef = null;
      if (full) {
        const m = String(full).match(/(@\d+)\s+(?:iframe|Iframe|frame)/);
        if (m) {
          const sub = await page.snapshot({ scope: "subtree", root: m[1] }).catch(() => null);
          plusRef = sub ? (String(sub).match(/(@\d+)\s+[a-z-]*\s*"\+"/) || [])[1] : null;
        }
      }
      o.steps.coverSnapshotPlusRef = plusRef || "(snapshot 里没找到 iframe/+ 的 ref)";
      if (plusRef) r = await withChooser(page, plusRef, s.cover);
    }
    if (!r.ok) {
      const c = await L.setFilesViaCDP(page, s.cover, { accept: "image" });
      r = c.ok ? { ok: true, via: c.via } : c;
    }
    o.steps.cover = r;
    if (!r.ok) o.blockers.push(`封面没上传成功：${r.error || "未知原因"}`);
    await sleep(4000);
    await snap("cover");
  }

  // 位置：平台按 IP 自动填（当天填成「华盛顿」）→ 必须清掉；**外国城市名直接算 blocker**
  if (s.hideLocation !== false) {
    const loc = await hideSphLocation(page);
    o.steps.location = loc;
    const finalText = loc.after || (loc.before && loc.before.locationText) || "";
    if (!loc.ok) {
      o.blockers.push(`视频号位置没清干净：现在是「${finalText || "读不到"}」 —— 外国城市名不许发`);
    } else if (finalText && !CN_PLACE.test(finalText)) {
      o.blockers.push(`视频号位置是「${finalText}」，看着不是中国大陆地名（外国城市名），不许发`);
    }
    await snap("location");
  }

  o.steps.readback = {
    editor: (await frameQueryText(page, ".input-editor")) || null,
    shortTitle: (await frameQueryText(page, 'input[placeholder*="短标题"]')) || null,
    location: await readSphLocation(page),
  };
  await snap("filled");
}

async function pubSph({ page, o, snap }) {
  const r1 = await L.egoClick(page, "text=直接发表", { label: "视频号直接发表" });
  const r2 = r1.ok ? r1 : await L.egoClick(page, "text=发表", { label: "视频号发表" });
  o.steps.publishVia = r1.ok ? "直接发表" : r2.ok ? "发表" : null;
  if (!r2.ok) o.warnings.push(`没点到「直接发表/发表」：${r1.error}`);
  await sleep(10000);
  o.steps.after = { url: await page.url(), text: (await frameText(page)) || (await L.textOf(page)).slice(0, 200) };
  await snap("published");
}

/* ─────────────── 抖音 ─────────────── */

async function declareAI(page) {
  await page
    .evaluate(() => {
      const el = [...document.querySelectorAll("*")].find((e) => (e.innerText || "").trim() === "请选择自主声明");
      if (el) el.scrollIntoView({ block: "center" });
    })
    .catch(() => {});
  await sleep(800);
  const opened = await L.clickText(page, "请选择自主声明");
  await sleep(1800);
  // 归档里的真实文案**没有空格**：「内容由AI生成」（带空格的版本点不中）
  const picked = (await L.clickText(page, "内容由AI生成")) || (await L.clickText(page, "内容由 AI 生成"));
  await sleep(1500);
  const t = await L.textOf(page);
  return { ok: opened && picked && !t.includes("请选择自主声明"), opened, picked, stillPlaceholder: t.includes("请选择自主声明") };
}

async function fillDy({ page, s, o, snap }) {
  if (await L.clickText(page, "我知道了")) {
    await sleep(800);
    o.steps.dismissedGuide = true;
  }
  if (s.video) {
    const up = await L.uploadVideo(page, s.video, { clickTarget: "text=上传视频" });
    o.steps.upload = up;
    if (!up.ok) o.blockers.push(`视频没上传成功：${up.error || "未知原因"}`);
    // 判据必须带「不再有上传中/解析中」，且不能只认「发布」（那个字一进页面就有）
    const w = await L.waitForUploadDone(page, {
      done: /重新上传|作品描述|填写作品|作品标题/,
      busy: /上传中|解析中/,
      tries: 40,
      every: 4000,
      label: "抖音上传",
    });
    o.steps.uploaded = { ok: w.ok, rounds: w.rounds };
    if (!w.ok) o.blockers.push("视频没上传成功（上传后没等到填写表单）");
    await snap("uploaded");
  }

  if (s.title) {
    const r = await L.typeInto(page, 'input[placeholder*="作品标题"]', s.title, {
      clear: true,
      verify: 'input[placeholder*="作品标题"]',
      tries: 3,
    });
    o.steps.title = r;
    if (!r.ok) o.blockers.push(`标题回读与 spec 不符：${r.reason || r.readback}`);
    await snap("title");
  }

  if (s.body) {
    const clicked = await L.egoClick(page, 'div[contenteditable="true"]', { label: "点进抖音简介" });
    if (!clicked.ok) o.blockers.push(`点不进抖音简介：${clicked.error}`);
    await sleep(500);
    for (const ln of String(s.body).split("\n")) {
      await page.keyboard.type(ln, { delay: 10 });
      await page.keyboard.press("Enter");
    }
    await L.addTags(page, s.tags || [], { wait: 1400 });
    const got = String((await L.readText(page, 'div[contenteditable="true"]')) || "");
    o.steps.bodyReadback = norm(got).slice(0, 80);
    if (!norm(got).includes(head(s.body))) o.blockers.push("简介回读与 spec 不符");
    await snap("body");
  }

  // AI 声明：**默认就声明**，除非 spec 明确写 declareAI:false
  if (s.declareAI !== false) {
    const r = await declareAI(page);
    o.steps.aiDeclare = r;
    if (!r.ok) o.blockers.push(`抖音 AI 声明没选中（页面仍显示「请选择自主声明」=${r.stillPlaceholder}）`);
    await snap("declare_ai");
  }

  o.steps.readback = await L.evalRetry(page, () => {
    const t = document.querySelector('input[placeholder*="作品标题"]');
    const d = document.querySelector('div[contenteditable="true"]');
    return {
      title: t ? t.value : null,
      desc: d ? d.innerText.replace(/\s+/g, " ").slice(0, 160) : null,
      aiDeclared: !document.body.innerText.includes("请选择自主声明"),
      hasDeclarationRow: /自主声明/.test(document.body.innerText),
    };
  }, undefined, { label: "抖音回读" });
  await snap("filled");
}

async function pubDy({ page, o, snap }) {
  await page
    .evaluate(() => {
      const b = [...document.querySelectorAll("button")].find((x) => (x.innerText || "").trim() === "发布");
      if (b) b.scrollIntoView({ block: "center" });
    })
    .catch(() => {});
  await sleep(800);
  // 台账实测：发布按钮被 toast 遮挡时坐标点击会打空 → element.click() 直接触发
  const js = await L.jsClick(page, "发布");
  o.steps.publishVia = js ? "js(element.click)" : (await L.clickText(page, "发布", { label: "抖音发布" })) ? "mouse" : null;
  if (!o.steps.publishVia) o.warnings.push("没点到「发布」按钮");
  await sleep(9000);
  o.steps.after = { url: await page.url(), text: (await L.textOf(page)).slice(0, 200) };
  await snap("published");
}

/* ─────────────── X ─────────────── */

async function fillX({ page, s, o, snap }) {
  if (s.video) {
    const up = await L.uploadVideo(page, s.video, { clickTarget: 'input[type="file"]' });
    o.steps.upload = up;
    if (!up.ok) o.blockers.push(`视频没上传成功：${up.error || "未知原因"}`);
    // 归档做法：先看到上传百分比，再等它消失（Post/发帖 一进页面就有，不能当信号）
    const w = await L.waitForUploadDone(page, {
      done: /Post|发帖/,
      busy: /\d{1,3}%|Uploading|上传中/,
      requireSeen: /\d{1,3}%/,
      tries: 45,
      every: 4000,
      label: "X 上传",
    });
    o.steps.uploaded = { ok: w.ok, sawSeen: w.sawSeen, rounds: w.rounds };
    if (!w.ok) o.blockers.push(w.sawSeen ? "X 上传百分比一直没消失（视频没传完）" : "X 上传没看到进度（视频没上传成功）");
    await snap("uploaded");
  }

  if (s.body) {
    const r = await L.typeInto(page, "div.public-DraftEditor-content", s.body, { delay: 12 });
    o.steps.typed = r;
    if (!r.ok) o.blockers.push(`没点进 X 的编辑器：${r.reason || ""}`);
    const got = String((await L.readText(page, "div.public-DraftEditor-content")) || "");
    o.steps.bodyReadback = norm(got).slice(0, 80);
    if (!norm(got).includes(head(s.body))) o.blockers.push("X 正文回读与 spec 不符");
    await snap("body");
  }

  const disabled = await L.evalRetry(page, () => {
    const b = document.querySelector('[data-testid="tweetButton"]');
    return b ? b.getAttribute("aria-disabled") : "missing";
  }, undefined, { label: "X Post 按钮状态" });
  o.steps.postDisabled = disabled;
  if (disabled === "true" || disabled === "missing") o.blockers.push(`X 的 Post 按钮不可点（aria-disabled=${disabled}）`);
  await snap("filled");
}

async function pubX({ page, s, o, snap }) {
  // 台账实测：打完话题/正文后必须先按 Esc 关掉联想下拉，否则点不到 Post
  await page.keyboard.press("Escape").catch(() => {});
  await sleep(1200);
  const clicked = await L.egoClick(page, '[data-testid="tweetButton"]', { label: "X 发帖" });
  o.steps.publishClicked = clicked.ok;
  if (!clicked.ok) o.steps.publishVia = (await L.clickSel(page, '[data-testid="tweetButton"]', { label: "X 发帖（坐标兜底）" })) ? "mouse" : null;
  else o.steps.publishVia = "ego click";
  if (!clicked.ok && !o.steps.publishVia) o.warnings.push(`没点到 Post 按钮：${clicked.error}`);
  await sleep(12000);
  o.steps.after = { url: await page.url() };
  await snap("published");
  await page.goto("https://x.com/home", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
  await sleep(8000);
  o.steps.homeText = (await L.textOf(page)).slice(0, 300);
  await snap("home_check");
  const first = head(String(s.body || "").split("\n")[0], 10);
  if (first && !norm(o.steps.homeText).includes(first)) o.warnings.push("主页时间线里没看到刚发的内容，请人工确认");
}

/* ─────────────── YouTube（只做「改文案 + 保存 + 回读」，不负责上传） ─────────────── */

async function waitYtTextBoxes(page, { tries = 30, every = 2500 } = {}) {
  return await L.waitFor(page, () => {
    const a = [...document.querySelectorAll("div#textbox")].filter((e) => e.getBoundingClientRect().width > 0);
    return a.length >= 2 ? a.length : null;
  }, undefined, { tries, every, label: "YouTube #textbox" });
}

async function fillYt({ page, s, o, snap }) {
  if (!s.url) {
    o.blockers.push("YouTube 需要 spec.url（编辑页 https://studio.youtube.com/video/<id>/edit）");
    return;
  }
  await page.goto(s.url, { waitUntil: "domcontentloaded", timeout: 60000 }).catch((e) => warn(`goto 编辑页失败：${String(e.message).split("\n")[0]}`));

  bag: {
    const n = await waitYtTextBoxes(page);
    if (!n) {
      o.blockers.push("找不到两个 div#textbox（Studio 没加载完或改版）");
      await snap("error");
      break bag;
    }
    o.steps.readbackBefore = await L.evalRetry(page, () =>
      [...document.querySelectorAll("div#textbox")].map((e) => (e.innerText || "").replace(/\s+/g, " ").slice(0, 60))
    );

    if (s.title) {
      const readTitle = async () => await L.evalRetry(page, () => (document.querySelectorAll("div#textbox")[0] || {}).innerText || "");
      // 三击 + Meta+A 双保险 + 回读；归档那次标题被拼成两段，就是全选没生效
      const r = await L.typeInto(page, "div#textbox >> nth=0", s.title, { clear: true, delay: 12, verifyFn: readTitle, tries: 3 });
      o.steps.title = r;
      if (!r.ok) o.blockers.push(`标题回读与 spec 不符：${(r.readback || "").slice(0, 50)}`);
      await snap("title");
    }

    if (s.body) {
      // 探针：先打两个字回读，确认真的点进说明框（Studio 偶尔「点不进去」）
      await L.egoClick(page, "div#textbox >> nth=1", { label: "点进说明框" });
      await sleep(400);
      await page.keyboard.type("测试", { delay: 80 });
      await sleep(900);
      const probe = await L.evalRetry(page, () => [...document.querySelectorAll("div#textbox")].map((e) => e.innerText));
      if (!probe || !String(probe[1] || "").includes("测试")) {
        o.blockers.push("说明框点不进去（Studio 偶发，重跑一次通常就好）");
      } else {
        await page.keyboard.press("Meta+A").catch(() => {});
        await sleep(300);
        await page.keyboard.press("Backspace").catch(() => {});
        await sleep(400);
        for (const ln of String(s.body).split("\n")) {
          await page.keyboard.type(ln, { delay: 8 });
          await page.keyboard.press("Enter");
        }
        await sleep(1500);
        const readDesc = async () => await L.evalRetry(page, () => (document.querySelectorAll("div#textbox")[1] || {}).innerText || "");
        o.steps.descReadback = await readDesc();
        if (!norm(o.steps.descReadback).includes(head(s.body, 10))) o.blockers.push("说明回读与 spec 不符");
        await snap("body");
      }
    }
  }
  await snap("filled");
}

async function pubYt({ page, o, snap }) {
  // 「保存」＝ YouTube 这条链路的第二段（它不发布新内容，只保存草稿改动）
  o.steps.saved = await L.clickText(page, "保存", { label: "YouTube 保存" });
  if (!o.steps.saved) o.warnings.push("没点到「保存」");
  await sleep(8000);
  await snap("saved");
  await page.reload({ waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});
  await waitYtTextBoxes(page, { tries: 12, every: 2500 });
  o.steps.readbackAfter = await L.evalRetry(page, () =>
    [...document.querySelectorAll("div#textbox")].map((e) => (e.innerText || "").replace(/\s+/g, " ").slice(0, 120))
  );
  await snap("after_reload");
}

/* ─────────────── 闸门彩排（rehearse） ─────────────── */

/**
 * ★ 为什么要有这个模式：
 * 验收要求「不许只写代码」，但真实跑一遍 fill 就必须先上传一条视频 —— 而验收又明确说不要真的上传。
 * 所以这里在一个 **本地 data: URL fixture** 上，用 lib.mjs 的真原语（真 uploadVideo / 真 typeInto 回读 /
 * 真 clickViaCDP 穿 closed shadow）走一遍完整的两段式流程，并当场断言：
 *   · publish=false        → 一次都不许点发布；
 *   · publish=true 有blocker 且没 force → 拒绝，一次都不许点；
 *   · publish=true 有blocker 且 force=true → 才允许点。
 * 三个场景的「点了没有」用 fixture 里的计数器断言，不靠嘴说。
 * 全程不碰任何真站点、不发任何内容。
 */
const REHEARSE_FIXTURE = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><title>fpb-rehearse</title>
<style>body{font-family:sans-serif;padding:32px}input,div.ed{display:block;margin:10px 0;padding:10px;font-size:16px;min-width:420px}
div.ed{border:1px solid #999;min-height:44px}</style></head><body>
<h1>两段式闸门彩排台</h1>
<input type="file" accept="video/mp4">
<input class="t" placeholder="标题">
<div class="ed" contenteditable="true">旧内容</div>
<xhs-publish-btn id="h"></xhs-publish-btn>
<script>
  window.__log = { published: 0, files: 0, title: "", body: "" };
  document.querySelector('input[type=file]').addEventListener("change", function (e) { window.__log.files = e.target.files.length; });
  var sr = document.getElementById("h").attachShadow({ mode: "closed" });
  sr.innerHTML = '<button id="p">发布</button>';
  sr.querySelector("#p").addEventListener("click", function () {
    window.__log.published += 1;
    window.__log.title = document.querySelector("input.t").value;
    window.__log.body = document.querySelector("div.ed").innerText.replace(/\\s+/g, " ").trim();
  });
</script>
</body></html>`;

async function rehearse(cmd) {
  const sample = cmd.sample || `${L.PUB_PROJECT}/output/sample.mp4`; // 分发版：不写死样例片，必须由命令 JSON 的 sample 指定
  const results = [];
  const check = (name, ok, detail) => {
    results.push({ name, ok: !!ok, detail });
    line(`${ok ? "✅" : "❌"} ${name}：${detail}`);
  };

  const task = await L.resumeSpace();
  let page = null;
  let scratch = false;
  try {
    page = await task.newPage();
    scratch = true;
  } catch {
    page = task.page("p1");
  }
  line(`彩排页：${page.label}${scratch ? "（临时页，跑完关掉）" : ""}`);

  try {
    await page.goto("data:text/html;charset=utf-8," + encodeURIComponent(REHEARSE_FIXTURE), { waitUntil: "domcontentloaded", timeout: 30000 });
    await sleep(600);

    // ── 用真原语走过第一段 ──
    const up = await L.uploadVideo(page, sample);
    const log1 = await page.evaluate(() => window.__log);
    check("uploadVideo 路线生效（page.setInputFiles）", up.ok && log1.files === 1, `via=${up.via}，fixture 收到 ${log1.files} 个文件`);

    const cdpUp = await L.setFilesViaCDP(page, sample, { accept: "video" });
    const log2 = await page.evaluate(() => window.__log);
    check("setFilesViaCDP 兜底路线可用（穿 shadow/iframe DOM）", cdpUp.ok && log2.files === 1, `${cdpUp.ok ? cdpUp.via : cdpUp.error}`);

    const typed = await L.typeInto(page, "input.t", "闸门彩排标题", { clear: true, verify: "input.t", tries: 3 });
    check("typeInto 三击+Meta+A+回读校验", typed.ok, typed.ok ? `回读「${typed.readback}」` : typed.reason);

    await L.egoClick(page, "div.ed", { label: "点进彩排正文" });
    await sleep(300);
    await page.keyboard.type("正文和 spec 对不上", { delay: 10 });
    const bodyRead = String((await L.readText(page, "div.ed")) || "");
    const head_ = "完全不存在的正文开头";
    const realBlocker = `正文回读与 spec 不符（读到「${bodyRead.slice(0, 20)}」）`;
    check("正文回读与 spec 不符能被判出来（造一条真 blocker）", !L.norm(bodyRead).includes(head_), realBlocker);

    const blockers = [realBlocker];
    const logBefore = await page.evaluate(() => window.__log);

    // ── 场景 1：默认只填不发 ──
    const g1 = L.publishGate({ blockers, publish: false, force: false });
    if (g1.allowed) await L.clickViaCDP(page, "发布");
    const logAfter1 = await page.evaluate(() => window.__log);
    check("场景1 默认（publish=false）：闸门不许发 + 真的一次没点", !g1.allowed && logAfter1.published === logBefore.published, `${g1.reason}｜published ${logBefore.published}→${logAfter1.published}`);

    // ── 场景 2：要发但有 blocker、没 force ──
    const g2 = L.publishGate({ blockers, publish: true, force: false });
    if (g2.allowed) await L.clickViaCDP(page, "发布");
    const logAfter2 = await page.evaluate(() => window.__log);
    check("场景2 publish=true 有 blocker 无 force：拒绝且真的一次没点", !g2.allowed && logAfter2.published === logBefore.published, `${g2.reason}｜published 仍是 ${logAfter2.published}`);

    // ── 场景 3：publish=true + force=true 才硬发 ──
    const g3 = L.publishGate({ blockers, publish: true, force: true });
    check("场景3 publish=true + force=true：闸门放行", g3.allowed && g3.forced, g3.reason);
    if (g3.allowed) {
      const hit = await L.clickViaCDP(page, "发布", { label: "彩排：点发布（closed shadow）" });
      await sleep(400);
      const logAfter3 = await page.evaluate(() => window.__log);
      check("场景3 放行后真的点中了（CDP 穿 closed shadow）", logAfter3.published === logBefore.published + 1, `published ${logAfter2.published}→${logAfter3.published}，坐标 ${JSON.stringify(hit && hit.box)}，回读标题「${logAfter3.title}」`);
    }

    await shot(page, "rehearse_gate");

    line("");
    line("──── 闸门彩排汇总 ────");
    for (const r of results) line(`${r.ok ? "✅" : "❌"} ${r.name}`);
    const ok = results.every((r) => r.ok);
    line(`结论：${ok ? "✅ 两段式发布闸门的顺序与行为都对（默认绝不发；有 blocker 拒绝；force 才硬发）" : "❌ 有断言没过"}`);
    return ok;
  } finally {
    if (scratch) await page.close().catch(() => {});
  }
}

/* ─────────────── 调度表 ─────────────── */

const FILL = { xhs: fillXhs, sph: fillSph, dy: fillDy, x: fillX, yt: fillYt };
const PUB = { xhs: pubXhs, sph: pubSph, dy: pubDy, x: pubX, yt: pubYt };

/* ─────────────── 主流程 ─────────────── */

function printHelp(reason) {
  if (reason) line(`⛔ ${reason}`);
  line("");
  line("fill.mjs 用法（ego 脚本拿不到 argv / 环境变量，参数只能从这个 JSON 读）：");
  line(`  命令 JSON：${L.CMD_FILE}`);
  line(`  {`);
  line(`    "platform": "xhs",              // xhs | sph | dy | x | yt`);
  line(`    "spec": "spec/xhs.json",        // 绝对路径，或相对 ${L.PUB_PROJECT}`);
  line(`    "publish": false,               // ★ 默认 false = 只填不发`);
  line(`    "force": false,                 // ★ 有 blocker 时也要硬发才写 true`);
  line(`    "preflightOnly": false,         // true = 只跑前置检查，碰都不碰页面`);
  line(`    "selftest": false               // true = 跑 closed shadow 自检，不需要 platform`);
  line(`  }`);
  line("");
  line("跑法：");
  line(`  ego-browser nodejs -e 'await import("file://${L.EGO_DIR}/fill.mjs")'`);
  line("");
}

async function main() {
  const cmd = L.loadCommand();
  if (!cmd) {
    printHelp(`没有命令 JSON：${L.CMD_FILE}`);
    process.exit(EXIT.ERROR);
  }
  line(`命令 JSON：${L.CMD_FILE}`);
  line(JSON.stringify(cmd, null, 2));

  /* ── 自检模式：验证 CDP 穿透 closed shadow root（不碰任何真站点） ── */
  if (cmd.selftest) {
    const task = await L.resumeSpace();
    let page = null;
    let scratch = false;
    try {
      page = await task.newPage();
      scratch = true;
    } catch {
      page = task.page("p1");
    }
    log(`自检页：${page.label}${scratch ? "（临时页，跑完关掉）" : "（复用 p1）"}`);
    const r = await L.runShadowSelfTest(page);
    line("");
    line("──── closed shadow 自检 ────");
    for (const s of r.steps) line(`${s.ok ? "✅" : "❌"} ${s.name}：${s.detail}`);
    line(`轻 DOM 视角：${JSON.stringify(r.lightDom)}`);
    line(`按住命中的节点：${JSON.stringify(r.click)}`);
    line(`点击后页面状态：${JSON.stringify(r.afterClick)}`);
    line(`结论：${r.ok ? "✅ CDP 能穿透 closed shadow root 并按坐标点中" : "❌ 有步骤没过"}`);
    if (scratch) await page.close().catch(() => {});
    process.exit(r.ok ? EXIT.OK : EXIT.ERROR);
  }

  /* ── 闸门彩排模式：在本地 fixture 上真跑一遍两段式，不碰真站点 ── */
  if (cmd.rehearse) {
    line("");
    line("──── 两段式闸门彩排（本地 fixture，不碰任何真站点） ────");
    const ok = await rehearse(cmd);
    process.exit(ok ? EXIT.OK : EXIT.ERROR);
  }

  const platform = cmd.platform;
  if (!platform || !L.PLATFORMS[platform]) {
    printHelp(`platform 不合法：${platform}（可选 ${L.PLATFORM_KEYS.join(" / ")}）`);
    process.exit(EXIT.ERROR);
  }
  const meta = L.PLATFORMS[platform];

  /* ── 第 0 段 A：不碰浏览器也能查的（spec / 文件 / 编码） ── */
  let spec = null;
  let specFile = null;
  if (cmd.spec) {
    try {
      const r = L.loadSpec(cmd.spec);
      spec = r.spec;
      specFile = r.file;
      line(`spec：${specFile}`);
      line(JSON.stringify(spec, null, 2));
    } catch (e) {
      line("");
      line(`⛔ ${String(e.message).split("\n")[0]}`);
      line("⛔ 找不到 spec 文件：发布参数不全，直接停下（退出码 3），没有碰浏览器。");
      process.exit(EXIT.PREFLIGHT);
    }
  } else if (platform !== "yt") {
    printHelp("命令 JSON 里没有 spec 字段");
    process.exit(EXIT.ERROR);
  }

  const videoPath = spec && spec.video ? spec.video : null;
  const coverPath = spec && spec.cover ? spec.cover : null;
  const early = L.preflight({ platform, spec, specFile, videoPath, coverPath, pageOpen: null });
  L.printPreflight(early);
  if (early.hardBlockers.length) {
    line("⛔ 前置检查没过（缺 spec / 缺文件这级别的问题无解，force 也不能硬闯）：");
    for (const b of early.hardBlockers) line(`  - ${b}`);
    process.exit(EXIT.PREFLIGHT);
  }
  if (cmd.preflightOnly) {
    line(`只跑前置检查（preflightOnly=true）：${early.gateBlockers.length ? "有 ❌ 项，退出码 3" : "全过，退出码 0"}`);
    process.exit(early.gateBlockers.length ? EXIT.PREFLIGHT : EXIT.OK);
  }

  /* ── 第 0 段 B：目标页是否打开 ── */
  const task = await L.resumeSpace();
  const tabs = await L.listTabs(task);
  const open = tabs.find((t) => t.url.includes(meta.tabPart));
  line(`目标页：${open ? `已打开（${open.label || "未纳管"} ${open.url.slice(0, 80)}）` : "未打开（下面会导航/新建一个页面）"}`);
  line(`空间里现有标签：${tabs.map((t) => `${t.label || "未纳管"}=${String(t.url).slice(0, 50)}`).join(" ｜ ")}`);

  const pf = L.preflight({ platform, spec, specFile, videoPath, coverPath, pageOpen: !!open });
  L.printPreflight(pf);

  const o = out(platform);
  o.specFile = specFile;
  o.preflight = pf.checks;
  // 前置检查里「编码/分辨率不对」这类进闸门 blocker（force 可硬闯）
  o.blockers.push(...pf.gateBlockers);
  o.warnings.push(...pf.warnings);
  if (pf.gateBlockers.length) warn(`前置检查有 ${pf.gateBlockers.length} 条 gate blocker（默认拦住，force 可硬闯）`);

  const { page } = await L.openPlatformPage(task, platform, { navigate: platform === "yt" && spec && spec.url ? false : true });
  const snap = shotter(page, platform);
  await snap("page");

  log(`平台 ${platform}（${meta.name}）${cmd.publish ? "：填完判门，通过才发" : "：只填不发（默认）"}`);

  /* ── 第 1 段：只填，绝不点发布 ── */
  try {
    await FILL[platform]({ page, s: spec, o, snap });
  } catch (e) {
    o.blockers.push(`填表阶段异常：${String(e.message).split("\n")[0]}`);
    await snap("error");
  }

  /* ── 闸门：这里才决定要不要点发布 ── */
  const gate = L.publishGate({ blockers: o.blockers, publish: !!cmd.publish, force: !!cmd.force });
  o.gate = gate;

  if (gate.allowed) {
    log(`闸门通过（${gate.reason}），开始第二段：发布`);
    try {
      await PUB[platform]({ page, s: spec, o, snap });
      o.published = true;
    } catch (e) {
      o.blockers.push(`发布阶段异常：${String(e.message).split("\n")[0]}`);
      await snap("publish_error");
    }
  } else if (cmd.publish) {
    o.refusedPublish = true;
    log(`⛔ 闸门拦住：${gate.reason}`);
  }

  L.printResult(o);

  // ⚠️ 硬闯发布过之后**绝不能再退非零**：上层看到非零会重跑，一重跑就是重复发布。
  if (o.published && gate.forced) {
    line("");
    line(`⚠️ 这次是 force 硬闯发布的（上面 ${o.blockers.length} 条 blocker 被强制越过）。退出码 0 —— **不要再重跑这条命令**，否则会重复发布。`);
    process.exit(EXIT.OK);
  }
  if (o.blockers.length) {
    line("");
    line(`⛔ blocker 未过（${o.blockers.length} 条）→ 退出码 2`);
    line(o.refusedPublish ? "⛔ 有 blocker，**发布没有执行**（页面停在填好的状态）。修好后重跑，或确认无害后把 force 改成 true。" : "⛔ 只填阶段就有 blocker 未过，请先看上面的清单和截图。");
    process.exit(EXIT.GATE);
  }
  if (o.published) {
    line("已点发布：**去后台逐项核对**（标题/话题/封面/可见性/声明/位置）——「点了发布按钮」不算发布成功。");
  } else if (cmd.publish) {
    line("命令里 publish=true 但闸门没放行（见上）。");
  } else {
    line(`只填了没发。截图在 ${L.SHOTS_DIR}/，确认后把命令 JSON 的 publish 改成 true 再跑。`);
  }
  process.exit(EXIT.OK);
}

main().catch((e) => {
  line("");
  line(`⛔ 失败：${String(e && e.message ? e.message : e).split("\n")[0]}`);
  process.exit(EXIT.ERROR);
});
