/**
 * five-platform-publish / scripts/ego/lib.mjs
 * ─────────────────────────────────────────────────────────────
 * ego lite 浏览器原生版「原语层」。**新增**，不改动旧版 scripts/lib.js。
 *
 * 与旧版 lib.js 的关系：
 *   · 旧版 = playwright-core 通过 CDP 连一个复制了用户 Chrome 配置的调试 Chrome（9222）。
 *   · 本版 = 直接驱动用户真实日常浏览器 ego lite（同一套登录态），
 *     只用 ego 明确提供的 API：TaskSpace / Page / mouse / keyboard / fileChooser / evaluate / cdp。
 *   · 语义一一对应，但连接方式、frame 处理、点击通道全部重写。
 *
 * 实测得到的 5 条硬事实（决定了这个文件的写法，别再"优化"回去）：
 *   1) 脚本进程**不继承 shell 环境变量**，`process.argv` 也只有 1 项（node helper 自己的路径）。
 *      → 所有输入只能从「绝对路径的命令 JSON」读，见 CMD_FILE / loadCommand()。
 *   2) 脚本 cwd 是 `/` → 一切文件路径必须写绝对路径。
 *   3) console.log/console.error 全部落到 **stderr**（stdout 是空的）。
 *   4) 用 `<` 或 heredoc 喂脚本时相对 import 会失败（base 是 `//[eval2]`）；
 *      用 `-e 'await import("file:///绝对路径.mjs")'` 才有真实文件 base。入口脚本已做兼容。
 *   5) `DOM.getFlattenedDocument` / `DOM.getBoxModel` 之前**必须先 `DOM.enable`**，
 *      否则报 `DOM agent hasn't been enabled`。`DOM.getDocument` 恰好会顺带 enable，
 *      所以在旧脚本里看不出来 —— 这个坑实测踩到了。
 *
 * 只做三件事：读、填、点。**绝不**代登录、扫码、发表（除非 fill.mjs 的两段式闸门放行）。
 */

import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

/* ─────────────── 常量 ─────────────── */

// 分发版：路径全部从文件自身位置推导，可用环境变量覆盖（EGO_DIR / SKILL_DIR / PUB_PROJECT）。
// 脚本进程不继承 shell 环境（见下方硬事实 1），因此 fill.mjs 等入口会优先读命令 JSON 里的 project。
const EGO_DIR_SELF = path.dirname(fileURLToPath(import.meta.url));
export const EGO_DIR = process.env.EGO_DIR || EGO_DIR_SELF;
export const SKILL_DIR = process.env.SKILL_DIR || path.resolve(EGO_DIR_SELF, "../..");
export const PUB_PROJECT = process.env.PUB_PROJECT || path.join(os.homedir(), "soul-singer", "projects");
export const SHOTS_DIR = path.join(PUB_PROJECT, ".publish-tools", "ego");
export const CMD_FILE = path.join(PUB_PROJECT, ".publish-tools", "ego-cmd.json");

/** 复用同一个 taskSpace，绝不新建（用户的目标是持续的，空间留着下次用）。 */
export const TASK_SPACE = "五平台发布";
export const TASK_SPACE_ID = 3;

/** 本机没有 ffprobe，只有 ffmpeg（用 `ffmpeg -i` 读流信息）。 */
export const FFMPEG_CANDIDATES = [
  path.join(os.homedir(), "bin", "ffmpeg"),
  path.join(os.homedir(), "local", "bin", "ffmpeg"),
  "/opt/homebrew/bin/ffmpeg",
  "/usr/local/bin/ffmpeg",
  "/usr/bin/ffmpeg",
];

/** 五平台元数据。url = 后台入口，tabPart = 用来认领已有标签页的 URL 片段。 */
export const PLATFORMS = {
  xhs: {
    key: "xhs",
    name: "小红书",
    url: "https://creator.xiaohongshu.com/publish/publish",
    tabPart: "creator.xiaohongshu.com",
    loginPart: "/login",
    backend: /发布笔记|上传视频|创作服务|笔记管理|创作服务平台/,
    account: null,
  },
  sph: {
    key: "sph",
    name: "视频号",
    url: "https://channels.weixin.qq.com/platform/post/create",
    tabPart: "channels.weixin.qq.com",
    loginPart: "login.html",
    backend: /发表动态|视频号|创作者|动态管理|发表|内容管理/,
    account: null,
  },
  dy: {
    key: "dy",
    name: "抖音",
    url: "https://creator.douyin.com/creator-micro/content/upload",
    tabPart: "creator.douyin.com",
    loginPart: "/login",
    backend: /发布视频|作品管理|创作者中心|上传视频|内容管理|作品描述/,
    account: null,
  },
  x: {
    key: "x",
    name: "X",
    url: "https://x.com/compose/post",
    tabPart: "x.com",
    loginPart: "/i/flow/login",
    backend: /发帖|Post|主页|Home|为你推荐|For you/,
    account: null,
  },
  yt: {
    key: "yt",
    name: "YouTube",
    url: "https://studio.youtube.com",
    tabPart: "studio.youtube.com",
    loginPart: "accounts.google.com",
    backend: /频道|Studio|Dashboard|内容|视频|Content|Channel/,
    account: null,
  },
};

export const PLATFORM_KEYS = Object.keys(PLATFORMS);

/** 登录墙特征（全文匹配）。 */
export const LOGIN_HINTS =
  /(扫码登录|请登录|登录后|立即登录|手机号登录|密码登录|使用其他账号|登录\/注册|Log in|Sign in|Sign in to|Continue with|Sign in with)/;

/** 每个平台的必填 spec 字段（前置检查用）。 */
export const REQUIRED_FIELDS = {
  xhs: ["video", "title", "body"],
  sph: ["video", "shortTitle", "body"],
  dy: ["video", "title", "body"],
  x: ["video", "body"],
  yt: ["url"], // YouTube 只做「改文案 + 保存 + 回读」，不负责上传
};

/** 每个平台的「建议有」字段（缺了只提示，不算 blocker）。 */
export const RECOMMENDED_FIELDS = {
  xhs: ["cover", "tags"],
  sph: ["cover", "tags"],
  dy: ["tags"],
  x: ["tags"],
  yt: ["title", "body"],
};

/* ─────────────── 基础工具 ─────────────── */

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const now = () => new Date().toISOString().slice(11, 19);
export const log = (...a) => console.error(`[${now()}]`, ...a);
export const warn = (...a) => console.error(`[${now()}] ⚠️`, ...a);
export const norm = (s) => String(s ?? "").replace(/\s+/g, "");
export const head = (s, n = 8) => norm(s).slice(0, n);
export const line = (s = "") => console.error(s);

/* ─────────────── 命令 JSON（唯一的输入通道） ─────────────── */

/**
 * 读命令 JSON。实测 argv / env 都传不进来，所以这是唯一可靠的入参通道。
 * 文件不存在时返回 null，由各脚本给默认行为。
 */
export function loadCommand(file = CMD_FILE) {
  if (!fs.existsSync(file)) return null;
  const raw = fs.readFileSync(file, "utf8");
  try {
    return JSON.parse(raw);
  } catch (e) {
    throw new Error(`命令 JSON 解析失败：${file}\n${e.message}`);
  }
}

/** 写一份命令 JSON（给用户/上层 agent 改参数用，也方便回读当时到底发了什么命令）。 */
export function writeCommand(cmd) {
  fs.mkdirSync(path.dirname(CMD_FILE), { recursive: true });
  fs.writeFileSync(CMD_FILE, JSON.stringify(cmd, null, 2), "utf8");
  return CMD_FILE;
}

/* ─────────────── 恢复 taskSpace 与取页 ─────────────── */

/** 恢复「五平台发布」空间（实测 spaceId=3，ownership=agent）。**不新建、不 finish**。 */
export async function resumeSpace() {
  const task = await taskSpace(TASK_SPACE);
  log(`taskSpace 恢复：${task.name} (id=${task.spaceId}, ownership=${task.ownership})`);
  return task;
}

/** 当前空间里所有标签页（含未纳管）。 */
export async function listTabs(task) {
  return (await task.tabs()).map((t) => ({
    label: t.label || null,
    url: t.url || "",
    title: t.title || "",
    active: !!t.active,
    openedBy: t.openedBy || null,
    page: t.page,
  }));
}

/**
 * 认领/取得某平台的标签页。
 *   1) 空间里已有该平台标签 → 用它（未纳管的先 adopt，绝不关用户的标签）；
 *   2) 否则用 p1（ego 的规矩：新空间从 p1 开始，导航它而不是到处开新页）；
 *   3) p1 也没有才 newPage。
 * `navigate=true` 时确保落在 meta.url 上（已在同平台其它页面则不强行导航）。
 */
export async function openPlatformPage(task, key, { navigate = true, force = false, waitMs = 6000 } = {}) {
  const meta = PLATFORMS[key];
  if (!meta) throw new Error(`未知平台：${key}（可选 ${PLATFORM_KEYS.join(" / ")}）`);

  const tabs = await task.tabs();
  const hit = tabs.find((t) => (t.url || "").includes(meta.tabPart));
  let page = null;
  let how = "";
  if (hit) {
    if (hit.label) {
      page = task.page(hit.label);
      how = `复用已有标签 ${hit.label}`;
    } else {
      page = await task.adopt(hit.page);
      how = `纳管了未纳管标签 → ${page.label}`;
    }
  } else {
    const pages = await task.pages();
    if (pages.length) {
      page = pages[0];
      how = `用 ${page.label} 导航`;
    } else {
      page = await task.newPage();
      how = `新建 ${page.label}`;
    }
  }

  const before = await page.url().catch(() => "");
  const needNav = force || (navigate && !String(before).includes(meta.tabPart));
  if (needNav) {
    await page.goto(meta.url, { waitUntil: "domcontentloaded", timeout: 60000 }).catch((e) => warn(`goto 失败：${String(e.message).split("\n")[0]}`));
    await sleep(waitMs);
  }
  const url = await page.url().catch(() => "");
  log(`${meta.name}：${how}；页面 ${page.label} → ${url.slice(0, 110)}`);
  return { page, url, how };
}

/* ─────────────── 截图（每步一张，绝对路径） ─────────────── */

/** 每步一个序号，文件名稳定：<平台>_<两位序号>_<步骤>.png */
export function shotter(page, platform) {
  let seq = 0;
  return async (step, opts = {}) => shot(page, `${platform}_${String(++seq).padStart(2, "0")}_${step}`, opts);
}

/**
 * 存 PNG 到 ~/Desktop/音乐创作/.publish-tools/ego/<name>.png。
 * 文件名约定：<平台>_<两步序号>_<步骤>（例：xhs_04_body.png）。
 */
export async function shot(page, name, { fullPage = false } = {}) {
  try {
    fs.mkdirSync(SHOTS_DIR, { recursive: true });
    const file = path.join(SHOTS_DIR, `${name}.png`);
    await page.screenshot({ path: file, fullPage });
    log(`截图 ${file}`);
    return file;
  } catch (e) {
    warn(`截图失败 ${name}：${String(e.message).split("\n")[0]}`);
    return null;
  }
}

/* ─────────────── 读取 / 等待（全部包 retry） ─────────────── */

/** 页面正文（压缩空白）。渲染/导航中 evaluate 会抛，重试。 */
export async function textOf(page, { tries = 4, every = 800 } = {}) {
  for (let i = 0; i < tries; i++) {
    try {
      return await page.evaluate(() => document.body.innerText.replace(/\s+/g, " "));
    } catch {
      await sleep(every);
    }
  }
  return "";
}

/** evaluate 包 retry：标签在渲染/导航时会抛 `Execution context was destroyed`，不是页面坏了。 */
export async function evalRetry(page, fn, arg, { tries = 8, every = 1200, label = "" } = {}) {
  let lastErr = null;
  for (let i = 0; i < tries; i++) {
    try {
      return arg === undefined ? await page.evaluate(fn) : await page.evaluate(fn, arg);
    } catch (e) {
      lastErr = e;
    }
    await sleep(every);
  }
  if (lastErr) warn(`evalRetry 失败${label ? `（${label}）` : ""}：${String(lastErr.message).split("\n")[0]}`);
  return null;
}

/** 反复取值直到真值（null/'' 不算成功）。 */
export async function waitFor(page, fn, arg, { tries = 10, every = 1500, label = "" } = {}) {
  for (let i = 0; i < tries; i++) {
    try {
      const v = arg === undefined ? await page.evaluate(fn) : await page.evaluate(fn, arg);
      if (v) return v;
    } catch {
      /* 页面忙，继续等 */
    }
    await sleep(every);
  }
  warn(`waitFor 超时${label ? `（${label}）` : ""}`);
  return null;
}

export async function waitForText(page, re, { tries = 25, every = 4000, label = "" } = {}) {
  for (let i = 0; i < tries; i++) {
    const t = await textOf(page);
    if (re.test(t)) return { ok: true, text: t, rounds: i + 1 };
    await sleep(every);
  }
  const t = await textOf(page);
  warn(`waitForText 超时${label ? `（${label}）` : ""}：${t.slice(0, 160)}`);
  return { ok: false, text: t, rounds: tries };
}

/**
 * 上传完成门（**不固定 sleep**）：
 *   · done 命中 且 busy 不命中 才算完成（只看「发布」这种一直存在的词会恒真 —— 抖音踩过）；
 *   · requireSeen 用于「先看到进度、再看到它消失」（X 的百分比）。
 */
export async function waitForUploadDone(page, { done, busy, requireSeen = null, tries = 30, every = 4000, label = "", onTick = null } = {}) {
  let sawSeen = !requireSeen;
  for (let i = 0; i < tries; i++) {
    const t = await textOf(page);
    if (requireSeen && requireSeen.test(t)) sawSeen = true;
    if (onTick) await onTick(t, i).catch(() => {});
    if (done.test(t) && !busy.test(t) && sawSeen) return { ok: true, text: t, rounds: i + 1, sawSeen };
    await sleep(every);
  }
  const t = await textOf(page);
  warn(`waitForUploadDone 超时${label ? `（${label}）` : ""}：${t.slice(0, 160)}`);
  return { ok: false, text: t, rounds: tries, sawSeen };
}

/** 读输入框/可编辑元素的当前值（回读校验用）。 */
export async function readText(page, selector) {
  try {
    return await page.evaluate((sel) => {
      const e = document.querySelector(sel);
      if (!e) return null;
      if (e.value !== undefined && e.value !== null && e.value !== "") return e.value;
      return e.innerText || "";
    }, selector);
  } catch {
    return null;
  }
}

/* ─────────────── 定位 ─────────────── */

/** 选择器 → 可见元素中心坐标。**穿不透 shadow DOM**（小红书发布按钮请用 cdpFind/clickViaCDP）。 */
export async function rectOf(page, selector, { nth = 0 } = {}) {
  try {
    return await page.evaluate(
      ({ sel, nth }) => {
        const els = [...document.querySelectorAll(sel)].filter((e) => {
          const r = e.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        });
        const e = els[nth];
        if (!e) return null;
        const r = e.getBoundingClientRect();
        return [Math.round(r.x + r.width / 2), Math.round(r.y + r.height / 2)];
      },
      { sel: selector, nth }
    );
  } catch {
    return null;
  }
}

/** 「文字按钮」定位：innerText 精确等于（或包含）text 的**叶子节点**中心。**穿不透 shadow DOM**。 */
export async function rectIn(page, text, { exact = true, nth = 0 } = {}) {
  try {
    return await page.evaluate(
      ({ t, exact, nth }) => {
        const hits = [];
        document.querySelectorAll("*").forEach((e) => {
          if (e.children.length) return;
          const s = (e.innerText || "").trim();
          if (!s) return;
          if (exact ? s !== t : !s.includes(t)) return;
          const r = e.getBoundingClientRect();
          if (r.width > 0 && r.height > 0) hits.push([Math.round(r.x + r.width / 2), Math.round(r.y + r.height / 2)]);
        });
        return hits[nth] || null;
      },
      { t: text, exact, nth }
    );
  } catch {
    return null;
  }
}

/** 把元素滚进视口中央 —— 按钮在视口外时坐标点击会打空。同样穿不透 shadow DOM。 */
export async function scrollInto(page, text, exact = true) {
  try {
    return await page.evaluate(
      ({ t, exact }) => {
        const el = [...document.querySelectorAll("*")].find((e) => {
          if (e.children.length) return false;
          const s = (e.innerText || "").trim();
          return exact ? s === t : s.includes(t);
        });
        if (!el) return false;
        el.scrollIntoView({ block: "center" });
        return true;
      },
      { t: text, exact }
    );
  } catch {
    return false;
  }
}

/* ─────────────── 点击 ─────────────── */

export async function clickText(page, text, { exact = true, dy = 0, nth = 0, clickCount = 1, scroll = true, label = null } = {}) {
  if (scroll) await scrollInto(page, text, exact).catch(() => {});
  const r = await rectIn(page, text, { exact, nth });
  if (!r) return false;
  await page.mouse.click(r[0], r[1] + dy, { clickCount, ...(label ? { label } : {}) });
  return true;
}

export async function clickSel(page, selector, { nth = 0, clickCount = 1, label = null } = {}) {
  const r = await rectOf(page, selector, { nth });
  if (!r) return false;
  await page.mouse.click(r[0], r[1], { clickCount, ...(label ? { label } : {}) });
  return true;
}

/** 直接触发 element.click()：被 toast/遮罩挡住时坐标点击会打空（抖音当天就是这么过的）。 */
export async function jsClick(page, text, { tag = "button,div,span,a" } = {}) {
  try {
    return await page.evaluate(
      ({ t, tags }) => {
        const el = [...document.querySelectorAll(tags)].find((e) => {
          if (e.children.length) return false;
          if ((e.innerText || "").trim() !== t) return false;
          const r = e.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        });
        if (!el) return false;
        el.click();
        return true;
      },
      { t: text, tags: tag }
    );
  } catch {
    return false;
  }
}

/** 用 ego 自己的元素点击（会自动在顶层文档找不到时回退到 frame 里找）。 */
export async function egoClick(page, selector, opts = {}) {
  try {
    const r = await page.click(selector, { timeout: opts.timeout ?? 6000, ...(opts.label ? { label: opts.label } : {}), ...(opts.clickCount ? { clickCount: opts.clickCount } : {}) });
    return { ok: true, receipt: r };
  } catch (e) {
    return { ok: false, error: String(e.message).split("\n")[0] };
  }
}

export const DEFAULT_CDP_NODE_NAMES = ["BUTTON", "A", "DIV", "SPAN", "LABEL", "INPUT", "YTPC-BUTTON", "TP-YT-PAPER-BUTTON"];

export function attrsOf(node) {
  const a = {};
  const arr = (node && node.attributes) || [];
  for (let i = 0; i < arr.length; i += 2) a[arr[i]] = arr[i + 1];
  return a;
}

/**
 * ★ CDP 穿透查找：能看进 **shadow DOM（含 closed shadow root）**。
 *
 * 为什么必须这样：小红书的发布按钮挂在 `<xhs-publish-btn>` 的 closed shadow root 里，
 * `document.querySelectorAll` / `innerText` / `host.shadowRoot` 全都拿不到。
 * CDP 的 DOM 域能穿过去（`pierce: true`）。
 *
 * 实现要点（都实测过）：
 *   · 先 `DOM.enable`，否则 getFlattenedDocument 报 `DOM agent hasn't been enabled`；
 *   · 用 `DOM.getFlattenedDocument{depth:-1, pierce:true}` 拿**扁平**节点表（带 parentId），
 *     比 `DOM.getDocument` 递归更省事、也不会被 `childNodes`/`children` 字段差异坑到；
 *   · 从命中的 `#text` 节点沿 parentId 往上找最近的可点元素；
 *   · `DOM.getBoxModel` 取内容四边形中心 → `page.mouse.click(x, y)`；
 *   · **nodeId 不能跨 round 用** —— 每次调用都重新拉一次扁平表，返回的 nodeId 只在本次有效。
 *
 * ⚠️ 不跨 iframe：CDP 给的是节点在**它自己 frame 里**的坐标，直接拿去 page.mouse.click 会点错地方。
 *     视频号（整张表单在 iframe 里）请用 egoClick()/clickText()。
 */
export async function cdpFind(page, text, { nodeNames = DEFAULT_CDP_NODE_NAMES, className = null, exact = true, nth = 0, limit = 40 } = {}) {
  await page.cdp("DOM.enable").catch(() => {});
  const flat = await page.cdp("DOM.getFlattenedDocument", { depth: -1, pierce: true });
  const nodes = (flat && flat.nodes) || [];
  const byId = new Map(nodes.map((n) => [n.nodeId, n]));
  const kids = new Map();
  for (const n of nodes) {
    if (n.parentId === undefined || n.parentId === null) continue;
    if (!kids.has(n.parentId)) kids.set(n.parentId, []);
    kids.get(n.parentId).push(n);
  }
  const textOfNode = (id, depth = 0) => {
    if (depth > 8) return "";
    const n = byId.get(id);
    if (!n) return "";
    if (n.nodeName === "#text") return n.nodeValue || "";
    let s = "";
    for (const c of kids.get(id) || []) s += textOfNode(c.nodeId, depth + 1);
    return s;
  };

  const want = norm(text);
  const seen = new Set();
  const hits = [];
  for (const n of nodes) {
    if (n.nodeName !== "#text") continue;
    const t = norm(n.nodeValue);
    if (!t) continue;
    const okText = want ? (exact ? t === want : t.includes(want)) : true;
    if (!okText) continue;
    let id = n.parentId;
    for (let up = 0; up < 8 && id !== undefined && id !== null; up++) {
      const el = byId.get(id);
      if (!el) break;
      if (nodeNames.includes(el.nodeName)) {
        const subtree = norm(textOfNode(el.nodeId));
        const okSub = want ? (exact ? subtree === want : subtree.includes(want)) : true;
        const a = attrsOf(el);
        const okClass = className ? String(a.class || "").includes(className) : true;
        if (okSub && okClass && !seen.has(el.nodeId)) {
          seen.add(el.nodeId);
          hits.push({ nodeId: el.nodeId, nodeName: el.nodeName, up, attrs: a, text: subtree, backendNodeId: el.backendNodeId });
        }
        break;
      }
      id = el.parentId;
    }
    if (hits.length >= limit) break;
  }
  hits.sort((a, b) => a.up - b.up);
  return { hits, total: nodes.length };
}

/** 只读：CDP 视角下页面的节点统计 + shadow host 线索（诊断用，不点任何东西）。 */
export async function cdpInspect(page, { text = null } = {}) {
  await page.cdp("DOM.enable").catch(() => {});
  const flat = await page.cdp("DOM.getFlattenedDocument", { depth: -1, pierce: true });
  const nodes = (flat && flat.nodes) || [];
  const counts = {};
  for (const n of nodes) counts[n.nodeName] = (counts[n.nodeName] || 0) + 1;
  const textNodes = text ? nodes.filter((n) => n.nodeName === "#text" && norm(n.nodeValue) === norm(text)) : [];
  return { total: nodes.length, counts, textMatches: textNodes.length };
}

/**
 * ★ 点进 shadow DOM（含 closed）：
 * CDP 找节点 → getBoxModel 取坐标 → page.mouse.click。
 * 返回 { box, nodeId, via } 或 null。
 */
export async function clickViaCDP(page, text, { nodeNames = DEFAULT_CDP_NODE_NAMES, className = null, exact = true, nth = 0, click = true, label = null } = {}) {
  let found;
  try {
    found = await cdpFind(page, text, { nodeNames, className, exact, nth, limit: 40 });
  } catch (e) {
    warn(`clickViaCDP 查找失败：${String(e.message).split("\n")[0]}`);
    return null;
  }
  const target = found.hits[Math.min(nth, found.hits.length - 1)];
  if (!target) return null;
  let box = null;
  try {
    const { model } = await page.cdp("DOM.getBoxModel", { nodeId: target.nodeId });
    const q = model.content; // [x1,y1,x2,y2,x3,y3,x4,y4]
    box = [Math.round((q[0] + q[2] + q[4] + q[6]) / 4), Math.round((q[1] + q[3] + q[5] + q[7]) / 4)];
  } catch (e) {
    warn(`clickViaCDP getBoxModel 失败：${String(e.message).split("\n")[0]}`);
    return null;
  }
  if (click) await page.mouse.click(box[0], box[1], label ? { label } : {});
  return { box, nodeId: target.nodeId, nodeName: target.nodeName, text: target.text, via: "cdp", hits: found.hits.length };
}

/* ─────────────── 上传文件 ─────────────── */

/**
 * 跨 shadow DOM 找 file input 并塞文件（CDP 通道）。
 * accept 传 null 表示不限类型（X 当天没有按 accept 过滤）。
 */
export async function setFilesViaCDP(page, file, { accept = "video" } = {}) {
  if (!fs.existsSync(file)) return { ok: false, error: `文件不存在：${file}` };
  try {
    await page.cdp("DOM.enable").catch(() => {});
    const flat = await page.cdp("DOM.getFlattenedDocument", { depth: -1, pierce: true });
    const nodes = (flat && flat.nodes) || [];
    const target = nodes.find((n) => {
      if (n.nodeName !== "INPUT") return false;
      const a = attrsOf(n);
      if (a.type !== "file") return false;
      return accept ? String(a.accept || "").includes(accept) : true;
    });
    if (!target) return { ok: false, error: `CDP 没找到 accept 含 "${accept}" 的 file input` };
    await page.cdp("DOM.setFileInputFiles", { nodeId: target.nodeId, files: [file] });
    return { ok: true, via: "cdp DOM.setFileInputFiles", nodeId: target.nodeId };
  } catch (e) {
    return { ok: false, error: String(e.message).split("\n")[0] };
  }
}

/**
 * 上传视频。三条路线，按顺序：
 *   1) `page.setInputFiles("input[type=file]", [绝对路径])`（ego 会自己回退到 iframe 里找）；
 *   2) 点击才生成 input → 先 `page.waitForFileChooser()` 再点（clickTarget 必须给）；
 *   3) CDP `DOM.setFileInputFiles`（穿 shadow DOM / iframe DOM 树）。
 * 返回 { ok, via, error }。**调用方必须把 ok=false 记成 blocker。**
 */
export async function uploadVideo(page, file, { clickTarget = null, chooserTimeout = 15000 } = {}) {
  if (!fs.existsSync(file)) return { ok: false, via: null, error: `视频文件不存在：${file}` };
  const sizeMB = (fs.statSync(file).size / 1024 / 1024).toFixed(1);

  // 路线 1
  try {
    await page.setInputFiles("input[type=file]", [file]);
    return { ok: true, via: "page.setInputFiles", sizeMB };
  } catch (e1) {
    var err1 = String(e1.message).split("\n")[0];
  }

  // 路线 2
  if (clickTarget) {
    try {
      const chooserPromise = page.waitForFileChooser({ timeout: chooserTimeout });
      chooserPromise.catch(() => {}); // 点击失败时别让它变成 unhandled rejection 把进程带崩
      await page.click(clickTarget, { timeout: 8000 });
      const chooser = await chooserPromise;
      const r = await chooser.setFiles(file);
      return { ok: true, via: "waitForFileChooser+click", dialog: r && r.dialog, sizeMB };
    } catch (e2) {
      var err2 = String(e2.message).split("\n")[0];
    }
  }

  // 路线 3
  const cdp = await setFilesViaCDP(page, file, { accept: "video" });
  if (cdp.ok) return { ok: true, via: cdp.via, sizeMB };
  const cdp2 = await setFilesViaCDP(page, file, { accept: null });
  if (cdp2.ok) return { ok: true, via: cdp2.via + "（不限 accept）", sizeMB };

  return { ok: false, via: null, sizeMB, error: [err1, err2, cdp.error, cdp2.error].filter(Boolean).join(" / ") };
}

/* ─────────────── 打字与话题 ─────────────── */

/**
 * 改写文本框 + **回读校验**（旧版 typeInto(..., {verify}) 的语义，原样保留）：
 *   三击选中 → Meta+A 全选 → 写入 → 回读比对（忽略空白），不符重来（默认 2 轮）。
 * 为什么必须回读：Meta+A 偶发不生效，新内容会被拼在旧内容后面（YouTube 那次标题拼成两段）。
 *
 * target: CSS 选择器 / snapshot ref（"@21"）
 * verify: CSS 选择器（回读用）；或传 verifyFn: async () => string
 */
export async function typeInto(page, target, str, { clear = false, verify = null, verifyFn = null, delay = 12, tries = 2 } = {}) {
  const attempts = verify || verifyFn ? Math.max(1, tries) : 1;
  let last = "";
  let lastErr = null;
  for (let i = 0; i < attempts; i++) {
    try {
      await page.click(target, { clickCount: clear ? 3 : 1, timeout: 8000 });
    } catch (e) {
      lastErr = `点不进 ${target}：${String(e.message).split("\n")[0]}`;
      await sleep(800);
      continue;
    }
    if (clear) {
      await page.keyboard.press("Meta+A").catch(() => {});
      await sleep(250);
      await page.keyboard.press("Backspace").catch(() => {});
      await sleep(300);
    }
    await page.keyboard.type(str, { delay });
    if (!verify && !verifyFn) return { ok: true, tries: i + 1 };
    await sleep(700);
    try {
      last = String(verifyFn ? await verifyFn() : await readText(page, verify)) || "";
    } catch (e) {
      last = "";
    }
    if (norm(last) === norm(str)) return { ok: true, readback: last, tries: i + 1 };
    warn(`回读不符（第 ${i + 1}/${attempts} 次）：${last.slice(0, 60)}`);
  }
  return { ok: false, readback: last, reason: lastErr || `回读不符：${last.slice(0, 60)}` };
}

/** 逐条加话题：#话题 → 等联想 → Enter → 空格（不加空格下一个 # 会粘上）。 */
export async function addTags(page, tags, { delay = 60, wait = 1400 } = {}) {
  const done = [];
  for (const t of tags || []) {
    if (!t) continue;
    await page.keyboard.type(`#${t}`, { delay });
    await sleep(wait);
    await page.keyboard.press("Enter");
    await sleep(500);
    await page.keyboard.type(" ", { delay: 20 });
    done.push(t);
  }
  await sleep(600);
  return done;
}

/* ─────────────── ★ 发布闸门（这份技能里最重要的一段逻辑） ─────────────── */

/**
 * 两段式闸门。**顺序写进代码，不是写在文档里**：
 *   1) 默认（publish=false）→ 永远不点发布；
 *   2) publish=true 且没有 blocker → 放行；
 *   3) publish=true 但有 blocker 且没有 force → 拒绝（调用方必须打印 blocker 并非零退出）；
 *   4) publish=true + blocker + force=true → 硬发（并明确记录是硬闯的）。
 */
export function publishGate({ blockers = [], publish = false, force = false } = {}) {
  if (!publish) return { allowed: false, publish: false, reason: "只填不发（默认，命令 JSON 里没有 publish:true）" };
  if (blockers.length && !force) return { allowed: false, publish: false, reason: `blocker 未清：${blockers.join("；")}` };
  return {
    allowed: true,
    publish: true,
    forced: force && blockers.length > 0,
    reason: force && blockers.length ? `有 blocker，但命令 JSON 里 force:true，硬发` : "闸门通过",
  };
}

/* ─────────────── spec / 媒体前置检查 ─────────────── */

export function resolveSpec(p) {
  if (!p) return null;
  const tries = path.isAbsolute(p)
    ? [p]
    : [path.join(PUB_PROJECT, p), path.join(SKILL_DIR, p), path.join(SKILL_DIR, "spec", path.basename(p)), path.join(EGO_DIR, p)];
  for (const t of tries) if (fs.existsSync(t)) return t;
  return null;
}

export function loadSpec(p) {
  const file = resolveSpec(p);
  if (!file) {
    throw new Error(
      `找不到 spec 文件：${p}\n  找过：${path.isAbsolute(p) ? p : [path.join(PUB_PROJECT, p), path.join(SKILL_DIR, p), path.join(SKILL_DIR, "spec", path.basename(String(p)))].join("、")}`
    );
  }
  let s;
  try {
    s = JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (e) {
    throw new Error(`spec JSON 读不了/解析失败：${file}\n  ${String(e.message).split("\n")[0]}`);
  }
  for (const k of ["video", "cover"]) if (s[k] && !path.isAbsolute(s[k])) s[k] = path.join(PUB_PROJECT, s[k]);
  return { spec: s, file };
}

export function findFfmpeg() {
  for (const f of FFMPEG_CANDIDATES) {
    try {
      if (fs.existsSync(f)) return f;
    } catch {}
  }
  return null;
}

/** 用 `ffmpeg -i` 读流信息（本机没有 ffprobe）。解析成 { video, audio, width, height, duration }。 */
export function probeMedia(file) {
  const ffmpeg = findFfmpeg();
  if (!ffmpeg) return { ok: false, skipped: true, error: "本机没找到 ffmpeg，跳过媒体检查" };
  if (!fs.existsSync(file)) return { ok: false, error: `文件不存在：${file}` };
  let text = "";
  try {
    execFileSync(ffmpeg, ["-hide_banner", "-i", file], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 30000 });
  } catch (e) {
    text = String(e.stderr || "") + String(e.stdout || "");
  }
  const video = (text.match(/Video:\s*([A-Za-z0-9_]+)/) || [])[1] || null;
  const audio = (text.match(/Audio:\s*([A-Za-z0-9_]+)/) || [])[1] || null;
  const size = text.match(/(\d{2,5})x(\d{2,5})/);
  const dur = text.match(/Duration:\s*(\d+):(\d+):(\d+\.\d+)/);
  return {
    ok: true,
    ffmpeg,
    video,
    audio,
    width: size ? Number(size[1]) : null,
    height: size ? Number(size[2]) : null,
    durationSec: dur ? Number(dur[1]) * 3600 + Number(dur[2]) * 60 + Number(dur[3]) : null,
    sizeMB: (fs.statSync(file).size / 1024 / 1024).toFixed(1),
    raw: text.split("\n").slice(0, 12).join("\n"),
  };
}

/**
 * 前置检查（**在真正上传之前**跑，逐项打印）。
 * 返回 { checks, hardBlockers, gateBlockers }：
 *   · hardBlockers → 缺 spec / 缺视频文件：无解，直接停（连浏览器都不必碰）；
 *   · gateBlockers → 编码/分辨率不对：可以 force 硬闯，但默认拦住。
 */
export function preflight({ platform, spec, specFile, pageOpen = null, videoPath = null, coverPath = null } = {}) {
  const checks = [];
  const add = (name, ok, detail, level = "gate") => checks.push({ name, ok, detail, level });
  const meta = PLATFORMS[platform];

  add("平台合法", !!meta, meta ? `${meta.name}（${meta.url}）` : `未知平台 ${platform}`, "hard");

  // 1) spec 文件
  add("spec 文件存在", !!specFile, specFile || "（没读到 spec 文件路径）", "hard");

  // 2) 必填字段
  const missing = (REQUIRED_FIELDS[platform] || []).filter((k) => {
    const v = spec ? spec[k] : undefined;
    return v === undefined || v === null || v === "" || (Array.isArray(v) && v.length === 0);
  });
  add("spec 必填字段齐全", missing.length === 0, missing.length ? `缺：${missing.join(", ")}（必填 ${(REQUIRED_FIELDS[platform] || []).join(", ")}）` : `必填 ${(REQUIRED_FIELDS[platform] || []).join(", ")} 都在`, "hard");
  const recMissing = (RECOMMENDED_FIELDS[platform] || []).filter((k) => {
    const v = spec ? spec[k] : undefined;
    return v === undefined || v === null || v === "" || (Array.isArray(v) && v.length === 0);
  });
  if (recMissing.length) add("spec 建议字段", false, `缺：${recMissing.join(", ")}（不影响发布，只是效果差）`, "warn");

  // 3) 目标页是否打开
  if (pageOpen !== null) add("目标页已在空间里打开", !!pageOpen, pageOpen ? "是" : "否（会导航/新建一个页面再继续）", "info");

  // 4) 视频 / 封面文件是否存在
  if (videoPath) add("视频文件存在", fs.existsSync(videoPath), `${videoPath}${fs.existsSync(videoPath) ? `（${(fs.statSync(videoPath).size / 1024 / 1024).toFixed(1)} MB）` : " ← 不存在"}`, "hard");
  else if ((REQUIRED_FIELDS[platform] || []).includes("video")) add("视频文件存在", false, "spec 里没有 video 字段", "hard");

  if (coverPath) add("封面文件存在", fs.existsSync(coverPath), `${coverPath}${fs.existsSync(coverPath) ? "" : " ← 不存在（不会带着默认首帧发，会记 blocker）"}`, "gate");

  // 5) 视频编码/分辨率
  if (videoPath && fs.existsSync(videoPath)) {
    const m = probeMedia(videoPath);
    if (m.skipped) add("视频是 H.264 + AAC + 1080x1920", true, m.error, "warn");
    else if (!m.ok) add("视频是 H.264 + AAC + 1080x1920", false, m.error, "gate");
    else {
      const bad = [];
      if (m.video !== "h264") bad.push(`视频编码是 ${m.video}（要 h264）`);
      if (m.audio !== "aac") bad.push(`音频编码是 ${m.audio}（要 aac）`);
      if (m.width !== 1080 || m.height !== 1920) bad.push(`分辨率是 ${m.width}x${m.height}（要 1080x1920）`);
      add("视频是 H.264 + AAC + 1080x1920", bad.length === 0, bad.length ? `${bad.join("；")}｜实测 ${m.video}/${m.audio}/${m.width}x${m.height}/${m.durationSec}s` : `${m.video}/${m.audio}/${m.width}x${m.height}/${m.durationSec}s ✓`, "gate");
    }
  }

  return {
    checks,
    hardBlockers: checks.filter((c) => !c.ok && c.level === "hard").map((c) => `${c.name}：${c.detail}`),
    gateBlockers: checks.filter((c) => !c.ok && c.level === "gate").map((c) => `${c.name}：${c.detail}`),
    warnings: checks.filter((c) => !c.ok && c.level !== "hard" && c.level !== "gate").map((c) => `${c.name}：${c.detail}`),
  };
}

/** 打印前置检查表。 */
export function printPreflight(pf) {
  line("");
  line("──── 前置检查（还没碰浏览器/还没上传） ────");
  for (const c of pf.checks) {
    const icon = c.ok ? "✅" : c.level === "hard" ? "⛔" : c.level === "gate" ? "❌" : c.level === "warn" ? "⚠️" : "•";
    line(`${icon} ${c.name}：${c.detail}`);
  }
  line("");
}

/* ─────────────── closed shadow 自检台（fixture） ─────────────── */

/**
 * 拿一个 data: URL 的本地测试台验证「CDP 穿透 closed shadow root 点击」这条路真的通。
 * 为什么不在真站点上验证：小红书的发布按钮只有**上传视频之后**才会渲染出来，
 * 而验收明确要求不要真的上传 —— 所以用 fixture 证明机制，真站点那一步如实标「未验证」。
 * （实测：ego 的 Node 运行时里起本地 http server 会卡在 listen，所以用 data: URL。）
 */
export async function makeShadowFixture(page) {
  const html = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><title>fpb-fixture</title>
<style>body{font-family:sans-serif;padding:40px}button{padding:14px 28px;font-size:18px}</style></head><body>
<h1>closed shadow 测试台</h1>
<div id="openHost"></div>
<xhs-publish-btn id="closedHost"></xhs-publish-btn>
<p><input type="file" accept="video/mp4"></p>
<div contenteditable="true" id="ed" style="border:1px solid #999;padding:12px;min-height:40px">旧内容</div>
<script>
  window.__fpb = { clicked: false, lightButtons: null };
  var host = document.getElementById("closedHost");
  var sr = host.attachShadow({ mode: "closed" });
  sr.innerHTML = '<button id="pub">发布</button>';
  sr.querySelector("#pub").addEventListener("click", function () { window.__fpb.clicked = true; });
  document.getElementById("openHost").attachShadow({ mode: "open" }).innerHTML = '<button id="draft">存草稿</button>';
  window.__fpb.lightButtons = document.querySelectorAll("button").length;
</script>
</body></html>`;
  await page.goto("data:text/html;charset=utf-8," + encodeURIComponent(html), { waitUntil: "domcontentloaded", timeout: 30000 });
  await sleep(800);
  return page;
}

/** 跑自检并返回结果（不点真站点的任何东西）。 */
export async function runShadowSelfTest(page) {
  const out = { steps: [] };
  const push = (name, ok, detail) => out.steps.push({ name, ok, detail });

  await makeShadowFixture(page);
  const info = await page.evaluate(() => {
    const host = document.getElementById("closedHost");
    return {
      shadowRootFromLightDom: String(host && host.shadowRoot),
      lightButtonCount: document.querySelectorAll("button").length,
      hostCount: document.querySelectorAll("xhs-publish-btn").length,
    };
  });
  out.lightDom = info;
  push("fixture 里 closed shadow 对轻 DOM 不可见", info.shadowRootFromLightDom === "null" && info.lightButtonCount === 0, `host.shadowRoot=${info.shadowRootFromLightDom}，light DOM button 数=${info.lightButtonCount}`);

  const found = await cdpFind(page, "发布");
  push("CDP getFlattenedDocument{pierce:true} 找到了 closed shadow 里的「发布」", found.hits.length > 0, `命中 ${found.hits.length} 个（扁平节点 ${found.total} 个）：${JSON.stringify(found.hits.slice(0, 2).map((h) => ({ nodeName: h.nodeName, up: h.up, text: h.text })))}`);

  const clicked = await clickViaCDP(page, "发布", { label: "点击 closed shadow 里的按钮" });
  await sleep(500);
  const after = await page.evaluate(() => window.__fpb).catch(() => null);
  out.click = clicked;
  out.afterClick = after;
  push("getBoxModel 取坐标 + mouse.click 真的点中了", !!(clicked && after && after.clicked), clicked ? `坐标 ${JSON.stringify(clicked.box)}，clicked=${after && after.clicked}` : "没找到节点或取不到 boxModel");

  await shot(page, "selftest_closed_shadow");
  out.ok = out.steps.every((s) => s.ok);
  return out;
}

/* ─────────────── 输出 ─────────────── */

export function printResult(o) {
  line("");
  line("=== 结果 ===");
  line(JSON.stringify(o, null, 2));
  if (o.blockers && o.blockers.length) line("⛔ blocker：\n- " + o.blockers.join("\n- "));
  if (o.warnings && o.warnings.length) line("⚠️ 提示：\n- " + o.warnings.join("\n- "));
}

export const EXIT = { OK: 0, ERROR: 1, GATE: 2, PREFLIGHT: 3 };
