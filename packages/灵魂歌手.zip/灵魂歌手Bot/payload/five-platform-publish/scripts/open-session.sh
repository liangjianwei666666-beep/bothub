#!/usr/bin/env bash
# 起一个「带用户登录态」的调试 Chrome（复制配置副本），端口默认 9222。
# 用法：
#   bash scripts/open-session.sh
#   PUB_PROFILE_DIR=/path/to/profile PUB_CDP_PORT=9333 bash scripts/open-session.sh
#
# 为什么要复制配置：不能直接操作用户日常的 Chrome 配置目录（会抢锁、有风险）。
# 注意：副本里的 cookie 常常已失效（实测：小红书、视频号都被弹回登录页），
#      起来之后要让**用户自己**在窗口里登录五站，Bot 不代登录。
set -euo pipefail

SRC="${PUB_SRC_PROFILE:-$HOME/Library/Application Support/Google/Chrome}"
PROFILE_DIR="${PUB_PROFILE_DIR:-$PWD/.publish-tools/chrome-profile}"
PORT="${PUB_CDP_PORT:-9222}"
CHROME="${CHROME_BIN:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}"
URLS=(
  "https://creator.xiaohongshu.com/login"
  "https://channels.weixin.qq.com/login.html"
  "https://creator.douyin.com/"
  "https://x.com/i/flow/login"
  "https://studio.youtube.com"
)

if [ ! -x "$CHROME" ]; then
  echo "找不到 Chrome：$CHROME（用 CHROME_BIN=<path> 指定）" >&2
  exit 1
fi

if curl -s -m 2 "http://127.0.0.1:$PORT/json/version" >/dev/null 2>&1; then
  echo "已经有调试 Chrome 在 $PORT，直接用，不再起第二个。"
  curl -s "http://127.0.0.1:$PORT/json/version" | head -3
  exit 0
fi

if [ ! -d "$PROFILE_DIR" ]; then
  echo "复制配置副本：$SRC → $PROFILE_DIR"
  mkdir -p "$PROFILE_DIR"
  rsync -a \
    --exclude 'Cache' --exclude 'Code Cache' --exclude 'GPUCache' \
    --exclude 'Service Worker' --exclude 'GrShaderCache' --exclude 'ShaderCache' \
    --exclude 'BrowserMetrics*' --exclude 'Crashpad' \
    "$SRC/" "$PROFILE_DIR/"
else
  echo "配置副本已存在：$PROFILE_DIR"
fi

echo "启动 Chrome（调试端口 $PORT）…"
"$CHROME" \
  --remote-debugging-port="$PORT" \
  --user-data-dir="$PROFILE_DIR" \
  --no-first-run --no-default-browser-check \
  --disable-blink-features=AutomationControlled \
  --no-sandbox \
  "${URLS[@]}" \
  >/dev/null 2>&1 &

for _ in $(seq 1 20); do
  if curl -s -m 2 "http://127.0.0.1:$PORT/json/version" >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

if curl -s -m 3 "http://127.0.0.1:$PORT/json/version" >/dev/null 2>&1; then
  echo
  echo "已就绪。现在请用户在刚弹出的 Chrome 窗口里登录五个站（小红书 / 视频号 / 抖音 / X / Google）。"
  echo "登录完成后：node \"$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/probe.js\" --open-login"
else
  echo "Chrome 没起来（$PORT 无响应）。检查是否有别的实例在用同一个配置目录。" >&2
  exit 1
fi

# 说明：--no-sandbox 是给沙箱环境用的（否则 sandbox initialization failed）。
# 已知情况：YouTube Studio 的上传对话框在这套环境里**时好时坏**（03:31 那次成功渲染并真的开始上传，
# 同一批参数在别的时刻又找不到「选择文件」）→ YouTube 上传交给用户手动，Bot 只改文案/核对。
