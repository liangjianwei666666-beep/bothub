'use strict';
/**
 * 五平台登录态 / 页面自检 —— 开跑前的唯一闸门。
 *
 *   node scripts/probe.js                     # 五个站全查（会依次打开各站的后台页）
 *   node scripts/probe.js xhs sph             # 只查指定站
 *   node scripts/probe.js --open-login        # 未登录的站，把登录页开到前台给用户扫码
 *   node scripts/probe.js --keep              # 不导航、只看当前标签页（该站没有已开标签时仍会新开一个）
 *
 * 平台前端改版后，先用这个校准，再跑 fill.js。
 */
const L = require('./lib.js');

const PLATFORMS = {
  xhs: {
    name: '小红书',
    part: 'creator.xiaohongshu.com',
    url: 'https://creator.xiaohongshu.com/publish/publish',
    login: 'https://creator.xiaohongshu.com/login',
  },
  sph: {
    name: '视频号',
    part: 'channels.weixin.qq.com',
    url: 'https://channels.weixin.qq.com/platform/post/create',
    login: 'https://channels.weixin.qq.com/login.html',
  },
  dy: {
    name: '抖音',
    part: 'creator.douyin.com',
    url: 'https://creator.douyin.com/creator-micro/content/upload',
    login: 'https://creator.douyin.com/',
  },
  x: { name: 'X', part: 'x.com', url: 'https://x.com/compose/post', login: 'https://x.com/i/flow/login' },
  yt: { name: 'YouTube', part: 'studio.youtube.com', url: 'https://studio.youtube.com', login: 'https://studio.youtube.com' },
};

// 登录墙特征（全文匹配，不只看开头）
const LOGIN_HINTS = /(扫码登录|请登录|登录后|立即登录|手机号登录|密码登录|使用其他账号|Log in|Sign in|Sign in to|Continue with)/;
// 后台特征
const BACKEND_HINTS = /(创作服务|发布笔记|笔记管理|上传视频|作品管理|发布视频|创作者|Create|Upload|Dashboard|内容管理|Post)/;

/** 三态判断：已登录 / 未登录 / 不确定。不确定就人工看截图，不要硬猜。 */
async function judge(page) {
  const url = page.url();
  const body = await L.text(page);
  const pw = await page
    .evaluate(() => [...document.querySelectorAll('input[type=password]')].filter((e) => e.getBoundingClientRect().width > 0).length)
    .catch(() => 0);
  if (/(login|signin|sign_in|passport)/i.test(url)) return { state: 'no', why: 'URL 是登录页' };
  if (pw > 0) return { state: 'no', why: '页面上有可见的密码输入框' };
  if (LOGIN_HINTS.test(body)) return { state: 'no', why: '正文出现登录话术' };
  if (BACKEND_HINTS.test(body)) return { state: 'yes', why: '正文出现后台元素' };
  return { state: 'unknown', why: '没看到明显特征，请看截图确认' };
}

async function probeOne(ctx, key, { openLogin, keep }) {
  const cfg = PLATFORMS[key];
  let p = ctx.pages().find((x) => x.url().includes(cfg.part));
  if (!p) {
    p = await ctx.newPage();
    keep = false; // 没有已开标签就只能新开+导航
    L.log(`（该站没有已开标签，新开一个并导航）`);
  }
  if (!keep) {
    // 每次都导航到后台页：否则会拿上一轮的残留页面（编辑页/登录页/已发表列表）当判据
    await p.goto(cfg.url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  }
  await p.bringToFront().catch(() => {});
  await L.sleep(6000);
  const url = p.url();
  const title = await p.title().catch(() => '');
  const body = (await L.text(p)).slice(0, 200);
  const v = await judge(p);
  const icon = v.state === 'yes' ? '✅' : v.state === 'no' ? '❌' : '❔';
  L.log(`### ${cfg.name} ${icon} ${v.state === 'yes' ? '已登录' : v.state === 'no' ? '未登录' : '不确定'}（${v.why}）`);
  L.log('   URL:', url.slice(0, 120));
  L.log('   TITLE:', title.slice(0, 80));
  L.log('   TEXT:', body.slice(0, 150));
  await L.shot(p, `probe_${key}`);
  if (v.state !== 'yes' && openLogin) {
    await p.goto(cfg.login, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    await p.bringToFront().catch(() => {});
    L.log(`   → 已把 ${cfg.name} 登录页开到前台，请用户自己扫码/输密码`);
  }
  return { key, name: cfg.name, url, ...v };
}

(async () => {
  const argv = process.argv.slice(2);
  const openLogin = argv.includes('--open-login');
  const keep = argv.includes('--keep');
  const keys = argv.filter((a) => !a.startsWith('--'));
  const targets = keys.length ? keys : Object.keys(PLATFORMS);
  for (const k of targets) {
    if (!PLATFORMS[k]) {
      console.error(`未知平台 "${k}"，可选：${Object.keys(PLATFORMS).join(' / ')}`);
      process.exit(1);
    }
  }
  const { b, ctx } = await L.connect();
  const results = [];
  for (const k of targets) results.push(await probeOne(ctx, k, { openLogin, keep }));
  await b.close();

  console.log('\n— 汇总 —');
  for (const r of results) {
    console.log(`${r.state === 'yes' ? '✅' : r.state === 'no' ? '❌' : '❔'} ${r.name}　${r.why}`);
  }
  const no = results.filter((r) => r.state === 'no').map((r) => r.name);
  const unknown = results.filter((r) => r.state === 'unknown').map((r) => r.name);
  if (no.length) console.log(`需要用户登录：${no.join('、')}（用 --open-login 开登录页）`);
  if (unknown.length) console.log(`不确定、需人工看截图：${unknown.join('、')}`);
  if (!no.length && !unknown.length) console.log('五站都就绪，可以开跑 fill.js。');
})().catch((e) => {
  console.error('失败：' + e.message);
  process.exit(1);
});
