# 视频号（channels.weixin.qq.com）

**账号**：你的视频号（ID 是后台读到的，归档脚本里没留存）
**入口**：`https://channels.weixin.qq.com/platform/post/create`　登录 `https://channels.weixin.qq.com/login.html`

## 关键：整张表单在 iframe 里

外层 DOM 抓不到任何表单元素，必须拿到 frame：

```js
const f = L.frame(page, '/micro/content/post/create');   // 表单都在这个 frame 里
```

- frame 内**没有 mouse**，点击要换算：`frame 内坐标 + iframe 偏移 → page.mouse.click()`
  （`lib.js` 的 `clickText(page, t, {frame: f})` / `clickSel(page, sel, {frame: f})` 已处理）。
- **iframe 会随步骤重新挂载：每一步都重新取一次 frame，别缓存**
  （`fill.js` 里的 `waitFrame()` 就是干这个的）。

## 步骤

```bash
node scripts/fill.js sph --spec spec/sph.json
```

1. **上传视频**：file input 在 frame 里，用 CDP `DOM.setFileInputFiles`（`lib.js` 的 `uploadVideo`）。
   > 注：当天也试通过 frame locator 的 `f.locator('input[type=file]').setInputFiles()`（sph_upload.js）；
   > 外层 `page.setInputFiles` 对 iframe 内元素当然找不到。「必须 CDP」这个说法过强，两条路都能走，
   > 本技能默认用 CDP（一条代码同时覆盖跨 frame/跨 shadow 的情况）。
   > 轮询到「重新上传 / 100% / 上传完成」为止。
2. **短标题**：`input[placeholder*="短标题"]`（独立输入框，**描述 ≠ 短标题**）。
3. **描述**：`.input-editor`（contenteditable），`click` 后 `keyboard.type`，`Enter` 换行。
4. **话题**：`#音乐` → 等 1.6s → `Enter` → 空格。这里话题是纯文本输入，
   平台**一般**会自动识别（当天没有回读结果的输出留存，下次跑看编辑器文本）。
5. **封面**：点「上传封面」——真正的热区在文字**上方约 40px 的 + 号区域**，用 `filechooser` 接住。
6. **位置**：页面会按 **IP 自动填**（当天填成了「华盛顿」）→ 改成「不显示位置」。
   这一步当天点了三次才稳定打开选择器；`fill.js` 会在回读里检查有没有外国城市名，有就报 blocker。
7. **发表**：文本「直接发表」（有的版本是「发表」），rect + `mouse.click`，等 10s 读 frame 文本确认。

## 核对

- 页面跳到已发表列表 → 截图存档。
- 「原创审核中」是**账号在创作分成计划里的默认标注**，不是本次勾的（这个账号所有视频都带）。
- 永久链接：分享链接要在手机端生成，后台拿不到 → 如实说。

## 已知坑

- 外层引导弹窗和 iframe 会抢焦点，操作前 `bringToFront()`。
- 位置那一行最不稳，改完一定回读 frame 文本。
