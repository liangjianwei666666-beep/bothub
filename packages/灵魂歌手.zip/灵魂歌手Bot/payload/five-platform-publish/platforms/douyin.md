# 抖音（creator.douyin.com）

**入口**：`https://creator.douyin.com/creator-micro/content/upload`（创作者中心 → 发布视频）
> 这条 URL 在当天那轮实测里没单独打印过，是从脚本常量读出来的（check3.js）——开跑前用
> `node scripts/probe.js dy` 确认落点。

## 步骤

```bash
node scripts/fill.js dy --spec spec/dy.json
```

1. **先关引导弹窗**（「我知道了」），否则遮罩挡住表单。用文字点击，别用 `getByRole().click()`。
2. **上传视频**：CDP `DOM.setFileInputFiles`（`lib.js` 的 `uploadVideo`）。
   轮询页面文本，出现 `重新上传 / 作品描述 / 填写作品` 且不再有 `上传中 / 解析中` 即完成。
3. **标题**：`input[placeholder*="作品标题"]`（独立输入框）。
4. **简介**：`div[contenteditable="true"]`（第一个），`click` 后 `keyboard.type`，`Enter` 换行。
5. **话题**：`#民谣` → 等 1.4s → `Enter` → 空格，逐个加。
6. **AI 声明（必做，用户要求）**：滚到「请选择自主声明」→ 点开 → 选 **「内容由AI生成」**
   ⚠️ 归档里的真实文案**没有空格**（dy_pub3.js / dy_pub.js 都是「内容由AI生成」），
   照字面写带空格的版本会点不中。选完回读页面文本，确认**不再包含**「请选择自主声明」。
   `fill.js` 把这一步失败记为 blocker，`--publish` 会直接拒绝。
7. **发布**：
   - 台账实测：发布按钮被 toast 遮挡时，坐标点击会打空 → 用 `element.click()` 直接触发（dy_js_click.js）。
   - `fill.js` 的顺序是 `jsClick('发布')` → 失败再 `clickText('发布')`，并把用了哪条记进 `steps.publishVia`。
   - 发完看 URL 和页面文本确认进审核。

## 核对

- 后台作品列表应出现这条：状态「审核中」、封面、标题。
- 「内容由AI生成」自主声明在列表里能看到标注。
- 永久链接：后台同样没有方便的复制入口 → 诚实说明，让用户从 App 取。

## 已知坑

- 表单是长页，**按钮很可能在视口外**：点击前一律 `scrollIntoView`。
- 声明那一行必须**先点开再选**，收起状态下直接找「内容由AI生成」找不到。
- 上传完成后页面自动跳到填写页，别在上传页傻等。
