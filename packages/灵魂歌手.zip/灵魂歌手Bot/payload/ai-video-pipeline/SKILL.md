---
name: ai-video-pipeline
description: 三段 API 的 AI 视频生产流水线（生图 + 视频 + 语音），分镜表进、成片出；含 7 阶段方法论（需求确认→分镜→角色卡/场景卡→单镜渲染→合成→拉片验收→封面）与《空舟效应》等实战沉淀的踩坑清单。当用户要做 AI 短片/动画/微短剧/口播视频、要把分镜批量出片、要搭可复用的视频生产流水线、或要在新电脑上重建这套生产能力时使用。
whenToUse: 用户要「做一条 AI 视频/动画/短片」、要「分镜批量出片」、要「流水线/工作流/搭一套生产流程」、要「跨设备复用视频生产能力」、或要「拉片验收/查镜头动没动」时。先读本 SKILL 再动手；方法论全文在 references/工作流方法论.md。
---

# ai-video-pipeline · AI 视频生产流水线

**核心理念：先规划，后渲染。** 没有分镜表＋镜头表，禁止开始渲染——这是《悉达多》翻车的直接原因（跳过规划 → 人设漂移、构图乱、质量差）。

两条可复用的资产：

| 资产 | 作用 |
|---|---|
| `scripts/` | 可执行流水线：分镜表(`shots.yaml`) 进，成片出。三段 API（生图/视频/语音）各自独立，换供应商只改 `config.yaml` |
| `references/工作流方法论.md` | 7 阶段方法论 + 铁律 + 踩坑记录（《三猫传》《空舟》《鱼竿与鱼》《悉达多》实战沉淀） |

---

## 0. 铁律（违反必翻车）

1. **先规划，后渲染。** 没有分镜表+镜头表，不许开渲。
2. **参考图必须绑定。** H3 图生视频每镜必须给「场景卡+角色卡」参考（≥2 张），否则人物是 AI 现编的，全片不一致。
3. **参考图必须公网 URL。** base64 会被**静默忽略**；本地图要用 HTTP 服务 + 隧道暴露（见 §4）。
4. **每步向用户确认**，不跳步、不擅自扩大范围。
5. **分辨率枚举必须小写**：`768p竖` / `768p横` / `480p竖`。

---

## 1. 首次在新设备上装配

```bash
# 1) 复制 skill 到目标机器（整个目录）
# 2) 建工作目录并装入流水线
mkdir -p ~/ai-video && cd ~/ai-video
cp -R ~/.agents/skills/ai-video-pipeline/scripts/* .

# 3) 装依赖
pip install pyyaml requests edge-tts imageio-ffmpeg
# ffmpeg：优先系统版（brew install ffmpeg），没有则自动用 imageio-ffmpeg 内置的

# 4) 建配置（模板在 skill 的 templates/）
cp ~/.agents/skills/ai-video-pipeline/templates/config.example.yaml ./config.yaml
cp ~/.agents/skills/ai-video-pipeline/templates/.env.example ./.env
# 编辑 .env 填 Key；编辑 config.yaml 填 base_url / model / workflow
echo "你的token" > ./.autodl_token && chmod 600 ./.autodl_token
```

**跨设备的关键设计**：密钥全在 `.env` 和 `./.autodl_token`，`config.yaml` 用 `${VAR}` 引用。换电脑只带走/重填这两个文件，**代码和 config 一个字都不用改**。

---

## 2. 一键跑（4 个阶段）

```bash
python3 run.py --project projects/<项目名> --stage all --dry-run   # 先看计划，不烧钱
python3 run.py --project projects/<项目名> --stage cards           # ① 角色卡/场景卡
python3 run.py --project projects/<项目名> --stage shots           # ② 逐镜渲染
python3 run.py --project projects/<项目名> --stage tts             # ③ 旁白配音
python3 run.py --project projects/<项目名> --stage assemble        # ④ 拼接+混音+响度
```

| 选项 | 作用 |
|---|---|
| `--only S03,S04` | 只重跑指定镜头（队列超时/失败重跑常用） |
| `--dry-run` | 只打印计划，不调 API |
| `--force` | 覆盖已有产物（默认断点续跑：产物存在且体积正常就跳过） |

> **半自动的关键在 cards 和 shots 之间**：卡片出来先自己看一眼，不满意就改 `shots.yaml` 里的 prompt 重跑单张（加 `--force`），**别直接批量烧几十镜**。

---

## 3. shots.yaml 怎么写

```yaml
project: 项目名
resolution: 768p竖                    # 必须小写
style_prefix: "Pixar-inspired 3D cartoon rendering, C4D+Octane look, Q-version proportions"  # 自动拼到每镜 prompt 前，保证画风统一

cards:                                 # 一致性锚点：先出卡，所有镜头引用
  - id: "char:hero"
    kind: char                         # char → 角色卡/ ; scene → 场景卡/
    prompt: "角色设定图，全身立绘…"
  - id: "scene:room"
    kind: scene
    prompt: "场景图，无人物…"

shots:
  - id: S01
    duration: 5                        # 单镜 ≤15s
    refs: ["char:hero", "scene:room"]  # ⚠️ 每镜 ≥2 张，否则人物漂移
    prompt: "角色从右侧走入，歪头看镜头，镜头固定"
    narration: "旁白文案…"              # 可选；会进 tts 阶段
    voice: zh-CN-YunxiNeural           # 可选，覆盖全局音色

assemble:
  transition: 0.6
  narration_delay_ms: 1200
  bgm_volume: 0.32
  # bgm: 配乐/bgm.m4a
```

**风格前缀举例**：
- 3D 动画（《空舟效应》用的）：`Pixar-inspired 3D cartoon rendering, C4D + Octane look, stylized Q-version proportions, warm SSS skin, designed detailed hair, strong character design, elastic Disney-style performance`
- 水墨禅意：`水墨水彩禅意东方寓言风格，宣纸纹理，晕染墨色与淡彩，柔和晨光，电影感构图，细腻笔触，高级质感`

---

## 4. 参考图公网化（H3 硬要求）

AutoDL 的 H3 **只认公网 http(s) URL**，base64 静默忽略；不给参考图人物必漂移。

```bash
python3 -m http.server 8790 -d /path/to/projects/<项目名>      # 起本地服务
ssh -R 80:localhost:8790 serveo.net                            # 开隧道
# 或 ssh -R 80:localhost:8790 localhost.run
```

拿到域名后填进 `config.yaml` 的 `video.public_base`（结尾无斜杠）。流水线会自动把本地卡路径拼成公网 URL。

> 隧道容易死→任务 FAILED，重提即可（长队列期间尤其常见）。

---

## 5. 三段 API 怎么配

`config.yaml` 每段一个 `provider`，互不干扰：

| 段 | provider | 必填 |
|---|---|---|
| `image` | `openai_compatible` / `gemini` / `autodl` | base_url + api_key + model |
| `video` | `autodl` / `openai_compatible` / `gemini` | autodl: token_file + workflow；网关: base_url + api_key + model |
| `tts` | `edge_tts` / `openai_compatible` / `doubao` | edge_tts 免 Key；doubao 要 api_key + resource_id |

字段对不上**不用改代码**：每段都有 `extra: {}` 会合并进请求体；路径/字段名也可配（`path` / `submit_path` / `status_path` / `ref_field` / `duration_field` / `input_field`）。

**AutoDL 接口**（视频）：
```
提交 POST https://autodl.art/api/v1/comfyui/comfyui_workflow/{workflow_id}
查询 GET  https://autodl.art/api/v1/comfyui/comfyui_workflow/result/{task_id}
Header: {"Authorization": <token>, "Content-Type": "application/json"}   # 裸 token，不加 Bearer
```

---

## 6. 阶段⑥ 拉片验收（出片 ≠ 交付）

**被漏得最狠的一步。** 生成式出片最常见的失败不是黑屏，是「**没动**」——时长和画面都正常，机位却纹丝不动，手机上看不出差别。

用 `video-shots` skill 拆逐镜表，用**运镜实测对账门**拦截。要点：

- **阈值必须下调**：`seed` 默认 `--threshold 0.3`，AI 生成的国风/慢片/暗调素材对比度低会大面积漏刀。**用已知镜数反推**：出了 N 个片段，成片就该有 N 镜，调到检出数 == N。
- **交叉验证**：检出切点 vs 各片段真实时长累积，**±0.05s 内对得上才可信**。
- **运镜以实测为准**：`shots.json` 的 `motion` 是逐帧差分量的。要求了运动却没动 → 降级为 `static` 并写进 note。
- **方向不做无根据断言**：AI 片段帧间内容在变，无法复原机位方向 → 照设计意图填，并在 `meta.cameraDirectionUnverified` 声明未核验。
- **不描述听不到的东西**：没试听就不能往 `audio` 写「风声」「水声」。

---

## 7. 阶段⑦ 封面

1. 从成片抽候选帧：`ffmpeg -ss <时间点> -i 成片.mp4 -frames:v 1 帧.jpg`（抽 6 帧拼总览让用户选）
2. 用 `telangpuai-imagegen` **一体生成带文字封面**（文字画进画面，不要 PIL 贴字）：
   ```bash
   bash ~/.agents/skills/telangpuai-imagegen/scripts/image_gen.sh \
     --prompt "视频封面图，3:4竖版比例。背景：…。标题文字「…」字要大清晰无错字，与画面融为一体…" \
     --input "帧.jpg" --out "封面_xxx_3x4.png"
   ```
3. 3:4 竖版 + 4:3 横版各一张
4. ⚠️ **AI 中文文字偶有错字**，生成后让用户核对，错字就重生成或简化标题措辞

---

## 8. 踩坑记录（每条都是真金白银）

1. **xfade offset 必须动态** = 当前累计时长 − 转场时长。硬编码会截断前面所有内容（实测 36s 拼成 9s）
2. **xfade 输出强制 yuv420p**，否则部分平台不认
3. **aevalsrc 表达式不能有逗号**：`mod(t,1)` → `t-floor(t)`
4. **参考图 base64 被静默忽略**，只认公网 URL
5. **H3 队列慢（5-15 分钟/镜）属正常**；隧道死导致 FAILED → 重提
6. **产物按体积校验**，0 字节/截断文件不会被当成「已完成」跳过
7. **响度归一到 -16 LUFS**（edge-tts 默认偏小声）
8. **旁白与画面长度对不上会提前警告**，别等导出才发现被裁

---

## 9. 交付物清单

```
项目名/
├── 项目规划.md              一句话主题 + 时长 + 风格 + 受众
├── 分镜_text-storyboards.md 每秒一行的精确指令（质量核心）
├── 镜头表_standard-shot-table.md
├── 渲染prompt预案.md
├── 角色卡/ 场景卡/          一致性锚点
├── 单镜片段/                S01.mp4 …
├── 旁白/                    旁白文案.txt + 旁白_全轨.mp3
├── 配乐/                    bgm.m4a
├── 成片_项目名.mp4
├── 拉片/                    shots.json / shots.md / shots-report.html
└── 封面_xxx_3x4.png / _4x3.png
```

---

## 10. 相关 skill

| skill | 何时用 |
|---|---|
| `telangpuai-imagegen` | 出角色卡/场景卡/封面（gpt-image-2） |
| `video-shots` | 阶段⑥ 拉片验收，查「镜头动没动」 |
| `video-sync` | 把拉片数据合成带分镜信息的视频 |
| `digital-human-video` | 需要「指定工作流/数字人对口型」时的通用客户端 |
| `autodl-video` | 单条图生视频的轻量封装 |
