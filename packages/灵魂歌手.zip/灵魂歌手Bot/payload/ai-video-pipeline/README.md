# ai-video-pipeline · 跨设备使用说明

三段 API 的 AI 视频生产流水线：**分镜表进，成片出**。
含 7 阶段方法论 +《空舟效应》等实战沉淀的踩坑清单。

---

## 这是什么

一个可以把「一个故事」变成「一条成片」的流水线：

```
shots.yaml（分镜表）
   ├─→ 生图 API  → 角色卡 / 场景卡（一致性锚点）
   ├─→ 视频 API  → 逐镜片段
   └─→ 语音 API  → 旁白全轨
                    └─→ ffmpeg 合成（拼接/转场/混音/响度）→ 成片
```

三段的供应商**各自独立**：换生图厂商不影响视频，换语音不影响生图。只改 `config.yaml`，**不动代码**。

---

## 在新电脑上装配（3 步）

```bash
# 1) 把这个 skill 目录拷到新机器（整目录）
#    放到 ~/.agents/skills/ai-video-pipeline

# 2) 一键装配（自动装代码、建配置骨架、查依赖）
bash ~/.agents/skills/ai-video-pipeline/scripts/bootstrap.sh ~/ai-video

# 3) 填密钥
cd ~/ai-video
vi .env                     # 填 API Key
vi config.yaml              # 填 base_url / model / workflow
echo "你的token" > .autodl_token && chmod 600 .autodl_token
```

依赖缺失时 bootstrap 会直接告诉你装什么：

```bash
pip install pyyaml requests edge-tts imageio-ffmpeg
```

---

## 日常使用

```bash
cd ~/ai-video

# 先看计划，不烧钱
python3 run.py --project projects/示例 --stage all --dry-run

# 分阶段跑
python3 run.py --project projects/示例 --stage cards      # ① 角色卡/场景卡
python3 run.py --project projects/示例 --stage shots      # ② 逐镜渲染
python3 run.py --project projects/示例 --stage tts        # ③ 旁白配音
python3 run.py --project projects/示例 --stage assemble   # ④ 合成成片

# 只重跑失败的镜头
python3 run.py --project projects/示例 --stage shots --only S03,S04
```

**断点续跑**：产物已存在且体积正常会自动跳过；失败的镜头结尾会汇总，用 `--only` 重跑即可。

---

## 跨设备怎么带走

| 内容 | 是否随 skill 走 | 说明 |
|---|---|---|
| 代码（`scripts/`） | ✅ 在 skill 里 | 拷目录即可 |
| 方法论（`references/`） | ✅ 在 skill 里 | 拷目录即可 |
| 配置模板（`templates/`） | ✅ 在 skill 里 | 拷目录即可 |
| **`.env`（API Key）** | ❌ 不带 | **安全设计**：密钥不随代码走，新设备重填 |
| **`config.yaml`** | ❌ 不带 | 新设备从模板重建（bootstrap 自动做） |
| **`.autodl_token`** | ❌ 不带 | 新设备重放一次 |

> 这是有意的：**代码可以随便拷，密钥永远手动填**。别把 `.env` 塞进 zip 或 git。

---

## 关键约束（不看会翻车）

1. **参考图必须公网 URL** —— H3 只认 `http(s)`，base64 会被**静默忽略**（人物必漂移）。
   ```bash
   python3 -m http.server 8790 -d projects/示例 &
   ssh -R 80:localhost:8790 serveo.net        # 拿到域名填进 config.yaml 的 video.public_base
   ```
2. **每镜 ≥2 张参考图**（角色卡+场景卡），否则人物是 AI 现编的。
3. **分辨率枚举必须小写**：`768p竖` / `768p横` / `480p竖`。
4. **先规划后渲染** —— 没有分镜表不许开渲。
5. **AutoDL 队列 5-15 分钟/镜属正常**；隧道死导致 FAILED 就重提。

---

## 目录结构

```
ai-video-pipeline/
├── SKILL.md                     入口（7 阶段方法论 + 用法）
├── README.md                    本文件（跨设备说明）
├── scripts/
│   ├── bootstrap.sh             跨设备一键装配
│   ├── run.py                   主入口（cards/shots/tts/assemble）
│   ├── assemble.py              ffmpeg 合成（xfade/混音/响度）
│   └── adapters/
│       ├── base.py              配置、HTTP、重试、产物校验
│       ├── image.py             生图：openai_compatible | gemini | autodl
│       ├── video.py             视频：autodl | openai_compatible | gemini
│       ├── tts.py               语音：edge_tts | openai_compatible | doubao
│       └── autodl.py            AutoDL ComfyUI 提交/轮询/下载
├── templates/
│   ├── config.example.yaml      三段 API 配置模板
│   ├── .env.example             密钥模板
│   └── shots.example.yaml       分镜表示例
└── references/
    └── 工作流方法论.md          7 阶段全文 + 铁律 + 踩坑记录
```

---

## 配套 skill

| skill | 何时用 |
|---|---|
| `telangpuai-imagegen` | 出角色卡/场景卡/封面（gpt-image-2） |
| `video-shots` | 拉片验收：把成片拆逐镜表，查「镜头动没动」 |
| `video-sync` | 把拉片数据合成带分镜信息的视频 |
| `digital-human-video` | 需要指定/切换 AutoDL 工作流时的通用客户端 |

---

## 版本与来源

- 方法论沉淀自《三猫传》《空舟》《鱼竿与鱼》《悉达多》等项目实战
- 最后更新：2026-09-13（新增阶段⑥ 拉片验收）
