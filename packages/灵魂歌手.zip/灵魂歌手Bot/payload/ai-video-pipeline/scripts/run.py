#!/usr/bin/env python3
"""AI 视频生产流水线 · 命令行入口

用法：
  python3 run.py --project projects/猫IP --stage all
  python3 run.py --project projects/猫IP --stage cards          # 只出角色卡/场景卡
  python3 run.py --project projects/猫IP --stage shots --only S03,S04   # 只重跑失败镜
  python3 run.py --project projects/猫IP --stage all --dry-run   # 只看计划不烧钱

阶段：cards → shots → tts → assemble（--stage all 全部跑）
断点续跑：已存在的产物默认跳过，加 --force 覆盖。
"""
import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from adapters import base, image, tts, video  # noqa: E402
import assemble as AS  # noqa: E402

PIPELINE = Path(__file__).resolve().parent


def safe_name(s):
    return re.sub(r"[^\w\u4e00-\u9fa5-]", "_", str(s))


def load_project(pdir):
    p = Path(pdir)
    f = p / "shots.yaml"
    if not f.exists():
        raise SystemExit(f"项目缺少 shots.yaml：{f}")
    import yaml
    return yaml.safe_load(f.read_text(encoding="utf-8")) or {}


class Runner:
    def __init__(self, project_dir, cfg, dry=False, force=False):
        self.dir = Path(project_dir)
        self.cfg = cfg
        self.dry = dry
        self.force = force
        self.proj = load_project(self.dir)
        self.ff = base.ffmpeg_exe()
        self.state_path = self.dir / ".state.json"
        self.state = json.loads(self.state_path.read_text(encoding="utf-8")) if self.state_path.exists() else {}
        if force:
            for sec in ("image", "video", "tts"):
                self.cfg.setdefault(sec, {})["overwrite"] = True
        self.prefix = (self.proj.get("style_prefix") or "").strip()
        self.card_paths = {}

    def save(self):
        self.state_path.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding="utf-8")

    def d(self, *parts):
        p = self.dir.joinpath(*parts)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def full_prompt(self, p):
        return f"{self.prefix} {p}".strip() if self.prefix else p

    # ---------- 阶段 1：角色卡 / 场景卡 ----------
    def stage_cards(self):
        cards = self.proj.get("cards") or []
        if not cards:
            base.log("无角色卡/场景卡定义，跳过")
            return
        base.log(f"阶段 1/4 角色卡·场景卡（{len(cards)} 张）")
        for c in cards:
            cid = c.get("id") or safe_name(c.get("prompt", "")[:12])
            sub = "角色卡" if c.get("kind") == "char" else "场景卡"
            out = self.d(sub, f"{safe_name(cid)}.png")
            self.card_paths[cid] = out
            base.log(f"  [{cid}] {c.get('prompt','')[:40]}…")
            if self.dry:
                continue
            try:
                base.retry(lambda: image.generate(self.full_prompt(c["prompt"]), out,
                                                  self.cfg.get("image", {}),
                                                  input_image=c.get("input_image")),
                           tries=self.cfg.get("retry", 3))
                self.state.setdefault("cards", {})[cid] = str(out)
            except Exception as e:
                base.log(f"  ✗ {cid} 失败：{e}")
                self.state.setdefault("cards", {})[cid] = f"FAILED: {e}"
        self.save()

    # ---------- 阶段 2：逐镜视频 ----------
    def resolve_refs(self, shot):
        paths = []
        for r in shot.get("refs") or []:
            p = self.card_paths.get(r)
            if p is None:
                cand = self.dir / r
                p = cand if cand.exists() else None
                if p is None:
                    for sub in ("角色卡", "场景卡"):
                        c2 = self.dir / sub / f"{safe_name(r)}.png"
                        if c2.exists():
                            p = c2
                            break
            if p and Path(p).exists():
                paths.append(Path(p))
            else:
                base.log(f"  ⚠️ 参考图缺失：{r}")
        return paths

    def stage_shots(self, only=None):
        shots = self.proj.get("shots") or []
        if only:
            shots = [s for s in shots if s.get("id") in only]
        base.log(f"阶段 2/4 单镜渲染（{len(shots)} 镜）")
        failed = []
        for s in shots:
            sid = s.get("id")
            out = self.d("单镜片段", f"{safe_name(sid)}.mp4")
            refs = self.resolve_refs(s)
            dur = s.get("duration", 5)
            base.log(f"  [{sid}] {dur}s · 参考 {len(refs)} 张")
            if self.dry:
                base.log(f"      prompt: {self.full_prompt(s.get('prompt',''))[:70]}…")
                continue
            try:
                base.retry(lambda: video.render(self.full_prompt(s.get("prompt", "")), out,
                                                self.cfg.get("video", {}),
                                                duration=dur, refs=refs,
                                                resolution=s.get("resolution") or self.proj.get("resolution"),
                                                project_root=self.dir),
                           tries=self.cfg.get("retry", 2))
                self.state.setdefault("shots", {})[sid] = str(out)
            except Exception as e:
                base.log(f"  ✗ {sid} 失败：{e}")
                self.state.setdefault("shots", {})[sid] = f"FAILED: {e}"
                failed.append(sid)
            self.save()
        if failed:
            base.log(f"失败镜头：{','.join(failed)} —— 修好后用 --only {','.join(failed)} 重跑")

    # ---------- 阶段 3：旁白配音 ----------
    def stage_tts(self):
        shots = self.proj.get("shots") or []
        with_nar = [s for s in shots if (s.get("narration") or "").strip()]
        base.log(f"阶段 3/4 旁白配音（{len(with_nar)} 段）")
        if self.dry:
            for s in with_nar:
                base.log(f"  [{s.get('id')}] {s['narration'][:50]}…")
            return
        files = []
        for s in with_nar:
            out = self.d("旁白", f"{safe_name(s.get('id'))}.mp3")
            try:
                r = base.retry(lambda: tts.synth(s["narration"], out, self.cfg.get("tts", {}),
                                                 voice=s.get("voice")), tries=self.cfg.get("retry", 3))
                if r:
                    files.append(Path(r))
                    self.state.setdefault("tts", {})[s["id"]] = str(r)
            except Exception as e:
                base.log(f"  ✗ {s.get('id')} 配音失败：{e}")
            self.save()
        if files:
            full = self.d("旁白", "旁白_全轨.mp3")
            self.concat_audio(files, full)
            base.log(f"  全轨：{full.name}")
        if not files and with_nar:
            base.log("  ⚠️ 全部配音失败，成片将无旁白")

    def check_pace(self, silent):
        """旁白与画面长度对不上是成片最常见的翻车点，提前警告。"""
        nar = self.d("旁白", "旁白_全轨.mp3")
        if not nar.exists():
            return
        vd = base.probe_duration(self.ff, silent)
        nd = base.probe_duration(self.ff, nar)
        if nd > vd + 0.5:
            base.log(f"  ⚠️ 旁白 {nd:.1f}s 长于画面 {vd:.1f}s，尾部会被裁掉 —— 精简文案或加镜头时长")
        elif vd > nd + 2:
            base.log(f"  ⚠️ 画面 {vd:.1f}s 比旁白长 {vd - nd:.1f}s，尾部会留白 —— 可补镜头或加 BGM 铺底")

    def concat_audio(self, files, out):
        if len(files) == 1:
            base.run([self.ff, "-y", "-i", str(files[0]), "-c", "copy", str(out)])
            return out
        cmd = [self.ff, "-y"]
        for f in files:
            cmd += ["-i", str(f)]
        labels = "".join(f"[{i}:a]" for i in range(len(files)))
        cmd += ["-filter_complex", f"{labels}concat=n={len(files)}:v=0:a=1[aout]",
                "-map", "[aout]", "-c:a", "libmp3lame", "-q:a", "2", str(out)]
        r = base.run(cmd)
        if r.returncode != 0:
            base.log(f"  ⚠️ 旁白拼接失败：{r.stderr[-300:]}")
        return out

    # ---------- 阶段 4：合成 ----------
    def stage_assemble(self):
        a = self.proj.get("assemble") or {}
        shots = self.proj.get("shots") or []
        files = [self.d("单镜片段", f"{safe_name(s.get('id'))}.mp4") for s in shots]
        files = [f for f in files if f.exists()]
        if not files:
            raise SystemExit("没有镜头片段可合成，先跑 --stage shots")
        base.log(f"阶段 4/4 合成（{len(files)} 镜）")
        if self.dry:
            base.log(f"  将合成：{', '.join(f.name for f in files)}")
            return

        ts = a.get("target_size")     # 如 "720x1280"，不填则取第一镜尺寸
        target = tuple(int(x) for x in ts.split("x")) if ts else None
        silent = self.d("成片_无声拼接.mp4")
        AS.concat(self.ff, files, silent, transition=a.get("transition", 0.6),
                  target_size=target, fps=a.get("fps"))
        self.check_pace(silent)

        nar = self.d("旁白", "旁白_全轨.mp3")
        bgm = self.dir / a.get("bgm") if a.get("bgm") else None
        mixed = self.d("成片_混音.mp4")
        AS.mix(self.ff, silent, nar if nar.exists() else None, bgm, mixed,
               delay_ms=a.get("narration_delay_ms", 1200),
               bgm_volume=a.get("bgm_volume", 0.32))

        final = self.d(f"成片_{safe_name(self.proj.get('project', 'output'))}.mp4")
        AS.loudnorm(self.ff, mixed, final)
        base.log(f"✅ 成片：{final}（{base.probe_duration(self.ff, final):.1f}s）")
        self.state["final"] = str(final)
        self.save()


def main():
    ap = argparse.ArgumentParser(description="AI 视频生产流水线")
    ap.add_argument("--project", required=True, help="项目目录（含 shots.yaml）")
    ap.add_argument("--stage", default="all",
                    choices=["cards", "shots", "tts", "assemble", "all"])
    ap.add_argument("--only", default="", help="只跑指定镜头，逗号分隔，如 S03,S04")
    ap.add_argument("--config", default=str(PIPELINE / "config.yaml"))
    ap.add_argument("--dry-run", action="store_true", help="只打印计划，不调用 API")
    ap.add_argument("--force", action="store_true", help="覆盖已存在产物")
    args = ap.parse_args()

    cfg = base.load_config(args.config)
    r = Runner(args.project, cfg, dry=args.dry_run, force=args.force)
    only = [x.strip() for x in args.only.split(",") if x.strip()] or None

    if args.stage in ("cards", "all"):
        r.stage_cards()
    if args.stage in ("shots", "all"):
        r.stage_shots(only)
    if args.stage in ("tts", "all"):
        r.stage_tts()
    if args.stage in ("assemble", "all"):
        r.stage_assemble()
    base.log("完成")


if __name__ == "__main__":
    main()
