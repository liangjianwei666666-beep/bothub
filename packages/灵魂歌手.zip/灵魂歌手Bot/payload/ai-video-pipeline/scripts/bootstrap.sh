#!/bin/bash
# ai-video-pipeline · 跨设备装配脚本
# 作用：把流水线装到一个工作目录，建好配置骨架，检查依赖。
# 用法：bash bootstrap.sh [工作目录]      （默认 ~/ai-video）
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${1:-$HOME/ai-video}"

echo "==> skill 目录：$SKILL_DIR"
echo "==> 工作目录：$WORK"

mkdir -p "$WORK"
cd "$WORK"

# 1) 装入流水线代码
cp -R "$SKILL_DIR/scripts/." "$WORK/"
echo "  ✓ 已装入 run.py / assemble.py / adapters/"

# 2) 建配置骨架（已存在则不覆盖，避免冲掉你的 Key）
if [ ! -f "$WORK/config.yaml" ]; then
  cp "$SKILL_DIR/templates/config.example.yaml" "$WORK/config.yaml"
  echo "  ✓ 生成 config.yaml（待填 base_url / model / workflow）"
else
  echo "  · config.yaml 已存在，跳过"
fi

if [ ! -f "$WORK/.env" ]; then
  cp "$SKILL_DIR/templates/.env.example" "$WORK/.env"
  echo "  ✓ 生成 .env（待填 API Key）"
else
  echo "  · .env 已存在，跳过"
fi

# 3) 示例项目
if [ ! -d "$WORK/projects/示例" ]; then
  mkdir -p "$WORK/projects/示例"
  cp "$SKILL_DIR/templates/shots.example.yaml" "$WORK/projects/示例/shots.yaml"
  echo "  ✓ 生成示例项目 projects/示例/shots.yaml"
fi

# 4) gitignore（保护密钥）
if [ ! -f "$WORK/.gitignore" ]; then
  cat > "$WORK/.gitignore" <<'EOF'
.env
.autodl_token
.state.json
__pycache__/
EOF
  echo "  ✓ 生成 .gitignore（.env / token 不会外泄）"
fi

# 5) 依赖检查
echo "==> 检查依赖"
PY="$(command -v python3 || true)"
[ -n "$PY" ] || { echo "  ✗ 找不到 python3"; exit 1; }
echo "  ✓ python3: $($PY -V 2>&1)"

$PY - <<'PYEOF'
import importlib, sys
need = {"yaml": "pyyaml", "requests": "requests", "edge_tts": "edge-tts"}
missing = []
for mod, pkg in need.items():
    try:
        importlib.import_module(mod)
        print(f"  ✓ {pkg}")
    except ImportError:
        print(f"  ✗ {pkg} 未安装")
        missing.append(pkg)
try:
    import imageio_ffmpeg
    print(f"  ✓ imageio-ffmpeg（ffmpeg: {imageio_ffmpeg.get_ffmpeg_exe()}）")
except ImportError:
    print("  ✗ imageio-ffmpeg 未安装")
    missing.append("imageio-ffmpeg")
if missing:
    print("\n缺依赖，请运行：")
    print(f"  {sys.executable} -m pip install " + " ".join(missing))
PYEOF

if command -v ffmpeg >/dev/null 2>&1; then
  echo "  ✓ 系统 ffmpeg: $(command -v ffmpeg)"
else
  echo "  · 无系统 ffmpeg，将使用 imageio-ffmpeg 内置二进制"
fi

cat <<EOF

==> 装配完成。接下来：
  1) 编辑 $WORK/.env         填 API Key
  2) 编辑 $WORK/config.yaml  填 base_url / model / workflow，并把 video.public_base 留待挖隧道后填
  3) 放 token：echo "<你的token>" > $WORK/.autodl_token && chmod 600 $WORK/.autodl_token
  4) 试跑（不烧钱）：
     cd $WORK && python3 run.py --project projects/示例 --stage all --dry-run

参考图公网化（H3 硬要求）：
  python3 -m http.server 8790 -d $WORK/projects/示例 &
  ssh -R 80:localhost:8790 serveo.net
EOF
