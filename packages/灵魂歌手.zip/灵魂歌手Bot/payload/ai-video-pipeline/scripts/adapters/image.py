"""生图适配器：openai_compatible / gemini / autodl（ComfyUI）。

统一入口：
    generate(prompt, out_path, cfg_img, input_image=None) -> Path
cfg_img 来自 config.yaml 的 image: 段。已存在的产物默认跳过（断点续跑）。
"""
import base64
from pathlib import Path

from . import autodl, base


def generate(prompt, out_path, cfg_img, input_image=None):
    out_path = Path(out_path)
    if base.is_valid(out_path, 2048) and not cfg_img.get("overwrite", False):
        base.log(f"  已存在，跳过：{out_path.name}")
        return out_path

    provider = (cfg_img.get("provider") or "openai_compatible").lower()
    if provider == "openai_compatible":
        return _openai_compatible(prompt, out_path, cfg_img, input_image)
    if provider == "gemini":
        return _gemini(prompt, out_path, cfg_img, input_image)
    if provider == "autodl":
        return _autodl(prompt, out_path, cfg_img, input_image)
    raise SystemExit(f"不支持的生图 provider：{provider}")


def _openai_compatible(prompt, out_path, cfg, input_image):
    base_url = (cfg.get("base_url") or "").rstrip("/")
    if not base_url:
        raise SystemExit("config.yaml 缺 image.base_url")
    url = f"{base_url}{cfg.get('path', '/images/generations')}"
    headers = {"Authorization": f"Bearer {cfg.get('api_key','')}", "Content-Type": "application/json"}
    body = {"model": cfg.get("model"), "prompt": prompt, "n": 1, "size": cfg.get("size", "1024x1024")}
    if input_image:
        field = cfg.get("input_field", "image")
        if cfg.get("input_as_url"):
            body[field] = str(input_image)
        else:
            body[field] = [base64.b64encode(Path(input_image).read_bytes()).decode()]
    body.update(cfg.get("extra") or {})

    status, resp = base.http_json("POST", url, headers=headers, body=body, timeout=cfg.get("timeout", 300))
    if status >= 400 or not isinstance(resp, dict):
        raise RuntimeError(f"生图失败 HTTP {status}: {str(resp)[:400]}")

    data = resp.get("data") or []
    if not data:
        raise RuntimeError(f"生图返回为空：{str(resp)[:400]}")
    item = data[0]
    if item.get("b64_json"):
        return base.save_b64(item["b64_json"], out_path)
    if item.get("url"):
        return base.download(item["url"], out_path)
    if resp.get("_raw"):
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(resp["_raw"])
        return out_path
    raise RuntimeError(f"无法解析生图响应：{str(resp)[:400]}")


def _gemini(prompt, out_path, cfg, input_image):
    model = cfg.get("model", "gemini-2.5-flash-image")
    key = cfg.get("api_key") or ""
    base_url = (cfg.get("base_url") or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
    url = f"{base_url}/models/{model}:generateContent?key={key}"
    parts = [{"text": prompt}]
    if input_image:
        parts.append({"inline_data": {
            "mime_type": "image/png",
            "data": base64.b64encode(Path(input_image).read_bytes()).decode(),
        }})
    body = {
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": {"responseModalities": ["IMAGE"]},
    }
    body.update(cfg.get("extra") or {})
    status, resp = base.http_json("POST", url, headers={"Content-Type": "application/json"},
                                  body=body, timeout=cfg.get("timeout", 300))
    if status >= 400 or not isinstance(resp, dict):
        raise RuntimeError(f"Gemini 生图失败 HTTP {status}: {str(resp)[:400]}")
    parts_out = (((resp.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
    for p in parts_out:
        b64 = (p.get("inlineData") or p.get("inline_data") or {}).get("data")
        if b64:
            return base.save_b64(b64, out_path)
    raise RuntimeError(f"Gemini 未返回图片：{str(resp)[:400]}")


def _autodl(prompt, out_path, cfg, input_image):
    adl = cfg.get("autodl") or {}
    workflow = adl.get("workflow")
    if not workflow:
        raise SystemExit("config.yaml 缺 image.autodl.workflow（AutoDL 文生图工作流 id）")
    body = {"prompt": prompt}
    if input_image:
        body["image"] = str(input_image)  # 图生图工作流按需调整字段名
    body.update(adl.get("extra") or {})
    return Path(autodl.run_workflow(adl, workflow, body, out_path))
