"""语音合成适配器：edge_tts（免费，中文效果好）/ openai_compatible / doubao（火山 seed-tts-2.0）。

统一入口：
    synth(text, out_path, cfg_tts, voice=None) -> Path
"""
import base64
import json
import uuid
from pathlib import Path

from . import base


def synth(text, out_path, cfg_tts, voice=None):
    out_path = Path(out_path)
    if base.is_valid(out_path, 1024) and not cfg_tts.get("overwrite", False):
        base.log(f"  已存在，跳过：{out_path.name}")
        return out_path
    if not text.strip():
        return None

    provider = (cfg_tts.get("provider") or "edge_tts").lower()
    if provider == "edge_tts":
        return _edge_tts(text, out_path, cfg_tts, voice)
    if provider == "openai_compatible":
        return _openai_compatible(text, out_path, cfg_tts, voice)
    if provider == "doubao":
        return _doubao(text, out_path, cfg_tts, voice)
    raise SystemExit(f"不支持的语音 provider：{provider}")


def _edge_tts(text, out_path, cfg, voice):
    import asyncio
    try:
        import edge_tts
    except ImportError:
        raise SystemExit("缺 edge-tts：pip install edge-tts（或改用 provider: openai_compatible）")
    v = voice or cfg.get("voice", "zh-CN-YunxiNeural")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    async def _run():
        comm = edge_tts.Communicate(text, v, rate=cfg.get("rate", "-10%"),
                                    volume=cfg.get("volume", "+0%"), pitch=cfg.get("pitch", "+0Hz"))
        await comm.save(str(out_path))

    asyncio.run(_run())
    if not base.is_valid(out_path, 1024):
        size = out_path.stat().st_size if out_path.exists() else 0
        out_path.unlink(missing_ok=True)
        raise RuntimeError(f"合成结果异常（{size} 字节），将重试")
    base.log(f"  edge-tts 完成：{out_path.name}（{v}）")
    return out_path


def _openai_compatible(text, out_path, cfg, voice):
    base_url = (cfg.get("base_url") or "").rstrip("/")
    if not base_url:
        raise SystemExit("config.yaml 缺 tts.base_url")
    body = {
        "model": cfg.get("model", "tts-1"),
        "input": text,
        "voice": voice or cfg.get("voice", "alloy"),
        "response_format": cfg.get("format", "mp3"),
    }
    body.update(cfg.get("extra") or {})
    status, resp = base.http_json("POST", f"{base_url}{cfg.get('path','/audio/speech')}",
                                  headers={"Authorization": f"Bearer {cfg.get('api_key','')}",
                                           "Content-Type": "application/json"},
                                  body=body, timeout=cfg.get("timeout", 120))
    if status >= 400:
        raise RuntimeError(f"TTS 失败 HTTP {status}: {str(resp)[:300]}")
    raw = resp.get("_raw") if isinstance(resp, dict) else None
    if not raw:
        raise RuntimeError(f"TTS 未返回音频：{str(resp)[:300]}")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(raw)
    return out_path


def _doubao(text, out_path, cfg, voice):
    """火山 v3 单向流式：NDJSON 逐行 base64 音频分片。"""
    api_key = cfg.get("api_key") or ""
    if not api_key:
        raise SystemExit("config.yaml 缺 tts.api_key（火山方舟 / 豆包语音 Key）")
    endpoint = cfg.get("endpoint", "https://openspeech.bytedance.com/api/v3/plan/tts/unidirectional")
    body = json.dumps({
        "req_params": {"text": text, "speaker": voice or cfg.get("voice")},
        "audio_params": {
            "format": cfg.get("format", "mp3"),
            "sample_rate": cfg.get("sample_rate", 24000),
            "speech_rate": cfg.get("speech_rate", 0),
            "loudness_rate": cfg.get("loudness_rate", 0),
        },
    }, ensure_ascii=False).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "X-Api-Key": api_key,
        "X-Api-Resource-Id": cfg.get("resource_id", "seed-tts-2.0"),
        "X-Api-Request-Id": str(uuid.uuid4()),
    }
    status, resp = base.http_json("POST", endpoint, headers=headers,
                                  body=json.loads(body.decode("utf-8")), timeout=cfg.get("timeout", 120))
    if status >= 400:
        raise RuntimeError(f"豆包 TTS 失败 HTTP {status}: {str(resp)[:300]}")
    raw = resp.get("_raw") if isinstance(resp, dict) else None
    if not raw:
        raise RuntimeError(f"豆包 TTS 无音频：{str(resp)[:300]}")
    chunks = []
    for line in raw.decode("utf-8", "ignore").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        code = obj.get("code", 0)
        if code not in (0, 20000000):
            raise RuntimeError(f"豆包 TTS 错误 code={code}: {str(obj)[:300]}")
        if obj.get("data"):
            chunks.append(base64.b64decode(obj["data"]))
    if not chunks:
        raise RuntimeError("豆包 TTS 未拼接出音频分片")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(b"".join(chunks))
    base.log(f"  豆包 TTS 完成：{out_path.name}")
    return out_path
