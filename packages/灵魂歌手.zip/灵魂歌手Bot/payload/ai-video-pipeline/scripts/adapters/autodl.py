"""AutoDL ComfyUI 异步任务：提交 + 轮询 + 下载（图/视频共用）。"""
import time
from pathlib import Path

from . import base

BASE_URL = "https://autodl.art/api/v1/comfyui"


def token(cfg_adl):
    tok = cfg_adl.get("token") or ""
    if not tok:
        tf = cfg_adl.get("token_file")
        if tf and Path(tf).exists():
            tok = Path(tf).read_text(encoding="utf-8").strip()
    if not tok:
        raise SystemExit("AutoDL token 缺失：请在 config.yaml 填 video.autodl.token 或 token_file")
    return tok


def submit(workflow, body, tok):
    url = f"{BASE_URL}/comfyui_workflow/{workflow}"
    status, resp = base.http_json(
        "POST", url,
        headers={"Authorization": tok, "Content-Type": "application/json"},
        body=body, timeout=60,
    )
    if status >= 400 or not isinstance(resp, dict):
        raise RuntimeError(f"提交失败 HTTP {status}: {str(resp)[:300]}")
    task_id = resp.get("task_id") or resp.get("id") or (resp.get("data") or {}).get("task_id")
    if not task_id:
        raise RuntimeError(f"未拿到 task_id：{str(resp)[:300]}")
    return task_id


def poll(task_id, tok, timeout=1800, interval=10):
    url = f"{BASE_URL}/result/{task_id}"
    deadline = time.time() + timeout
    waited = 0
    while time.time() < deadline:
        status, resp = base.http_json("GET", url, headers={"Authorization": tok}, timeout=60)
        data = resp if isinstance(resp, dict) else {}
        inner = data.get("data") or data
        state = str(inner.get("status") or inner.get("state") or data.get("status") or "").upper()
        if state in ("SUCCESS", "DONE", "COMPLETED"):
            return inner
        if state in ("FAILED", "ERROR", "CANCELLED"):
            raise RuntimeError(f"任务失败：{str(inner)[:300]}")
        time.sleep(interval)
        waited += interval
        if waited % 60 == 0:
            base.log(f"  排队中… 已等 {waited}s（AutoDL 视频队列常态 5-15 分钟）")
    raise TimeoutError(f"轮询超时 {timeout}s，task_id={task_id}（可重跑本镜，脚本会续跑）")


def extract_urls(inner):
    urls = []
    for key in ("results", "result", "outputs", "images", "videos"):
        val = inner.get(key)
        if isinstance(val, list):
            for item in val:
                if isinstance(item, str):
                    urls.append(item)
                elif isinstance(item, dict):
                    u = item.get("url") or item.get("file") or item.get("path")
                    if u:
                        urls.append(u)
        elif isinstance(val, str):
            urls.append(val)
    return urls


def run_workflow(cfg_adl, workflow, body, out_path, timeout=None, interval=None):
    """提交→轮询→下载第一个产物，返回本地路径。"""
    tok = token(cfg_adl)
    task_id = submit(workflow, body, tok)
    base.log(f"  已提交 task_id={task_id}")
    inner = poll(task_id, tok,
                 timeout=timeout or cfg_adl.get("timeout", 1800),
                 interval=interval or cfg_adl.get("poll_interval", 10))
    urls = extract_urls(inner)
    if not urls:
        raise RuntimeError(f"任务结束但无产物 URL：{str(inner)[:300]}")
    base.download(urls[0], out_path)
    base.log(f"  已下载：{out_path}")
    return out_path
