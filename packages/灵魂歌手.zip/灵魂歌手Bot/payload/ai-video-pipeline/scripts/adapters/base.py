"""公共工具：配置加载、环境变量展开、HTTP、下载、重试、ffmpeg 定位。"""
import json
import os
import re
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path

PIPELINE_DIR = Path(__file__).resolve().parent.parent
ROOT = PIPELINE_DIR.parent

ENV_PATTERN = re.compile(r"^\$\{([A-Z0-9_]+)\}$")


def work_dir():
    """工作目录：$SOUL_WORK，默认 ~/Desktop/音乐创作（安装脚本建的就是它）。"""
    return Path(os.environ.get("SOUL_WORK") or (Path.home() / "Desktop/音乐创作"))


def load_dotenv(path=None):
    """把 .env 里的 KEY=VALUE 注入 os.environ（不覆盖已有值）。

    分发版：除了 pipeline/.env，也读工作目录的 .env —— 安装脚本只生成后一个，
    所以两条都读，用户填一个地方就够。
    """
    targets = [Path(path) if path else PIPELINE_DIR / ".env", work_dir() / ".env"]
    for t in targets:
        _load_one(t)


def _load_one(path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        if k.startswith("export "):
            k = k[7:].strip()
        os.environ.setdefault(k, v.strip().strip("\"'"))


def expand(value):
    """递归把 '${VAR}' 展开为环境变量值。"""
    if isinstance(value, dict):
        return {k: expand(v) for k, v in value.items()}
    if isinstance(value, list):
        return [expand(v) for v in value]
    if isinstance(value, str):
        m = ENV_PATTERN.match(value.strip())
        if m:
            return os.environ.get(m.group(1), "")
        return value
    return value


def load_config(path=None):
    import yaml  # 延迟导入，报错信息更友好
    path = Path(path) if path else PIPELINE_DIR / "config.yaml"
    if not path.exists():
        raise SystemExit(f"找不到配置文件：{path}\n请复制 config.example.yaml 为 config.yaml 后填写。")
    cfg = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    load_dotenv()
    return expand(cfg)


def http_json(method, url, headers=None, body=None, timeout=60):
    """返回 (status, dict_or_None)。非 2xx 不抛异常，便于上层决策。"""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            try:
                return resp.status, json.loads(raw.decode("utf-8"))
            except Exception:
                return resp.status, {"_raw": raw}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw.decode("utf-8"))
        except Exception:
            return e.code, {"_raw": raw, "_text": raw.decode("utf-8", "ignore")}
    except Exception as e:
        return 0, {"_error": str(e)}


def download(url, dest, timeout=180):
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as f:
        f.write(resp.read())
    return dest


def save_b64(data, dest):
    import base64
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(base64.b64decode(data))
    return dest


def retry(fn, tries=3, delay=2.0, on_fail=None):
    last = None
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            last = e
            if on_fail:
                on_fail(i + 1, e)
            if i < tries - 1:
                time.sleep(delay * (i + 1))
    raise last


def is_valid(path, min_bytes=1024):
    """产物是否有效：存在且体积达标。防止 0 字节/截断文件被当成已完成。"""
    p = Path(path)
    return p.exists() and p.stat().st_size >= min_bytes


def ffmpeg_exe(cfg=None):
    """优先系统 ffmpeg，其次 imageio_ffmpeg 内置二进制。"""
    import shutil
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        raise SystemExit("找不到 ffmpeg：请 brew install ffmpeg，或 pip install imageio-ffmpeg")


def run(cmd, quiet=True):
    return subprocess.run(cmd, capture_output=quiet, text=True)


def probe_duration(ff, path):
    r = run([ff, "-i", str(path)])
    m = re.search(r"Duration: (\d+):(\d+):(\d+)\.(\d+)", r.stderr)
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)) + int(m.group(4)) / 100


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)
