"""视频生成适配器：autodl（ComfyUI H3）/ openai_compatible 异步 / gemini veo。

统一入口：
    render(prompt, out_path, cfg_vid, duration=5, refs=None, resolution=None) -> Path
refs 为本地参考图路径列表（角色卡/场景卡）。
⚠️ AutoDL 只认公网 http(s) URL，base64 会被静默忽略 —— 需配 public_base（隧道域名）。
"""
from pathlib import Path

from . import autodl, base


def public_url(local_path, public_base, project_root):
    """本地参考图 → 公网 URL。未配 public_base 时提醒开隧道。"""
    local_path = Path(local_path)
    if not public_base:
        base.log(f"  ⚠️ 未配 video.public_base，参考图 {local_path.name} 只能传本地路径，"
                 f"AutoDL 会静默忽略。建议：python3 -m http.server 8790 + serveo/localhost.run 隧道")
        return str(local_path)
    try:
        rel = local_path.relative_to(Path(project_root))
    except ValueError:
        rel = Path(local_path.name)
    return f"{public_base.rstrip('/')}/{rel.as_posix()}"


def render(prompt, out_path, cfg_vid, duration=5, refs=None, resolution=None, project_root=None):
    out_path = Path(out_path)
    if base.is_valid(out_path, 20480) and not cfg_vid.get("overwrite", False):
        base.log(f"  已存在，跳过：{out_path.name}")
        return out_path

    provider = (cfg_vid.get("provider") or "autodl").lower()
    refs = refs or []
    if provider == "autodl":
        return _autodl(prompt, out_path, cfg_vid, duration, refs, resolution, project_root)
    if provider == "openai_compatible":
        return _openai_compatible(prompt, out_path, cfg_vid, duration, refs, resolution, project_root)
    if provider == "gemini":
        return _gemini(prompt, out_path, cfg_vid, duration, refs, resolution, project_root)
    raise SystemExit(f"不支持的视频 provider：{provider}")


def _autodl(prompt, out_path, cfg, duration, refs, resolution, project_root):
    adl = cfg.get("autodl") or {}
    workflow = adl.get("workflow", "minimax_h3_lightx2v_v5")
    body = {
        "prompt": prompt,
        "duration": duration,
        "resolution": (resolution or cfg.get("resolution") or "768p竖"),
    }
    for i, r in enumerate(refs[:9]):
        body[f"ref_image_{i}"] = public_url(r, cfg.get("public_base"), project_root)
    body.update(adl.get("extra") or {})
    base.log(f"  参考图 {len(refs[:9])} 张（H3 要求 ≥2，否则人物会漂移）")
    return Path(autodl.run_workflow(adl, workflow, body, out_path))


def _openai_compatible(prompt, out_path, cfg, duration, refs, resolution, project_root):
    base_url = (cfg.get("base_url") or "").rstrip("/")
    if not base_url:
        raise SystemExit("config.yaml 缺 video.base_url")
    headers = {"Authorization": f"Bearer {cfg.get('api_key','')}", "Content-Type": "application/json"}
    body = {
        "model": cfg.get("model"),
        "prompt": prompt,
        cfg.get("duration_field", "seconds"): duration,
    }
    if resolution or cfg.get("resolution"):
        body[cfg.get("size_field", "size")] = resolution or cfg["resolution"]
    if refs:
        field = cfg.get("ref_field", "input_reference")
        body[field] = [public_url(r, cfg.get("public_base"), project_root) for r in refs]
    body.update(cfg.get("extra") or {})

    status, resp = base.http_json("POST", f"{base_url}{cfg.get('submit_path','/videos')}",
                                  headers=headers, body=body, timeout=cfg.get("timeout", 120))
    if status >= 400 or not isinstance(resp, dict):
        raise RuntimeError(f"视频提交失败 HTTP {status}: {str(resp)[:400]}")
    job_id = resp.get("id") or resp.get("task_id") or (resp.get("data") or {}).get("id")
    if not job_id:
        raise RuntimeError(f"未拿到任务 id：{str(resp)[:400]}")
    base.log(f"  已提交 job_id={job_id}")

    import time
    deadline = time.time() + cfg.get("poll_timeout", 1800)
    interval = cfg.get("poll_interval", 10)
    while time.time() < deadline:
        st, r = base.http_json("GET", f"{base_url}{cfg.get('status_path','/videos')}/{job_id}",
                               headers=headers, timeout=60)
        d = r if isinstance(r, dict) else {}
        state = str(d.get("status") or d.get("state") or "").lower()
        if state in ("completed", "succeeded", "success", "done"):
            url = (d.get("url") or d.get("video_url")
                   or ((d.get("data") or [{}])[0].get("url") if isinstance(d.get("data"), list) else None)
                   or ((d.get("data") or {}).get("url") if isinstance(d.get("data"), dict) else None))
            if not url:
                raise RuntimeError(f"任务完成但无下载 URL：{str(d)[:400]}")
            return base.download(url, out_path)
        if state in ("failed", "error", "cancelled"):
            raise RuntimeError(f"视频任务失败：{str(d)[:400]}")
        time.sleep(interval)
    raise TimeoutError(f"轮询超时，job_id={job_id}")


def _gemini(prompt, out_path, cfg, duration, refs, resolution, project_root):
    base_url = (cfg.get("base_url") or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
    model = cfg.get("model", "veo-3.0-generate-001")
    key = cfg.get("api_key") or ""
    instance = {"prompt": prompt}
    if refs:
        instance["image"] = {"gcsUri": public_url(refs[0], cfg.get("public_base"), project_root)}
    body = {"instances": [instance], "parameters": {"durationSeconds": duration}}
    body.update(cfg.get("extra") or {})

    status, resp = base.http_json("POST", f"{base_url}/models/{model}:predictLongRunning?key={key}",
                                  headers={"Content-Type": "application/json"}, body=body, timeout=120)
    if status >= 400 or not isinstance(resp, dict):
        raise RuntimeError(f"Veo 提交失败 HTTP {status}: {str(resp)[:400]}")
    op = resp.get("name")
    if not op:
        raise RuntimeError(f"未拿到 operation：{str(resp)[:400]}")

    import time
    deadline = time.time() + cfg.get("poll_timeout", 1800)
    while time.time() < deadline:
        st, r = base.http_json("GET", f"{base_url}/{op}?key={key}", timeout=60)
        d = r if isinstance(r, dict) else {}
        if d.get("done"):
            vids = ((d.get("response") or {}).get("generatedVideos") or [])
            if not vids:
                raise RuntimeError(f"Veo 无产物：{str(d)[:400]}")
            uri = vids[0].get("video", {}).get("uri")
            return base.download(f"{uri}&key={key}" if "?" in uri else f"{uri}?key={key}", out_path)
        time.sleep(cfg.get("poll_interval", 15))
    raise TimeoutError("Veo 轮询超时")
