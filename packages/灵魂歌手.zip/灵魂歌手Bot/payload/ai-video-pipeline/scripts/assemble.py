"""ffmpeg 合成：xfade 拼接 → 旁白/BGM 混音 → 响度归一化 → 抽帧。

踩过的坑都写死在这里了：
1) xfade 的 offset 必须动态（累计时长 - 转场时长），硬编码会截断前面所有内容
2) 输出强制 yuv420p
3) 响度必须 loudnorm 到 -16 LUFS，否则 edge-tts 出来的声音偏小
"""
import re
from pathlib import Path

from adapters import base


def probe_video_info(ff, path):
    """从 ffmpeg 输出里抓 (宽, 高, fps)。"""
    r = base.run([ff, "-i", str(path)])
    m = re.search(r"Video:.*?(\d{2,5})x(\d{2,5})", r.stderr)
    f = re.search(r"(\d+(?:\.\d+)?) fps", r.stderr)
    w, h = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
    return w, h, float(f.group(1)) if f else 24.0


def normalize(ff, files, outdir, target=None, fps=None, crf=20):
    """把所有片段统一到同一分辨率/帧率，否则 xfade 会报尺寸不匹配。"""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    if not target:
        w0, h0, f0 = probe_video_info(ff, files[0])
        target, fps = (w0, h0), fps or f0
    fps = fps or 24
    w, h = target[0] - target[0] % 2, target[1] - target[1] % 2
    outs = []
    for i, f in enumerate(files, 1):
        iw, ih, ifps = probe_video_info(ff, f)
        if (iw, ih) == (w, h) and abs(ifps - fps) < 0.1:
            outs.append(Path(f))
            continue
        base.log(f"  归一化 {Path(f).name}: {iw}x{ih}@{ifps} → {w}x{h}@{fps}")
        out = outdir / f"n_{i:02d}.mp4"
        vf = (f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
              f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps}")
        r = base.run([ff, "-y", "-i", str(f), "-vf", vf, "-an", "-c:v", "libx264",
                      "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p", str(out)])
        if r.returncode != 0 or not out.exists():
            raise RuntimeError(f"归一化失败 {f}: {r.stderr[-300:]}")
        outs.append(out)
    return outs


def has_audio(ff, path):
    r = base.run([ff, "-i", str(path)])
    return "Audio:" in r.stderr


def concat(ff, shot_files, out, transition=0.6, crf=20, target_size=None, fps=None):
    """带 xfade 转场拼接视频轨（音轨后期统一加）。"""
    shot_files = [Path(f) for f in shot_files]
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if not shot_files:
        raise SystemExit("没有可拼接的镜头片段")
    shot_files = normalize(ff, shot_files, out.parent / "_tmp_norm",
                           target=target_size, fps=fps, crf=crf)
    if len(shot_files) == 1:
        base.run([ff, "-y", "-i", str(shot_files[0]), "-an", "-c:v", "libx264",
                  "-preset", "medium", "-crf", str(crf), "-pix_fmt", "yuv420p", str(out)])
        return out

    cur, acc = shot_files[0], base.probe_duration(ff, shot_files[0])
    tmp_dir = out.parent / "_tmp_concat"
    tmp_dir.mkdir(exist_ok=True)
    for i, nxt in enumerate(shot_files[1:], 1):
        tmp = tmp_dir / f"xf_{i:02d}.mp4"
        off = max(acc - transition, 0)
        base.run([ff, "-y", "-i", str(cur), "-i", str(nxt), "-filter_complex",
                  f"[0:v][1:v]xfade=transition=fade:duration={transition}:offset={off:.2f},"
                  f"format=yuv420p[v]", "-map", "[v]", "-an",
                  "-c:v", "libx264", "-preset", "medium", "-crf", str(crf), str(tmp)])
        acc = acc + base.probe_duration(ff, nxt) - transition
        cur = tmp
    Path(cur).rename(out)
    base.log(f"拼接完成：{out.name}（{acc:.1f}s，{len(shot_files)} 镜）")
    return out


def mix(ff, video, narration, bgm, out, delay_ms=1200, bgm_volume=0.32, duration=None):
    """视频 + 旁白（延迟）+ BGM（侧链闪避）→ 成片。"""
    video, out = Path(video), Path(out)
    inputs = [ff, "-y", "-i", str(video)]
    dur = duration or base.probe_duration(ff, video)
    va = has_audio(ff, video)

    if narration and Path(narration).exists():
        inputs += ["-i", str(narration)]
        nar_idx = 1
    else:
        nar_idx = None
    if bgm and Path(bgm).exists():
        inputs += ["-i", str(bgm)]
        bgm_idx = (1 if nar_idx is None else 2)
    else:
        bgm_idx = None

    parts, labels = [], []
    if nar_idx is not None:
        parts.append(f"[{nar_idx}:a]adelay={delay_ms}|{delay_ms},apad[nar]")
        labels.append("[nar]")
    if bgm_idx is not None:
        parts.append(f"[{bgm_idx}:a]volume={bgm_volume}[bg]")
        if va:
            parts.append("[bg][0:a]sidechaincompress=threshold=0.03:ratio=8:attack=50:release=300[bgd]")
            labels.append("[bgd]")
        else:
            labels.append("[bg]")
    if va:
        labels.append("[0:a]")
    if not labels:
        raise SystemExit("没有可混的音轨（既无旁白也无 BGM，视频本身也无声）")

    if len(labels) == 1:
        parts.append(f"{labels[0]}atrim=0:{dur:.2f}[aout]")
    else:
        parts.append("".join(labels) + f"amix=inputs={len(labels)}:duration=first:normalize=0,"
                                       f"atrim=0:{dur:.2f}[aout]")
    fc = ";".join(parts)
    inputs += ["-filter_complex", fc, "-map", "0:v", "-map", "[aout]",
               "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", f"{dur:.2f}", str(out)]
    r = base.run(inputs)
    if r.returncode != 0:
        raise RuntimeError(f"混音失败：{r.stderr[-800:]}")
    base.log(f"混音完成：{out.name}")
    return out


def loudnorm(ff, src, out, i=-16, tp=-1.5, lra=11):
    r = base.run([ff, "-y", "-i", str(src), "-af", f"loudnorm=I={i}:TP={tp}:LRA={lra}",
                  "-c:v", "copy", "-c:a", "aac", str(out)])
    if r.returncode != 0:
        raise RuntimeError(f"响度归一化失败：{r.stderr[-500:]}")
    return Path(out)


def extract_frames(ff, video, times, outdir, name="frame"):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    paths = []
    for i, t in enumerate(times, 1):
        p = outdir / f"{name}_{i:02d}_{t}s.jpg"
        base.run([ff, "-y", "-ss", str(t), "-i", str(video), "-frames:v", "1", "-q:v", "2", str(p)])
        if p.exists():
            paths.append(p)
    return paths
