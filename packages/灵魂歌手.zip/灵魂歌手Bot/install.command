#!/usr/bin/env bash
# macOS 双击入口：跑装配 + 自检，然后停住等你看结果。
HERE="$(cd "$(dirname "$0")" && pwd)"
/bin/bash "$HERE/install.sh" "$@"
INSTALL_RC=$?
echo
echo "------------------------------------------"
echo "  安装退出码：$INSTALL_RC（0 = 成功）"
echo "------------------------------------------"
echo
/bin/bash "$HERE/selfcheck.sh" || true
echo
read -r -p "按回车关闭这个窗口…" _ || true
