#!/usr/bin/env bash
# 灵魂歌手 Bot · 一键装配脚本
#
# 用法：
#   bash install.sh                      # 装到默认位置
#   bash install.sh --work=~/我的MV        # 自定义工作目录
#   bash install.sh --skills=~/.agents/skills
#   bash install.sh --force              # 已存在的同名技能先备份再覆盖
#
# 幂等：重复执行不会覆盖用户已有技能（除非 --force），会生成带时间戳的备份。
set -euo pipefail

VERSION="1.2.0"
NAME="灵魂歌手 Bot"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

WORK="${SOUL_WORK:-$HOME/Desktop/音乐创作}"
SKILLS="${SOUL_SKILLS:-$HOME/.agents/skills}"
FORCE=0
WITH_SKILLS=1

SKILL_LIST="five-platform-publish micro-song lyric-story-mv lyric-loop-video cover-publish ai-video-pipeline autodl-video kie-models character-consistency"

for arg in "$@"; do
  case "$arg" in
    --work=*)   WORK="${arg#*=}" ;;
    --skills=*) SKILLS="${arg#*=}" ;;
    --force)    FORCE=1 ;;
    --no-skills) WITH_SKILLS=0 ;;
    -h|--help)
      sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'
      exit 0 ;;
    -*) echo "未知参数：$arg（用 --help 看用法）" >&2; exit 1 ;;
    *)  WORK="$arg" ;;
  esac
done

say()  { printf '%s\n' "$*"; }
ok()   { printf '  ✓ %s\n' "$*"; }
warn() { printf '  ! %s\n' "$*"; }
die()  { printf '\n✗ %s\n' "$*" >&2; exit 1; }

jsonesc() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }

find_node() {
  if command -v node >/dev/null 2>&1; then command -v node; return; fi
  cand="$(ls -d "$HOME"/.nvm/versions/node/*/bin/node /opt/homebrew/bin/node /usr/local/bin/node "$HOME"/.volta/bin/node 2>/dev/null | sort -V | tail -1)"
  if [ -n "$cand" ] && [ -x "$cand" ]; then printf '%s\n' "$cand"; fi
  return 0
}

say "=========================================="
say "  $NAME · 一键装配  v$VERSION"
say "=========================================="
say "  安装包：$PKG"
say "  工作目录：$WORK"
say "  技能目录：$SKILLS"
say ""

# ---------- 0. 前置检查 ----------
[ -d "$PKG/payload" ] || die "安装包不完整：缺少 payload/ 目录。请重新解压完整压缩包。"
if [ "$WITH_SKILLS" = "1" ]; then
  mkdir -p "$SKILLS" 2>/dev/null || true
  [ -w "$SKILLS" ] || die "没有写入权限：$SKILLS
  → 这是 DS Bot 沙箱（workspace-write）的限制，不是文件属主问题，sudo/chown 治不了。
  → 办法：在 Bot 设置里把这个目录加入可写范围，或用更高权限重跑本脚本；也可以 --skills=<另一个可写目录> 换个位置装。"

fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$WORK/.install-backup/$STAMP"

# ---------- 1. 工作目录骨架 ----------
mkdir -p "$WORK" "$WORK/projects" "$WORK/assets" "$WORK/out" "$WORK/publish" "$WORK/.publish-tools"
ok "工作目录骨架：projects/ assets/ out/ publish/ .publish-tools/"

# ---------- 2. 工作台 ----------
BENCH_SRC="$PKG/payload/工作台/灵魂歌手工作台.html"
BENCH_DST="$WORK/灵魂歌手工作台.html"
if [ -f "$BENCH_SRC" ]; then
  if [ -f "$BENCH_DST" ]; then
    mkdir -p "$BACKUP"; cp "$BENCH_DST" "$BACKUP/灵魂歌手工作台.html.bak"
    warn "工作台已存在，旧版备份到 $BACKUP/"
  fi
  cp "$BENCH_SRC" "$BENCH_DST"
  ok "工作台：$BENCH_DST"
else
  warn "安装包里没有工作台 HTML（跳过）"
fi

# ---------- 3. 技能 ----------
INSTALLED=""
SKIPPED=""
if [ "$WITH_SKILLS" = "1" ]; then
  for s in $SKILL_LIST; do
    SRC="$PKG/payload/$s"
    DST="$SKILLS/$s"
    [ -d "$SRC" ] || { warn "缺技能 $s（安装包不完整）"; continue; }
    if [ -d "$DST" ] && [ ! -f "$DST/SKILL.md" ]; then
      # 目录在但没有 SKILL.md = 上次装了一半，直接补装（不占用 --force）
      warn "$s 目录残缺（缺 SKILL.md），本次补装"
      mkdir -p "$BACKUP"; cp -R "$DST" "$BACKUP/$s.broken" 2>/dev/null || true
      rm -rf "$DST"
    elif [ -d "$DST" ]; then
      if [ "$FORCE" != "1" ]; then
        SKIPPED="$SKIPPED $s"
        warn "$s 已存在，跳过（要覆盖加 --force）"
        continue
      fi
      mkdir -p "$BACKUP"; cp -R "$DST" "$BACKUP/$s.bak"
      rm -rf "$DST"
      warn "$s 旧版已备份后覆盖"
    fi
    cp -R "$SRC" "$DST"
    INSTALLED="$INSTALLED $s"
    ok "技能 $s"
  done
  # 脚本可执行位
  for s in $INSTALLED; do
    chmod +x "$SKILLS/$s"/scripts/*.sh 2>/dev/null || true
  done
  INSTALLED="$(printf '%s' "$INSTALLED" | sed 's/^ *//')"
  SKIPPED="$(printf '%s' "$SKIPPED" | sed 's/^ *//')"
else
  warn "按参数跳过技能安装（--no-skills）"
fi

# ---------- 4. 密钥文件（不含任何密钥） ----------
# 约定：所有技能都读同一个文件 $WORK/.env（song.py 与 pipeline 的 adapters 已按这个路径实现）。
ENVF="$WORK/.env"
if [ ! -f "$ENVF" ]; then
  cat > "$ENVF" <<'EOF'
# 灵魂歌手 Bot · 密钥文件
# 填好保存即可：song.py 与流水线的 adapters 会自动读这个文件，不需要写进 shell 配置。
# 本文件由安装脚本生成，里面**不含任何真实密钥**。

# 1) 出歌（KIE / Suno）—— 必需
KIE_API_KEY=

# 2) 生图（任意 OpenAI 兼容的生图接口）—— 出画面必需，用哪家填哪家
IMAGE_API_BASE=
IMAGE_API_KEY=

# 3) 视频（AutoDL Art / ComfyUI 网关，MiniMax H3 工作流）—— 对口型 MV 必需
AUTODL_API_BASE=
AUTODL_API_KEY=

# 想在 shell 里直接调接口时（可选）：
#   set -a; . "$HOME/Desktop/音乐创作/.env"; set +a
# 发布不需要密钥：Bot 驱动你自己已登录的浏览器，不代登录、不存密码。
EOF
  chmod 600 "$ENVF" 2>/dev/null || true
  ok "密钥文件：$ENVF（空的，待填；脚本会自动读）"
else
  warn "$ENVF 已存在，保留不动（不会覆盖你填过的 key）"
fi

# ---------- 5. 环境体检（只报告，不安装） ----------
say ""
say "环境体检："
NODE_BIN=""; NODE_BIN="$(find_node)"; [ -n "$NODE_BIN" ] && NODE_OK="yes" || NODE_OK="no"
PY_OK="no";   command -v python3 >/dev/null 2>&1 && PY_OK="yes"
FFMPEG_OK="no"
for c in "$HOME/bin/ffmpeg" /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg /usr/bin/ffmpeg; do
  [ -x "$c" ] && FFMPEG_OK="$c" && break
done
say "  node   : $( [ "$NODE_OK" = yes ] && "$NODE_BIN" -v || echo '缺失（发布脚本与生图/视频脚本需要）' )"
say "  python3: $( [ "$PY_OK" = yes ] && python3 -V 2>&1 || echo '缺失（部分流水线脚本需要）' )"
say "  ffmpeg : $( [ "$FFMPEG_OK" != no ] && echo "$FFMPEG_OK" || echo '缺失（剪辑/合成/字幕烧录需要，装好后再跑）' )"

# ---------- 6. 安装报告 ----------
REPORT_JSON="$WORK/安装报告.json"
REPORT_MD="$WORK/安装报告.md"
cat > "$REPORT_JSON" <<EOF
{
  "package": "$(jsonesc "$NAME")",
  "version": "$VERSION",
  "installedAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "workDir": "$(jsonesc "$WORK")",
  "skillsDir": "$(jsonesc "$SKILLS")",
  "workbench": "$(jsonesc "$BENCH_DST")",
  "skillsInstalled": "$(jsonesc "$INSTALLED")",
  "skillsSkipped": "$(jsonesc "$SKIPPED")",
  "node": "$NODE_OK",
  "python3": "$PY_OK",
  "ffmpeg": "$(jsonesc "$FFMPEG_OK")",
  "backupDir": "$(jsonesc "$BACKUP")"
}
EOF

cat > "$REPORT_MD" <<EOF
# $NAME 安装报告

- 版本：$VERSION
- 安装时间：$(date '+%Y-%m-%d %H:%M:%S')
- 工作目录：\`$WORK\`
- 技能目录：\`$SKILLS\`
- 新装技能：${INSTALLED:-（无）}
- 跳过（已存在）：${SKIPPED:-（无）}
- 备份目录：\`$BACKUP\`（没有覆盖任何文件时可能为空）

## 环境

| 依赖 | 状态 |
|---|---|
| node | $NODE_OK |
| python3 | $PY_OK |
| ffmpeg | $FFMPEG_OK |

## 还没验证的

- 本脚本只检查了文件是否就位，**没有**真实调用任何生成接口（会花钱）。
- 密钥尚未配置时，出歌/出画面/出视频都跑不通，这是预期状态，不是安装失败。
- 发布链路需要用户自己先登录五个平台，安装阶段不碰登录。

## 下一步

1. 用 \`BOT.md\` 全文作为 instructions 创建 Bot（见 \`1-发给主Bot一键安装.md\`）。
2. 配密钥：编辑 \`$WORK/.env\` 填写（脚本会自动读，不用 source），或直接交给 Bot 用安全卡片收取。
3. 打开工作台：\`open "$BENCH_DST"\`
EOF

# 让 selfcheck.sh 记得上次装到哪：写到工作目录（包目录可能只读）
printf '%s\n' "$WORK" > "$WORK/.install-last-work" 2>/dev/null || \
  warn "写不了 $WORK/.install-last-work，跑自检时请手动带上路径：bash $PKG/selfcheck.sh \"$WORK\""

# ---------- 7. 收尾 ----------
say ""
say "=========================================="
say "  装好了"
say "=========================================="
say "  工作目录：$WORK"
say "  技能：${INSTALLED:-（无新增）}"
[ -n "$SKIPPED" ] && say "  跳过：$SKIPPED（已存在，未覆盖）"
say "  报告：$REPORT_MD"
say "  密钥文件：$ENVF（填了脚本就会自动读）"
say ""
say "下一步："
say "  1) 把 BOT.md 全文作为 instructions 创建 Bot（详见 1-发给主Bot一键安装.md）"
say "  2) 配密钥：直接编辑 $ENVF，填 KIE_API_KEY / IMAGE_API_KEY / AUTODL_API_KEY"
say "  3) 打开工作台：open \"$BENCH_DST\""
say "  4) 自检：bash \"$PKG/selfcheck.sh\" \"$WORK\""
say ""
say "本安装器不配置账号、不代登录、不调用任何付费接口。"
