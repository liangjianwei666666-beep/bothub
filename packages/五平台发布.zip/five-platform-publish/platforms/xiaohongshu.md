# 小红书（creator.xiaohongshu.com）

**账号**：帧心可视化（账号名来自用户提供／当日后台显示；归档脚本里没有留存账号名）
**入口**：`https://creator.xiaohongshu.com/publish/publish`　登录 `/login`　笔记管理 `/new/note-manager`

## ⚠️ 这条链路有一个必须知道的坑：发布按钮在 closed shadow root 里

发布按钮挂在 `<xhs-publish-btn>` 这个自定义元素内部，而它的 shadow root 是 **closed** 的：

- `document.querySelectorAll('*')` + `innerText` 找「发布」→ **找不到**（当天 find_pub.js / find_pub2.js / find_pub3.js 连试三次都没找到）
- `page.evaluate(() => host.shadowRoot)` → `null`（shadow.js 的探测结果是 `closed shadow`）
- `getByRole('button', {name:'发布'})` → 当天也试过，不可靠

**唯一稳的办法**：CDP `DOM.getDocument{pierce:true}` 遍历（能穿 closed shadow）→ 找到节点 → `DOM.getBoxModel` 取坐标 → `mouse.click`。
`lib.js` 里就是 `clickViaCDP(ctx, page, '发布')`；`fill.js xhs --publish` 已经默认走它。

> 同一份技能里的 `clickText()`（innerText + rect）在这个按钮上**找不到**（当天三次都没找到）——别指望它。
> `fill.js` 里保留它只是兜底，一旦用上会在 `warnings` 里提醒你人工确认点的是不是发布键。
> 当天最终点中的一次是坐标 (830,758)（fix_and_pub.js，点一次就成功）；但归档里没留下那个坐标的来源输出，
> 台账（灵魂歌手工作台.html）记的结论就是「用 CDP DOM.getBoxModel 取坐标点，不能靠 innerText」。

## 步骤

```bash
node scripts/probe.js xhs                        # 先确认登录态
node scripts/fill.js xhs --spec spec/xhs.json    # 先只填（默认不发）
node scripts/fill.js xhs --spec spec/xhs.json --publish
```

1. `/publish/publish` 打开即上传页，视频走 file input。
2. **标题**：`input.d-text[placeholder*="标题"]`（≤20 字）。
3. **正文**：`div.tiptap`（contenteditable，`fill()` 无效，要 `keyboard.type`）。
4. **话题**：键盘输入 `#AI音乐` → 等 1.2s 出联想 → `Enter` → 打一个空格，逐个加
   （不加空格，下一个 `#` 会和上一个粘在一起）。
   是否识别成**真话题**：回读 `div.tiptap` 的 HTML，数 `a` 标签数量（当天判断是 4 个全识别，
   但那次的输出没留存；下次跑 `fill.js` 时看 `steps.readback.topicLinks`）。
5. **封面**：点「设置封面」→ 打开的是**封面编辑器弹窗**，上传入口在弹窗里，页面上的按钮会被遮罩挡住
   （当天先点了一次以为失败，其实是弹窗挡住了；后来在弹窗内点坐标 (962,596) 才传上去）。
   传完平台会跑「封面效果评估」。
   `fill.js` 按三条路试：弹窗内文字「上传」→ 文字「+」→ 用 CDP 直接塞图片文件（`accept=image`）；
   全失败就记 blocker，不会带着默认首帧发出去。
6. **发布**：`fill.js --publish` → `clickViaCDP(ctx, page, '发布')`。点完必须看 URL/文案有没有变化。

## 核对（发布后）

- 回 `/new/note-manager` 看这条：标题、封面缩略图、时间、状态。
- **永久链接**：创作者后台的笔记列表里没找到复制/分享入口（当天用 get_links.js、note_link.js 各探了一次，
  两次输出都没留存，台账里三条 url 都是空的）→ 如实告诉用户从小红书 App 里取，**不要编链接**。

## 已知坑

- 发布页有多个 `button`，别记固定坐标：视口/文案高度一变就点在两个按钮的缝隙里
  （当天用固定坐标试过 730,700 两次、还探过 730/660/740/820/900 一排，都没点中）。
- 编辑器是 tiptap，回读要看 innerHTML，不看 `value`。
- 账号若有「原创声明」开关，读 `checked` 状态确认，别假设默认值。
