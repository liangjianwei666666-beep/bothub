# X / Twitter（x.com）

**账号**：@mu_jabi19028（账号名来自用户提供）　**入口**：`https://x.com/compose/post`

## 步骤

```bash
node scripts/fill.js x --spec spec/x.json
```

1. `goto('https://x.com/compose/post')`，等 7s 让 DraftJS 编辑器挂载。
2. **上传视频**：CDP `DOM.getDocument{pierce:true}` 找 `input[type=file]` 后 `DOM.setFileInputFiles`
   （当天成功那次用的就是这个，没有按 accept 过滤）。
   > 归档日志里那句 `file input 229` 是 CDP 的 **nodeId**，不是文件框数量——别当成「页面有 229 个 file input」。
3. **等上传完**：归档做法是**等上传百分比消失**（日志：`pct 13` → `pct 70` → `pct -` → 结束）。
   注意 `Post` 这个字样在页面一打开就存在，不能拿它当上传完成的信号
   （日志里的 `Post count 1` 是 Post 按钮的元素计数，跟上传无关）。
4. **正文**：编辑器是 DraftJS，选择器 `div.public-DraftEditor-content`（当天用的这个）；
   `fill()` 无效，必须 `click` + `keyboard.type`（中文标题 + 两句歌词 + `#AI音乐 #华语民谣 #MusicVideo`）。
5. **发布**：
   - **先按 `Esc`**：台账记的结论是「打完话题后必须先按 Esc 关掉联想下拉，否则点不到 Post」。
   - 当天出现过一次 `locator.click: Timeout 30000ms exceeded`（脚本把 Call log 截断了，真实原因没留下），
     所以**不要依赖 `locator.click()`**；成功那次（x_post_now.js）是 `[data-testid="tweetButton"]`
     取 rect → `page.mouse.click(中心)`。`fill.js` 走的也是这条。
   - 点之前读一下 `aria-disabled`，是 `true` 就别点（记为 blocker）。
6. **发完必须复核**：当天有一次点完发布、主页里却找不到这条，重发一次才成。
   `fill.js --publish` 会自动 `goto('https://x.com/home')` 读时间线并截图。

## 核对

- 个人主页能看到：视频、中文标题、话题。
- 推文永久链接形如 `https://x.com/mu_jabi19028/status/<id>`；打开确认可访问。
  （当天台账在 03:38 那条记录里留下了 status 链接。）

## 未验证的说法（别当实测结论用）

- 「连发会触发风控、要间隔 ≥30s」——**没有证据**，只是常规谨慎做法。
- 「视频大时首帧要几秒才渲染」——同理，属于经验判断，不是当天测出来的。
