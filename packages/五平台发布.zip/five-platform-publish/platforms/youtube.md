# YouTube（studio.youtube.com）

**频道**：mu jabi（channel id `UCin-U_FQBymtlkGS_QgvFXw`，这是归档里唯一反复出现的标识）

## 结论：上传不稳，别硬刚；**改文案和核对走自动化**

当天真实发生的（按归档日志，不按印象）：

| 时间 | 脚本 | 结果 |
|---|---|---|
| 03:19–03:25 | yt_start / yt_up2 / yt_retry2-4 | 点「创建」→「上传视频」后**对话框不渲染**，找不到「选择文件」 |
| 03:31 | **yt_retry5.js** | **成功**：`clicked 创建` → `menu 上传视频 at [844,665]` → `选择文件 count 1` → `FILE SET OK` → `tick0 7% READY`（对话框渲染出来，上传真的开始了） |
| 03:32–03:40 | yt_full / yt_up6 / yt_up7 / yt_up8 / yt_last / yt_last2 | 又回到 `选择文件 0` / `NO CHOOSER`；还有几次 `page.evaluate: Execution context was destroyed`（页面在导航时被我们戳） |

**所以正确的说法不是「5 条路径全卡死」**，而是：**这条路能走通一次，但不稳定**——
同一批脚本在不同时刻一会儿点得开、一会儿连按钮都找不到；也没能在自动化下走完一次上传并公开。
再往下的时间都花在重试上，收益很差。**结论：上传交给用户手动拖，Bot 做后面所有事。**

> 归档里没有「对话框显示已保存为私享视频」这类记录，也没有任何「禁用 GPU」的操作记录——
> chrome.log 里是默认参数下 GPU 进程反复崩（沙箱环境本身不稳）。别拿这些当依据。

## 路线 A：用户手动上传（推荐）

1. `open -R <视频路径>` 在 Finder 里选中成片，并把文案文件打开给用户。
2. 给用户五样东西（写成一段能复制的文本）：
   - 视频完整路径
   - 标题（≤100 字符）
   - 说明（歌词 + `温情民谣 / 14 秒竖屏短片 / AI 演唱` + `#Shorts #AI音乐 #华语民谣`）
   - 标签（逗号分隔）
   - 入口：`https://studio.youtube.com/channel/UCin-U_FQBymtlkGS_QgvFXw/videos/upload`
3. 提醒上传向导三处必答：**受众选「不是为儿童打造的内容」→ 可见性选「公开」→ 版权检查直接跳过**。
4. 用户传完说一声，Bot 走路线 B 核对并补全（**用户手动传的经常是草稿、标题还是文件名**）。

## 路线 B：进 Studio 改标题/说明（这条自动化是**可用**的）

```bash
node scripts/fill.js yt --spec spec/yt.json     # spec.url = https://studio.youtube.com/video/<id>/edit
node scripts/fill.js yt --spec spec/yt.json --publish   # --publish = 点「保存」并刷新回读
```

当天 08:42–08:46 就是靠这条把用户手传的视频的标题和说明补全的。要点：

1. `goto(<编辑页>)`，等 **12 秒**（Studio 首屏很慢）。
2. 两个文本框是 `div#textbox`：**第 0 个是标题，第 1 个是说明**；等出现**两个**再动手。
3. **标题**：三击 + `Meta+A` + 输入。当天第一次只按 `Meta+A`，新标题被**拼接**成旧标题＋新标题两段，
   第二次才改对（这一点能靠代码演进看出来：yt_edit2.js 只有 Meta+A，之后 yt_fix.js 才加了三击和回读）。
   ⇒ `fill.js` 现在写死了回读校验，不符就报 blocker。
4. **说明**：点第 1 个 `div#textbox` → 先打「测试」两个字回读，确认真的点进去了 → 再全选清空写正式内容。
   Studio 的说明框偶尔"点不进去"，这个探针很值（当天就是靠它确认落点的）。
5. **保存**：文字「保存」→ rect 中心 `mouse.click`。
6. **复核**：`reload()` → 再回读两个 `#textbox` 确认是新的；列表页 `.../videos/short` 看可见性。
   ⚠️ **可见性不在这条自动化的覆盖范围内**：归档里没有任何脚本碰过公开/私享开关，
   `fill.js` 的 yt 流程只改标题+说明+保存。台账里那句「已在 Studio 改好并公开」是人工在页面上点的，
   脚本没留存。所以**要改可见性就在 Studio 里手点**，或用 `probe.js --keep` 打开列表页人工确认后再动。
7. **公开页**：`https://www.youtube.com/shorts/<id>`（竖屏 <3 分钟自动算 Shorts），链接可写进台账。

## 已知坑

- 一个标签容易卡死/被导航打断：所有 `evaluate` 都包 retry；卡了就关标签重开（草稿不会丢）。
- 别为了让它稳定去换浏览器参数（`--no-sandbox` 之类）——当天换参数只换来更多白屏和导航中断。
