#!/usr/bin/env bash
# =============================================================================
# selfcheck.sh — 校验信息图 skill 是否装好、能不能真跑
#
#   bash selfcheck.sh                          # 查 ~/.agents/skills/infographic-maker
#   SKILL_DIR=/某个路径 bash selfcheck.sh       # 查指定目录
#
# 全部通过才打印「自检通过」并以 0 退出。
# =============================================================================
set -uo pipefail
SKILL_DIR="${SKILL_DIR:-$HOME/.agents/skills/infographic-maker}"
S="$SKILL_DIR/scripts"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
PASS=0; FAIL=0; WARN=0
ok(){ printf '  ✓ %s\n' "$1"; PASS=$((PASS+1)); }
no(){ printf '  ✗ %s\n' "$1"; FAIL=$((FAIL+1)); }
warn(){ printf '  ⚠ %s\n' "$1"; WARN=$((WARN+1)); }

echo "自检目录：$SKILL_DIR"

# 1. 结构与库
[ -f "$SKILL_DIR/SKILL.md" ] && ok "SKILL.md 存在" || no "缺 SKILL.md"
[ -x "$S/make_prompt.sh" ]  && ok "make_prompt.sh 可执行" || no "make_prompt.sh 不可执行"
NL=$(awk 'END{print NR-1}' "$SKILL_DIR/reference/layouts/catalog.tsv" 2>/dev/null || echo 0)
NS=$(awk 'END{print NR-1}' "$SKILL_DIR/reference/styles/catalog.tsv" 2>/dev/null || echo 0)
[ "${NL:-0}" -ge 21 ] && ok "布局定义 ${NL} 个（≥21）" || no "布局定义不足（${NL:-0}，应 ≥21）"
[ "${NS:-0}" -ge 23 ] && ok "风格定义 ${NS} 个（≥23）" || no "风格定义不足（${NS:-0}，应 ≥23）"
[ -f "$SKILL_DIR/reference/layouts/catalog.tsv" ] && ok "布局 catalog 存在" || no "缺布局 catalog.tsv"
[ -f "$SKILL_DIR/reference/styles/catalog.tsv" ]  && ok "风格 catalog 存在" || no "缺风格 catalog.tsv"

# 2. 默认组合：提示词必须带 L1/L4/L6、墨绿、署名
bash "$S/make_prompt.sh" --signature "@自检署名" \
  --topic "自检主题" --title "自检标题" --sub "自检副题" --lead "自检机制" \
  --card "细线一个方块|标签一|重点一|说明一" \
  --card "细线一个圆圈|标签二|重点二|说明二" \
  --card "细线一个三角|标签三|重点三|说明三" \
  --rule "自检口诀" --out "$TMP/d.txt" >/dev/null 2>"$TMP/e1.txt"
if [ -s "$TMP/d.txt" ]; then
  ok "默认组合组装成功"
  grep -q 'L1 大标题' "$TMP/d.txt" && ok "含 L1 大标题" || no "缺 L1 大标题"
  grep -q 'L4 知识卡片区' "$TMP/d.txt" && ok "含 L4 卡片区" || no "缺 L4 卡片区"
  grep -q 'L6 署名' "$TMP/d.txt" && ok "含 L6 署名层" || no "缺 L6 署名层"
  grep -q '墨绿 #2F4F45' "$TMP/d.txt" && ok "含主色 hex" || no "缺主色 hex（可能 .env 引号问题）"
  grep -q '@自检署名' "$TMP/d.txt" && ok "署名写入提示词" || no "署名没写进提示词"
  grep -q '色相不超过 3' "$TMP/d.txt" && ok "含量化红线" || no "缺量化红线"
else
  no "默认组合组装失败（见 $TMP/e1.txt）"
fi

# 3. 非默认组合：结构与风格定义要被注入
bash "$S/make_prompt.sh" --signature "@自检署名" --topic t --title T \
  --layout venn-diagram --style chalkboard \
  --card "a|b|c|d" --card "e|f|g|h" --out "$TMP/alt.txt" >/dev/null 2>&1
if [ -s "$TMP/alt.txt" ]; then
  grep -q '信息结构：维恩图' "$TMP/alt.txt" && ok "非默认布局已注入" || no "非默认布局未注入"
  grep -q '风格定义 · 黑板粉笔' "$TMP/alt.txt" && ok "非默认风格已注入" || no "非默认风格未注入"
  grep -q '不再要求单列卡片' "$TMP/alt.txt" && ok "L4 排法已改写" || no "L4 排法没随布局改写"
else
  no "非默认组合组装失败"
fi

# 4. 非法参数必须报错
bash "$S/make_prompt.sh" --signature "@x" --topic t --title T --layout 不存在的布局 \
  --card "a|b|c|d" --card "e|f|g|h" >/dev/null 2>&1 && no "非法布局没有报错" || ok "非法布局被拦下"

# 5. 署名闸门：不传必须失败
bash "$S/make_prompt.sh" --topic t --title T --card "a|b|c|d" --card "e|f|g|h" >/dev/null 2>&1 \
  && no "缺署名时没有报错（闸门失效）" || ok "缺署名被拦下（闸门生效）"

# 6. 压图：造一张 2160×2880 测试图，压到 1080 宽 ≤300KB，比例不变
if python3 -c "import PIL" >/dev/null 2>&1; then
  python3 - "$TMP/test.png" <<'PY'
import sys
from PIL import Image, ImageDraw
im=Image.new('RGB',(2160,2880),(255,255,255)); d=ImageDraw.Draw(im)
d.rectangle([120,120,2040,2760], fill=(246,241,231), outline=(227,227,222), width=3)
d.rectangle([240,240,1920,700], fill=(31,31,29))
for i in range(4):
    y=900+i*420; d.rectangle([240,y,1920,y+300], fill=(250,247,240), outline=(227,227,222), width=2)
    d.rectangle([300,y+60,900,y+140], fill=(47,79,69))
im.save(sys.argv[1])
PY
  if bash "$S/compress_image.sh" "$TMP/test.png" --width 1080 --max-kb 300 --out "$TMP/out.jpg" >"$TMP/c.txt" 2>&1; then
    python3 - "$TMP/out.jpg" <<'PY' > "$TMP/c2.txt" 2>&1
import sys, os
from PIL import Image
im=Image.open(sys.argv[1]); kb=os.path.getsize(sys.argv[1])/1024
print(round(im.width/im.height,4), round(kb,1))
PY
    RATIO=$(awk '{print $1}' "$TMP/c2.txt"); KB=$(awk '{print $2}' "$TMP/c2.txt")
    [ "$RATIO" = "0.75" ] && ok "压图保持 3:4（$RATIO）" || no "压图比例变了（$RATIO）"
    awk -v k="$KB" 'BEGIN{exit !(k<=300)}' && ok "压图体积 ${KB}KB（≤300）" || no "压图体积 ${KB}KB 超标"
  else
    no "压图脚本失败：$(head -1 "$TMP/c.txt")"
  fi
else
  warn "缺 Pillow：出图不受影响，压图不可用（python3 -m pip install --user pillow）"
fi

echo
echo "通过 $PASS 项，失败 $FAIL 项，警告 $WARN 项"
if [ "$FAIL" -eq 0 ]; then
  echo "自检通过"
  exit 0
else
  echo "自检未通过，请按上面 ✗ 处理"
  exit 1
fi
