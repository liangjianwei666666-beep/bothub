#!/usr/bin/env bash
# =============================================================================
# package.sh — 维护者用：把最新 skill 重新打进安装包，生成校验和并打成 zip
#
#   bash package.sh                       # 输出到 ~/Desktop/图片生成/信息图大师Bot-v3.0.zip
#   bash package.sh --out /path/xxx.zip
#
# 会：① 从 ~/.agents/skills/infographic-maker 同步 payload（排除 .env/备份/示例产物）
#     ② 同步工作台 HTML ③ 生成 MANIFEST.sha256 ④ 打 zip
# =============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"            # infographic-master-bot
PKG="$(cd "$ROOT/.." && pwd)"             # 信息图大师Bot-vX.Y
SKILL_SRC="${SKILL_SRC:-$HOME/.agents/skills/infographic-maker}"
WORKBENCH_SRC="${WORKBENCH_SRC:-/Users/a1-6/Desktop/图片生成/信息图大师工作台-v3.html}"
OUT="${2:-/Users/a1-6/Desktop/图片生成/$(basename "$PKG").zip}"
[ "${1:-}" = "--out" ] && OUT="$2"

[ -d "$SKILL_SRC" ] || { echo "找不到源 skill：$SKILL_SRC" >&2; exit 1; }

echo "同步 payload ..."
rsync -a --delete \
  --exclude '.env' --exclude '.env.bak*' --exclude '*.bak*' \
  --exclude 'generated' --exclude '.DS_Store' \
  "$SKILL_SRC/" "$ROOT/payload/infographic-maker/"
chmod +x "$ROOT"/payload/infographic-maker/scripts/*.sh 2>/dev/null || true
[ -f "$WORKBENCH_SRC" ] && cp "$WORKBENCH_SRC" "$ROOT/payload/信息图大师工作台-v3.html"

echo "生成 MANIFEST.sha256 ..."
( cd "$PKG" && find . -type f ! -name 'MANIFEST.sha256' ! -name '.DS_Store' -print0 \
    | sort -z | xargs -0 shasum -a 256 > MANIFEST.sha256 )
echo "  $(wc -l < "$PKG/MANIFEST.sha256" | tr -d ' ') 个文件已登记"

echo "打包（UTF-8 文件名，跨平台不乱码）..."
rm -f "$OUT"
python3 - "$PKG" "$OUT" <<'PYEOF'
import sys, os, zipfile
src, out = sys.argv[1], sys.argv[2]
base = os.path.basename(src)
items = []
for root, dirs, files in os.walk(src):
    dirs[:] = [d for d in dirs if d != '.DS_Store']
    for f in files:
        if f == '.DS_Store':
            continue
        full = os.path.join(root, f)
        items.append((os.path.relpath(full, os.path.dirname(src)), full))
items.sort()
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for arc, full in items:
        z.write(full, arc.replace(os.sep, '/'))
print('  写入', len(items), '个文件')
PYEOF
echo "完成：$OUT（$(du -h "$OUT" | cut -f1)）"
