#!/usr/bin/env bash
# =============================================================================
# install.sh — 一键安装「信息图大师」skill（v3）
#
#   bash install.sh                     # 装到 ~/.agents/skills/infographic-maker
#   bash install.sh --check             # 只自检，不安装
#   bash install.sh --no-desktop        # 不往桌面复制工作台
#   AGENTS_SKILLS_DIR=/path bash install.sh   # 装到指定目录
#
# 旧版会自动备份成 infographic-maker.bak-<时间戳>，不会静默覆盖。
# =============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"          # .../infographic-master-bot/scripts
ROOT="$(cd "$HERE/.." && pwd)"                                 # .../infographic-master-bot
PAYLOAD="$ROOT/payload/infographic-maker"
WORKBENCH="$ROOT/payload/信息图大师工作台-v3.html"
DEST_ROOT="${AGENTS_SKILLS_DIR:-$HOME/.agents/skills}"
DEST="$DEST_ROOT/infographic-maker"
MODE="install"; COPY_DESKTOP=1

for a in "$@"; do
  case "$a" in
    --check|check) MODE="check";;
    --no-desktop)  COPY_DESKTOP=0;;
    -h|--help) sed -n '2,12p' "$0"; exit 0;;
    *) echo "未知参数: $a" >&2; exit 2;;
  esac
done

[ -d "$PAYLOAD" ] || { echo "找不到 payload：$PAYLOAD（请确认压缩包解压完整）" >&2; exit 1; }

if [ "$MODE" = "check" ]; then
  SKILL_DIR="$PAYLOAD" bash "$HERE/selfcheck.sh"
  exit $?
fi

# ---------- 安装 ----------
mkdir -p "$DEST_ROOT"
if [ -e "$DEST" ]; then
  BAK="$DEST.bak-$(date +%Y%m%d-%H%M%S)"
  mv "$DEST" "$BAK"
  echo "已备份旧版：$BAK"
fi
mkdir -p "$DEST"
# 不复制 .env / 备份 / 示例产物，避免把旧密钥带到别人机器
for item in SKILL.md README.md .env.example scripts reference presets; do
  [ -e "$PAYLOAD/$item" ] && cp -R "$PAYLOAD/$item" "$DEST/"
done
chmod +x "$DEST"/scripts/*.sh 2>/dev/null || true
chmod +x "$DEST"/scripts/*.py 2>/dev/null || true

echo "已安装 skill → $DEST"

# ---------- 工作台 ----------
if [ "$COPY_DESKTOP" = "1" ] && [ -f "$WORKBENCH" ]; then
  TARGET="$HOME/Desktop/信息图大师工作台-v3.html"
  if [ -d "$HOME/Desktop" ]; then
    cp "$WORKBENCH" "$TARGET" && echo "已放工作台 → $TARGET"
  else
    cp "$WORKBENCH" "$DEST/信息图大师工作台-v3.html" && echo "无桌面目录，工作台放在 → $DEST/信息图大师工作台-v3.html"
  fi
fi

echo
echo "---------- 自检 ----------"
SKILL_DIR="$DEST" bash "$HERE/selfcheck.sh"
echo
echo "下一步："
cat <<EOM
  1) 配生图接口（不配也能用，只能产出提示词）：
       cd "$DEST" && cp .env.example .env && 编辑 .env
     填 IMG_API_BASE / IMG_API_KEY / IMG_MODEL。
  2) 建 Bot：用 create_bot，name=信息图大师，role=信息图，
     instructions 原样拷贝 $ROOT/BOT.md 全文。
  3) 交付用户时把工作台路径一起给它。
EOM
