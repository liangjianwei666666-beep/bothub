# infographic-master-bot

主 Bot 用的装配技能：把「信息图大师」Bot 一键装出来。

- `SKILL.md` —— 操作手册（装 → 建 Bot → 自检 → 交付）
- `BOT.md` —— 新 Bot 的 instructions，原样传给 create_bot
- `scripts/install.sh` —— 安装 payload 到 `~/.agents/skills/infographic-maker`，工作台复制到桌面
- `scripts/selfcheck.sh` —— 20 项自检（结构 / 提示词 / 署名闸门 / 压图）
- `scripts/package.sh` —— 维护者重新打包用
- `payload/` —— 实际安装的东西（skill v3 + 工作台）
- `examples/` —— 两条真实提示词 + 一张成品缩略图

用法：见 `SKILL.md`。
