---
name: infographic-master-bot
description: 一键装配「信息图大师 Bot」。当用户说「装一个信息图 Bot」「装信息图大师」「发你个 Bot 包，装一下」「创建信息图 Bot」时使用。本技能教主 Bot 如何：① 跑 install.sh 把信息图 skill v3 与工作台装到本地；② 跑自检；③ 用 create_bot 建出「信息图大师」；④ 说明生图 Key 怎么配（不配也能出提示词）。装好后该 Bot 能把知识点做成一页 3:4 竖版信息图（21 种布局 × 23 种风格、L1–L6 分层、发布压图）。
version: 3.0.0
---

# 一键装配「信息图大师」Bot v3

**这份文件是给「主 Bot」看的操作手册。** 用户说一句「装这个信息图 Bot」，你按下面 4 步跑完，用户就得到一个能出信息图的 Bot。

不需要生图 Key 也能装、也能用：先跑通提示词组装，之后再接 Key。

## 前置检查（30 秒）

```bash
ls "$(dirname "$0")" >/dev/null && echo "包目录 OK"
command -v bash && command -v python3
python3 -c "import PIL; print('Pillow', PIL.__version__)"   # 压图功能需要
```

缺 Pillow 不影响出图，只影响 `compress_image.sh` 压图：
`python3 -m pip install --user pillow`

## 步骤 1：跑装配脚本

```bash
bash <包目录>/infographic-master-bot/scripts/install.sh
```

脚本会：
1. 把完整 skill（21 布局 + 23 风格 + 全部脚本 + 预设）装到 `~/.agents/skills/infographic-maker`
2. 把工作台 HTML 复制到桌面（`~/Desktop/信息图大师工作台-v3.html`）
3. 旧版会被备份成 `infographic-maker.bak-<时间戳>`，不会静默覆盖
4. 装完自动跑一遍自检

装到别处：`AGENTS_SKILLS_DIR=/自定义/路径 bash .../install.sh`
只看自检不安装：`bash .../scripts/install.sh --check`

看到 `自检通过` 再往下走。

## 步骤 2：建 Bot

用 `create_bot`，参数照抄：

- **name**: `信息图大师`
- **role**: `信息图`
- **instructions**: 原样拷贝本包 `infographic-master-bot/BOT.md` 的**全文**（`cat` 出来整段传入，不要改写、不要摘要）

不要填 model（跟随主 Bot 当前模型）。不要填 work_dir，除非用户指定。

## 步骤 3：自检（别跳过）

```bash
bash <包目录>/infographic-master-bot/scripts/selfcheck.sh
```

必须看到全部 ✓（没有 Pillow 时会出现 1 条 ⚠，不影响）和最后一行 `自检通过`。它会验：

- 21 个布局文件、23 个风格文件、两个 catalog 都在
- 默认组合能组装出含 L1/L4/L6、墨绿 `#2F4F45`、署名的提示词
- 非默认组合（维恩图 + 黑板风）能正确注入结构与风格
- 缺 `--signature` 时脚本**必须报错退出**（这是防署错品牌的闸门）
- 压图脚本能把图压到目标 KB 且保持比例

## 步骤 4：交付给用户

告诉用户：

> 信息图大师已建好，直接跟它说「做一张信息图：主题 XX，署名 YY」。
> 它会先问署名（这个不能省），再定布局、出图、核验尺寸。
> 工作台在 `~/Desktop/信息图大师工作台-v3.html`，双击能开，可以选布局/风格、填内容、直接生成命令。

然后说明两件可后补的事（**不给也能用**）：

1. **生图 Key**：`cd ~/.agents/skills/infographic-maker && cp .env.example .env`，填 `IMG_API_BASE` / `IMG_API_KEY` / `IMG_MODEL`。不填时 Bot 只能产出提示词，不能直接出图。
2. **品牌配色**：`.env` 里的 `BRAND_ACCENT`（默认墨绿，带 `#` 必须加引号）。署名不在这里配，每次问用户。

## 这个 Bot 能做什么

- 21 种信息结构：单列递进（默认）、二元对比、对比矩阵、层级金字塔、分支树、中心辐射、爆炸剖面、便当格、冰山、桥梁、漏斗、等距场景、指标看板、周期表、四格漫画、故事山、拼图、维恩图、蜿蜒路线、环形流程、高密度模块
- 23 种视觉风格：默认现代极简编辑风；其余需用户明确指定才换
- 3:4 竖版 2160×2880，L1–L6 六级层级，署名每次问
- 发布压图：X（≤1MB）/ 小红书（2160 宽 ≤700KB）/ 备用小图
- 工作台：单文件 HTML，选布局/风格/填内容 → 实时生成命令

## 常见坑

| 现象 | 原因 / 处理 |
|---|---|
| `缺少 --signature` | 这是设计：署名必须由用户给定，去问用户，别猜 |
| 装完 Bot 里命令找不到 | 确认装的是 `~/.agents/skills/infographic-maker`，别改目录名 |
| 自检报「缺 Pillow」 | `python3 -m pip install --user pillow` |
| 接口报错 / 超时 | 先在 `.env` 确认 `IMG_API_BASE` 与模型名；服务端波动时重试一次，别重复落图 |
| 换风格后量化指标不达标 | 非默认风格本来就不适用三项量化红线，改按该风格自己的配色一致性 |
