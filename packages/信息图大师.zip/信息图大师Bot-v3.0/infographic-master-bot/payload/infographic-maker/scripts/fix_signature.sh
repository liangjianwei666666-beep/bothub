#!/usr/bin/env bash
# =============================================================================
# fix_signature.sh — 修复底部署名（包装 fix_signature.swift）
#
# 生图模型常把 "@帧心英语" 写错/写漏。本脚本覆盖底部一条带并重画署名。
# 仅在 macOS 可用（依赖 AppKit）。非 macOS 请跳过此步，人工重出一版。
#
# 用法:
#   bash fix_signature.sh 图.png [--text "@帧心英语"] [--band 0.065] \
#         [--bg auto|white|#RRGGBB] [--fg auto|dark|light|#RRGGBB] [--want 2160x2880]
#
# 粉笔黑板图示例：
#   bash fix_signature.sh chalk.png --bg '#2A4440' --fg light
# =============================================================================
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

img=""; want="${IMG_DEFAULT_SIZE:-2160x2880}"; passthru=()
while [ "$#" -gt 0 ]; do
  case "$1" in
    --want) want="${2:-}"; shift 2;;
    *) if [ -z "$img" ]; then img="$1"; else passthru+=("$1"); fi; shift;;
  esac
done
[ -n "$img" ] || { echo "用法: fix_signature.sh 图.png [--text ...] [--band ...] [--bg ...] [--fg ...] [--want 2160x2880]" >&2; exit 2; }
[ -f "$img" ] || { echo "IMAGE_NOT_FOUND: $img" >&2; exit 2; }
command -v swift >/dev/null 2>&1 || { echo "FIX_SKIP: 未找到 swift（本步仅 macOS 可用），请人工核对署名" >&2; exit 3; }

tmp="${img%.png}.sigfix.png"
swift "$SKILL_DIR/scripts/fix_signature.swift" "$img" --out "$tmp" "${passthru[@]:-}"

# AppKit 有时把画布翻倍，用 sips 回缩到目标规格
if command -v sips >/dev/null 2>&1 && [ -n "$want" ]; then
  W="${want%x*}"; H="${want#*x}"
  ow="$(sips -g pixelWidth "$tmp" 2>/dev/null | awk '/pixelWidth/{print $2}')"
  oh="$(sips -g pixelHeight "$tmp" 2>/dev/null | awk '/pixelHeight/{print $2}')"
  if [ "$ow" != "$W" ] || [ "$oh" != "$H" ]; then
    echo "FIX_RESIZE: ${ow}x${oh} -> ${W}x${H}"
    sips -z "$H" "$W" "$tmp" >/dev/null
  fi
fi

mv "$tmp" "$img"
echo "FIX_DONE=$img"
bash "$SKILL_DIR/scripts/check_image.sh" "$img" --want "$want" || true
