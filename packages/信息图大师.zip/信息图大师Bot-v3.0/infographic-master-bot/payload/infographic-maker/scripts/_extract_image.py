#!/usr/bin/env python3
"""_extract_image.py — 从 OpenAI 兼容生图响应里取出图片并落盘。

用法: _extract_image.py <response.json> <out.png>
成功: 打印 OK <bytes> 并 exit 0
失败: 打印原因到 stderr 并 exit 1
"""
import base64
import json
import os
import sys
import time
import urllib.request


def main() -> int:
    if len(sys.argv) < 3:
        print("usage: _extract_image.py <response.json> <out.png>", file=sys.stderr)
        return 1
    resp_path, out_path = sys.argv[1], sys.argv[2]

    try:
        with open(resp_path, "r", encoding="utf-8", errors="replace") as fh:
            resp = json.load(fh)
    except Exception as exc:  # noqa: BLE001
        print(f"IMAGE_BAD_RESPONSE: 响应不是合法 JSON: {exc}", file=sys.stderr)
        return 1

    err = resp.get("error")
    if err:
        msg = err if isinstance(err, str) else err.get("message", json.dumps(err, ensure_ascii=False))
        print(f"IMAGE_API_ERROR: {msg}", file=sys.stderr)
        return 1

    data = resp.get("data") or []
    if not data:
        print("IMAGE_EMPTY_DATA: 接口成功但没有图片数据（常见于服务端 -2700）", file=sys.stderr)
        return 1

    item = data[0]
    b64 = item.get("b64_json")
    url = item.get("url")

    try:
        if b64:
            if b64.startswith("data:"):
                b64 = b64.split(",", 1)[1]
            with open(out_path, "wb") as fh:
                fh.write(base64.b64decode(b64))
        elif url:
            # CDN 会拒绝 Python-urllib 默认 UA（403 Forbidden），必须带浏览器 UA
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                                  "Chrome/124.0 Safari/537.36",
                    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
                },
            )
            last_exc = None
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(req, timeout=180) as resp, \
                            open(out_path, "wb") as fh:
                        fh.write(resp.read())
                    last_exc = None
                    break
                except Exception as exc:  # noqa: BLE001
                    last_exc = exc
                    time.sleep(3 * (attempt + 1))
            if last_exc is not None:
                raise last_exc
        else:
            print("IMAGE_NO_IMAGE: 响应里既没有 b64_json 也没有 url", file=sys.stderr)
            return 1
    except Exception as exc:  # noqa: BLE001
        print(f"IMAGE_DECODE_ERROR: {exc}", file=sys.stderr)
        return 1

    size = os.path.getsize(out_path)
    if size <= 0:
        print("IMAGE_WRITE_FAILED: 落盘文件为空", file=sys.stderr)
        return 1
    print(f"OK {size}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
