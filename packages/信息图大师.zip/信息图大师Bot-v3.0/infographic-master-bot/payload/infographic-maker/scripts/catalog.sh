#!/usr/bin/env bash
# catalog.sh — 列出可选布局 / 风格
#   bash catalog.sh layouts|styles
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
case "${1:-}" in
  layouts) f="$SKILL_DIR/reference/layouts/catalog.tsv";;
  styles)  f="$SKILL_DIR/reference/styles/catalog.tsv";;
  *) echo "用法: catalog.sh layouts|styles" >&2; exit 2;;
esac
awk -F'\t' 'NR>1 {printf "%-22s %-16s %s\n", $1, $2, $3}' "$f"
