#!/usr/bin/env bash
# =============================================================================
# make_prompt.sh — 按模板组装提示词（避免手写长提示词时漏项/写错）
#
# 用法：
#   bash make_prompt.sh --topic "..." --title "..." --signature "@账号名" \
#        --card "底色，画面元素|标签|重点句|说明" （可重复 2~5 次） \
#        [--sub "副标题"] [--lead "一句话机制"] [--rule "底部口诀"] \
#        [--logic "现象→真相→机制→行动"] [--accent "墨绿 #2F4F45"] \
#        [--layout linear-progression] [--style minimal-editorial] \
#        [--aspect 3:4] [--canvas 2160x2880] [--role "手绘元素描述"] [--out prompt.txt]
#
# --signature 必填：署名必须由用户指定并输入，脚本不给默认值。
# --layout  信息结构（默认 linear-progression = L1–L6 单列递进）
#           可选 21 种，见 reference/layouts/catalog.tsv
# --style   视觉风格（默认 minimal-editorial = 本机 v2 极简编辑风）
#           可选 23 种，见 reference/styles/catalog.tsv
# --aspect  3:4（默认）/ 9:16 / 1:1 / 16:9；给了 --aspect 会推算出 --canvas
#
# --card 每张卡的四个字段用竖线 | 分隔：
#   1) 画面元素（如：一束细线光柱照在人形剪影上）
#   2) 标签（如：现象）
#   3) 重点句（要突出的那句话，会用主色大字）
#   4) 说明（一句话解释 + 生活例子）
#
# 不传 --out 时输出到 stdout。
# =============================================================================
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for f in "$SKILL_DIR/.env" "./.env"; do
  if [ -f "$f" ]; then set -a; . "$f"; set +a; fi
done

topic=""; title=""; sub=""; lead=""; rule=""; out=""
signature=""
accent="${BRAND_ACCENT:-墨绿 #2F4F45}"
canvas="${IMG_DEFAULT_SIZE:-2160x2880}"
logic="现象 → 真相 → 机制 → 行动"
layout="linear-progression"
style="minimal-editorial"
aspect=""
role="极简细线描插画，线宽约 1pt（相对 2160 宽画布），单色（墨 #1F1F1D 或主色），不填色、不加阴影、不用粗黑描边。可用几何形、示意线、极简符号、剖面线、坐标轴、细箭头等功能性图形。每张卡片最多一个图形锚点，宁缺勿滥，没有合适的就留白不放图。禁止：卡通角色、拟人表情、丑萌小怪物、拟声词、贴纸感、手绘抖动质感、渐变、任何现成 IP。"
cards=()

while [ "$#" -gt 0 ]; do
  case "$1" in
    --topic)     topic="${2:-}"; shift 2;;
    --title)     title="${2:-}"; shift 2;;
    --sub)       sub="${2:-}"; shift 2;;
    --lead)      lead="${2:-}"; shift 2;;
    --card)      cards+=("${2:-}"); shift 2;;
    --rule)      rule="${2:-}"; shift 2;;
    --logic)     logic="${2:-}"; shift 2;;
    --signature) signature="${2:-}"; shift 2;;
    --accent)    accent="${2:-}"; shift 2;;
    --canvas)    canvas="${2:-}"; shift 2;;
    --layout)    layout="${2:-}"; shift 2;;
    --style)     style="${2:-}"; shift 2;;
    --aspect)    aspect="${2:-}"; shift 2;;
    --role)      role="${2:-}"; shift 2;;
    --out)       out="${2:-}"; shift 2;;
    -h|--help)   sed -n '2,21p' "$0"; exit 0;;
    *) echo "未知参数: $1" >&2; exit 2;;
  esac
done

[ -n "$topic" ] || { echo "缺少 --topic" >&2; exit 2; }
[ -n "$title" ] || { echo "缺少 --title" >&2; exit 2; }
[ "${#cards[@]}" -ge 2 ] || { echo "至少需要 2 个 --card（建议 3~4 个）" >&2; exit 2; }
if [ -z "$signature" ]; then
  cat >&2 <<'EOF'
缺少 --signature：署名必须由用户指定并输入，本脚本不提供默认值。
先向用户确认这次图的署名（例如 "@在地心理"），再把结果作为 --signature 传入。
EOF
  exit 2
fi

# --- 比例 → 画布（给了 --aspect 才覆盖） -------------------------------------
if [ -n "$aspect" ]; then
  case "$aspect" in
    3:4)  canvas="2160x2880";;
    9:16) canvas="1620x2880";;
    1:1)  canvas="2160x2160";;
    16:9) canvas="2880x1620";;
    *) echo "--aspect 只支持 3:4 / 9:16 / 1:1 / 16:9（默认 3:4）" >&2; exit 2;;
  esac
fi

# --- 比例文案（标题区、风格区共用） ------------------------------------------
case "${aspect:-3:4}" in
  3:4|"") rlabel="3:4竖版";;
  9:16)   rlabel="9:16竖版";;
  1:1)    rlabel="1:1方形";;
  16:9)   rlabel="16:9横版";;
esac

# --- 查表：布局 ---------------------------------------------------------------
LAYOUT_TSV="$SKILL_DIR/reference/layouts/catalog.tsv"
STYLE_TSV="$SKILL_DIR/reference/styles/catalog.tsv"
[ -f "$LAYOUT_TSV" ] || { echo "缺少 $LAYOUT_TSV" >&2; exit 2; }
[ -f "$STYLE_TSV" ]  || { echo "缺少 $STYLE_TSV"  >&2; exit 2; }

row_of() { # $1=tsv $2=key
  awk -F'\t' -v k="$2" 'NR>1 && $1==k {print; exit}' "$1"
}
layout_row="$(row_of "$LAYOUT_TSV" "$layout")"
if [ -z "$layout_row" ]; then
  echo "未知 --layout: $layout" >&2
  echo "可选：" >&2
  awk -F'\t' 'NR>1 {printf "  %-22s %s\n", $1, $2}' "$LAYOUT_TSV" >&2
  exit 2
fi
style_row="$(row_of "$STYLE_TSV" "$style")"
if [ -z "$style_row" ]; then
  echo "未知 --style: $style" >&2
  echo "可选：" >&2
  awk -F'\t' 'NR>1 {printf "  %-22s %s\n", $1, $2}' "$STYLE_TSV" >&2
  exit 2
fi

layout_cn="$(printf '%s' "$layout_row" | cut -f2)"
layout_use="$(printf '%s' "$layout_row" | cut -f3)"
layout_adapt="$(printf '%s' "$layout_row" | cut -f4)"
layout_frag="$(printf '%s' "$layout_row" | cut -f5)"
style_cn="$(printf '%s' "$style_row" | cut -f2)"

NUM_CN=(零 一 二 三 四 五 六 七 八)
NUM_MARK=(① ② ③ ④ ⑤ ⑥ ⑦)

# 非默认风格：抽出该风格的配色/元素/避免项，原样注入（英文定义可直接被模型理解）
style_block() {
  local f="$SKILL_DIR/reference/styles/$style.md"
  [ -f "$f" ] || { echo "（未找到风格定义 $f）"; return; }
  awk '
    /^## / { sec=$0 }
    sec ~ /Color Palette|Visual Elements|Style Enforcement|Avoid|Typography/ { if ($0 !~ /^## /) print }
  ' "$f" | sed '/^$/d'
}

build() {
  if [ "$style" = "minimal-editorial" ]; then
    printf '%s信息图，%s，纯白背景 #FFFFFF，现代极简编辑风信息图：低饱和、单色系、细线描、大量留白，干净高级、克制不花哨。字号层级分明，行距 1.6，四边安全边距不少于 8%%。全图只用一个强调色（%s），其余为墨黑与灰阶，禁止多色并用、禁止渐变、禁止彩色阴影。\n\n' "$rlabel" "$canvas" "$accent"
  else
    printf '%s信息图，%s，视觉风格：%s（%s）。层级分明，行距 1.6，四边安全边距不少于 8%%。本图不用极简单色规范，改按下面的风格定义执行；但文字必须清晰准确、信息层级必须分明。\n' "$rlabel" "$canvas" "$style_cn" "$style"
    printf '【风格定义 · %s（%s）（必须整体一致，不得混搭其他风格）】\n' "$style_cn" "$style"
    style_block
    printf '\n'
  fi
  printf '主题：%s\n\n' "$topic"

  # 非默认布局：先给信息结构（优先级高于默认单列）
  if [ "$layout" != "linear-progression" ]; then
    printf '【信息结构：%s（%s）——优先级高于下面的默认单列卡片】\n' "$layout_cn" "$layout"
    printf '用途：%s\n' "$layout_use"
    printf '排法：%s\n' "$layout_frag"
    printf '竖版适配：%s。节点不超过 5 个；横版的「左右并排」一并改「上下分段」；装饰性元素一律不加。\n\n' "$layout_adapt"
  fi

  printf '【版面结构与信息层级（从上到下分层，必须一眼看出主次和阅读顺序）】\n'
  printf 'L1 大标题：思源宋体 Medium，墨黑 #1F1F1D，全图最大字号，最多两行，靠字重和字号压场，不用彩色标题："%s"\n' "$title"
  if [ -n "$sub" ]; then
    printf 'L2 副标题：约标题一半字号，深灰色："%s"\n' "$sub"
  fi
  if [ -n "$lead" ]; then
    printf 'L3 一句机制：更小字号、浅灰色："%s"\n' "$lead"
  fi

  if [ "$layout" = "linear-progression" ]; then
    printf 'L4 知识卡片区（全图主体）：%s张卡片单列从上到下排列，按「%s」的递进逻辑串起来；卡片之间用留白加一条 1px 浅灰细线 #E3E3DE 分隔，形成清楚的阅读路线，不要堆箭头。\n' \
      "${NUM_CN[${#cards[@]}]}" "$logic"
    printf '   每张卡片左上角有%s圆形序号 %s（细线圆圈 + 主色数字，不用实心色块）；卡片内部统一为「小标签 → 大字重点句 → 小字说明」三级层次，全部左对齐；所有卡片同一底色 #F6F1E7、同一圆角，靠留白分区，不靠颜色分区。\n' \
      "$accent" "${NUM_MARK[*]:0:${#cards[@]}}"
  else
    printf 'L4 内容区（全图主体）：共 %s 组内容，按上面【信息结构：%s】的排法摆放（不再要求单列卡片）；每组仍是「小标签 → 大字重点句 → 小字说明」三级，全部左对齐；所有区块同一底色 #F6F1E7，靠留白和 1px 细线 #E3E3DE 分区。\n' \
      "${#cards[@]}" "$layout_cn"
    printf '   每组左上角有%s圆形序号 %s（细线圆圈 + 主色数字）。\n' "$accent" "${NUM_MARK[*]:0:${#cards[@]}}"
  fi

  local i=0 c rest f1 f2 f3 f4
  for c in "${cards[@]}"; do
    i=$((i+1))
    f1="${c%%|*}"
    # 兜底：卡片底色统一由模板写死，剥掉用户可能带进来的旧色底/旧画风词
    if [[ "$f1" == 浅*底，* || "$f1" == 彩色底，* ]]; then f1="${f1#*底，}"; fi
    f1=${f1//小怪物/极简人形剪影}
    f1=${f1//手绘/细线描}
    rest="${c#*|}"
    f2="${rest%%|*}"; rest="${rest#*|}"
    f3="${rest%%|*}"; f4="${rest#*|}"
    if [ "$rest" = "$f4" ]; then
      echo "  --card 需要 4 个字段（底色/画面元素|标签|重点句|说明），收到：$c" >&2
      exit 2
    fi
    printf '   内容%d（卡面 #F6F1E7，%s）：标签"%s"，墨黑重点句大字"%s"（其中关键词可用%s），说明小字"%s"。\n' "$i" "$f1" "$f2" "$f3" "$accent" "$f4"
  done
  printf '\n'
  if [ -n "$rule" ]; then
    printf 'L5 收尾：不用色块横条。一条 1px 浅灰细线之上，一行%s加粗短句："%s"\n' "$accent" "$rule"
  fi
  printf 'L6 署名：最底部居中一行小字，不能省、不能换位置："%s"\n\n' "$signature"

  printf '字号层级参考：大标题 100%%，卡片重点句 58%%，副标题 42%%，说明 32%%，标签 24%%，署名 20%%；层级之间用字号和字重拉开差距，不靠颜色区分层级。\n\n'
  if [ "$style" = "minimal-editorial" ]; then
    printf '插画元素：%s\n\n' "$role"
    printf '文字要求：中文简体规范无乱码，英文拼写标点完全正确，中英文之间留 1/4 字空隙；四周留安全边距，不裁切不遮挡。全图色相不超过 3 个（白/灰不计），平均饱和度不超过 18%%，近白与卡面灰占比不低于 45%%。底部居中一行浅灰小字：%s\n' "$signature"
  else
    printf '插画元素遵循上面风格定义；每张图内元素风格必须统一，禁止现成 IP。\n\n'
    printf '文字要求：中文简体规范无乱码，英文拼写标点完全正确，中英文之间留 1/4 字空隙；四周留安全边距，不裁切不遮挡；插画内部不出现任何文字、字母、数字（要表现「有字」用几道灰线代替）。底部居中一行浅灰小字：%s\n' "$signature"
  fi
}

if [ -n "$out" ]; then
  mkdir -p "$(dirname "$out")"
  build > "$out"
  echo "PROMPT_SAVED=$out" >&2
  echo "SIGNATURE=$signature" >&2
  echo "LAYOUT=$layout" >&2
  echo "STYLE=$style" >&2
  echo "CANVAS=$canvas" >&2
else
  build
fi
