#!/usr/bin/env bash
# =============================================================================
# gen_image.sh — 可插拔生图脚本
#
# 两种接入方式（任选其一，见 ../.env.example）：
#   A. OpenAI 兼容接口：  IMG_API_BASE + IMG_API_KEY (+ IMG_MODEL)
#      走 POST {IMG_API_BASE}/images/generations，兼容返回 b64_json 或 url。
#   B. 自定义命令：       IMG_CMD="my-gen"
#      脚本会调用：
#        $IMG_CMD --prompt "..." --out /path/x.png --size WxH [--model M] [--quality Q] [--input 参考图]...
#      只要该命令把图片写到 --out 即可。
#
# 用法：
#   bash gen_image.sh --prompt "..." --out out.png [--size 2160x2880]
#                     [--model ...] [--quality ...] [--n 1] [--input ref.png]...
#
# 退出码：0 成功；1 生成/落盘失败；2 参数或配置错误
# =============================================================================
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# ---- 载入配置：skill 目录下的 .env 与当前目录的 .env ----
for f in "$SKILL_DIR/.env" "./.env"; do
  if [ -f "$f" ]; then
    set -a
    # shellcheck disable=SC1090
    . "$f"
    set +a
  fi
done

prompt=""; out=""; size="${IMG_DEFAULT_SIZE:-2160x2880}"
model="${IMG_MODEL:-}"; quality=""; n=""; max_retry="${IMG_MAX_RETRY:-3}"
inputs=()

usage() {
  cat <<'U'
用法: gen_image.sh --prompt "..." [--out 路径] [--size 2160x2880]
                   [--model 名称] [--quality 档位] [--n 数量] [--input 参考图]...

配置（环境变量或 .env）:
  A) OpenAI 兼容接口:  IMG_API_BASE  IMG_API_KEY  IMG_MODEL
  B) 自定义命令:       IMG_CMD
  可选: IMG_DEFAULT_SIZE(默认 2160x2880)  IMG_MAX_RETRY(默认 3)
U
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --prompt)  prompt="${2:-}"; shift 2;;
    --out)     out="${2:-}"; shift 2;;
    --input)   inputs+=("${2:-}"); shift 2;;
    --size)    size="${2:-}"; shift 2;;
    --model)   model="${2:-}"; shift 2;;
    --quality) quality="${2:-}"; shift 2;;
    --n)       n="${2:-}"; shift 2;;
    -h|--help) usage; exit 0;;
    *) echo "未知参数: $1" >&2; usage >&2; exit 2;;
  esac
done

[ -n "$prompt" ] || { echo "IMAGE_PROMPT_MISSING: 缺少 --prompt" >&2; exit 2; }
[ -n "$out" ] || out="$PWD/generated/infographic-$(date +%Y%m%d-%H%M%S).png"
mkdir -p "$(dirname "$out")"

finish() { printf 'IMAGE_SAVED=%s\n' "$(cd "$(dirname "$out")" && pwd)/$(basename "$out")"; }

# ---------------------------------------------------------------------------
# 模式 B：自定义命令
# ---------------------------------------------------------------------------
if [ -n "${IMG_CMD:-}" ]; then
  printf 'IMAGE_SKILL_STARTED (custom command)\n'
  args=(--prompt "$prompt" --out "$out" --size "$size")
  [ -n "$model" ]   && args+=(--model "$model")
  [ -n "$quality" ] && args+=(--quality "$quality")
  [ -n "$n" ]       && args+=(--n "$n")
  for f in "${inputs[@]:-}"; do [ -n "$f" ] && args+=(--input "$f"); done
  # shellcheck disable=SC2086
  $IMG_CMD "${args[@]}"
  [ -s "$out" ] || { echo "IMAGE_WRITE_FAILED: 自定义命令未生成图片: $out" >&2; exit 1; }
  finish
  exit 0
fi

# ---------------------------------------------------------------------------
# 模式 A：OpenAI 兼容接口
# ---------------------------------------------------------------------------
base="${IMG_API_BASE:-}"; key="${IMG_API_KEY:-}"

# 支持从文件读 Key（避免把密钥直接写进 .env）
if [ -z "$key" ] && [ -n "${IMG_API_KEY_FILE:-}" ] && [ -f "${IMG_API_KEY_FILE}" ]; then
  key="$(tr -d '\r\n' < "${IMG_API_KEY_FILE}")"
fi

if [ -z "$base" ] || [ -z "$key" ]; then
  echo "IMAGE_CONFIG_MISSING: 未配置生图接口。" >&2
  echo "  请设置 IMG_API_BASE + (IMG_API_KEY 或 IMG_API_KEY_FILE)（OpenAI 兼容接口），" >&2
  echo "  或设置 IMG_CMD 指向你自己的生图命令。参考 .env.example。" >&2
  exit 2
fi
base="${base%/}"
[ -n "$model" ] || model="${IMG_DEFAULT_MODEL:-gpt-image-2}"

nref=${#inputs[@]}
for f in "${inputs[@]:-}"; do
  [ -z "$f" ] && continue
  [ -f "$f" ] || { echo "找不到参考图片：$f" >&2; exit 2; }
done

printf 'IMAGE_SKILL_STARTED\n'
printf 'ENDPOINT=%s  MODEL=%s  QUALITY=%s  SIZE=%s  REFS=%s\n' \
  "$base" "$model" "${quality:-默认}" "$size" "$nref"

tmp="$(mktemp)"; trap 'rm -f "$tmp"' EXIT
attempt=1
while :; do
  if [ "$nref" -gt 0 ]; then
    url="$base/images/edits"
    cargs=(-sS --max-time 600 -X POST -H "Authorization: Bearer $key"
          -F "model=$model" -F "prompt=$prompt")
    [ -n "$size" ]    && cargs+=(-F "size=$size")
    [ -n "$quality" ] && cargs+=(-F "quality=$quality")
    [ -n "$n" ]       && cargs+=(-F "n=$n")
    if [ "$nref" -eq 1 ]; then cargs+=(-F "image=@${inputs[0]}")
    else for f in "${inputs[@]}"; do cargs+=(-F "image[]=@$f"); done; fi
  else
    url="$base/images/generations"
    json="{\"model\":\"$model\",\"prompt\":$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$prompt")"
    [ -n "$size" ]    && json="$json,\"size\":\"$size\""
    [ -n "$quality" ] && json="$json,\"quality\":\"$quality\""
    [ -n "$n" ]       && json="$json,\"n\":$n"
    json="$json}"
    cargs=(-sS --max-time 600 -X POST -H "Authorization: Bearer $key"
           -H 'Content-Type: application/json' -d "$json")
  fi

  http_ok=1
  curl "${cargs[@]}" "$url" >"$tmp" || http_ok=0

  if [ "$http_ok" = 1 ] && python3 "$SKILL_DIR/scripts/_extract_image.py" "$tmp" "$out"; then
    break
  fi

  if [ "$attempt" -ge "$max_retry" ]; then
    echo "IMAGE_FAILED: 重试 $attempt 次仍未成功（服务端不稳定或配置有误）" >&2
    echo "  提示：502/503/超时/-2700(接口成功但没有数据) 多为服务端波动，稍后重试或换模型/降尺寸。" >&2
    exit 1
  fi
  echo "IMAGE_RETRY: 第 $attempt 次失败，$((attempt*20))s 后重试..." >&2
  sleep $((attempt*20))
  attempt=$((attempt+1))
done

[ -s "$out" ] || { echo "IMAGE_WRITE_FAILED: 图片文件为空" >&2; exit 1; }
finish
