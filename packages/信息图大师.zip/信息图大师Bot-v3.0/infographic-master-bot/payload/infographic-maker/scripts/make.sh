#!/usr/bin/env bash
# =============================================================================
# make.sh — 一条命令出图：组装提示词 → 生成 → 核验尺寸
#
# 参数与 make_prompt.sh 完全一致，额外需要 --out（图片路径）：
#
#   bash make.sh --topic "..." --title "..." --signature "@用户给的署名" \
#        --card "底色，画面元素|标签|重点句|说明" （可重复） \
#        [--sub ...] [--lead ...] [--rule ...] [--logic ...] [--out 图.png]
#
# --signature 必填：署名必须由用户指定并输入，脚本不提供默认值。
# 结束后打印图片路径与尺寸，并把提示词存到同目录的 <图名>.prompt.txt 便于复盘。
# =============================================================================
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

out=""; passthru=(); aspect=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --out) out="${2:-}"; shift 2;;
    --aspect) aspect="${2:-}"; passthru+=("$1" "${2:-}"); shift 2;;
    -h|--help) sed -n '2,13p' "$0"; exit 0;;
    *) passthru+=("$1"); shift;;
  esac
done
[ -n "$out" ] || { echo "缺少 --out 图片路径" >&2; exit 2; }

promptfile="${out%.png}.prompt.txt"
bash "$SKILL_DIR/scripts/make_prompt.sh" "${passthru[@]}" --out "$promptfile"

echo "--- 提示词 ---" >&2
cat "$promptfile" >&2
echo "--------------" >&2

bash "$SKILL_DIR/scripts/gen_image.sh" --out "$out" \
  --prompt "$(cat "$promptfile")"

want="${IMG_DEFAULT_SIZE:-2160x2880}"
case "$aspect" in
  9:16) want="1620x2880";;
  1:1)  want="2160x2160";;
  16:9) want="2880x1620";;
  3:4|"") : ;;
esac
bash "$SKILL_DIR/scripts/check_image.sh" "$out" --want "$want"
