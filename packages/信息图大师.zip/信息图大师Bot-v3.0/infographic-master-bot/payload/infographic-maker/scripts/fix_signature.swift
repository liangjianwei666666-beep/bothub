// =============================================================================
// fix_signature.swift — 底部署名修复（macOS / AppKit）
//
// 背景：生图模型经常把底部 "@帧心英语" 写错（帧/顿/侦/I…）或写漏。
// 做法：覆盖底部一条横带（取样原底色或指定纯色），再用 PingFang SC 重画署名。
//
// 用法:
//   swift fix_signature.swift <图.png> [--out 输出.png] \
//         [--text "@帧心英语"] [--band 0.065] \
//         [--bg auto|white|#RRGGBB] [--fg auto|dark|light|#RRGGBB] \
//         [--font-ratio 0.022] [--y-center 0.5]
//
//   --band       底部带高占整图比例（默认 0.065）
//   --bg auto    从底部带里采样“最常见且较亮”的颜色作为底色；粉笔黑板图请传 #2A4440 之类
//   --fg auto    底色亮→深灰字；底色暗→白字
//   --font-ratio 字号 = 图宽 × 该比例（默认 0.022）
//   --y-center   文字在带内的纵向位置（0=带顶,1=带底），默认 0.5
//
// 输出末尾打印 OUTPUT_SIZE=WxH，便于核对（AppKit 有时会翻倍画布）。
// 注意：若输出尺寸被翻倍，用 `sips -z 2880 2160 out.png` 缩回标准规格。
// =============================================================================
import AppKit
import Foundation

func hexColor(_ s: String) -> NSColor? {
    var h = s.trimmingCharacters(in: .whitespaces)
    if h.hasPrefix("#") { h.removeFirst() }
    guard h.count == 6, let v = Int(h, radix: 16) else { return nil }
    return NSColor(calibratedRed: CGFloat((v >> 16) & 0xFF) / 255.0,
                   green: CGFloat((v >> 8) & 0xFF) / 255.0,
                   blue: CGFloat(v & 0xFF) / 255.0, alpha: 1.0)
}

var args = Array(CommandLine.arguments.dropFirst())
guard let input = args.first, !input.hasPrefix("--") else {
    FileHandle.standardError.write("用法: swift fix_signature.swift <图.png> [--out 输出.png] [--text @帧心英语] [--band 0.065] [--bg auto|white|#RRGGBB] [--fg auto|dark|light|#RRGGBB] [--font-ratio 0.022] [--y-center 0.5]\n".data(using: .utf8)!)
    exit(2)
}
args.removeFirst()

var outPath = input
var text = "@帧心英语"
var bandFrac = 0.065
var bgSpec = "auto"
var fgSpec = "auto"
var fontRatio = 0.022
var yCenter = 0.5

var i = 0
while i < args.count {
    switch args[i] {
    case "--out": outPath = args[i + 1]; i += 2
    case "--text": text = args[i + 1]; i += 2
    case "--band": bandFrac = Double(args[i + 1]) ?? bandFrac; i += 2
    case "--bg": bgSpec = args[i + 1]; i += 2
    case "--fg": fgSpec = args[i + 1]; i += 2
    case "--font-ratio": fontRatio = Double(args[i + 1]) ?? fontRatio; i += 2
    case "--y-center": yCenter = Double(args[i + 1]) ?? yCenter; i += 2
    default: i += 1
    }
}

guard let img = NSImage(contentsOfFile: input),
      let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
    FileHandle.standardError.write("FIX_FAIL: 无法读取图片 \(input)\n".data(using: .utf8)!)
    exit(1)
}
let W = cg.width, H = cg.height

guard let rep = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: W, pixelsHigh: H,
                                 bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true,
                                 isPlanar: false, colorSpaceName: .deviceRGB,
                                 bytesPerRow: 0, bitsPerPixel: 0) else {
    FileHandle.standardError.write("FIX_FAIL: 无法创建画布\n".data(using: .utf8)!)
    exit(1)
}
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
NSGraphicsContext.current?.shouldAntialias = true
img.draw(in: NSRect(x: 0, y: 0, width: CGFloat(W), height: CGFloat(H)))

// ---- 采样底部带背景色（取出现次数最多、且较亮的颜色） ----
func sampleBandColor() -> NSColor {
    var counts: [UInt32: Int] = [:]
    let y0 = Int(Double(H) * (1.0 - bandFrac))
    for y in stride(from: y0, to: H, by: 3) {
        for x in stride(from: 0, to: W, by: 3) {
            guard let c = rep.colorAt(x: x, y: y) else { continue }
            let r = UInt32(c.redComponent * 255), g = UInt32(c.greenComponent * 255), b = UInt32(c.blueComponent * 255)
            let lum = 0.299 * c.redComponent + 0.587 * c.greenComponent + 0.114 * c.blueComponent
            if lum < 0.15 { continue }  // 跳过纯黑文字
            let key = (r << 16) | (g << 8) | b
            counts[key, default: 0] += 1
        }
    }
    guard let best = counts.max(by: { $0.value < $1.value })?.key else { return .white }
    return NSColor(calibratedRed: CGFloat((best >> 16) & 0xFF) / 255.0,
                   green: CGFloat((best >> 8) & 0xFF) / 255.0,
                   blue: CGFloat(best & 0xFF) / 255.0, alpha: 1.0)
}

var bg: NSColor
if bgSpec == "auto" { bg = sampleBandColor() }
else if bgSpec == "white" { bg = .white }
else { bg = hexColor(bgSpec) ?? .white }

let bgLum = 0.299 * bg.redComponent + 0.587 * bg.greenComponent + 0.114 * bg.blueComponent

var fg: NSColor
switch fgSpec {
case "auto": fg = bgLum > 0.55 ? NSColor(calibratedWhite: 0.18, alpha: 1) : .white
case "dark": fg = NSColor(calibratedWhite: 0.18, alpha: 1)
case "light": fg = .white
default: fg = hexColor(fgSpec) ?? (bgLum > 0.55 ? NSColor(calibratedWhite: 0.18, alpha: 1) : .white)
}

// ---- 覆盖底部带 ----
let bandH = CGFloat(Double(H) * bandFrac)
let bandRect = NSRect(x: 0, y: 0, width: CGFloat(W), height: bandH)
bg.setFill()
bandRect.fill()

// ---- 重画署名 ----
let fontSize = CGFloat(Double(W) * fontRatio)
let font = NSFont(name: "PingFangSC-Medium", size: fontSize) ?? NSFont.systemFont(ofSize: fontSize)
let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: fg]
let str = NSAttributedString(string: text, attributes: attrs)
let ts = str.size()
let tx = (CGFloat(W) - ts.width) / 2
let ty = bandH * CGFloat(yCenter) - ts.height / 2
str.draw(at: NSPoint(x: tx, y: max(0, ty)))

NSGraphicsContext.restoreGraphicsState()

guard let png = rep.representation(using: .png, properties: [:]) else {
    FileHandle.standardError.write("FIX_FAIL: PNG 编码失败\n".data(using: .utf8)!)
    exit(1)
}
do {
    try png.write(to: URL(fileURLWithPath: outPath))
} catch {
    FileHandle.standardError.write("FIX_FAIL: 写文件失败 \(error)\n".data(using: .utf8)!)
    exit(1)
}
print("FIX_OK=\(outPath)")
print("OUTPUT_SIZE=\(rep.pixelsWide)x\(rep.pixelsHigh)")
