#!/usr/bin/env bash
# =============================================================================
# compress_image.sh — 把成品图压到发布平台能吃的体积（保持比例，不裁切）
#
# 用法：
#   bash compress_image.sh 输入.png --max-kb 1000 --out 输出.jpg
#   bash compress_image.sh 输入.png --width 2160  --max-kb 700 --out 输出.jpg
#
#   --max-kb  目标上限（KB）。X 用 1000；小红书常用 700；稳妥版 300
#   --width   输出宽度（保持 3:4 比例等比缩），不给就保持原宽
#   --quality 起始 JPEG 质量（默认 92，脚本会自动往下降）
#   --out     输出路径（.jpg）；不给则输出到 输入名-<maxkb>k.jpg
#
# 依赖：python3 + Pillow
# =============================================================================
set -euo pipefail
src=""; maxkb="1000"; width=""; qstart="92"; out=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --max-kb)  maxkb="${2:-}"; shift 2;;
    --width)   width="${2:-}"; shift 2;;
    --quality) qstart="${2:-}"; shift 2;;
    --out)     out="${2:-}"; shift 2;;
    -h|--help) sed -n '2,17p' "$0"; exit 0;;
    -*) echo "未知参数: $1" >&2; exit 2;;
    *)  src="$1"; shift;;
  esac
done
[ -n "$src" ] || { echo "用法: compress_image.sh 输入.png --max-kb 1000 --out 输出.jpg" >&2; exit 2; }
[ -f "$src" ] || { echo "文件不存在: $src" >&2; exit 2; }
[ -n "$out" ] || out="${src%.*}-${maxkb}k.jpg"

python3 - "$src" "$out" "$maxkb" "$width" "$qstart" <<'PY'
import sys, os
from PIL import Image
src, out, maxkb, width, qstart = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4], int(sys.argv[5])
im = Image.open(src)
if im.mode in ('RGBA','LA','P'):
    bg = Image.new('RGB', im.size, (255,255,255))
    im2 = im.convert('RGBA')
    bg.paste(im2, mask=im2.split()[-1])
    im = bg
else:
    im = im.convert('RGB')
orig_w, orig_h = im.size
if width:
    w = int(width); h = round(orig_h * w / orig_w)
    if w < orig_w:
        im = im.resize((w, h), Image.LANCZOS)

target = maxkb * 1024
best = None
q = qstart
cur = im
scales = [1.0, 0.92, 0.85, 0.78, 0.7, 0.62]
for s in scales:
    if s != 1.0:
        cur = im.resize((max(1,int(im.width*s)), max(1,int(im.height*s))), Image.LANCZOS)
    for qq in range(q, 49, -4):
        tmp = out + ".tmp.jpg"
        cur.save(tmp, 'JPEG', quality=qq, optimize=True, progressive=True)
        size = os.path.getsize(tmp)
        if size <= target:
            os.replace(tmp, out)
            print("OK %dx%d %.1fKB quality=%d scale=%.2f" % (cur.width, cur.height, size/1024, qq, s))
            sys.exit(0)
        best = (tmp, size)
    q = max(60, q - 6)
# 仍未达标：保留最小的一份并明确报警
if best and os.path.exists(best[0]):
    os.replace(best[0], out)
    print("WARN 压到 %.1fKB 仍超过目标 %dKB，已保留最小版本 %s" % (best[1]/1024, maxkb, out))
    sys.exit(0)
print("FAIL 无法压缩", file=sys.stderr)
sys.exit(1)
PY
