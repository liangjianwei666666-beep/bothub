#!/usr/bin/env bash
# =============================================================================
# check_image.sh — 尺寸核验（生成后必做的一步）
#
# 校验重点：
#   1. 能读出宽高
#   2. 比例是否为 3:4（容差 1%）
#   3. 是否达到目标规格（默认 2160x2880，可用 --want WxH 覆盖）
#
# 用法:
#   bash check_image.sh 图.png [--want 2160x2880]
#
# 退出码：0 通过；1 不通过
# 依赖：优先 sips(macOS)，其次 python3+Pillow，再次 ImageMagick `identify`，最后 `file`
# =============================================================================
set -euo pipefail

img=""; want="${IMG_DEFAULT_SIZE:-2160x2880}"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --want) want="${2:-}"; shift 2;;
    -h|--help) echo "用法: check_image.sh 图.png [--want 2160x2880]"; exit 0;;
    *) img="$1"; shift;;
  esac
done
[ -n "$img" ] || { echo "用法: check_image.sh 图.png [--want 2160x2880]" >&2; exit 2; }
[ -f "$img" ] || { echo "IMAGE_NOT_FOUND: $img" >&2; exit 2; }

W=""; H=""
if command -v sips >/dev/null 2>&1; then
  W="$(sips -g pixelWidth "$img" 2>/dev/null | awk '/pixelWidth/{print $2}')"
  H="$(sips -g pixelHeight "$img" 2>/dev/null | awk '/pixelHeight/{print $2}')"
fi
if { [ -z "$W" ] || [ -z "$H" ]; } && command -v python3 >/dev/null 2>&1; then
  read -r W H <<<"$(python3 - "$img" <<'PY' 2>/dev/null || true
import sys
try:
    from PIL import Image
    w, h = Image.open(sys.argv[1]).size
    print(w, h)
except Exception:
    pass
PY
)"
fi
if { [ -z "$W" ] || [ -z "$H" ]; } && command -v identify >/dev/null 2>&1; then
  read -r W H <<<"$(identify -format '%w %h' "$img" 2>/dev/null || true)"
fi
if [ -z "$W" ] || [ -z "$H" ]; then
  echo "IMAGE_DIM_UNKNOWN: 无法读取尺寸（请安装 python3+Pillow 或 ImageMagick）" >&2
  exit 1
fi

echo "SIZE=${W}x${H}"

# 3:4 校验（竖版），容差 1%
awk -v w="$W" -v h="$H" 'BEGIN{
  if (w<=0||h<=0){print "IMAGE_DIM_INVALID"; exit 1}
  ratio = w/h; target = 3/4;
  if (ratio > target*1.01 || ratio < target*0.99){
    printf "IMAGE_RATIO_FAIL: %.4f（目标 0.75，非 3:4 竖版）\n", ratio; exit 1
  }
}' || exit 1

wantW="${want%x*}"; wantH="${want#*x}"
if [ -n "$wantW" ] && [ -n "$wantH" ]; then
  if [ "$W" != "$wantW" ] || [ "$H" != "$wantH" ]; then
    echo "IMAGE_SIZE_WARN: 期望 ${wantW}x${wantH}，实际 ${W}x${H}（比例仍合格）"
  else
    echo "IMAGE_SIZE_OK: ${W}x${H}"
  fi
fi
echo "IMAGE_RATIO_OK: 3:4"
exit 0
