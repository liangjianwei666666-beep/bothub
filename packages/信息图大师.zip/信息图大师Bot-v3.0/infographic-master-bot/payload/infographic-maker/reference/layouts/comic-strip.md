# comic-strip

Sequential narrative panels telling a story or explaining a concept.

## Structure

- Multiple panels in sequence
- Left-to-right, top-to-bottom reading
- Characters or subjects in scenes
- Speech/thought bubbles
- Panel borders clearly defined

## Best For

- Storytelling explanations
- User journey narratives
- Scenario illustrations
- Step sequences with context
- Before/during/after stories

## Visual Elements

- Panel frames
- Speech and thought bubbles
- Sound effects (optional)
- Characters with expressions
- Scene backgrounds

## Text Placement

- Title at top
- Dialogue in speech bubbles
- Narration in caption boxes
- Sound effects integrated
- Panel numbers if needed

## Recommended Pairings

- `graphic-novel`: Dramatic narratives
- `kawaii`: Cute character stories
- `cartoon-hand-drawn`: Friendly explanations

## 3:4 竖版适配（本机）

- 中文名：四格漫画
- 适用：叙事、前后变化、过程
- 竖版改法：3~4 格竖排，格间 1px 细线
- 提示词片段：竖排 3~4 格，格与格之间用 1px 细线分隔，每格一句台词或标注，格内插画保持极简细线，不画卡通表情包
