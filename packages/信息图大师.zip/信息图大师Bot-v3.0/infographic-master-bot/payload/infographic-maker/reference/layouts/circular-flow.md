# circular-flow

Cyclic process showing continuous or recurring steps.

## Structure

- Circular arrangement
- Steps around the circle
- Arrows showing direction
- No clear start/end (continuous)
- Center can hold main concept

## Best For

- Recurring processes
- Feedback loops
- Lifecycle stages
- Continuous improvement
- Natural cycles

## Visual Elements

- Circle or ring shape
- Directional arrows
- Step nodes evenly spaced
- Icons per step
- Optional center element

## Text Placement

- Title at top
- Step labels at each node
- Brief descriptions near nodes
- Center concept if applicable
- Cycle name

## Recommended Pairings

- `cartoon-hand-drawn`: Friendly cycles
- `corporate-memphis`: Business processes
- `subway-map`: Transit-style cycles

## 3:4 竖版适配（本机）

- 中文名：环形流程
- 适用：循环、周期性过程
- 竖版改法：圆环上 3~5 个节点，箭头闭环
- 提示词片段：在圆环上均匀放 3~5 个节点，节点之间用箭头首尾相接形成闭环，圆心写一句话总结
