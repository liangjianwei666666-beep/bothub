# periodic-table

Grid of categorized elements with consistent cell formatting.

## Structure

- Rectangular grid
- Each cell is one element
- Color-coded categories
- Consistent cell format
- Optional grouping gaps

## Best For

- Categorized collections
- Tool/resource catalogs
- Skill matrices
- Element collections
- Reference guides

## Visual Elements

- Uniform cell sizes
- Category colors
- Symbol/abbreviation prominent
- Small icon per cell
- Category legend

## Text Placement

- Title at top
- Cell: symbol, name, brief info
- Category names in legend
- Optional row/column headers
- Footnotes for special cases

## Recommended Pairings

- `pop-art`: Vibrant element grids
- `pixel-art`: Retro collection displays
- `corporate-memphis`: Business tool catalogs

## 3:4 竖版适配（本机）

- 中文名：周期表
- 适用：分类集合、成套概念
- 竖版改法：网格卡片按组排列，组间留白
- 提示词片段：把要点做成网格状小卡片，按 2~3 组分组，组与组之间留白更宽，每张卡只写一个词 + 一句最短解释
