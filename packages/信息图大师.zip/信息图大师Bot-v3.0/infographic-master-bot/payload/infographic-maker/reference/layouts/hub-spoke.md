# hub-spoke

Central concept with radiating connections to related items.

## Structure

- Central hub (main concept)
- Spokes radiating outward
- Nodes at spoke ends (related concepts)
- Even or weighted distribution
- Optional secondary connections

## Best For

- Central theme with components
- Product features around core
- Team roles around project
- Ecosystem mapping
- Mind maps

## Visual Elements

- Prominent central hub
- Clear spoke lines
- Consistent node styling
- Icons representing each spoke item
- Optional grouping colors

## Text Placement

- Title at top
- Core concept in center hub
- Spoke item labels at nodes
- Brief descriptions near nodes
- Connection labels on spokes if needed

## Recommended Pairings

- `cartoon-hand-drawn`: Friendly concept maps
- `corporate-memphis`: Business ecosystems
- `subway-map`: Network-style connections

## 3:4 竖版适配（本机）

- 中文名：中心辐射
- 适用：一个核心概念 + 若干关联项
- 竖版改法：中心圆居中，四面细线放射，卫星不超过 6 个
- 提示词片段：中心一个圆写核心概念，四周 4~6 个卫星节点用小圆或小方块，细线放射连接，卫星文字不超过 6 字
