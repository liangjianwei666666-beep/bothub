# funnel

Narrowing stages showing conversion, filtering, or refinement process.

## Structure

- Wide top (input/start)
- Narrow bottom (output/result)
- Horizontal layers for stages
- Progressive narrowing
- 3-6 stages typically

## Best For

- Sales/marketing funnels
- Conversion processes
- Filtering/selection
- Recruitment pipelines
- Decision processes

## Visual Elements

- Funnel shape clearly defined
- Distinct colors per stage
- Width indicates volume/quantity
- Stage icons or symbols
- Numbers/percentages per stage

## Text Placement

- Title at top
- Stage names inside or beside
- Metrics/numbers per stage
- Input label at top
- Output label at bottom

## Recommended Pairings

- `corporate-memphis`: Marketing funnels
- `isometric-3d`: Technical pipelines
- `cartoon-hand-drawn`: Educational funnels

## 3:4 竖版适配（本机）

- 中文名：漏斗
- 适用：转化、筛选、逐步收窄
- 竖版改法：上宽下窄 3~4 层，每层一行说明
- 提示词片段：上宽下窄 3~4 层漏斗，每层左侧写阶段名、右侧写一句说明，最底层是最终动作
