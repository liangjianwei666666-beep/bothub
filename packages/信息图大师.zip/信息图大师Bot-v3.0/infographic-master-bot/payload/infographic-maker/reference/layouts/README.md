# 布局库（21 种 · 来自 baoyu-skills，本机已加 3:4 竖版适配）

来源：https://github.com/JimLiu/baoyu-skills 的 `baoyu-infographic`（MIT-0 分发）。本机只引入布局定义，出图仍走 `scripts/make.sh`。

## 怎么用

- 默认 `linear-progression`（= 我们的 L1–L6 单列递进，最稳）。
- 内容本身不是「一条线」时再换：对比用 `binary-comparison`，层级用 `hierarchical-layers`，循环用 `circular-flow`，一个核心带若干点用 `hub-spoke`。
- 一次只选一种布局，不要混。选完把 `<key>` 传给 `make.sh --layout <key>`。

## 索引

| key | 中文名 | 适用场景 | 3:4 竖版适配 |
|---|---|---|---|
| `linear-progression` | 线性递进 | 流程、时间线、教程、步骤 | 上下一条主线，节点等距，1px 细线串联 |
| `binary-comparison` | 二元对比 | A/B、前后、利弊、误解 vs 真相 | 竖版改上下两段，中间 1px 横线分割，两侧条目一一对齐 |
| `comparison-matrix` | 对比矩阵 | 多因素对比、多个对象的若干维度 | 顶部一行维度、左侧一列对象，细线表格，单元格只放最短词 |
| `hierarchical-layers` | 层级金字塔 | 优先级、能力层级、金字塔 | 从下到上逐层收窄的梯形，最底层最宽 |
| `tree-branching` | 分支树 | 分类、归属、层级树 | 根在顶部，向下分叉，分支线 1px |
| `hub-spoke` | 中心辐射 | 一个核心概念 + 若干关联项 | 中心圆居中，四面细线放射，卫星不超过 6 个 |
| `structural-breakdown` | 爆炸剖面 | 结构拆解、组成、爆炸图 | 主体居中，引线拉出标注，标注短 |
| `bento-grid` | 便当格 | 多主题概览、几个要点并列 | 2×3 不对称网格，同色同底，格间留白 |
| `iceberg` | 冰山 | 表面现象 vs 隐藏原因 | 一条水平分水线，线上小、线下大 |
| `bridge` | 桥梁 | 问题 → 方法 → 结果 | 左岸问题、右岸结果、桥面是方法 |
| `funnel` | 漏斗 | 转化、筛选、逐步收窄 | 上宽下窄 3~4 层，每层一行说明 |
| `isometric-map` | 等距场景 | 空间关系、场景化说明 | 2.5D 等距小场景，细线不填色 |
| `dashboard` | 指标看板 | KPI、数据结论、指标对比 | 顶部关键数字，下面细线图表 |
| `periodic-table` | 周期表 | 分类集合、成套概念 | 网格卡片按组排列，组间留白 |
| `comic-strip` | 四格漫画 | 叙事、前后变化、过程 | 3~4 格竖排，格间 1px 细线 |
| `story-mountain` | 故事山 | 情节结构、张力曲线 | 一条上升-峰值-下降曲线，关键点标注 |
| `jigsaw` | 拼图 | 相互关联、缺一不可 | 几块咬合拼图，每块一个要点 |
| `venn-diagram` | 维恩图 | 重叠概念、共同点 | 两圆相交，交集写结论 |
| `winding-roadmap` | 蜿蜒路线 | 旅程、里程碑、阶段 | 一条蜿蜒路径，节点标注 |
| `circular-flow` | 环形流程 | 循环、周期性过程 | 圆环上 3~5 个节点，箭头闭环 |
| `dense-modules` | 高密度模块 | 信息量大、指南、清单 | 多模块密排但留白，模块间细线 |

详细结构定义见同目录 `<key>.md`；机器可读版本见 `catalog.tsv`。
