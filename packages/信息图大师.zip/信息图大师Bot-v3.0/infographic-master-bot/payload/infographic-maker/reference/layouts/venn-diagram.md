# venn-diagram

Overlapping circles showing relationships, commonalities, and differences.

## Structure

- 2-3 overlapping circles
- Each circle is a category/concept
- Overlaps show shared elements
- Center shows common to all
- Unique areas for exclusives

## Best For

- Concept relationships
- Skill overlaps
- Market segments
- Comparative analysis
- Finding common ground

## Visual Elements

- Translucent circle fills
- Clear overlap regions
- Distinct colors per circle
- Icons in regions
- Boundary labels

## Text Placement

- Title at top
- Circle labels outside or on edge
- Items in appropriate regions
- Overlap region labels
- Legend if needed

## Recommended Pairings

- `cartoon-hand-drawn`: Friendly concept overlaps
- `corporate-memphis`: Business segment analysis
- `pop-art`: High-contrast comparisons

## 3:4 竖版适配（本机）

- 中文名：维恩图
- 适用：重叠概念、共同点
- 竖版改法：两圆相交，交集写结论
- 提示词片段：画两个（或三个）相交的圆，各圆内写一侧特征，交集处写共同结论，圆用 1px 细线、不填色
