# isometric-map

3D-style spatial layout showing locations, relationships, or journey through space.

## Structure

- Isometric 3D perspective
- Locations as buildings/landmarks
- Paths connecting locations
- Spatial relationships visible
- Bird's eye view angle

## Best For

- Office/campus layouts
- City/ecosystem maps
- User journey maps
- System architecture
- Process landscapes

## Visual Elements

- Consistent isometric angle (30°)
- 3D buildings or objects
- Pathways and roads
- Labels floating above
- Mini scenes at locations

## Text Placement

- Title at top corner
- Location labels above objects
- Path labels along routes
- Legend for symbols
- Scale indicator if relevant

## Recommended Pairings

- `isometric-3d`: Clean technical maps
- `pixel-art`: Retro game-style maps
- `lego-brick`: Playful location maps

## 3:4 竖版适配（本机）

- 中文名：等距场景
- 适用：空间关系、场景化说明
- 竖版改法：2.5D 等距小场景，细线不填色
- 提示词片段：用 2.5D 等距视角画一个极简小场景（桌面上、房间里），物件用细线、不填色，用 2~3 个短标注指认关系
