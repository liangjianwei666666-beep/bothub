# winding-roadmap

Curved path showing journey with milestones and checkpoints.

## Structure

- S-curve or winding path
- Milestones along the path
- Start and destination points
- Side elements (obstacles, helpers)
- Progress indicators

## Best For

- Project roadmaps
- Career paths
- Customer journeys
- Learning paths
- Strategy timelines

## Visual Elements

- Curving road or river
- Milestone markers/flags
- Scene elements along path
- Vehicle/character on journey
- Destination landmark

## Text Placement

- Title at top
- Milestone labels at each point
- Path section names
- Destination description
- Optional timeline indicators

## Recommended Pairings

- `storybook-watercolor`: Whimsical journeys
- `cartoon-hand-drawn`: Friendly roadmaps
- `isometric-3d`: Technical project paths

## 3:4 竖版适配（本机）

- 中文名：蜿蜒路线
- 适用：旅程、里程碑、阶段
- 竖版改法：一条蜿蜒路径，节点标注
- 提示词片段：画一条蜿蜒向上的路径，路径上 3~5 个节点标阶段名，每个节点一句说明，终点写结果
