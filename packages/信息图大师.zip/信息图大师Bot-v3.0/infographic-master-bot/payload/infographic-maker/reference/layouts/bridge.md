# bridge

Gap-crossing structure connecting problem to solution or current to future state.

## Structure

- Left side: current state/problem
- Right side: desired state/solution
- Bridge element spanning the gap
- Gap representing challenge/obstacle
- Bridge elements as steps/methods

## Best For

- Problem to solution journeys
- Current vs future state
- Gap analysis
- Transformation bridges
- Strategic initiatives

## Visual Elements

- Two distinct platforms/sides
- Visible gap or chasm
- Bridge structure with supports
- Icons representing each side
- Stepping stones or bridge planks

## Text Placement

- Title at top
- Left label (From/Problem/Current)
- Right label (To/Solution/Future)
- Bridge elements labeled
- Gap description below

## Recommended Pairings

- `cartoon-hand-drawn`: Friendly journeys
- `corporate-memphis`: Business transformations
- `isometric-3d`: Technical transitions

## 3:4 竖版适配（本机）

- 中文名：桥梁
- 适用：问题 → 方法 → 结果
- 竖版改法：左岸问题、右岸结果、桥面是方法
- 提示词片段：左边画岸写问题，右边画岸写结果，中间一座简单桥，桥面上写 2~3 步方法
