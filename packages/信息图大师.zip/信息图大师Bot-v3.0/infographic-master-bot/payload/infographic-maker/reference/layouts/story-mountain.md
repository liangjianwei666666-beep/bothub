# story-mountain

Plot structure visualization showing rising action, climax, and resolution.

## Structure

- Mountain/arc shape
- Rising slope (build-up)
- Peak (climax)
- Falling slope (resolution)
- Start and end at base level

## Best For

- Narrative structures
- Project lifecycles
- Tension/release patterns
- Emotional journeys
- Campaign arcs

## Visual Elements

- Mountain or arc curve
- Points along the path
- Climax visually emphasized
- Slope steepness meaningful
- Base camps or milestones

## Text Placement

- Title at top
- Stage labels along path
- Climax prominently labeled
- Brief descriptions at points
- Start/end clearly marked

## Recommended Pairings

- `storybook-watercolor`: Narrative journeys
- `cartoon-hand-drawn`: Educational plot diagrams
- `graphic-novel`: Dramatic story arcs

## 3:4 竖版适配（本机）

- 中文名：故事山
- 适用：情节结构、张力曲线
- 竖版改法：一条上升-峰值-下降曲线，关键点标注
- 提示词片段：画一条从左下上升到峰值再下降的细线曲线，曲线上标 3~5 个关键点（起、升、峰、落、结），每点一句说明
