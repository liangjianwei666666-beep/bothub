# tree-branching

Hierarchical structure branching from root to leaves, showing categories and subcategories.

## Structure

- Root/trunk at top or left
- Branches splitting into sub-branches
- Leaves as terminal nodes
- Clear parent-child relationships
- Balanced or organic branching

## Best For

- Taxonomies and classifications
- Decision trees
- Organizational charts
- File/folder structures
- Family trees

## Visual Elements

- Connecting lines showing relationships
- Nodes at branch points
- Icons or labels at each node
- Color coding by branch
- Visual weight decreasing toward leaves

## Text Placement

- Title at top
- Root concept prominently labeled
- Branch and leaf labels
- Optional descriptions at key nodes
- Legend for categories

## Recommended Pairings

- `cartoon-hand-drawn`: Friendly taxonomies
- `da-vinci-notebook`: Scientific classifications
- `origami`: Geometric tree structures

## 3:4 竖版适配（本机）

- 中文名：分支树
- 适用：分类、归属、层级树
- 竖版改法：根在顶部，向下分叉，分支线 1px
- 提示词片段：根节点在顶部，向下分叉 2~3 层，分支线 1px、不填色，叶子节点用小标签，避免超过 12 个叶子
