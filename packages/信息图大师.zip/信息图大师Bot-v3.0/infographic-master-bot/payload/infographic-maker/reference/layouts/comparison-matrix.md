# comparison-matrix

Grid-based multi-factor comparison across multiple items.

## Structure

- Table/grid layout
- Rows: items being compared
- Columns: comparison criteria
- Cells: scores, checks, or values
- Header row and column clearly marked

## Best For

- Product feature comparisons
- Tool/software evaluations
- Multi-criteria decisions
- Specification sheets
- Rating comparisons

## Visual Elements

- Clear grid lines or cell boundaries
- Checkmarks, X marks, or scores in cells
- Color coding for quick scanning
- Icons for criteria categories
- Highlight for recommended option

## Text Placement

- Title at top
- Item names in first column
- Criteria in header row
- Brief values in cells
- Legend if using symbols

## Recommended Pairings

- `corporate-memphis`: Business tool comparisons
- `ui-wireframe`: Technical feature matrices
- `blueprint`: Specification comparisons

## 3:4 竖版适配（本机）

- 中文名：对比矩阵
- 适用：多因素对比、多个对象的若干维度
- 竖版改法：顶部一行维度、左侧一列对象，细线表格，单元格只放最短词
- 提示词片段：顶部一行写维度，左侧一列写对比对象，中间是细线表格，单元格只放最短的词或对错符号，不要长句
