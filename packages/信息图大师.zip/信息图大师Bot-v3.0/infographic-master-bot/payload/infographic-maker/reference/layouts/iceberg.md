# iceberg

Surface vs hidden depths, visible vs underlying factors.

## Structure

- Waterline dividing visible/hidden
- Tip above water (obvious/surface)
- Larger mass below (hidden/deep)
- Proportional to emphasize hidden depth
- Optional layers within underwater section

## Best For

- Surface vs root causes
- Visible vs invisible work
- Symptoms vs underlying issues
- Public vs private aspects
- Known vs unknown factors

## Visual Elements

- Clear water/surface line
- Above: smaller, brighter
- Below: larger, darker/deeper
- Wave or water texture
- Gradient showing depth

## Text Placement

- Title at top
- Surface items above waterline
- Hidden items below, larger
- Waterline label optional
- Depth indicators for layers

## Recommended Pairings

- `cartoon-hand-drawn`: Friendly metaphor
- `storybook-watercolor`: Artistic depth
- `graphic-novel`: Dramatic revelation

## 3:4 竖版适配（本机）

- 中文名：冰山
- 适用：表面现象 vs 隐藏原因
- 竖版改法：一条水平分水线，线上小、线下大
- 提示词片段：画面中部一条水平细线做水面，线上露出小部分写表面现象，线下大块写隐藏原因/机制，水下部分可用更浅的灰
