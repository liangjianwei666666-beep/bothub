# dashboard

Multi-metric display with charts, numbers, and KPI indicators.

## Structure

- Multiple data widgets
- Charts, graphs, numbers
- Grid or modular layout
- Key metrics prominent
- Status indicators

## Best For

- KPI summaries
- Performance metrics
- Analytics overviews
- Status reports
- Data snapshots

## Visual Elements

- Chart types (bar, line, pie, gauge)
- Big numbers for KPIs
- Trend arrows (up/down)
- Color-coded status (green/red)
- Clean data visualization

## Text Placement

- Title at top
- Widget titles above each section
- Metric labels and values
- Units clearly shown
- Time period indicated

## Recommended Pairings

- `corporate-memphis`: Business dashboards
- `ui-wireframe`: Technical dashboards
- `cyberpunk-neon`: Futuristic displays

## 3:4 竖版适配（本机）

- 中文名：指标看板
- 适用：KPI、数据结论、指标对比
- 竖版改法：顶部关键数字，下面细线图表
- 提示词片段：顶部横排 2~3 个关键数字（大字号 + 小标签），下面用极细的条形/坐标轴或一行对比条说明趋势，图表只用主色和灰阶
