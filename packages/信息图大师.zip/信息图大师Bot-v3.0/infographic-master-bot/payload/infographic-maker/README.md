# infographic-maker

把一个知识点做成一页 **3:4 竖版手绘信息图**（默认 2160×2880，纯白底、L1–L6 分层排版、手绘元素随主题、底部自定义署名）。署名**每次由用户输入**，脚本不设默认值。

选题公式、提示词模板、工作流都在 `SKILL.md`；本文件只讲**怎么装、怎么接自己的生图 API、怎么改品牌**。

---

## 1. 安装

```bash
bash install.sh          # 自动拷到 ~/.agents/skills/infographic-maker
```

装完后在新对话里说「用 infographic-maker 生成一张关于 XX 的信息图」即可被识别。

依赖：`bash` + `curl` + `python3`。核验尺寸优先用 macOS `sips`，否则退回 `python3(+Pillow)` 或 ImageMagick。署名修复仅 macOS 可用（AppKit），其它平台跳过、人工核对即可。

---

## 2. 配置（一个 `.env` 管两件事：接口 + 品牌）

```bash
cp .env.example .env      # 然后编辑
```

### 2.1 生图接口（二选一）

**方式 A：OpenAI 兼容接口**（最常见）
```dotenv
IMG_API_BASE=https://api.your-provider.com/v1
IMG_API_KEY=sk-xxxxxxxx
IMG_MODEL=gpt-image-2
```
走 `POST {base}/images/generations`，兼容返回 `data[0].b64_json` 或 `data[0].url`。

**方式 B：自定义命令**（任意接口 / 本地模型）
```dotenv
IMG_CMD=/usr/local/bin/my-gen
```
会被这样调用，只要把图片写到 `--out` 即可：
```bash
my-gen --prompt "..." --out /path/x.png --size 2160x2880 [--model M] [--quality Q] [--input 参考图]...
```

### 2.2 品牌与画布

```dotenv
BRAND_ACCENT=墨绿 #2F4F45            # 标题与重点句的主色
IMG_DEFAULT_SIZE=2160x2880    # 成品尺寸（务必 3:4）
```

> **署名不再从 `.env` 自动读取。** 每次出图必须在命令行传 `--signature "@用户的账号"`，
> 没传 `make_prompt.sh` / `make.sh` 会直接报错退出。这是为了防止署错名。
> `presets/*.env` 以后只提供配色参考。

也可以用 `presets/` 里的现成配置：

```bash
cp presets/psychology.env .env       # 心理学科普
cp presets/english-grammar.env .env  # 英语语法（帧心英语）
```

> 部分接口不支持 2160×2880，可改成同比例的 `1080x1440` / `1536x2048`，并把 `IMG_DEFAULT_SIZE` 一起改。

---

## 3. 冒烟测试

```bash
S=scripts

bash "$S/make.sh" \
  --signature "@测试账号" \
  --topic "测试：验证链路是否打通" \
  --title "测试标题" \
  --sub "副标题" \
  --lead "一句话机制" \
  --card "细线描一个挥手的小图标|标签一|Hello world.|这是一条说明" \
  --card "细线描一个打勾的便签|标签二|It works.|另一条说明" \
  --card "细线描一块写着 Done 的小黑板|速记|Done.|收尾" \
  --rule "看到 2160x2880 就算通了" \
  --out "/tmp/test.png"
```

看到 `IMAGE_SIZE_OK: 2160x2880` + `IMAGE_RATIO_OK: 3:4` 即成功。

---

## 4. 日常出图（推荐姿势）

```bash
S=~/.agents/skills/infographic-maker/scripts

bash "$S/make.sh" \
  --signature "@在地心理" \
  --topic "聚光灯效应：你以为全场都在看你，其实别人都在忙自己的事" \
  --title "没人那么关注你" \
  --sub "你以为的尴尬，别人转头就忘" \
  --lead "聚光灯效应：高估别人对自己的关注度" \
  --logic "现象 → 真相 → 机制 → 行动" \
  --card "细线描一个小人站在光柱正中|现象|You think everyone is watching.|你以为全场都在看你" \
  --card "细线描一群人低头各忙各的，没人抬头|真相|Nobody noticed.|实验里不到一半的人注意到" \
  --card "手绘光柱从自己头顶移到别人身上|机制|It is your own spotlight.|注意力全在自己身上，看不到别人也在紧张" \
  --card "细线描一个人主动开口问旁边人问题|行动|Shift your focus outward.|注意力从我转到事" \
  --rule "你远没有自己想的那么受关注" \
  --out "generated/聚光灯效应.png"
```

`--card` 四段用 `|` 分隔：**底色+画面元素 | 标签 | 重点句 | 说明**，给 2~5 张（建议 3~4 张，按「现象→真相→机制→行动」递进）。

**署名**：`--signature` 必填，必须先用 `ask_user` 之类的交互问用户这次署什么名，别用旧值。

批量出图就循环调用 `make.sh`（一次一张，服务端不稳时脚本会自动重试）。心理学科普的选题库和 10 个现成配方见 `reference/topic-bank-psychology.md`。

---

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| `IMAGE_CONFIG_MISSING` | 没配 `.env`，或没设 `IMG_API_BASE/IMG_API_KEY` |
| `IMAGE_MODEL` 不支持 | 换成账号里可用的模型名 |
| `-2700 / 502 / 503 / 超时` | 服务端波动，脚本自动重试；仍失败就换模型或降尺寸 |
| 忘了传 `--signature` | 脚本直接报错退出，这就是设计：去问用户，别猜 |
| 署名写错/写漏 | `bash scripts/fix_signature.sh 图.png --text "@用户给的署名" --bg auto --fg auto` |
| 尺寸不对 | 确认生成时**显式传了** `--size 2160x2880`（只写在提示词里不算） |
| macOS 修复后图变成 4320×5760 | `fix_signature.sh` 会自动缩回；手动则 `sips -z 2880 2160 图.png` |

---

## 6. v3：结构库与风格库（2026-11-04）

v3 把「版式」和「画风」从写死变成两套可选项，来源是 [JimLiu/baoyu-skills](https://github.com/JimLiu/baoyu-skills) 的 `baoyu-infographic`（MIT-0 分发），本机已做 3:4 竖版适配。

| 目录 | 内容 |
|---|---|
| `reference/layouts/` | 21 种信息结构 + `catalog.tsv` + `README.md` + 每篇的「3:4 竖版适配」 |
| `reference/styles/` | 22 种风格 + 本机 house style `minimal-editorial` + `catalog.tsv` |
| `reference/layout-adapt-3x4.md` | 横版布局进竖版的通用改法 |
| `reference/content-analysis-framework.md` | 内容类型判定 → 布局推荐 → 复杂度评估 |
| `reference/structured-content.md` | 结构化内容模板（数据原文照抄） |

```bash
S=~/.agents/skills/infographic-maker/scripts
bash "$S/catalog.sh" layouts     # 看 21 种布局
bash "$S/catalog.sh" styles      # 看 23 种风格

# 换结构（默认 linear-progression）
bash "$S/make.sh" --signature "@账号" --layout venn-diagram ... 
# 换风格（默认 minimal-editorial，需用户同意）
bash "$S/make.sh" --signature "@账号" --style chalkboard ...
# 换比例（默认 3:4）
bash "$S/make.sh" --signature "@账号" --aspect 9:16 ...
```

**默认不动**：不传 `--layout`/`--style` 时，出图与 v2 完全一致。

### 发布压图

```bash
bash "$S/compress_image.sh" 成品.png --max-kb 1000 --out X.jpg
bash "$S/compress_image.sh" 成品.png --width 2160 --max-kb 700 --out XHS.jpg
```

实测：5.47MB 的 2880×3840 PNG → 904KB（q88）；2160×2880 → 616KB。保持比例，不裁切。

### 工作台

`/Users/a1-6/Desktop/图片生成/信息图大师工作台-v3.html` —— 单文件、离线可开，选布局/风格/填内容，实时生成可复制的命令。
