#!/usr/bin/env bash
# 安装到 ~/.agents/skills/（或 $AGENTS_SKILLS_DIR）
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_ROOT="${AGENTS_SKILLS_DIR:-$HOME/.agents/skills}"
DEST="$DEST_ROOT/$(basename "$SRC")"

mkdir -p "$DEST_ROOT"
if [ -e "$DEST" ]; then
  echo "目标已存在：$DEST"
  read -r -p "覆盖？[y/N] " ans
  case "$ans" in y|Y) rm -rf "$DEST";; *) echo "已取消"; exit 0;; esac
fi

mkdir -p "$DEST"
for item in SKILL.md README.md .env.example scripts reference presets examples; do
  cp -R "$SRC/$item" "$DEST/" 2>/dev/null || true
done
chmod +x "$DEST"/scripts/*.sh "$DEST"/scripts/*.py 2>/dev/null || true

cat <<EOM
已安装到：$DEST

下一步：
  1) cd "$DEST" && cp .env.example .env    # 填生图接口（署名不在这里配，每次出图问用户）
  2) 读 SKILL.md 了解工作流与选题公式
  3) 心理学选题库：reference/topic-bank-psychology.md
EOM
