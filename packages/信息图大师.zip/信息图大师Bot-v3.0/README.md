# 信息图大师 Bot · 安装包 v3.0

一个可以直接发给「主 Bot」的一键装配包。装完你就有一个能把知识点做成 3:4 竖版信息图的 Bot。

## 三步装好

```bash
unzip 信息图大师Bot-v3.0.zip
bash 信息图大师Bot-v3.0/infographic-master-bot/scripts/install.sh
```

然后在你的主 Bot 里说一句「用 BOT.md 的 instructions 创建一个叫信息图大师的 Bot」。
更完整的话术见 `给主Bot的指令.md`（整段复制给主 Bot 即可）。

## 包里有什么

| 路径 | 说明 |
|---|---|
| `给主Bot的指令.md` | **复制粘贴用**：一段话让主 Bot 全自动装好并建 Bot |
| `安装说明.html` | 人看的安装说明（双击打开，含已验证/未验证清单） |
| `infographic-master-bot/SKILL.md` | 主 Bot 的操作手册（安装 → 建 Bot → 自检 → 交付） |
| `infographic-master-bot/BOT.md` | 新 Bot 的 instructions（v3 全文） |
| `infographic-master-bot/scripts/install.sh` | 一键安装（旧版自动备份） |
| `infographic-master-bot/scripts/selfcheck.sh` | 自检 20 项（缺 Pillow 时 18 项 + 1 条警告，安装照常成功） |
| `infographic-master-bot/payload/infographic-maker/` | 完整 skill v3：21 布局 + 23 风格 + 全部脚本 |
| `infographic-master-bot/payload/信息图大师工作台-v3.html` | 工作台（单文件，12 张样式样张内嵌） |

## 装完会得到什么

- `/…/.agents/skills/infographic-maker` —— skill v3
- `~/Desktop/信息图大师工作台-v3.html` —— 工作台
- 一个叫「信息图大师」的 Bot

## 不需要生图 Key 也能装

不配 Key 时这个 Bot 只能组装提示词，你把提示词拿到任何生图工具出图都行。要它自己出图，再配：

```bash
cd ~/.agents/skills/infographic-maker && cp .env.example .env
# 填 IMG_API_BASE / IMG_API_KEY / IMG_MODEL
```

## 版本

v3.0.0 · 2026-11-04
布局/风格库源自 [JimLiu/baoyu-skills](https://github.com/JimLiu/baoyu-skills) 的 `baoyu-infographic`（MIT-0），已做 3:4 竖版适配。
