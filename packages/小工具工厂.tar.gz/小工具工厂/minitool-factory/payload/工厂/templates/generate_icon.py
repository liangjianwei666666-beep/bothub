#!/usr/bin/env python3
"""__TOOL_NAME__ 图标生成器（占位版，先保证合规出图，再按需精修）

输出: ../__TOOL_SLUG__-icon.png  (512x512, 1:1)
"""
import os
from PIL import Image, ImageDraw, ImageFont

S = 512
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   '__TOOL_SLUG__-icon.png')

# Claude 暖纸设计系统
BG      = (245, 244, 237, 255)   # Parchment
CARD    = (250, 249, 245, 255)
TERRA   = (201, 100, 66, 255)    # Terracotta
INK     = (29, 27, 22, 255)
BD      = (227, 221, 208, 255)

img = Image.new('RGBA', (S, S), BG)
d = ImageDraw.Draw(img)

# 圆角卡片
d.rounded_rectangle((56, 56, S - 56, S - 56), radius=64, fill=CARD, outline=BD, width=6)

# 主图形：一个陶土色圆环 + 中心点（换成工具自己的意象）
cx = cy = S // 2
d.ellipse((cx - 110, cy - 110, cx + 110, cy + 110), outline=TERRA, width=22)
d.ellipse((cx - 34, cy - 34, cx + 34, cy + 34), fill=TERRA)

# 底部标题（中文两字最稳，长了换图形表达）
font = None
for path in ('/System/Library/Fonts/PingFang.ttc',
             '/System/Library/Fonts/STHeiti Medium.ttc'):
    if os.path.exists(path):
        try:
            font = ImageFont.truetype(path, 52)
            break
        except Exception:
            pass
if font:
    label = '__TOOL_NAME__'[:4]
    box = d.textbbox((0, 0), label, font=font)
    d.text(((S - (box[2] - box[0])) / 2 - box[0], S - 150), label, font=font, fill=INK)

img.convert('RGB').save(OUT, 'PNG')
print('Icon saved:', OUT)
