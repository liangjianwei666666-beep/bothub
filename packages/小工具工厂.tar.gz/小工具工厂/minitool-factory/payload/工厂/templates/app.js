'use strict';
/* __TOOL_NAME__ — 逻辑层
 * 硬性规范：
 *   - 经典脚本 IIFE，无 import/export/module，无 top-level await
 *   - 事件一律 addEventListener，容器禁内联 onclick
 *   - 字符串里的中文引号一律用「」，禁止在 JS 字符串里嵌 ASCII 双引号
 *   - 节点一律 createElement + textContent 构建，不拼 HTML 字符串
 *   - 纯本地计算，不联网、不动态执行代码
 * 注意：连注释里都不许出现禁用 API 的字面名字，扫描器会照拦（官方扫描同样笨）
 */
(function () {
  var $ = function (id) { return document.getElementById(id); };

  // ===================== 配置数据 =====================
  var OPTIONS = [
    { key: 'a', name: '选项一', val: 1 },
    { key: 'b', name: '选项二', val: 2 },
    { key: 'c', name: '选项三', val: 3 }
  ];

  var COPY = {
    title: '__TOOL_NAME__',
    tiers: [
      { max: 30, name: '第一档', text: '第一档的解读文案。' },
      { max: 70, name: '第二档', text: '第二档的解读文案。' },
      { max: 999, name: '第三档', text: '第三档的解读文案。' }
    ]
  };

  // ===================== 状态 =====================
  var state = { a: null, pick: null };
  var lastRes = null;

  // ===================== 视图切换 =====================
  function showView(id) {
    var views = document.querySelectorAll('.view');
    for (var i = 0; i < views.length; i++) {
      views[i].classList.remove('active');
    }
    var el = $(id);
    if (el) el.classList.add('active');
    window.scrollTo(0, 0);
  }

  function toast(msg) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'show';
    setTimeout(function () { t.className = ''; }, 1800);
  }

  // ===================== 计算 =====================
  function compute() {
    var a = state.a;
    if (a == null || a <= 0) return null;
    var score = Math.max(0, Math.min(100, Math.round(a * 10)));
    var tier = COPY.tiers[0];
    for (var i = 0; i < COPY.tiers.length; i++) {
      if (score <= COPY.tiers[i].max) { tier = COPY.tiers[i]; break; }
    }
    return { score: score, tier: tier };
  }

  // ===================== 渲染结果 =====================
  function renderResult(res) {
    $('resNum').textContent = String(res.score);
    $('resLabel').textContent = res.tier.name;
    $('resText').textContent = res.tier.text;
    showView('viewResult');
  }

  // ===================== 海报绘制 =====================
  // 铁律：wrapText 返回「下一条起始 y」，调用方不要再加行距
  function wrapText(ctx, text, x, y, maxW, lineH) {
    var chars = String(text).split('');
    var line = '';
    for (var i = 0; i < chars.length; i++) {
      var test = line + chars[i];
      if (ctx.measureText(test).width > maxW && line) {
        ctx.fillText(line, x, y);
        line = chars[i];
        y += lineH;
      } else {
        line = test;
      }
    }
    if (line) { ctx.fillText(line, x, y); y += lineH; }
    return y;
  }

  function drawCard(res) {
    var W = 750, H = 1000;
    var cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    var ctx = cv.getContext('2d');
    if (!ctx) return null;

    // 暖纸渐变底
    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#f8f5ee');
    g.addColorStop(1, '#ece4d4');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // 古铜边框
    ctx.strokeStyle = '#c96442';
    ctx.lineWidth = 6;
    ctx.strokeRect(30, 30, W - 60, H - 60);

    // 标题（衬线）
    ctx.fillStyle = '#141413';
    ctx.font = '600 52px Georgia, "Songti SC", serif';
    ctx.textAlign = 'center';
    ctx.fillText(COPY.title, W / 2, 150);

    // 副标题（mono 小标）
    ctx.fillStyle = '#c96442';
    ctx.font = '22px ui-monospace, Menlo, monospace';
    ctx.fillText('RESULT CARD', W / 2, 196);

    // 分数
    ctx.fillStyle = '#c96442';
    ctx.font = '600 160px Georgia, serif';
    ctx.fillText(String(res.score), W / 2, 400);

    // 档位名（与分数基线间距 >= 行高，避免压字）
    ctx.fillStyle = '#141413';
    ctx.font = '600 44px "PingFang SC", sans-serif';
    ctx.fillText(res.tier.name, W / 2, 500);

    // 解读正文（深字浅底，保证对比度）
    ctx.fillStyle = '#3d3d3a';
    ctx.font = '28px "PingFang SC", sans-serif';
    ctx.textAlign = 'left';
    wrapText(ctx, res.tier.text, 80, 580, W - 160, 46);

    // 底部引导
    ctx.textAlign = 'center';
    ctx.fillStyle = '#87867f';
    ctx.font = '24px "PingFang SC", sans-serif';
    ctx.fillText('长按保存 · 去小红书测测你的', W / 2, H - 80);

    return cv;
  }

  // ===================== 保存到相册（JSBridge 判空 + 兜底） =====================
  function saveCard() {
    if (!lastRes) { toast('先算一下再保存哦'); return; }
    var cv = drawCard(lastRes);
    if (!cv) { toast('生成失败，可截图保存'); return; }

    var dataUrl;
    try {
      dataUrl = cv.toDataURL('image/png');
    } catch (e) {
      toast('生成失败，试试截图吧');
      return;
    }
    var base64 = dataUrl.split(',')[1] || '';

    function fallback() { toast('长按上方结果可截图保存'); }

    try {
      var mt = window.xhs && window.xhs.miniTool;
      if (mt && typeof mt.writeTempFile === 'function') {
        mt.writeTempFile({
          data: base64,
          fileType: 'image',
          success: function (r) {
            var p = r && (r.filePath || r.path || r.tempFilePath);
            if (p && mt.saveImageToPhotosAlbum) {
              mt.saveImageToPhotosAlbum({
                filePath: p,
                success: function () { toast('已保存到相册'); },
                fail: function () { toast('保存失败，可截图保存'); }
              });
            } else {
              toast('已生成，可长按保存');
            }
          },
          fail: fallback
        });
        return;
      }
    } catch (e) {}
    fallback();
  }

  // ===================== 交互绑定 =====================
  function refreshBtn() {
    $('calcBtn').disabled = !(state.a != null && state.a > 0);
  }

  function bindChips(boxId, onPick) {
    var box = $(boxId);
    if (!box) return;
    for (var i = 0; i < OPTIONS.length; i++) {
      (function (opt) {
        var chip = document.createElement('button');
        chip.className = 'chip';
        chip.type = 'button';
        chip.textContent = opt.name;
        chip.addEventListener('click', function () {
          var all = box.querySelectorAll('.chip');
          for (var j = 0; j < all.length; j++) all[j].classList.remove('on');
          chip.classList.add('on');
          onPick(opt);
        });
        box.appendChild(chip);
      })(OPTIONS[i]);
    }
  }

  // ===================== 初始化 =====================
  function init() {
    bindChips('chGroup', function (opt) { state.pick = opt.val; refreshBtn(); });

    var inpA = $('inpA');
    if (inpA) {
      inpA.addEventListener('input', function () {
        var n = parseFloat(inpA.value);
        state.a = isNaN(n) ? null : n;
        refreshBtn();
      });
    }

    $('startBtn').addEventListener('click', function () { showView('viewInput'); });

    $('calcBtn').addEventListener('click', function () {
      var res = compute();
      if (!res) { toast('先把信息填完整'); return; }
      lastRes = res;
      renderResult(res);
    });

    $('saveBtn').addEventListener('click', saveCard);

    $('againBtn').addEventListener('click', function () {
      state = { a: null, pick: null };
      lastRes = null;
      if (inpA) inpA.value = '';
      refreshBtn();
      showView('viewHome');
    });

    // 铁律：首屏必须有 active，这里兜底一次
    if (!document.querySelector('.view.active')) showView('viewHome');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
