# 小红书小工具 · 高效开发发布工作流（SOP）

> 沉淀自 14+ 个已上线工具（五行/MBTI/灵数/塔罗/八维/星座配对/图测 MBTI/2048…）。目标：从想法到可上传 zip，单工具 1-2 小时内交付，零返工。

---

## 〇、总览

```
创意筛选 → 素材准备 → 编码（模板化） → 三查（语法/合规/实测） → 打包 → 发布表单 → 笔记引流
   |           |          |               |              |        |         |
 Fi 闸门    图片/文案   index+js 规范    jscheck+      zip 规范   名称≤14字   生图封面+
 只做该做的  压缩≤2MB  视觉家族风格     grep+浏览器     根目录     权限最小化   文案+评论区
```

---

## 一、创意筛选（5 分钟，防止白做）

- 对照容器能力：✅ 纯前端计算/Canvas 画图/本地数据/随机/包内音频 ❌ 联网/AI 推理/WASM/Worker
- 传播公式：**互动/游戏 → 成绩海报（存相册）→ 晒图引流**——没有"晒点"的工具不值得做
- 先问：用户能"晒什么"？（分数/称号/雷达图/测试结果）
- 命名 ≤14 字、简介一句话、图标 1:1——先想好这三个，决定产品形态

## 二、素材准备

- 图片素材（如图测 MBTI 的 8 张图）：压缩到 **640-720px、质量 70-80**，包内总图 ≤1.5MB（zip 建议 ≤2MB）
- 文案数据（题库/解读/称号）：**字符串内部引用一律用「」中文引号**，禁止在 JS 字符串里嵌 ASCII 双引号（踩坑：语法直接崩）
- 图标：AI 生成 1024² → sips 压到 512²

## 三、编码模板（每工具同构）

目录：`工具名/`（index.html + assets/main.js，脚本**外置**）

**index.html 硬性要求**：
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
```
- 视觉家族风格：浅色高级紫系（`--bg:#f6f4fb` 白卡紫主色）或深色游戏风（2048）；圆角 18、细边框、柔和阴影
- **初始视图必须写 `class="view active"`**（踩坑：漏 JS 初始化导致空白页）

**main.js 硬性要求**：
- 经典脚本 IIFE、无 import/export/module、无 top-level await
- 事件全部 `addEventListener`（容器禁内联 onclick）
- JSBridge 统一模式：`window.xhs?.miniTool` 判空 → 无则 toast「请在小红书 App 内使用此功能」
- 保存海报：`canvas.toDataURL() → writeTempFile（完整 data:uri）→ saveImageToPhotosAlbum`
- localStorage 存最高分/历史（独立隔离合规）

**Canvas 海报排版铁律**（踩坑最多）：
- 文字行距：**wrapText 返回"下一条起始 y"**（= 最后一行基线 + lineH），调用者不要再 + 小间距——1 行条目行距 9px 会叠字
- 标题与内容基线间距 ≥ 行高（22px 字至少 30px 间距）
- 动态预算：先 measureText 计算总行数，超画布自动降字号/截断
- 对比度：浅背景上白字看不清——深底白字或深字浅底
- 验证：**1:1 克隆 canvas（drawImage）再截图**，别直接截 CSS 缩放的 canvas（会压缩失真）

## 四、三查（质检，每步都有命令）

### 1. 语法检查（JavaScriptCore）
```bash
swift jscheck.swift 工具名/assets/main.js   # → "JS OK"
```
jscheck.swift = 用 JSContext 包装执行脚本，捕获 SyntaxError。

### 2. 合规扫描（grep 禁用模式）
```bash
grep -nE "fetch\(|XMLHttpRequest|new WebSocket|eval\(|new Function|WebAssembly|window\.open|window\.prompt|navigator\.geolocation|navigator\.clipboard|onclick=|type=\"module\"|<iframe|<object|https?://" index.html assets/main.js
# 无输出 = 通过
```
- 另查：无内联 `<script>`（只允许 `<script src="./assets/main.js">`）、无行内事件

### 3. 无头浏览器实测（browse）
```bash
browsecli goto http://127.0.0.1:PORT/index.html
browsecli console --errors                 # 必须零报错
browsecli js "..."                          # 驱动交互、断言状态
browsecli screenshot /tmp/x.png             # 截图 OCR 验证视觉
```
- **测试要覆盖**：正常路径 + 边界（满分/零分/非法输入/结束判定）
- 内容型工具：设计"已知答案模式"验证逻辑（如 MBTI 全 A → ESTJ）
- **首屏检查**：`view.active` 必须存在（空白页坑）

## 五、打包（zip 规范）

```bash
cd 工具目录 && zip -r ../xxx小工具.zip . -x '*.DS_Store'
unzip -l ../xxx.zip           # index.html 必须在根目录（顶层直接是文件）
unzip -t ../xxx.zip           # 完整性
diff <(unzip -p ../xxx.zip index.html) index.html   # 与源文件一致
```
- **压缩目录内容而非目录本身**（`cd 目录 && zip -r ../x.zip .`）
- 体积：zip ≤ 10MB（硬限），建议 ≤ 2MB；超了先压图
- 禁止：node_modules/.git/.DS_Store/*.map/构建配置

## 六、发布（创作服务平台表单）

1. **名称**：≤14 字（如"MBTI 简易速测"）
2. **简介**：≤14 字，一句话 = 功能 + 玩法 + 存相册/发笔记
3. **图标**：1:1、png/jpg ≤5M（512² 即可）
4. **封面**：**必填**，JPG/PNG ≤10M，固定 **3:4** 裁切 —— 工具名写进封面时和「名称」一字不差
5. **场景标签**：七选一（生活方式 / 休闲玩法 / 图像创作 / 学习知识 / 实用工具 / 娱乐测试 / 其他）
6. **权限最小化**：只用相册就只勾相册（利于过审）；未用摄像头/麦克风绝不勾
7. 版本号 1.0.0 → 勾《小工具发布安全规范》→ 扫码预览（创服模拟器 / Android / iOS 三端）→ 发布 → 审核（通常几分钟）

> 上传包仅收 **.zip、单文件 ≤10M**；表单第一步是「改写口令」（给 AI 按官方 Skill 改代码格式），第二步才是填表和传包。

## 七、笔记引流（发布包模板）

每个工具配套《xxx-笔记发布包.md》：
- **生图封面 prompt**：3:4 竖版、图文一体视觉笔记（sketchnote）或游戏海报；**文字易乱码 → 生成无字底图 + 后期叠字**
- **笔记文案**：标题 3 选 1 + 正文（玩法引导 + "评论区晒…"）+ 标签
- **配图**：封面（生图）+ 真实成绩海报（工具生成，零乱码）+ 截图
- **评论区钩子**：晒分数/称号/雷达图——发布后 1-2 小时回评互动

## 八、踩坑清单（血的教训，写代码时对照）

| 坑 | 现象 | 防法 |
| --- | --- | --- |
| JS 字符串嵌 ASCII 引号 | 语法错误 | 中文引用一律「」 |
| 16 型 Loop 写成主导+辅助 | 内容错误 | 一三 Loop = 主导+第三，逐型核对 |
| Canvas 行距 9px | 文字叠字/乱码 | wrapText 返回下一条 y，行距=lineH |
| 标题内容基线间距不足 | 标题压内容 | 间距 ≥ 字号行高 |
| 浅底白字 | 看不清/OCR 乱码 | 深底白字或深字浅底 |
| 漏 showView 初始化 | 首次打开空白页 | HTML 预置 active + JS 初始化调用 |
| 测试污染 canvas | 误判渲染问题 | 每次验证前 reload 干净页面 |
| 截 CSS 缩放 canvas | 图片失真/误判 | drawImage 克隆 1:1 再截 |
| 浏览器缓存旧 JS | 修复无效假象 | restart 会话或 cache-bust |
| 直接截图太快（img 异步） | 空白图 | 用 drawImage 同步克隆 |

## 九、复用资产（本工作区）

| 资产 | 用途 |
| --- | --- |
| `/tmp/jscheck.swift` | JS 语法校验（重建即可，内容见工作流） |
| `/tmp/browsecli.sh` | 无头浏览器 CLI（bun 运行 gstack browse） |
| `/tmp/ocr.swift` | 截图 OCR 验证 |
| `上传说明.md` 模板（各工具） | 发布表单 + 校验摘要 + 引流建议 |
| `笔记发布包.md` 模板（各工具） | 生图封面 + 文案 + 配图方案 |
| 视觉规范 | 浅色紫系 / 深色游戏风两套 CSS token |

## 十、一次开发的执行顺序（核对用）

1. [ ] 创意过 Fi 闸门（值得做？能晒什么？）
2. [ ] 建目录，写 index.html（容器规范 + 预置 active + 视觉风格）
3. [ ] 写 main.js（数据用「」引号，事件 addEventListener，JSBridge 判空）
4. [ ] swift jscheck 语法 ✓
5. [ ] grep 合规扫描 ✓
6. [ ] 起 http.server，browse 加载：console 零错 + 首屏 active + 功能路径测试 + 截图 OCR
7. [ ] 海报：1:1 克隆验证排版（行距/间距/对比度）
8. [ ] zip 打包（根目录校验 + 体积）
9. [ ] 生成图标 512² + 上传说明 + 笔记发布包
10. [ ] 出 3:4 封面：`python3 工厂/bin/gen_cover.py <目录> <名字> "卖点" "主体描述"`（生图底图 + 代码叠字 + OCR 复核），**人眼看一遍**
11. [ ] 上传：名称/简介/图标/封面/场景标签/权限最小化 → 三端预览 → 发布 → 评论区引流
