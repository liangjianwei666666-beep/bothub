---
name: minitool-factory
description: 一键装配「小工具工厂 Bot」。当用户说「装一个小工具工厂 Bot」「建一个小工具工厂」「我要做小红书小工具」「打包文/压缩包发你了，装一下」时使用。本技能教主 Bot 如何：① 从压缩包或技能目录装好工厂到本地；② 跑自检确认装好了；③ 用 create_bot 建出「小工具工厂」Bot；④ 告诉用户还差哪把生图 Key。装好后那个 Bot 能把一个想法做成能上传小红书的小工具（zip + 图标 + 封面 + 校验报告）。
---

# minitool-factory · 一键装配「小工具工厂 Bot」

**这个技能是给「主 Bot」看的操作手册。** 用户说一句「装一个小工具工厂 Bot」，你按下面 5 步做完，用户就得到一个能把想法做成小红书小工具的 Bot。

全程不碰用户的账号密码，不代登录任何平台。

---

## 第 0 步：先看技能包在哪

```bash
ls ~/.agents/skills/minitool-factory/   # 技能包已就位？
```

**如果用户是「发了个压缩包给你」**（.tar.gz / .zip），先把它解开再往下走：

```bash
# 用户附件一般落在会话工作目录或 ~/Downloads，先把真实路径找出来
ls -lt ~/Downloads/*.tar.gz ~/Downloads/*.zip 2>/dev/null | head
mkdir -p ~/.agents/skills
tar -xzf <包路径> -C ~/.agents/skills/          # .tar.gz 用这个
# unzip -o <包路径> -d ~/.agents/skills/        # .zip 用这个
ls ~/.agents/skills/minitool-factory/SKILL.md   # 解出来应该是这个
```

解出来的目录名必须是 `minitool-factory`。解完重读一遍本文件，再继续。

---

## 第 1 步：跑装配脚本

```bash
bash ~/.agents/skills/minitool-factory/scripts/install.sh ~/小红书小工具开发
```

工作目录可以换成用户想要的位置；不给就默认 `~/小红书小工具开发`。

脚本会：装工厂（`工厂/bin` 6 个脚本 + 3 个 python）→ 放 SOP 和空总清单 → 检查依赖（python3 / Pillow / node / unzip）。

**依赖缺了必须先补**，缺了就说清楚缺什么、怎么装，别硬往下走：

| 缺件 | 怎么装 |
|---|---|
| Pillow | `python3 -m pip install pillow` |
| node | 装 nvm 或 `brew install node`（三查里的语法检查要用） |

## 第 2 步：跑自检（这一步不许跳）

```bash
python3 ~/.agents/skills/minitool-factory/scripts/selfcheck.py ~/小红书小工具开发
```

它会在临时目录里真建一个工具、跑三查、打包、验 zip 结构、验官方审计脚本、验封面自检，**不碰用户的工作目录**。

- 全过 → 继续
- 有失败项 → 把失败项原文给用户看，修好再往下。**自检没过不说「装好了」**

## 第 3 步：建 Bot

用 `create_bot`，参数照抄：

- **name**: `小工具工厂`
- **role**: `工厂`
- **work_dir**: 第 1 步用的那个工作目录（如 `/Users/<用户名>/小红书小工具开发`）
- **model**: 不填（跟随主 Bot 当前模型）
- **instructions**: 原样拷贝下面那一整段

## 第 4 步：告诉用户还差什么

装配本身不需要任何密钥。**只有出封面**需要一把生图 Key（走 gpt-image-2）：

| 变量 | 用途 | 怎么配 |
|---|---|---|
| `TELANGPUAI_IMAGE_API_KEY` | 出封面（3:4 生图） | 存成 `~/.codex/telangpuai-image-key`，或设成环境变量 |

没有这把 Key 也能用：能建工具、能三查、能打包，**只是出不了封面**（而封面是上传表单必填项）。所以要明确告诉用户这一条，别说成「全都好了」。

配好后验一下：

```bash
python3 ~/小红书小工具开发/工厂/bin/gen_cover.py <随便一个工具目录> 测试 "一句话卖点" "主体描述" --dry-run
```

---

# 建 Bot 时使用的完整 instructions（原样拷贝）

```
你是「小工具工厂」，只做一件事：把用户的一个想法做成能上传小红书的小工具，交付四件套（xxx-tool.zip + xxx-icon.png + xxx-cover.jpg + xxx-validation.md）。

## 开工前必读
- 工厂/README.md —— 操作手册，命令都在里面（含工具数量口径表和改名对照表）
- 小红书小工具/开发发布工作流-SOP.md —— 完整流程和踩坑表
先读这两个文件再动手，里面的规则比你的记忆准。

## 标准流程
1. 先过创意闸门：对照容器能力（只允许纯前端计算 / Canvas / 本地数据 / 包内音频，禁止联网、WASM、Worker、eval）；并回答「用户能晒什么」——没有晒点的工具不做，直接告诉用户别做。
2. 工厂/bin/new.sh <英文目录名> <中文工具名> —— 建脚手架
3. 改 index.html（沿用 Claude 暖纸设计系统）和 app.js（IIFE，事件用 addEventListener，中文引号用「」）
4. python3 <目录>/generate_icon.py —— 出 512×512 图标
5. python3 工厂/bin/gen_cover.py <目录> <工具名> 「一句话卖点」 「主体描述」 —— 出 3:4 封面（生图底图 + 代码叠字）
6. 工厂/bin/check.sh <目录> —— 三查：语法 + 合规 + 元素 id 核对
7. 工厂/bin/build.sh <目录> —— 打包并校验 zip 结构（收尾会清点四件套）
8. 按工厂/templates/ 里的模板写 validation.md、上传说明、笔记发布包

## 硬规矩
- 三查不过不许打包，不许说「做好了」
- 本地校验不等于真机验收。保存到相册、发笔记这两条 JSBridge 只能在容器里实测，必须明说「未实测」，不许含糊成「已完成」
- 命名 ≤14 字，简介 ≤14 字，图标 1:1 512²，封面 3:4
- 每次交付给可验证的交接包：文件绝对路径、体积、三查结果、哪些没验证
- 不改用户已有的小工具，除非用户明确要求；新工具另建目录
- 工具总数和口径一律以 工厂/README.md 为准，别背数字（会变）
- build.sh 按目录名生成 zip 名。对改过名的老工具（对照表见 README）重打包会产出新名字的 zip，必须显式传第二个参数指定输出名，别留下两套包
- 不代用户登录任何平台账号，不碰账号密码
- 封面好不好看只能人眼看：脚本只管合规（比例/体积/空白），出完要请用户看一眼再定

## 说话方式
简短，先说结论。用户是产品负责人，不是程序员，别讲平台术语。
```

---

## 给别人分发时怎么打包

```bash
bash ~/.agents/skills/minitool-factory/scripts/package.sh
```

产出 `~/.agents/skills/minitool-factory.tar.gz`，把这个文件发给对方即可。

对方拿到后：存到本地 → 发给自己的主 Bot → 说「装一个小工具工厂 Bot」。

**技能包里不含任何密钥。** 生图 Key 只在各自本地的 `~/.codex/telangpuai-image-key` 或环境变量里。
