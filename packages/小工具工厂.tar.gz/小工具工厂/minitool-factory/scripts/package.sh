#!/bin/bash
# 重新打包这个技能包（作者用）
# 用法：bash package.sh
# 产出：~/.agents/skills/minitool-factory.tar.gz
#
# 打包前会把最新的工厂同步进 payload，所以先在工厂源码目录改完再跑这个。
set -uo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SKILLS_DIR="$(dirname "$SKILL_DIR")"
NAME="$(basename "$SKILL_DIR")"
SOURCE_FACTORY="${1:-$HOME/Desktop/小红书小工具开发/工厂}"

echo "技能目录：$SKILL_DIR"
echo "工厂源码：$SOURCE_FACTORY"
echo

if [ -d "$SOURCE_FACTORY" ]; then
  rm -rf "$SKILL_DIR/payload/工厂"
  cp -R "$SOURCE_FACTORY" "$SKILL_DIR/payload/工厂"
  echo "✓ 已把最新工厂同步进 payload"
else
  echo "· 没找到工厂源码，用 payload 里现有的（打包历史版本）"
fi

# 随包带一份生图能力，保证对方没装 telangpuai-imagegen 也能出封面
# 必须连 save_image.py 一起带：image_gen.sh 要靠同目录的它把响应落成图片
IMG_DIR="$HOME/.agents/skills/telangpuai-imagegen/scripts"
if [ -f "$IMG_DIR/image_gen.sh" ] && [ -f "$IMG_DIR/save_image.py" ]; then
  mkdir -p "$SKILL_DIR/payload/工厂/bin/imagegen"
  cp "$IMG_DIR/image_gen.sh" "$IMG_DIR/save_image.py" \
     "$SKILL_DIR/payload/工厂/bin/imagegen/"
  chmod 644 "$SKILL_DIR/payload/工厂/bin/imagegen/"*
  # 这份副本里给「变量紧跟中文」的地方补上花括号（行为不变，只是不会被 shell 误读）
  python3 - "$SKILL_DIR/payload/工厂/bin/imagegen/image_gen.sh" <<'PYEOF'
import re, sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
s = re.sub(r'\$([A-Za-z_][A-Za-z0-9_]*)(?=[\u0080-\uffff])', r'${\1}', s)
open(p, 'w', encoding='utf-8').write(s)
PYEOF
  echo "✓ 已带上生图脚本（image_gen.sh + save_image.py，对方本机没装的话用它兜底）"
else
  echo "! 没找到本机的 telangpuai-imagegen，包里不带生图脚本"
  echo "  对方要么自己装这个技能，要么用 TELANGPUAI_IMG_SCRIPT 指到别的生图脚本"
fi

# 每次同步都会带回来一堆权限位，统一一下
chmod +x "$SKILL_DIR/scripts/"*.sh "$SKILL_DIR/scripts/"*.py
chmod +x "$SKILL_DIR/payload/工厂/bin/"*.sh "$SKILL_DIR/payload/工厂/bin/"*.py 2>/dev/null

find "$SKILL_DIR" -name ".DS_Store" -delete
find "$SKILL_DIR" -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null

# 保险：确认包里没有任何密钥文件
if find "$SKILL_DIR" -type f \( -name "*.env" -o -name "*telangpuai-image-key" -o -name "*.pem" \) | grep -q .; then
  echo "✗ 包里发现疑似密钥文件，先清掉再打包："
  find "$SKILL_DIR" -type f \( -name "*.env" -o -name "*telangpuai-image-key" -o -name "*.pem" \)
  exit 1
fi

# 闸门：变量后面紧跟中文，bash 会把中文当成变量名的一部分，set -u 下当场炸。
# 这个坑只在别人机器上才暴露，所以放在打包前拦。
echo
echo "检查 shell 脚本里的「变量紧跟中文」隐患…"
python3 - "$SKILL_DIR" <<'PYEOF' || exit 1
import glob, os, re, sys
root = sys.argv[1]
pat = re.compile(rb'\$[A-Za-z_][A-Za-z0-9_]*[\x80-\xff]')
bad = []
for path in glob.glob(os.path.join(root, '**', '*.sh'), recursive=True):
    data = open(path, 'rb').read()
    for m in pat.finditer(data):
        line = data[:m.start()].count(b'\n') + 1
        bad.append('%s:%d  %s' % (os.path.relpath(path, root), line,
                                  m.group().decode('utf-8', 'replace')))
if bad:
    print('  发现 %d 处，改成 ${VAR} 形式再打包：' % len(bad))
    for b in bad:
        print('    ' + b)
    sys.exit(1)
print('  OK  没有这处隐患')
PYEOF

OUT="$SKILLS_DIR/$NAME.tar.gz"
rm -f "$OUT"
cd "$SKILLS_DIR"
tar --exclude='.DS_Store' -czf "$OUT" "$NAME/"

echo
echo "打包完成：$OUT"
echo "  体积：$(du -h "$OUT" | cut -f1)"
echo "  文件数：$(tar -tzf "$OUT" | grep -vc '/$')"
echo
echo "发给别人，对方存下来发给自己的主 Bot 即可。"
