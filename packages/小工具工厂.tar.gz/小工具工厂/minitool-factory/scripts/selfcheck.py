#!/usr/bin/env python3
"""小工具工厂 · 装配自检

用法：python3 selfcheck.py [工作目录]        （默认 ~/小红书小工具开发）

它会真的建一个工具、跑三查、打包、验 zip 结构、验封面自检，
跑在临时目录里，不碰你自己的工作目录。

退出码 0 = 装好了；1 = 有失败项。
"""
import os
import shutil
import subprocess
import sys
import tempfile

WORK = os.path.abspath(os.path.expanduser(sys.argv[1] if len(sys.argv) > 1 else '~/小红书小工具开发'))
FACTORY = os.path.join(WORK, '工厂')

results = []


def check(name, ok, detail=''):
    results.append((name, ok, detail))
    print('  %s  %-38s %s' % ('OK  ' if ok else 'FAIL', name, detail))
    return ok


def run(cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return r.returncode, (r.stdout or '') + (r.stderr or '')


def main():
    print('小工具工厂 · 装配自检')
    print('工作目录：%s\n' % WORK)

    # ── 1. 文件在不在 ──
    print('【1】文件')
    check('工厂目录', os.path.isdir(FACTORY), FACTORY)
    for f in ['bin/new.sh', 'bin/check.sh', 'bin/build.sh', 'bin/pack.py', 'bin/scan.py',
              'bin/lint_ids.py', 'bin/gen_cover.py', 'bin/check_cover.py',
              'templates/index.html', 'templates/app.js', 'templates/generate_icon.py',
              'README.md']:
        check(os.path.join('工厂', f), os.path.exists(os.path.join(FACTORY, f)))
    check('官方打包规范', os.path.exists(
        os.path.join(FACTORY, '官方规范/minitool-zip-builder-1.8.0/scripts/audit_artifact.mjs')))

    # ── 2. 依赖 ──
    print('\n【2】依赖')
    try:
        import PIL  # noqa
        check('Pillow', True, '版本 %s' % PIL.__version__)
    except ImportError:
        check('Pillow', False, '跑：%s -m pip install pillow' % sys.executable)
    check('node', shutil.which('node') is not None,
          run(['node', '-v'])[1].strip() if shutil.which('node') else '没装 node，语法检查会失败')
    check('unzip', shutil.which('unzip') is not None)
    check('swiftc（封面文字检测，可选）', shutil.which('swiftc') is not None,
          '' if shutil.which('swiftc') else '没有也不影响出封面，只是不查底图里的乱码字')

    # ── 3. 真跑一遍流水线（在临时目录，不碰工作目录）──
    print('\n【3】流水线跑通（临时目录里真建一个工具）')
    tmp = tempfile.mkdtemp(prefix='minitool-selfcheck-')
    try:
        sandbox = os.path.join(tmp, 'sandbox')
        os.makedirs(sandbox)
        shutil.copytree(FACTORY, os.path.join(sandbox, '工厂'))
        for root, _, files in os.walk(os.path.join(sandbox, '工厂', 'bin')):
            for f in files:
                os.chmod(os.path.join(root, f), 0o755)

        code, out = run(['工厂/bin/new.sh', 'demo-tool', '自检演示工具'], cwd=sandbox)
        check('new.sh 建脚手架', code == 0 and os.path.exists(
            os.path.join(sandbox, 'demo-tool/index.html')), out.strip().splitlines()[-1] if out else '')

        code, out = run(['python3', 'demo-tool/generate_icon.py'], cwd=sandbox)
        icon = os.path.join(sandbox, 'demo-tool-icon.png')
        try:
            from PIL import Image
            size = Image.open(icon).size
            ok = code == 0 and size == (512, 512)
            detail = '%dx%d' % size
        except Exception as e:
            ok, detail = False, str(e)
        check('出图标 512×512', ok, detail)

        code, out = run(['工厂/bin/check.sh', 'demo-tool'], cwd=sandbox)
        check('三查（语法+合规+id）', code == 0, out.strip().splitlines()[-1] if out else '')

        code, out = run(['工厂/bin/build.sh', 'demo-tool'], cwd=sandbox)
        z = os.path.join(sandbox, 'demo-tool-tool.zip')
        check('打包', code == 0 and os.path.exists(z), out.strip().splitlines()[-1] if out else '')

        if os.path.exists(z):
            r = subprocess.run(['unzip', '-l', z], capture_output=True, text=True)
            names = [ln.split()[-1] for ln in r.stdout.splitlines()[3:] if ln.split()]
            check('zip 根有 index.html', 'index.html' in names, '、'.join(n for n in names if not n.startswith('---')))
            check('zip 里没有 .py 等垃圾', not any(n.endswith('.py') for n in names))

            audit = os.path.join(sandbox, '工厂/官方规范/minitool-zip-builder-1.8.0/scripts/audit_artifact.mjs')
            if os.path.exists(audit) and shutil.which('node'):
                code, out = run(['node', audit, z], cwd=sandbox)
                check('过官方审计脚本', code == 0, out.strip().splitlines()[-1] if out else '')

        # 封面自检：正例 + 反例
        from PIL import Image, ImageDraw
        good = os.path.join(sandbox, 'good-cover.jpg')
        im = Image.new('RGB', (1080, 1440), (245, 244, 237))
        ImageDraw.Draw(im).rectangle((80, 500, 1000, 1360), fill=(201, 100, 66))
        im.save(good)
        code, out = run(['python3', '工厂/bin/check_cover.py', good], cwd=sandbox)
        check('封面自检认得合规图', code == 0)

        bad = os.path.join(sandbox, 'bad-cover.jpg')
        Image.new('RGB', (1280, 720), (245, 244, 237)).save(bad)
        code, out = run(['python3', '工厂/bin/check_cover.py', bad], cwd=sandbox)
        check('封面自检拦得住不合规图', code != 0, '比例不对就该拦')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # ── 4. 生图能力（只报告，不算失败）──
    print('\n【4】生图能力（出封面才用得到）')
    key = os.environ.get('TELANGPUAI_IMAGE_API_KEY') or os.environ.get('DSH_SECRET_TELANGPUAI_API_KEY')
    if not key:
        kf = os.path.expanduser('~/.codex/telangpuai-image-key')
        if os.path.exists(kf) and os.path.getsize(kf) > 0:
            key = '文件'
    check('生图 Key 已配', bool(key), '' if key else '还没配：封面出不了，其它都能用')
    code, out = run(['python3', os.path.join(FACTORY, 'bin/gen_cover.py'),
                     os.path.join(FACTORY, 'templates'), '自检', '一句话卖点', '测试', '--dry-run'])
    check('gen_cover.py 能构造提示词', code == 0)

    # ── 汇总 ──
    bad = [n for n, ok, _ in results if not ok]
    print('\n' + '=' * 46)
    if bad:
        print('自检未全过：%d 项失败' % len(bad))
        for n in bad:
            print('  - %s' % n)
        return 1
    print('自检全过 ✓ 工厂可以开工了')
    return 0


if __name__ == '__main__':
    sys.exit(main())
