#!/bin/bash
# 小工具工厂 Bot · 一键装配脚本
# 用法：bash install.sh [工作目录]        （默认 ~/小红书小工具开发）
# 作用：把工厂装到本地、建好目录、检查依赖。可重复执行，不覆盖你已有的工具和文档。
set -uo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${1:-$HOME/小红书小工具开发}"
WORK="${WORK%/}"

echo "=========================================="
echo "  小工具工厂 · 环境装配"
echo "=========================================="
echo "  技能目录：$SKILL_DIR"
echo "  工作目录：$WORK"
echo ""

mkdir -p "$WORK"
mkdir -p "$WORK/小红书小工具"

# ---------- 1) 装工厂 ----------
if [ -d "$WORK/工厂" ]; then
  # 只覆盖代码，保留用户自己加过的东西
  cp -R "$SKILL_DIR/payload/工厂/." "$WORK/工厂/"
  echo "[1/4] ✓ 工厂已更新（$WORK/工厂，已有文件按新版本覆盖）"
else
  cp -R "$SKILL_DIR/payload/工厂" "$WORK/工厂"
  echo "[1/4] ✓ 工厂已装入（$WORK/工厂）"
fi
chmod +x "$WORK/工厂/bin/"*.sh "$WORK/工厂/bin/"*.py 2>/dev/null

# ---------- 2) 放流程文档 ----------
if [ ! -f "$WORK/小红书小工具/开发发布工作流-SOP.md" ]; then
  cp "$SKILL_DIR/payload/小红书小工具/开发发布工作流-SOP.md" \
     "$WORK/小红书小工具/开发发布工作流-SOP.md"
  echo "[2/4] ✓ 放入《开发发布工作流-SOP.md》"
else
  echo "[2/4] · SOP 已存在，保留不动"
fi

if [ ! -f "$WORK/小工具总清单.md" ]; then
  cat > "$WORK/小工具总清单.md" <<'EOF'
# 小工具总清单

> 每做一个工具，在这里加一行。口径以 `工厂/README.md` 为准，别背数字，要数就现数。

| 工具名 | 目录 | zip | 图标 | 封面 | 状态 | 使用人数 |
|---|---|---|---|---|---|---|
| （示例）拼豆打字 | `bead-type/` | `bead-type-tool.zip` | ✅ | ✅ | 已发布 | 0 |
EOF
  echo "      ✓ 建了空的总清单（$WORK/小工具总清单.md）"
fi

# 工具目录和交付包同级放在工作目录根下，这是工厂的约定
echo "      约定：一个工具一个目录（英文名），zip/图标/封面/校验报告放工作目录根下"

# ---------- 3) 依赖检查 ----------
echo "[3/4] 检查依赖"
MISSING=""
PY="$(command -v python3 || true)"
if [ -n "$PY" ]; then
  echo "      ✓ python3: $($PY -V 2>&1)"
else
  echo "      ✗ 找不到 python3（需要 3.9+）"; MISSING="python3"
fi

if [ -n "$PY" ]; then
  $PY - <<'PYEOF'
import sys
try:
    from PIL import Image  # noqa
    print("      ✓ Pillow（出图标 / 出封面要用）")
except ImportError:
    print("      ✗ Pillow 未安装")
    print("        装它：%s -m pip install pillow" % sys.executable)
    sys.exit(1)
PYEOF
  [ $? -ne 0 ] && MISSING="${MISSING} pillow"
fi

if command -v node >/dev/null 2>&1; then
  echo "      ✓ node: $(node -v)"
else
  echo "      ✗ 找不到 node（三查里的语法检查要用；装 nvm 或 brew install node）"
  MISSING="${MISSING} node"
fi

command -v unzip >/dev/null 2>&1 && echo "      ✓ unzip" || { echo "      ✗ 找不到 unzip"; MISSING="${MISSING} unzip"; }
if command -v swiftc >/dev/null 2>&1; then
  echo "      · swiftc 在（封面文字检测可用）"
else
  echo "      · 没有 swiftc：封面文字检测会跳过，其它功能不受影响"
fi

# ---------- 4) 生图 Key ----------
echo "[4/4] 检查生图能力（出封面要用）"
KEY_FOUND=""
for f in "$HOME/.codex/telangpuai-image-key"; do
  [ -s "$f" ] && KEY_FOUND="$f"
done
[ -n "${TELANGPUAI_IMAGE_API_KEY:-}" ] && KEY_FOUND="环境变量"
if [ -n "$KEY_FOUND" ]; then
  echo "      ✓ 找到生图 Key（来源：${KEY_FOUND}）"
else
  echo "      · 还没配生图 Key —— 封面出不了，其它都能用"
  echo "        两种配法（挑一个）："
  echo "          a) 把 Key 存成文件：$HOME/.codex/telangpuai-image-key"
  echo "          b) 设环境变量： export TELANGPUAI_IMAGE_API_KEY=你的Key"
fi

echo ""
echo "=========================================="
if [ -n "$MISSING" ]; then
  echo "  装配完成，但有缺件：$MISSING"
else
  echo "  装配完成 ✓"
fi
echo "=========================================="
echo ""
echo "下一步（主 Bot 会接着做）："
echo "  1. 建 Bot（名字「小工具工厂」，工作目录填 ${WORK}）"
echo "  2. 跑自检确认装好了："
echo "       $PY \"$SKILL_DIR/scripts/selfcheck.py\" \"$WORK\""
echo ""
echo "试着做一个工具："
echo "  $WORK/工厂/bin/new.sh demo-tool 演示工具"
echo "  $WORK/工厂/bin/build.sh demo-tool"

[ -z "$MISSING" ] || exit 1
