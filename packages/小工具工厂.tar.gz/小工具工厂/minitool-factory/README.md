# 小工具工厂 Bot · 装配包

把「一个想法 → 一个能上传小红书的小工具」这条流程打包成一个 Bot。

**给谁用**：要做小红书小工具的人，但不想每次重写打包脚本、扫描脚本、校验报告。

## 拿到这个包怎么用

1. 把 `minitool-factory.tar.gz` 发给你的主 Bot，说一句：
   > 给你发了个包，装一个小工具工厂 Bot

2. 主 Bot 会自己解开、装到本地、跑自检、把 Bot 建出来。

**包里不含任何密钥。**

## 装完你会得到什么

一个工作目录（默认 `~/小红书小工具开发`）：

```
小红书小工具开发/
├── 工厂/
│   ├── bin/           new.sh 建脚手架 / check.sh 三查 / build.sh 打包
│   │                  gen_cover.py 生图出封面 / check_cover.py 封面自检
│   │                  pack.py 白名单打包 / scan.py 合规扫描 / lint_ids.py id 核对
│   ├── templates/     Claude 暖纸设计系统的 index.html / app.js / 模板文档
│   ├── 官方规范/       小红书官方打包规范 1.8.0 + 官方审计脚本
│   └── README.md      命令都在这
├── 小红书小工具/开发发布工作流-SOP.md
└── 小工具总清单.md
```

和一条命令：

```bash
工厂/bin/build.sh <工具目录>     # 语法 → 合规 → id 核对 → 打包 → 清点四件套
```

## 一个工具交四件

| 文件 | 说什么 |
|---|---|
| `xxx-tool.zip` | 上传包（zip 根必须含 index.html） |
| `xxx-icon.png` | 512×512 图标，1:1 |
| `xxx-cover.jpg` | 1080×1440 封面，3:4（上传必填，生图出） |
| `xxx-validation.md` | 校验报告 |

## 要什么环境

- macOS
- `python3` + `Pillow`（出图标、出封面）
- `node`（三查里的语法检查）
- 生图 Key **只有出封面才需要**；没有的话其它功能照常，只是封面得自己想办法

## 重新打包（作者用）

```bash
bash ~/.agents/skills/minitool-factory/scripts/package.sh
```

产出 `~/.agents/skills/minitool-factory.tar.gz`。

## 已验证 / 未验证

- ✅ 装配脚本、自检脚本在干净 HOME 里跑过
- ✅ 流水线在 PATH 极干净的环境下跑得通（env.sh 自己找 node）
- ✅ 封面生成真跑过 gpt-image-2，出 3:4、底图无乱码字、文字叠得上去
- ❌ 没在别人的电脑上装过
- ❌ 小工具的「保存到相册 / 发笔记」只能在手机容器里实测，本地验不了
