#!/usr/bin/env bash
# 外教匹配 Bot —— 一键安装
#
# 做什么：
#   把安装包里的匹配器、老师库、照片、工作台，装到这台机器上的一个固定目录，
#   然后把 Bot 指令里的路径替换成真实路径，生成「可直接粘给主 Bot」的创建参数。
#
# 用法（普通用户双击「3-一键安装.sh」也能跑；终端里用 bash 跑）：
#   bash 3-一键安装.sh                    # 装到 ~/Desktop/外教业务/外教匹配
#   bash 3-一键安装.sh --dir ~/外教匹配    # 装到指定目录
#   bash 3-一键安装.sh --force            # 目标目录已存在时，删掉重装
#
# 不联网、不需要 pip 安装任何东西（匹配器只用 Python 3 标准库）。

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG="$HERE"
APP_SRC="$PKG/app"
DEFAULT_DIR="$HOME/Desktop/外教业务/外教匹配"
TARGET=""
FORCE=0

while [ $# -gt 0 ]; do
  case "$1" in
    --dir) TARGET="${2:-}"; shift 2 ;;
    --dir=*) TARGET="${1#--dir=}"; shift ;;
    --force) FORCE=1; shift ;;
    -h|--help)
      sed -n '2,14p' "$0" | sed 's/^# \{0,1\}//'
      exit 0 ;;
    *) echo "不认识的参数：$1"; exit 1 ;;
  esac
done

[ -z "$TARGET" ] && TARGET="$DEFAULT_DIR"
TARGET="${TARGET/#\~/$HOME}"

say(){ printf '%s\n' "$*"; }
die(){ printf '\n[失败] %s\n' "$*" >&2; exit 1; }

say ""
say "外教匹配 Bot · 一键安装"
say "────────────────────────────"
say "安装包：$PKG"
say "装到：  $TARGET"
say ""

[ -d "$APP_SRC" ] || die "安装包不完整：找不到 app/ 目录。请把整个文件夹解压后再运行。"

# ── 1. 运行时检查（只查，不装）────────────────────────────
PY=""
if command -v python3 >/dev/null 2>&1 && python3 -c 'import sys' >/dev/null 2>&1; then
  PY="$(command -v python3)"
else
  for p in /usr/bin/python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
    if [ -x "$p" ] && "$p" -c 'import sys' >/dev/null 2>&1; then PY="$p"; break; fi
  done
fi
[ -n "$PY" ] || die "这台机器上没找到 python3。装一下 Python 3（python.org 下载，一路下一步），再回来运行本脚本。"
say "· Python：$PY"

# ── 2. 目标目录：已存在就不硬盖 ──────────────────────────
if [ -e "$TARGET" ]; then
  if [ "$FORCE" -eq 1 ]; then
    say "· 目标目录已存在 —— 按 --force 覆盖重装"
    rm -rf "$TARGET"
  else
    if [ -d "$TARGET" ] && [ -z "$(ls -A "$TARGET" 2>/dev/null)" ]; then
      :   # 空目录，直接用
    else
      die "目标目录已经有东西了：$TARGET
      · 想覆盖：加 --force
      · 想换个位置：加 --dir \"\$HOME/外教匹配\""
    fi
  fi
fi

mkdir -p "$TARGET"
TARGET="$(cd "$TARGET" && pwd)"   # 归一化，避免路径里带 ../

# ── 3. 拷文件 ───────────────────────────────────────────
say "· 拷贝匹配器与数据（约 20MB，稍等）…"
cp -R "$APP_SRC"/. "$TARGET"/
chmod +x "$TARGET/推荐.sh" 2>/dev/null || true

# 工作台 HTML 也放进同一个目录，方便随时打开
if [ -f "$PKG/工作台/外教匹配Bot-工作台.html" ]; then
  cp "$PKG/工作台/外教匹配Bot-工作台.html" "$TARGET/外教匹配Bot-工作台.html"
fi

# ── 4. 把指令里的路径替换成真实路径 ─────────────────────
INSTR_SRC="$PKG/指令/Bot指令.md"
INSTR_OUT="$TARGET/Bot指令-已安装.md"
PARAMS_OUT="$TARGET/创建参数-粘给主Bot.md"

[ -f "$INSTR_SRC" ] || die "安装包不完整：找不到 指令/Bot指令.md"

APP_DIR_ESC="$TARGET"
APP_DIR_ESC="${APP_DIR_ESC//&/\\&}"

sed "s|{{APP_DIR}}|$APP_DIR_ESC|g" "$INSTR_SRC" > "$INSTR_OUT"

{
  cat <<EOF
请用 create_bot 在本机创建一位新的 Bot。参数如下，原样使用，不要自行改写：

- name: 外教一对一匹配
- role: 外教匹配
- work_dir: $TARGET
- instructions: 读取下面这份文件，把它的**全文**作为 instructions 传进去（不要摘要、不要改写）
  $INSTR_OUT
- brief: 用户要一个「输入需求就自动推荐一位外教」的 Bot：听懂需求 → 跑本机匹配器 → 先发老师照片 → 再给介绍、价格和可约时段。安装包已在 $TARGET 装好，直接可用。

装好后请再做三件事：
1) 用 message_bot 或让用户在这个新 Bot 的对话里发一句：\`8岁孩子想练口语\`，确认它能出图、能报时段。
2) 帮它挂两个例行任务：每周一 08:10 跑 \`bash $TARGET/推荐.sh 刷新 slots\`；每月 1 号 08:20 跑 \`bash $TARGET/推荐.sh 刷新 teachers\`。
3) 如果这台机器上 python3 不在 PATH 里，先确认 \`bash $TARGET/推荐.sh --text "测试" --no-slots --json\` 能跑通，再交付。
EOF
} > "$PARAMS_OUT"

say "· 已生成：$INSTR_OUT"
say "· 已生成：$PARAMS_OUT"
say ""

# ── 5. 自检 ─────────────────────────────────────────────
chmod +x "$PKG/4-自检.sh" 2>/dev/null || true
if [ -f "$PKG/4-自检.sh" ]; then
  bash "$PKG/4-自检.sh" --dir "$TARGET" || die "自检没通过，先别急着创建 Bot。把上面报错内容发给出包人。"
else
  say "（安装包里没有 4-自检.sh，跳过自检）"
fi

say ""
say "────────────────────────────"
say "装好了。三步收尾："
say "  1) 打开 $PARAMS_OUT"
say "  2) 把里面的内容整段发给你的 DS Bot 主 Bot —— 它会创建出「外教一对一匹配」"
say "  3) 在新建的 Bot 对话里发一句「8岁孩子想练口语」，看它有没有先发照片、再报可约时段"
say ""
say "工作台：$TARGET/外教匹配Bot-工作台.html（双击打开）"
say "手动验证：bash $TARGET/推荐.sh --text \"8岁孩子想练口语\" --json"
say ""
