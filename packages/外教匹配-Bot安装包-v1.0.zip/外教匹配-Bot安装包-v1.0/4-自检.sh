#!/usr/bin/env bash
# 外教匹配 Bot —— 自检
#
# 检查这份安装是不是真的能用：数据在不在、照片齐不齐、匹配器跑不跑得出人。
# 全程离线（--no-slots），不连订课系统，所以断网也能自检。
#
# 用法：
#   bash 4-自检.sh                       # 查默认安装位置
#   bash 4-自检.sh --dir ~/外教匹配       # 查指定位置

set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$HERE/app"
TARGET=""
while [ $# -gt 0 ]; do
  case "$1" in
    --dir) TARGET="${2:-}"; shift 2 ;;
    --dir=*) TARGET="${1#--dir=}"; shift ;;
    *) shift ;;
  esac
done
[ -z "$TARGET" ] && TARGET="$HOME/Desktop/外教业务/外教匹配"
TARGET="${TARGET/#\~/$HOME}"
[ -d "$APP" ] || APP="$TARGET"
# 还没安装时（解压后直接自检），目标目录没有匹配器 → 就检查安装包里自带的这份
if [ ! -f "$TARGET/match.py" ] && [ -f "$APP/match.py" ]; then TARGET="$APP"; fi

FAIL=0
ok(){   printf '  \033[32m✓\033[0m %s\n' "$*"; }
bad(){  printf '  \033[31m✗\033[0m %s\n' "$*"; FAIL=1; }
warn(){ printf '  \033[33m!\033[0m %s\n' "$*"; }
head1(){ printf '\n%s\n' "$*"; }

printf '\n外教匹配 Bot · 自检\n'
printf '位置：%s\n' "$TARGET"

head1 "1. 运行时"
PY=""
if command -v python3 >/dev/null 2>&1; then PY="$(command -v python3)"; fi
if [ -z "$PY" ]; then
  for p in /usr/bin/python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
    [ -x "$p" ] && PY="$p" && break
  done
fi
if [ -n "$PY" ]; then ok "python3：$PY"; else bad "没找到 python3（匹配器跑不起来）"; fi

head1 "2. 关键文件"
for f in match.py 推荐.sh refresh.py data/teachers_live.json data/fixed_teachers.json data/photo_index.json data/series.json; do
  [ -f "$TARGET/$f" ] && ok "$f" || bad "缺文件：$f"
done
[ -f "$TARGET/外教匹配Bot-工作台.html" ] && ok "工作台 HTML" || warn "工作台 HTML 不在（不影响匹配）"

head1 "3. 数据体检"
if [ -n "$PY" ] && [ -f "$TARGET/data/teachers_live.json" ]; then
  "$PY" - "$TARGET" <<'PYEOF'
import json, os, sys, glob
root = sys.argv[1]
tl = json.load(open(os.path.join(root, "data/teachers_live.json"), encoding="utf-8"))
print(f"  · 老师库：{tl.get('count')} 位（抓取于 {tl.get('fetched_at')}）")
bt = tl.get("by_type", {})
print("    按师资：" + "、".join(f"{k} {v}" for k, v in bt.items()))
fx = json.load(open(os.path.join(root, "data/fixed_teachers.json"), encoding="utf-8"))
print(f"  · 固定课表：{fx.get('resolved')}/{fx.get('total')} 个席位已对齐")
pi = json.load(open(os.path.join(root, "data/photo_index.json"), encoding="utf-8"))
have = sum(1 for fn in pi.values() if os.path.isfile(os.path.join(root, "照片", fn)))
print(f"  · 照片：索引 {len(pi)} 条，落地 {have} 张（目录内 jpg {len(glob.glob(os.path.join(root,'照片','*.jpg')))} 个）")
miss = [k for k, fn in pi.items() if not os.path.isfile(os.path.join(root, "照片", fn))]
if miss:
    print(f"    ! 有 {len(miss)} 位老师的照片文件缺失，聊天里会走首字母占位兜底")
sj = os.path.join(root, "data/slots.json")
if os.path.isfile(sj):
    sl = json.load(open(sj, encoding="utf-8"))
    print(f"  · 时段快照：{sl.get('fetched_at')}（只到本周；不刷新会变旧，用「刷新 slots」更新）")
PYEOF
  [ $? -eq 0 ] && ok "数据可读" || bad "数据结构读不出来，可能文件损坏"
else
  bad "数据文件缺失，跳过"
fi

head1 "4. 跑一次真匹配（离线，不查时段）"
if [ -n "$PY" ] && [ -f "$TARGET/推荐.sh" ]; then
  OUT_TMP="$TARGET/.selfcheck-out.json"
  ERR_TMP="$TARGET/.selfcheck-err.txt"
  if bash "$TARGET/推荐.sh" --text "8岁孩子想练口语" --no-slots --json > "$OUT_TMP" 2>"$ERR_TMP"; then
    "$PY" - "$OUT_TMP" <<'PYEOF'
import sys, json
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception as e:
    print("  \u2717 输出不是 JSON：", e)
    sys.exit(1)
p = d.get("primary") or {}
name = p.get("name"); typ = p.get("type"); price = p.get("price")
canfix = "是" if p.get("can_fix") else "否"
photo = "有" if p.get("photo_exists") else "无（会走首字母占位）"
print("  · 主推：%s · %s · ¥%s" % (name, typ, price))
print("  · 可固定：%s｜照片：%s" % (canfix, photo))
print("  · 备选：%s 位｜同档：%s 位" % (len(d.get("alternates") or []), (d.get("tie") or {}).get("count", 0)))
for g in (d.get("data_gaps") or []):
    print("  · 数据缺口：" + g)
if not name:
    print("  \u2717 没推出老师")
    sys.exit(1)
PYEOF
    if [ $? -eq 0 ]; then ok "匹配器跑通（离线）"; else bad "匹配器输出异常"; fi
  else
    bad "匹配器报错："
    head -12 "$ERR_TMP" 2>/dev/null | sed 's/^/      /'
  fi
  rm -f "$OUT_TMP" "$ERR_TMP"
else
  bad "跳过一次真匹配（缺 python3 或 推荐.sh）"
fi

head1 "5. 联网能力（实时时段）"
if [ -n "$PY" ]; then
  if "$PY" - <<'PYEOF' 2>/dev/null
import urllib.request, json
req = urllib.request.Request("http://titalk.etutors.cn/api/json.php",
    data=json.dumps({"a_args":{"s_class":"c_teacher","s_method":"f_get_teacher_list",
    "i_teacher_type":"teacher","i_page":1,"i_page_size":1,"i_user_id":0,"s_api_key":"","i_zone_id":501}}).encode(),
    headers={"Content-Type":"application/json","Referer":"http://titalk.etutors.cn/class_booking.php"})
json.loads(urllib.request.urlopen(req, timeout=8).read().decode("utf-8","replace"))
PYEOF
  then ok "能连上订课系统（实时可约时段可用）"
  else warn "现在连不上订课系统 —— 离线也能出结果，但「可约时段」会取不到；换网络再试" ; fi
fi

printf '\n────────────────────────────\n'
if [ "$FAIL" -eq 0 ]; then
  printf '\033[32m自检通过\033[0m：这份安装可以交给 Bot 用了。\n\n'
else
  printf '\033[31m自检未通过\033[0m：上面带 ✗ 的项要先解决。\n\n'
fi
exit "$FAIL"
