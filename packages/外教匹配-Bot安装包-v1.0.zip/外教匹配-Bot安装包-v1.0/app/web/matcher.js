// 匹配逻辑（与 match.py 同一套权重和规则，改一处必须两边同步改）
import { DATA, FIXED_IDS } from './data.js';

const { series: SERIES, teachers: TEACHERS } = DATA;

export const PRICE = { '菲律宾外教': 38, '欧美外教': 128, '中教': null };
export const TYPE_LABEL = { '菲律宾外教': '菲教', '欧美外教': '欧美', '中教': '中教' };
export const TIE_BAND = 6.0;

const W = {
  series_exact: 40,
  goal: 6,
  audience: 12,
  audience_hit: 4,
  experience: 1.2,
  degree: 5,
  type_pref: 15,
  type_penalty: -25,
  adult_kid_only: -30,
  kid_adult_only: -30,
};

export const GOAL_ALIASES = {
  '口语': ['口语', '开口', '说话', '表达', '对话', 'oral', 'speaking', 'conversation'],
  '阅读': ['阅读', 'reading', '分级阅读', '绘本', '读'],
  '启蒙': ['启蒙', '零基础', '入门', 'phonics', '自然拼读', '幼儿'],
  '少儿综合': ['少儿综合', '综合', '系统学', '教材课', '打基础'],
  '应试YLE': ['yle', '剑桥少儿', 'starters', 'movers', 'flyers'],
  '应试KET': ['ket'],
  '应试PET': ['pet'],
  '应试FCE': ['fce'],
  '应试雅思': ['雅思', 'ielts'],
  '应试托福': ['托福', 'toefl'],
  '商务': ['商务', '职场', 'business', '工作', '外贸', '会议', '汇报'],
  '旅行': ['旅行', '旅游', '出国', 'travel', '出境'],
  '写作': ['写作', 'writing'],
  '进阶': ['进阶', '高阶', '拔高', '学术', '国际学校'],
};

export const TYPE_ALIASES = {
  '菲律宾': ['菲教', '菲律宾', '菲', 'philippine', 'filipino'],
  '欧美': ['欧美', '外教', '北美', 'native', 'western'],
  '中教': ['中教', '中国老师', '国内老师', '双语老师'],
};

export const LEVEL_SERIES = {
  Y1: ['oxford_reading_tree', 'oxford_phonics', 'kids_box', 'power_up', 'reading_a_z'],
  Y2: ['reading_a_z', 'oxford_reading_tree', 'lets_go', 'kids_box', 'power_up', 'speaking_time'],
  Y3: ['reading_a_z', 'oxford_reading_tree', 'lets_go', 'kids_box', 'power_up', 'fun_for'],
  Y4: ['reading_a_z', 'oxford_reading_tree', 'kids_box', 'power_up', 'speaking_time', 'ket'],
  Y5: ['reading_a_z', 'power_up', 'speaking_time', 'pet', 'think'],
  Y6: ['reading_a_z', 'power_up', 'think', 'reading_explorer'],
};

const CN_NUM = { '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10 };

export function parseType(raw) {
  if (!raw) return null;
  const r = String(raw).toLowerCase();
  for (const [std, keys] of Object.entries(TYPE_ALIASES)) {
    if (keys.some((k) => r.includes(k))) return std;
  }
  return null;
}

export function parseText(text) {
  const t = String(text || '');
  const out = { goals: [] };
  let m = t.match(/(\d{1,2})\s*岁/);
  if (m) out.age = parseInt(m[1], 10);
  m = t.match(/([一二三四五六七八九十两]|\d{1,2})\s*年级/);
  if (m) {
    const g = /^\d+$/.test(m[1]) ? parseInt(m[1], 10) : CN_NUM[m[1]] || 0;
    out.grade = g;
    if (out.age === undefined && g) out.age = g + 6;
  }
  if (/成人|大人|职场|上班|面试|出国|雅思|托福|自己学|我想学/.test(t)) out.audience = 'adult';
  else if (/孩子|娃|小朋友|儿子|女儿|小孩|学生|小学|初中|幼儿|宝宝/.test(t)) out.audience = 'kid';
  if (out.grade) out.audience = out.grade > 12 ? 'adult' : out.grade >= 7 ? 'teen' : 'kid';

  m = t.match(/[Yy]\s*([1-6])/);
  if (m) out.level = 'Y' + m[1];
  if (!out.level) {
    m = t.match(/(\d{1,2})\s*级/);
    if (m && +m[1] >= 1 && +m[1] <= 10) out.level = m[1];
  }

  for (const [std, keys] of Object.entries(GOAL_ALIASES)) {
    if (keys.some((k) => t.toLowerCase().includes(k))) out.goals.push(std);
  }
  for (const ex of ['KET', 'PET', 'FCE']) {
    if (t.toUpperCase().includes(ex)) out.goals.push('应试' + ex);
  }
  out.goals = [...new Set(out.goals)];
  const tt = parseType(t);
  if (tt) out.type = tt;
  return out;
}

function scoreTeacher(t, ctx) {
  const detail = {};
  const ts = t.series;
  let hits = [];

  if (ctx.targetSeries.size) {
    const matched = ts.filter((s) => ctx.targetSeries.has(s));
    if (matched.length) {
      detail.series_exact = W.series_exact * matched.length;
      hits = matched;
    }
  }
  if (ctx.targetGoals.size) {
    const gHit = ts.filter((s) => SERIES[s] && SERIES[s].goals.some((g) => ctx.targetGoals.has(g))).length;
    if (gHit) detail.goal = Math.min(gHit * W.goal, 18);
  }
  const aud = ctx.audience;
  const same = ts.filter((s) => SERIES[s] && SERIES[s].audience.includes(aud));
  if (same.length) {
    detail.audience = W.audience;
    detail.audience_hit = Math.min(same.length * W.audience_hit, 20);
  }
  if (t.expValue) detail.experience = Math.min(t.expValue * W.experience, 14);
  if (/教育|英语/.test(t.degree || '')) detail.degree = W.degree;

  if (ctx.wantType) {
    detail.type_pref = t.type.includes(ctx.wantType) ? W.type_pref : W.type_penalty;
  }
  if (ts.length) {
    const allKid = ts.every((s) => SERIES[s] && SERIES[s].audience.length === 1 && SERIES[s].audience[0] === 'kid');
    const allAdult = ts.every((s) => SERIES[s] && SERIES[s].audience.every((a) => a === 'adult'));
    if (aud === 'adult' && allKid) detail.adult_kid_only = W.adult_kid_only;
    if (aud === 'kid' && allAdult) detail.kid_adult_only = W.kid_adult_only;
  }

  const score = Object.values(detail).reduce((a, b) => a + b, 0);
  return { score, detail, hits };
}

function buildReason(rec) {
  const why = [];
  const t = rec.teacher;
  if (rec.hits.length) why.push('教材方向正好对口');
  else if (rec.detail.goal) why.push('教材方向对得上');
  if (rec.detail.audience) why.push('带过同类学生');
  if (t.expValue >= 5) why.push(`教龄 ${t.exp.replace(/(\d)\s*年/, '$1 年')}` + (t.expAssumed ? '（估算）' : ''));
  return why.length ? why.join('，') : '综合排序靠前，但没有直接命中项';
}

function buildRisks(rec, ctx) {
  const risks = [];
  const t = rec.teacher;
  if (!rec.hits.length && ctx.targetSeries.size) risks.push('没有目标方向的确切教材标签，属于旁证推荐');
  if (ctx.audience === 'adult' && t.series.length && t.series.every((s) => SERIES[s].audience.length === 1 && SERIES[s].audience[0] === 'kid')) {
    risks.push('教材标签集中在少儿段，成人商务/考试承接力需先核实');
  }
  if (!t.series.length) risks.push('教材标签无法识别');
  return risks;
}

export function match(criteria = {}) {
  const targetGoals = new Set(criteria.goals || []);
  const wantType = criteria.type || null;
  const audience = criteria.audience || 'kid';

  let targetSeries = new Set(criteria.series || []);
  let levelUsed = null;
  if (!targetSeries.size && criteria.level && LEVEL_SERIES[String(criteria.level).toUpperCase()]) {
    levelUsed = String(criteria.level).toUpperCase();
    targetSeries = new Set(LEVEL_SERIES[levelUsed]);
  }
  if (!targetSeries.size && targetGoals.size) {
    for (const [sid, s] of Object.entries(SERIES)) {
      if (s.goals.some((g) => targetGoals.has(g))) targetSeries.add(sid);
    }
    // 人群过滤：给孩子的需求不该推青少年/成人段教材
    const ok = new Set([...targetSeries].filter((sid) => (SERIES[sid].audience || []).includes(audience)));
    if (ok.size) targetSeries = ok;
  }

  const ctx = { audience, targetGoals, targetSeries, wantType };
  // 师资偏好是硬条件：家长说欧美，就不能回菲教
  let pool = wantType ? TEACHERS.filter((t) => t.type.includes(wantType)) : TEACHERS;
  if (!pool.length) pool = TEACHERS;
  if (criteria.fixed) {
    const f = pool.filter((t) => FIXED_IDS.has(t.id));
    if (f.length) pool = f;
  }
  let scored = pool.map((t) => ({ teacher: t, ...scoreTeacher(t, ctx) }));
  scored.sort((a, b) => b.score - a.score || a.teacher.name.localeCompare(b.teacher.name));

  // 同档处理：分差很小就不假装精确，少儿段默认给菲教，同时披露欧美升级项
  let tie = null;
  const band = scored.filter((r) => r.score >= scored[0].score - TIE_BAND);
  if (band.length > 1) {
    tie = { count: band.length, spread: +(scored[0].score - band[band.length - 1].score).toFixed(1) };
    if (!wantType && (audience === 'kid' || audience === 'teen')) {
      const phi = band.filter((r) => r.teacher.type.includes('菲律宾'));
      const eu = band.filter((r) => r.teacher.type.includes('欧美'));
      if (phi.length && eu.length) {
        const pick = phi[0];
        scored = [pick, ...scored.filter((r) => r !== pick)];
        tie.premium = { name: eu[0].teacher.name, price: eu[0].teacher.price, score: +eu[0].score.toFixed(1) };
      }
    }
  }

  for (const rec of scored) {
    rec.reason = buildReason(rec);
    rec.risks = buildRisks(rec, ctx);
  }

  const top = scored[0];
  const alternates = scored.slice(1, 3);
  if (tie && tie.premium && alternates.some((a) => a.teacher.name === tie.premium.name)) tie.premium = null;

  const gaps = [];
  if (audience === 'adult') gaps.push('成人商务/考试向老师库极少（纯成人向仅 2 人），建议人工复核');
  if (levelUsed) gaps.push(`${levelUsed} 已按课程体系自动选教材：${LEVEL_SERIES[levelUsed].slice(0, 4).map((s) => SERIES[s].cn).join('、')}`);

  const orderSeries = (rec) => [...rec.hits, ...rec.teacher.series.filter((s) => !rec.hits.includes(s))];

  return {
    query: { audience, level: criteria.level || null, goals: [...targetGoals], type: TYPE_LABEL[wantType] || '不限' },
    primary: {
      ...top.teacher,
      score: +top.score.toFixed(1),
      reason: top.reason,
      risks: top.risks,
      hits: top.hits,
      canFix: FIXED_IDS.has(top.teacher.id),
      seriesCn: orderSeries(top).map((s) => SERIES[s].cn),
    },
    alternates: alternates.map((a) => ({
      name: a.teacher.name,
      type: a.teacher.type,
      price: a.teacher.price,
      exp: a.teacher.exp,
      photo: a.teacher.photo,
      canFix: FIXED_IDS.has(a.teacher.id),
      score: +a.score.toFixed(1),
      reason: a.reason,
      seriesCn: orderSeries(a).map((s) => SERIES[s].cn).slice(0, 4),
    })),
    tie,
    data_gaps: gaps,
    candidateCount: scored.length,
  };
}

export { SERIES, TEACHERS };
