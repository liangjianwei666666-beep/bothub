#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
外教数据刷新器

老师资料会变（新老师入职、老老师离职、教材更新），抓一次就当成永久数据必然过期。
这个脚本从订课系统实时接口重拉，并且只保存需要的字段。

用法：
    python3 refresh.py all        # 全流程：老师资料 + 照片 + 固定名单对齐 + 时段
    python3 refresh.py teachers   # 只重拉老师资料
    python3 refresh.py photos     # 只补齐缺的照片
    python3 refresh.py fixed      # 只重算固定名单对齐
    python3 refresh.py slots      # 只重拉固定老师的可约时段

数据来源：
    http://titalk.etutors.cn/api/json.php   （订课系统内部接口，无需登录）
    敏感字段（手机号/密码/密钥/邮箱）一律丢弃，不落盘。
"""
import argparse
import datetime
import json
import re
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUSINESS = ROOT.parent
DATA = ROOT / "data"
PHOTO_DIR = ROOT / "照片"
LIB_DIR = BUSINESS / "教培agent" / "08_供给资产_外教老师库" / "外教老师库"

API = "http://titalk.etutors.cn/api/json.php"
REFERER = "http://titalk.etutors.cn/class_booking.php"
SITE = "http://titalk.etutors.cn/"
ZONE = 501

TYPE_MAP = {"teacher": "菲律宾外教", "om-teacher": "欧美外教", "cn-teacher": "中教"}

# 白名单：只保存这些字段。其余（s_phone/s_pass/s_api_key/s_email/s_qq/s_skype/s_ip/classin_*）全部丢弃
KEEP = ("i_id", "s_name", "s_name_en", "s_pic_path", "s_desc", "s_role",
        "s_speed", "s_correction", "s_timezone", "credential_url",
        "recommend_video_url", "d_time")


def api(args, retry=3):
    body = json.dumps({"a_args": args}).encode()
    req = urllib.request.Request(API, data=body, headers={
        "Content-Type": "application/json", "Referer": REFERER,
        "User-Agent": "Mozilla/5.0",
    })
    last = None
    for i in range(retry):
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:          # noqa: BLE001
            last = e
            time.sleep(1 + i * 2)
    raise RuntimeError(f"接口失败: {args.get('s_method')} {last}")


def fetch_type(tkey, date):
    """拉某一类师资的全部老师。"""
    r = api({"s_class": "c_teacher", "s_method": "f_get_teacher_list",
             "d_date": date, "i_page": 1, "i_per_page": 1000,
             "i_teacher_type": tkey, "s_searchword": "", "radioCheck": "",
             "starttime": "", "endtime": "", "i_user_id": 0, "s_api_key": "",
             "i_zone_id": ZONE})
    out = r.get("a_result")
    if not isinstance(out, list):
        raise RuntimeError(f"{tkey} 返回异常: {r}")
    return out


def clean_desc(raw):
    """把 <p><p> 之类的富文本标记换成空行，保留原有分行。"""
    s = str(raw or "")
    s = re.sub(r"(<p>\s*){2,}", "\n\n", s, flags=re.I)
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"</p>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    s = s.replace("&nbsp;", " ").replace("&amp;", "&")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


LABELS = [
    (r"最高学历", "degree"),
    (r"教学经验|教龄|教学年限", "experience"),
    (r"教学特色|教学特点|教学风格", "feature"),
    (r"擅长教材|使用教材|教材", "materials"),
]

GENERIC_LABELS = {
    "最高学历": r"最高学历|学历|毕业院校|教育背景",
    "教学经验": r"教学经验|教龄|教学年限|从业年限",
    "教学特色": r"教学特色|教学特点|教学风格|教学理念|教师特色",
    "擅长教材": r"擅长教材|使用教材|教授教材|教材",
    "擅长课程": r"擅长课程|教授课程|课程方向",
    "口音": r"英语发音|发音方式|口音",
}


def split_labels(intro):
    """把「*最高学历：…\n*教学经验：…」这种段落切成字段。

    按空行切段落，一个段落一个字段；同名字段取第一次出现的。
    不因为遇到不认识的标签就停（口音、证书这些字段经常夹在中间）。
    """
    out = {}
    for block in re.split(r"\n\s*\n", intro):
        block = block.strip()
        if not block:
            continue
        for label, pat in GENERIC_LABELS.items():
            if label in out:
                continue
            m = re.match(r"^\*?\s*(?:" + pat + r")\s*[:：]\s*", block)
            if m:
                out[label] = re.sub(r"\s*\n\s*", " ", block[m.end():]).strip()
                break
    return out


def split_materials(s):
    if not s:
        return []
    # 教材之间用 / 或、或 , 分隔；括号里的说明不要
    parts = re.split(r"\s*/\s*|\s*、\s*|\s*,\s*|\s*，\s*|\s*；\s*|\s*;\s*", s)
    out = []
    for p in parts:
        p = p.strip().strip("。.")
        if p and len(p) < 60 and p not in out:
            out.append(p)
    return out


def initials(name, tid):
    """姓名首字母，照片失效时的替补。"""
    base = re.sub(r"^Teacher\s*", "", str(name)).strip()
    letters = [c for c in re.split(r"[^A-Za-z]+", base) if c]
    if len(letters) >= 2:
        return (letters[0][0] + letters[1][0]).upper()
    if letters:
        return letters[0][:2].upper()
    return "T" + str(tid)[:1]


def to_record(raw, tkey):
    """原始记录 -> 精简记录（白名单字段）。"""
    tid = str(raw["i_id"])
    full = str(raw.get("s_name") or "").strip()
    name = re.sub(r"^Teacher\s*", "", full).strip() or full
    intro = clean_desc(raw.get("s_desc"))
    f = split_labels(intro)
    mats = split_materials(f.get("擅长教材", ""))
    courses = split_materials(f.get("擅长课程", ""))
    feature = f.get("教学特色", "")
    # 中教常把教学方向写在「擅长课程」里，没写教材标签时用课程方向兜底展示
    if not feature and courses:
        feature = " / ".join(courses[:4])

    # 英文自述里挑一句老师自己说的话（去掉问候信噪音）
    quote = ""
    tail = re.split(r"擅长教材[:：].*?\n", intro, maxsplit=1)
    if len(tail) > 1:
        body = tail[1].strip()
        if not re.search(r"Hello Teacher|It is so nice to meet you|Hiiii", body, re.I):
            sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+", body) if len(x.strip()) > 40]
            if sents:
                quote = sents[0]

    pic = str(raw.get("s_pic_path") or "")
    return {
        "id": tid,
        "name": name,
        "fullName": full,
        "nameEn": str(raw.get("s_name_en") or "").strip(),
        "type": TYPE_MAP.get(tkey, tkey),
        "typeKey": tkey,
        "initials": initials(name, tid),
        "experience": f.get("教学经验", ""),
        "degree": f.get("最高学历", ""),
        "feature": feature,
        "materials": mats,
        "courses": courses,
        "accent": re.split(r"\s*\*|\n", f.get("口音", ""))[0].strip(),
        "tags": [x for x in [feature] if x],
        "bio": feature,
        "intro": intro,
        "quote": quote,
        "photoUrl": (SITE + urllib.parse.quote(pic)) if pic else "",
        "photoPath": pic,
        "detailUrl": f"{SITE}teacher.php?i_teacher_id={tid}",
        "videoUrl": str(raw.get("recommend_video_url") or ""),
        "credential": str(raw.get("credential_url") or ""),
        "speed": str(raw.get("s_speed") or ""),
        "correction": str(raw.get("s_correction") or ""),
        "since": str(raw.get("d_time") or ""),
        "speedLevel": str(raw.get("s_level") or ""),
    }


def cmd_teachers(date):
    all_recs = []
    stats = {}
    for tkey, label in TYPE_MAP.items():
        raw = fetch_type(tkey, date)
        recs = [to_record(r, tkey) for r in raw]
        all_recs.extend(recs)
        stats[label] = len(recs)
        print(f"  {label}: {len(recs)}")
        time.sleep(0.5)

    # 去重：同一个 id 出现两次时以菲律宾优先（历史数据里 3 位老师跨类）
    seen = {}
    for r in all_recs:
        seen.setdefault(r["id"], r)
    recs = list(seen.values())
    recs.sort(key=lambda x: int(x["id"]) if str(x["id"]).isdigit() else 0)

    payload = {
        "source": API,
        "fetched_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "date_param": date,
        "count": len(recs),
        "by_type": stats,
        "note": "只保存老师介绍/照片/教材等展示字段，电话密码密钥等敏感字段已丢弃",
        "teachers": recs,
    }
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / "teachers_live.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"已写入 data/teachers_live.json：{len(recs)} 位")

    # 同步一份到业务资产目录，日期命名，不覆盖历史
    if LIB_DIR.is_dir():
        out = LIB_DIR / f"teachers_{date}.json"
        out.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"已同步业务资产：{out}")
    return recs


def cmd_photos():
    """补齐没有本地照片的老师。已存在的跳过，不重复下载。"""
    src = DATA / "teachers_live.json"
    if not src.exists():
        raise SystemExit("先跑 python3 refresh.py teachers")
    recs = json.loads(src.read_text(encoding="utf-8"))["teachers"]
    idx_path = DATA / "photo_index.json"
    idx = json.loads(idx_path.read_text(encoding="utf-8")) if idx_path.exists() else {}
    PHOTO_DIR.mkdir(exist_ok=True)

    got = skipped = failed = 0
    for r in recs:
        tid = r["id"]
        if idx.get(tid) and (PHOTO_DIR / idx[tid]).is_file():
            skipped += 1
            continue
        if not r.get("photoUrl"):
            failed += 1
            print(f"  ✗ {tid} {r['name']} 无照片地址")
            continue
        fn = f"{tid}_{re.sub(r'[^A-Za-z0-9]+','',r['name']) or 'T'}.jpg"
        try:
            req = urllib.request.Request(r["photoUrl"], headers={"User-Agent": "Mozilla/5.0",
                                                                 "Referer": REFERER})
            with urllib.request.urlopen(req, timeout=30) as resp:
                blob = resp.read()
            if not blob or len(blob) < 500:
                raise ValueError("空图片")
            # 源站有的图是 png/webp，统一转成真 JPEG，聊天里才不会因为后缀不对不显示
            (PHOTO_DIR / fn).write_bytes(blob)
            try:
                from PIL import Image
                im = Image.open(PHOTO_DIR / fn)
                if im.format != "JPEG":
                    im.convert("RGB").save(PHOTO_DIR / fn, "JPEG", quality=88)
            except Exception:
                pass
            idx[tid] = fn
            got += 1
            print(f"  ✓ {tid} {r['name']} -> {fn} ({len(blob)//1024}KB)")
        except Exception as e:            # noqa: BLE001
            failed += 1
            print(f"  ✗ {tid} {r['name']}: {e}")
        time.sleep(0.2)

    idx_path.write_text(json.dumps(dict(sorted(idx.items())), ensure_ascii=False, indent=1),
                        encoding="utf-8")
    print(f"新下载 {got} 张，已有 {skipped} 张，失败 {failed} 张")


def norm(s):
    return re.sub(r"[^a-z0-9]+", "", str(s).lower())


def cmd_fixed():
    """重算固定名单：标签页名字 -> 老师库 id。"""
    fx = DATA / "fixed_teachers.json"
    if not fx.exists():
        raise SystemExit("缺 data/fixed_teachers.json")
    doc = json.loads(fx.read_text(encoding="utf-8"))
    recs = json.loads((DATA / "teachers_live.json").read_text(encoding="utf-8"))["teachers"]

    by_norm = {}
    for r in recs:
        by_norm.setdefault(norm(r["name"]), r)
        by_norm.setdefault(norm(r["fullName"]), r)

    # 课表上的名字与库里的写法常有出入，这几个是人工核对过的
    ALIAS = {
        "richciemae": "richiemae",         # 课表写 Richcie Mae，库里是 Richie Mae
        "中教nichole": None,
        "ggrezel": "grezel",
        "wyand": "wynand",
    }

    filled = 0
    for group, rows in doc.get("groups", {}).items():
        for row in rows:
            sn = row["sheet_name"].strip()
            key = norm(sn)
            hit = by_norm.get(key)
            if hit is None:
                alt = ALIAS.get(key)
                if alt:
                    hit = by_norm.get(alt)
            if hit is None:
                # 中教标签带「中教」前缀，去掉再试
                stripped = norm(re.sub(r"^中教", "", sn))
                hit = by_norm.get(stripped)
                if hit and hit["type"] != "中教":
                    hit = None
            if hit:
                row.update({"library_id": hit["id"], "library_name": hit["name"],
                            "library_type": hit["type"], "in_library": True,
                            "photoUrl": hit.get("photoUrl", "")})
                filled += 1
            else:
                row.update({"library_id": None, "library_name": None,
                            "library_type": None, "in_library": False})
    doc["fetched"] = datetime.date.today().isoformat()
    doc["resolved"] = filled
    doc["total"] = sum(len(v) for v in doc.get("groups", {}).values())
    doc["missing"] = doc["total"] - filled
    fx.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"固定名单 {doc['total']} 位，已在库 {filled} 位，缺 {doc['missing']} 位")
    for group, rows in doc.get("groups", {}).items():
        miss = [r["sheet_name"] for r in rows if not r.get("in_library")]
        if miss:
            print(f"  仍缺（{group}）: {', '.join(miss)}")


def cmd_slots(days=14):
    """拉固定老师的可约时段（订课系统实时数据）。"""
    fx = json.loads((DATA / "fixed_teachers.json").read_text(encoding="utf-8"))
    ids = [r["library_id"] for g in fx.get("groups", {}).values()
           for r in g if r.get("in_library")]
    ids = sorted({i for i in ids if i})
    today = datetime.date.today()
    out = {"fetched_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
           "note": "订课系统实时可约时段；status 1=可约，0/9=关闭，2/3=已排",
           "days": {}, "teachers": {}}

    print(f"共 {len(ids)} 位固定老师 × {days} 天")
    for off in range(days):
        d = (today + datetime.timedelta(days=off)).isoformat()
        row = {}
        for n, tid in enumerate(ids, 1):
            try:
                r = api({"s_class": "c_teacher", "s_method": "f_get_teacher_class",
                         "d_date": d, "i_teacher_id": tid, "i_user_id": 0,
                         "s_api_key": "", "i_zone_id": ZONE})
                slots = r.get("a_result") if isinstance(r.get("a_result"), list) else []
                open_ = [x["s_start"] for x in slots if x.get("i_status") == 1]
                row[tid] = open_
            except Exception as e:        # noqa: BLE001
                row[tid] = None
                print(f"    ! {d} {tid}: {e}")
            time.sleep(0.15)
            if n % 20 == 0:
                print(f"  {d} {n}/{len(ids)}")
        out["days"][d] = row

    # 汇总成「每位老师最近的可约日期 + 时段」
    for tid in ids:
        spots = {d: v for d, v in ((d, out["days"][d].get(tid)) for d in out["days"]) if v}
        out["teachers"][tid] = {"by_date": spots}

    (DATA / "slots.json").write_text(json.dumps(out, ensure_ascii=False, indent=1),
                                     encoding="utf-8")
    n_open = sum(1 for t in out["teachers"].values() if t["by_date"])
    print(f"已写入 data/slots.json：{n_open}/{len(ids)} 位有可约时段")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["all", "teachers", "photos", "fixed", "slots"])
    ap.add_argument("--days", type=int, default=14)
    ap.add_argument("--date", default=datetime.date.today().isoformat())
    a = ap.parse_args()

    if a.cmd in ("all", "teachers"):
        cmd_teachers(a.date)
    if a.cmd in ("all", "photos"):
        cmd_photos()
    if a.cmd in ("all", "fixed"):
        cmd_fixed()
    if a.cmd in ("all", "slots"):
        cmd_slots(a.days)


if __name__ == "__main__":
    main()
