#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把老师数据 + 教材系列导出成网页可用的 data.js。

导出的是「已经算好系列归属」的干净数据，网页端只做打分，不再重复解析教材名，
这样 Python 端和网页端不会各算一套、算出不同结果。

数据源优先用 refresh.py 拉的实时数据（data/teachers_live.json），没有再退回旧快照。
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUSINESS = ROOT.parent
LIVE = ROOT / "data" / "teachers_live.json"
LEGACY = BUSINESS / "教育应用" / "约课系统" / "public" / "teachers.json"
SERIES_JSON = ROOT / "data" / "series.json"
FIXED_JSON = ROOT / "data" / "fixed_teachers.json"
PHOTO_INDEX = ROOT / "data" / "photo_index.json"
OUT = ROOT / "web" / "data.js"

PRICE = {"菲律宾外教": 38, "欧美外教": 128, "中教": None}


def norm(s: str) -> str:
    s = str(s).replace("’", "'").replace("‘", "'").replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", s).strip().lower()


def parse_exp(raw: str):
    s = str(raw)
    m = re.search(r"(\d+)", s)
    if m:
        return float(m.group(1)), False
    if "丰富" in s:
        return 8.0, True
    return 0.0, True


def load():
    if LIVE.exists():
        doc = json.loads(LIVE.read_text(encoding="utf-8"))
        return doc["teachers"], doc.get("fetched_at", "")
    return json.loads(LEGACY.read_text(encoding="utf-8")), "2026-07-04（旧快照）"


def main():
    teachers, fetched = load()
    cfg = json.loads(SERIES_JSON.read_text(encoding="utf-8"))["series"]

    tag2sid = {}
    for sid, s in cfg.items():
        for t in s["teacher_tags"]:
            tag2sid[norm(t)] = sid

    pidx = json.loads(PHOTO_INDEX.read_text(encoding="utf-8")) if PHOTO_INDEX.exists() else {}

    series_out = {sid: {"name": s.get("short") or s["name"], "cn": s["cn"],
                        "audience": s["audience"], "goals": s["goals"]}
                  for sid, s in cfg.items()}

    out = []
    for t in teachers:
        sids = []
        for m in t.get("materials", []):
            sid = tag2sid.get(norm(m))
            if sid and sid not in sids:
                sids.append(sid)

        exp_value, exp_assumed = parse_exp(t.get("experience", ""))
        out.append({
            "id": t["id"],
            "name": t["name"],
            "type": t["type"],
            "price": PRICE.get(t["type"]),
            "exp": t.get("experience", ""),
            "expValue": exp_value,
            "expAssumed": exp_assumed,
            "degree": t.get("degree", ""),
            "feature": t.get("feature", ""),
            "accent": t.get("accent", ""),
            "quote": t.get("quote", ""),
            "series": sids,
            "photo": f"../照片/{pidx[t['id']]}" if pidx.get(t["id"]) else t.get("photoUrl", ""),
        })

    out.sort(key=lambda x: int(x["id"]) if str(x["id"]).isdigit() else 0)

    fixed_ids = []
    fixed_total = 0
    if FIXED_JSON.exists():
        fj = json.loads(FIXED_JSON.read_text(encoding="utf-8"))
        fixed_ids = sorted({r["library_id"] for g in fj.get("groups", {}).values()
                            for r in g if r.get("in_library") and r.get("library_id")})
        fixed_total = sum(len(g) for g in fj.get("groups", {}).values())

    payload = {
        "series": series_out,
        "fixedIds": fixed_ids,
        "fixedTotal": fixed_total,
        "teachers": out,
        "meta": {
            "count": len(out),
            "fetchedAt": fetched,
            "byType": {k: sum(1 for t in out if t["type"] == k) for k in PRICE},
        },
    }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(
        "// 自动生成，勿手改。源：data/teachers_live.json\n"
        "export const DATA = " + json.dumps(payload, ensure_ascii=False, indent=1) + ";\n"
        "export const FIXED_IDS = DATA.fixedIds;\n",
        encoding="utf-8",
    )
    print(f"已导出 {len(out)} 位老师 -> {OUT}")
    print("类型分布:", payload["meta"]["byType"])
    print("固定名单:", fixed_total, "个席位 /", len(fixed_ids), "位老师")
    print("无教材系列的老师:", sum(1 for t in out if not t["series"]))


if __name__ == "__main__":
    main()
