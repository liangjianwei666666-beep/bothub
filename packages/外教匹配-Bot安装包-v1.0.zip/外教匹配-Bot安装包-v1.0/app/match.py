#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
外教匹配器 V1
输入：学生需求（人群/水平/目标/教材/师资偏好）
输出：最合适的 1 位主推外教 + 2 位备选，含中文介绍、照片、匹配理由和风险提示

用法：
    python3 match.py --audience kid --level Y3 --goal 口语 --type 菲律宾
    python3 match.py --audience kid --goal 阅读 --series reading_a_z --json
    python3 match.py --audience adult --goal 商务

设计原则：
1. 先归一化再匹配。老师库教材标签有 88 种写法、实际 72 种，教材目录用中文名，不做桥接必然错配。
2. 匹配必须可解释。每一分都要能说出「为什么」，不能只给一个名字。
3. 数据缺口要暴露，不要装作匹配上了。时间、性别这类库里没有的字段，直接标「库中无数据」。
"""
import argparse
import datetime
import json
import re
import shutil
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUSINESS = ROOT.parent
TEACHERS_LIVE = ROOT / "data" / "teachers_live.json"        # refresh.py 从订课系统实时拉的
TEACHERS_LEGACY = BUSINESS / "教育应用" / "约课系统" / "public" / "teachers.json"
PHOTO_DIR = ROOT / "照片"          # 预算转好的 jpg，聊天里直接引用
FIXED_JSON = ROOT / "data" / "fixed_teachers.json"
FIXED = json.loads(FIXED_JSON.read_text(encoding="utf-8")) if FIXED_JSON.exists() else {"groups": {}}
SLOTS_JSON = ROOT / "data" / "slots.json"
SLOTS_CACHE = ROOT / "data" / "slots_cache.json"
SLOT_API = "http://titalk.etutors.cn/api/json.php"
# 老师库里的 id -> 是否在固定课表名单
FIXED_IDS = {r["library_id"] for g in FIXED.get("groups", {}).values() for r in g if r.get("in_library")}
FIXED_MISSING = [r["sheet_name"] for g in FIXED.get("groups", {}).values() for r in g if not r.get("in_library")]
FIXED_TOTAL = sum(len(g) for g in FIXED.get("groups", {}).values())

PHOTO_INDEX = json.loads((ROOT / "data" / "photo_index.json").read_text(encoding="utf-8")) if (ROOT / "data" / "photo_index.json").exists() else {}
SERIES_JSON = ROOT / "data" / "series.json"
OUT_DIR = ROOT / "out"


def load_teachers():
    """读老师库。优先用 refresh.py 拉的实时数据，没有再退回旧快照。"""
    if TEACHERS_LIVE.exists():
        doc = json.loads(TEACHERS_LIVE.read_text(encoding="utf-8"))
        recs = doc["teachers"] if isinstance(doc, dict) else doc
        meta = {"source": doc.get("source", "") if isinstance(doc, dict) else "",
                "fetched_at": doc.get("fetched_at", "") if isinstance(doc, dict) else ""}
    else:
        recs = json.loads(TEACHERS_LEGACY.read_text(encoding="utf-8"))
        meta = {"source": "旧快照", "fetched_at": "2026-07-04"}
    out = []
    for t in recs:
        r = dict(t)
        r.setdefault("courses", [])
        r.setdefault("accent", "")
        r.setdefault("quote", "")
        r.setdefault("initials", "")
        if not r.get("initials"):
            base = re.sub(r"^Teacher\s*", "", r.get("name", ""))
            parts = [x for x in re.split(r"[^A-Za-z]+", base) if x]
            r["initials"] = (parts[0][0] + parts[1][0]).upper() if len(parts) > 1 else (parts[0][:2].upper() if parts else "T")
        out.append(r)
    return out, meta


def load_slots():
    if not SLOTS_JSON.exists():
        return None
    try:
        return json.loads(SLOTS_JSON.read_text(encoding="utf-8"))
    except Exception:
        return None


def _api(args, retry=2):
    """订课系统的内部接口，不需要登录。"""
    body = json.dumps({"a_args": args}).encode()
    req = urllib.request.Request(SLOT_API, data=body, headers={
        "Content-Type": "application/json",
        "Referer": "http://titalk.etutors.cn/class_booking.php",
        "User-Agent": "Mozilla/5.0"})
    last = None
    for i in range(retry):
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:            # noqa: BLE001
            last = e
            time.sleep(0.8)
    raise RuntimeError(str(last))


def _read_cache():
    if not SLOTS_CACHE.exists():
        return {"by_teacher": {}}
    try:
        return json.loads(SLOTS_CACHE.read_text(encoding="utf-8"))
    except Exception:
        return {"by_teacher": {}}


def fetch_slots(tid, days=8, want=3):
    """去订课系统问这位老师接下来几天哪个时段可约。

    攒够 want 个有空的天就停，不把整周都问一遍（一次请求约 0.2 秒，问满 8 天没必要）。
    """
    today = datetime.date.today()
    by_date = {}
    for off in range(days):
        d = (today + datetime.timedelta(days=off)).isoformat()
        try:
            r = _api({"s_class": "c_teacher", "s_method": "f_get_teacher_class",
                      "d_date": d, "i_teacher_id": tid, "i_user_id": 0,
                      "s_api_key": "", "i_zone_id": 501})
            rows = r.get("a_result") if isinstance(r.get("a_result"), list) else []
            opens = [x["s_start"] for x in rows if x.get("i_status") == 1]
            if opens:
                by_date[d] = opens
                if len(by_date) >= want:
                    break
        except Exception:
            pass
        time.sleep(0.12)
    return {"fetched_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "by_date": by_date}


WD_CN_LIST = "一二三四五六日"


def first_open(tid, offline=False):
    """这位老师最近哪个时段能约。查到就停，不把整周都问一遍。"""
    hit = slot_view(tid, offline=offline, days=1, per_day=1, want=1)
    return hit[0] if hit else None


def slot_view(tid, offline=False, days=3, per_day=3, want=None):
    """某位老师最近能约的时段。默认会现查订课系统，查不到再吃缓存。

    返回 [{date, weekday, times, label}]，只保留整点/半点里最早的那几个。
    """
    cache = _read_cache()
    rec = cache["by_teacher"].get(str(tid))
    today = datetime.date.today().isoformat()
    fresh = rec and str(rec.get("fetched_at", ""))[:10] == today
    if not fresh and not offline:
        try:
            rec = fetch_slots(tid, want=want or days)
            cache["by_teacher"][str(tid)] = rec
            cache["fetched_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            SLOTS_CACHE.parent.mkdir(parents=True, exist_ok=True)
            SLOTS_CACHE.write_text(json.dumps(cache, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            rec = rec or None
    if not rec:
        return []
    now_hm = datetime.datetime.now().strftime("%H:%M")
    out = []
    for d in sorted(rec.get("by_date", {})):
        if d < today:
            continue
        times = rec["by_date"][d]
        if d == today:
            times = [t for t in times if t > now_hm]
        if not times:
            continue
        wd = WD_CN_LIST[datetime.date.fromisoformat(d).isoweekday() - 1]
        out.append({"date": d, "weekday": wd, "times": times[:per_day],
                    "label": f"周{wd} {times[0]}"})
        if len(out) >= days:
            break
    return out

# 零售参考价（元/25分钟/节），来自《自媒体双号总案》与《一对一外教商务合作核心价》
PRICE = {"菲律宾外教": 38, "欧美外教": 128, "中教": None}
TYPE_LABEL = {"菲律宾外教": "菲教", "欧美外教": "欧美", "中教": "中教"}
TIE_BAND = 6.0  # 分差在这个区间内视为同一档，靠价格和政策决定，不假装精确
# 少儿段没指定师资时，按业务主线推菲教；菲教比欧美低这么多分以内仍算同一档
LOCAL_BAND = 15.0

# ---------- 归一化 ----------
def norm(s: str) -> str:
    """老师教材标签归一化：撇号/破折号统一、空格合一、小写。"""
    s = str(s)
    s = s.replace("’", "'").replace("‘", "'").replace("–", "-").replace("—", "-")
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s

# ---------- 目标归一化（自然语言 -> 标准目标）----------
GOAL_ALIASES = {
    "口语": ["口语", "开口", "说话", "表达", "对话", "oral", "speaking", "conversation"],
    "阅读": ["阅读", "reading", "分级阅读", "绘本", "读"],
    "启蒙": ["启蒙", "零基础", "入门", "phonics", "自然拼读", "幼儿"],
    "少儿综合": ["少儿综合", "综合", "系统学", "教材课", "打基础"],
    "应试YLE": ["yle", "剑桥少儿", "starters", "movers", "flyers"],
    "应试KET": ["ket"],
    "应试PET": ["pet"],
    "应试FCE": ["fce"],
    "应试雅思": ["雅思", "ielts"],
    "应试托福": ["托福", "toefl"],
    "商务": ["商务", "职场", "business", "工作", "外贸", "会议", "汇报"],
    "旅行": ["旅行", "旅游", "出国", "travel", "出境"],
    "写作": ["写作", "作文", "writing"],
    "进阶": ["进阶", "高阶", "拔高", "学术", "国际学校"],
}

def parse_goals(raw_goals):
    """把用户写的目标转成标准目标集合。认不出就返回空并提示。"""
    out = set()
    unknown = []
    for g in raw_goals:
        gl = str(g).lower().strip()
        hit = False
        for std, keys in GOAL_ALIASES.items():
            if any(k in gl for k in keys):
                out.add(std)
                hit = True
        if not hit:
            unknown.append(g)
    return out, unknown

TYPE_ALIASES = {
    "菲律宾": ["菲教", "菲律宾", "菲籍", "philippine", "filipino"],
    # 「外教」是通称，不能当成「欧美」。只说「外教」= 不限。
    "欧美": ["欧美", "北美", "美籍", "英籍", "native speaker", "western"],
    "中教": ["中教", "中国老师", "国内老师", "双语老师"],
}

def parse_type(raw):
    """师资偏好归一化。"""
    if not raw:
        return None
    r = str(raw).lower()
    for std, keys in TYPE_ALIASES.items():
        if any(k in r for k in keys):
            return std
    return None

WD_CN = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "日": 7, "天": 7}
WD_EN = {"mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6, "sun": 7}


def parse_time_spec(s):
    """把「周三晚上7点」这类时间说法解开。返回 (weekday|None, "HH:MM"|None, 原文)。"""
    if not s:
        return None, None, ""
    raw = str(s)
    t = raw.replace("：", ":").strip()
    wd = None
    m = re.search(r"(?:周|星期|礼拜)\s*([一二三四五六日天1-7])", t)
    if m:
        g = m.group(1)
        wd = int(g) if g.isdigit() else WD_CN.get(g)
    if wd is None:
        m = re.search(r"(mon|tue|wed|thu|fri|sat|sun)d?a?y?", t, re.I)
        if m:
            wd = WD_EN.get(m.group(1)[:3].lower())

    hhmm = None
    m = re.search(r"(\d{1,2}):(\d{2})", t)
    if m:
        hhmm = f"{int(m.group(1)):02d}:{m.group(2)}"
    else:
        m = re.search(r"(\d{1,2})\s*[点時时](\d{1,2})?", t)
        if m:
            h = int(m.group(1))
            mi = int(m.group(2) or 0)
            if re.search(r"下午|晚上|傍晚|夜", t) and h < 12:
                h += 12
            if re.search(r"上午|早上|早晨", t) and h == 12:
                h = 0
            hhmm = f"{h:02d}:{mi:02d}"
    return wd, hhmm, raw


def free_at(slots, wd, hhmm, tol=0):
    """谁在这个时间有空。返回 {老师id: [(日期, 时段)]}。用的是订课系统的实时可约时段。

    tol=0 只认整点对上（家长说 7 点就是要 7 点那节）；
    实在没人有空，才由调用方放宽到邻近时段。
    """
    if not slots or not slots.get("days"):
        return {}
    out = {}
    for date, row in sorted(slots["days"].items()):
        if wd:
            try:
                import datetime as _dt
                if _dt.date.fromisoformat(date).isoweekday() != wd:
                    continue
            except Exception:
                continue
        for tid, opens in row.items():
            if not opens:
                continue
            if hhmm:
                cand = [x for x in opens if abs(_minute(x) - _minute(hhmm)) <= tol]
            else:
                cand = list(opens)
            if cand:
                out.setdefault(tid, []).append((date, cand))
    return out


def _minute(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def best_alt_time(teachers, ctx, cur_hits, fel_only=False, prefer_wd=None):
    """当前时段没有合适的老师时，找最近一个「有空 + 教材对口」的时段。

    用来回答家长真正关心的那句：那我换个时间行不行。
    先看同一个星期几（家长说的周三就是周三），没有再看别的天。
    """
    import datetime as _dt
    slots = load_slots()
    if not slots:
        return None
    target = ctx["target_series"]
    today = _dt.date.today().isoformat()
    passes = [[prefer_wd], [1, 2, 3, 4, 5, 6, 7]] if prefer_wd else [[1, 2, 3, 4, 5, 6, 7]]
    for allowed in passes:
        for date in sorted(slots["days"]):
            isowd = _dt.date.fromisoformat(date).isoweekday()
            if isowd not in allowed or date <= today:
                continue
            for tid, opens in sorted(slots["days"][date].items()):
                if tid in cur_hits or not opens:
                    continue
                t = next((x for x in teachers if x["id"] == tid), None)
                if not t:
                    continue
                if fel_only and "菲律宾" not in t["type"]:
                    continue
                if target and not (set(ctx["teacher_series"][tid]) & target):
                    continue
                wd = "一二三四五六日"[isowd - 1]
                return {"name": t["name"], "type": t["type"],
                        "price": PRICE.get(t["type"]),
                        "date": date, "weekday": wd, "slots": opens[:3]}
    return None


# 阅读诊断 Y 级 -> 该级别主推教材系列（来自《英跃外教小班课课程体系设计方案 V1》）
LEVEL_SERIES = {
    "Y1": ["oxford_reading_tree", "oxford_phonics", "kids_box", "power_up", "reading_a_z"],
    "Y2": ["reading_a_z", "oxford_reading_tree", "lets_go", "kids_box", "power_up", "speaking_time"],
    "Y3": ["reading_a_z", "oxford_reading_tree", "lets_go", "kids_box", "power_up", "fun_for"],
    "Y4": ["reading_a_z", "oxford_reading_tree", "kids_box", "power_up", "speaking_time", "ket"],
    "Y5": ["reading_a_z", "power_up", "speaking_time", "pet", "think"],
    "Y6": ["reading_a_z", "power_up", "think", "reading_explorer"],
}

CN_NUM = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
          "初": 7, "高": 10}

def parse_text(text):
    """把一句人话解析成需求。返回 dict，只填能确定识别出的字段。"""
    t = str(text)
    out = {"goals": [], "unknown_notes": []}

    # 年龄
    m = re.search(r"(\d{1,2})\s*岁", t)
    if m:
        out["age"] = int(m.group(1))
    # 年级
    grade = 0
    m = re.search(r"([一二三四五六七八九十两]|\d{1,2})\s*年级", t)
    if m:
        g = m.group(1)
        grade = int(g) if g.isdigit() else CN_NUM.get(g, 0)
    else:
        # 初一/高二/小四 这种写法
        m = re.search(r"小\s*([一二三四五六])", t)
        if m:
            grade = CN_NUM.get(m.group(1), 0)
        m = re.search(r"(初|高)\s*([一二三])", t)
        if m:
            grade = (7 if m.group(1) == "初" else 10) + CN_NUM.get(m.group(2), 1) - 1
    if grade:
        out["grade"] = grade
        if "age" not in out:
            out["age"] = grade + 6

    # 人群
    if re.search(r"成年人|成人|大人|职场人|职场|上班族|上班|面试|出国|雅思|托福|自己学|我想学|"
                 r"外贸|业务员|白领|老板|家长自己|我自己|公司|同事|客户|工作|商务|"
                 r"\d{2}\s*岁.*(?:想学|要学|练)", t):
        out["audience"] = "adult"
    elif re.search(r"孩子|娃|小朋友|儿子|女儿|小孩|学生|小学|初中|幼儿|宝宝", t):
        out["audience"] = "kid"
    if "grade" in out and out["grade"]:
        out["audience"] = "adult" if out["grade"] > 12 else ("teen" if out["grade"] >= 7 else "kid")

    # Y 级
    m = re.search(r"[Yy]\s*([1-6])", t)
    if m:
        out["level"] = "Y" + m.group(1)
    # 1-10 级
    m = re.search(r"(\d{1,2})\s*级", t)
    if m and "level" not in out:
        n = int(m.group(1))
        if 1 <= n <= 10:
            out["level"] = str(n)

    # 目标
    for std, keys in GOAL_ALIASES.items():
        if any(k in t.lower() for k in keys):
            out["goals"].append(std)
    # KET/PET 单独抓，避免被通用词吃掉
    for exam in ["KET", "PET", "FCE"]:
        if exam.lower() in t.lower() or exam in t:
            out["goals"].append("应试" + exam)

    # 师资
    tt = parse_type(t)
    if tt:
        out["type"] = tt

    # 时间：「周三晚上7点」「每周三 19:00」「周六上午」
    mt = re.search(r"(?:每周|每)?(?:(?:周|星期|礼拜)\s*[一二三四五六日天1-7])\s*(?:上午|下午|晚上|早上|傍晚|夜)?\s*(\d{1,2}\s*(?::\s*\d{2}|[点時时]\s*\d{0,2})?)", t)
    if mt:
        out["time"] = mt.group(0).strip()
    else:
        mt = re.search(r"(\d{1,2}\s*[:：]\s*\d{2})", t)
        if mt:
            out["time"] = mt.group(0).strip()

    # 去重保序
    seen = set()
    out["goals"] = [g for g in out["goals"] if not (g in seen or seen.add(g))]
    return out

# ---------- 教材系列 ----------
def load_series():
    cfg = json.loads(SERIES_JSON.read_text(encoding="utf-8"))["series"]
    tag2sid = {}
    for sid, s in cfg.items():
        for t in s["teacher_tags"]:
            tag2sid[norm(t)] = sid
    return cfg, tag2sid

def teacher_series(teacher, tag2sid):
    """一位老师能教哪些教材系列（去重、保持稳定顺序）。"""
    out = []
    for m in teacher.get("materials", []):
        sid = tag2sid.get(norm(m))
        if sid and sid not in out:
            out.append(sid)
    return out

def parse_exp(raw: str) -> float:
    """教龄解析。返回 (年数, 是否推测)。"""
    s = str(raw)
    m = re.search(r"(\d+)", s)
    if m:
        return float(m.group(1)), False
    if "丰富" in s:
        return 8.0, True
    return 0.0, True

# ---------- 评分 ----------
W = {
    "series_exact": 40,    # 直接命中目标教材系列
    "goal": 6,             # 每个命中目标（上限 18）
    "audience": 12,        # 人群对得上
    "audience_hit": 4,     # 每本同人群教材（上限 20）
    "experience": 1.2,     # 每年教龄（上限 14）
    "degree": 5,           # 教育/英语专业学历
    "type_pref": 15,       # 师资类型符合偏好
    "type_penalty": -25,   # 师资类型不符
    "adult_kid_only": -30, # 成人需求但老师只有少儿教材
    "kid_adult_only": -30, # 少儿需求但老师只有成人教材
}

def score_teacher(t, ctx):
    """返回 (分数, 得分明细 dict, 命中的 series 列表)。每一分都要能解释。"""
    cfg = ctx["cfg"]
    ts = ctx["teacher_series"][t["id"]]
    detail = {}
    hits = []

    # 1) 教材系列
    if ctx["target_series"]:
        matched = [s for s in ts if s in ctx["target_series"]]
        if matched:
            detail["series_exact"] = W["series_exact"] * len(matched)
            hits = matched
    # 2) 目标
    if ctx["target_goals"]:
        g_hit = sum(1 for s in ts if set(cfg[s]["goals"]) & ctx["target_goals"])
        if g_hit:
            detail["goal"] = min(g_hit * W["goal"], 18)
    # 3) 人群
    aud = ctx["audience"]
    same = [s for s in ts if aud in cfg[s]["audience"]]
    if same:
        detail["audience"] = W["audience"]
        # 成人向教材本来就少，覆盖广度是主要区分度，别被 20 分的上限抹平
        cap = 32 if aud == "adult" else 20
        detail["audience_hit"] = min(len(same) * W["audience_hit"], cap)
    # 4) 教龄
    exp, _ = parse_exp(t.get("experience", ""))
    if exp:
        detail["experience"] = min(exp * W["experience"], 14)
    # 5) 学历
    deg = t.get("degree", "")
    if "教育" in deg or "英语" in deg:
        detail["degree"] = W["degree"]
    # 6) 师资偏好
    want = ctx["want_type"]
    if want:
        detail["type_pref"] = W["type_pref"] if want in t["type"] else W["type_penalty"]
    # 7) 人群错配惩罚
    if ts:
        all_kid = all(cfg[s]["audience"] == ["kid"] for s in ts)
        all_adult = all(set(cfg[s]["audience"]) <= {"adult"} for s in ts)
        if aud == "adult" and all_kid:
            detail["adult_kid_only"] = W["adult_kid_only"]
        if aud == "kid" and all_adult:
            detail["kid_adult_only"] = W["kid_adult_only"]

    return sum(detail.values()), detail, hits

# ---------- 介绍生成 ----------
def clean_intro(t):
    """抽结构化字段。实时数据里这些已经解析好了，旧快照才需要现解析。"""
    struct = {}
    for key, label in [("degree", "degree"), ("experience", "exp"),
                       ("feature", "feature"), ("materials", "materials")]:
        if t.get(key):
            struct[label] = t[key]
    quote = t.get("quote", "")
    if struct and quote:
        return struct, quote

    intro = t.get("intro", "")
    for key, label in [("最高学历", "degree"), ("教学经验", "exp"), ("教学特色", "feature"), ("擅长教材", "materials")]:
        m = re.search(r"\*?" + key + r"[:：]\s*(.+?)(?:\n|$)", intro)
        if m and label not in struct:
            struct[label] = m.group(1).strip()
    if not quote:
        tail = re.split(r"擅长教材[:：].*?\n", intro, maxsplit=1)
        if len(tail) > 1:
            body = tail[1].strip()
            if not re.search(r"Hello Teacher|It is so nice to meet you|Hiiii", body, re.I):
                sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", body) if len(s.strip()) > 40]
                if sents:
                    quote = sents[0]
    return struct, quote

def series_cn(sid, cfg):
    return cfg[sid]["cn"] if sid in cfg else sid

def series_short(sid, cfg):
    """聊天里用短名，家长看得懂也不占地方。"""
    if sid not in cfg:
        return sid
    return cfg[sid].get("short") or cfg[sid]["name"]

def render_card(rec, ctx, rank=1):
    t = rec["teacher"]
    cfg = ctx["cfg"]
    L = []
    tag = "【主推】" if rank == 1 else f"【备选 {rank-1}】"
    L.append(f"{tag} Teacher {t['name']}（{t['type']}）")
    L.append("")
    L.append(f"- 教龄：{t.get('experience','未知')}　学历：{t.get('degree','未知')}")
    mats = [series_cn(s, cfg) for s in ctx["teacher_series"][t["id"]]]
    L.append(f"- 擅长教材：{'、'.join(mats[:6]) if mats else '无明确标签'}")
    struct, quote = rec["intro"]
    if struct.get("feature"):
        L.append(f"- 教学特色：{struct['feature']}")
    if quote:
        L.append(f"- 老师原话：{quote}")
    L.append("")
    L.append(f"为什么是他：{rec['reason']}")
    if rec["risks"]:
        L.append(f"需要注意：{'；'.join(rec['risks'])}")
    L.append(f"匹配分：{rec['score']:.0f}")
    return "\n".join(L)

def _ordered_series(rec, ctx):
    """命中的教材排最前，其次是人群对口的，其余按原顺序。"""
    cfg = ctx["cfg"]
    ts = ctx["teacher_series"][rec["teacher"]["id"]]
    aud = ctx["audience"]
    hits = [s for s in ts if s in rec["hits"]]
    fit = [s for s in ts if s not in hits and aud in cfg[s]["audience"]]
    return hits + fit + [s for s in ts if s not in hits and s not in fit]

# ---------- 主流程 ----------
def match(args):
    teachers, tmeta = load_teachers()
    cfg, tag2sid = load_series()

    # 先解析自由文本（如果有），命令行参数优先覆盖
    parsed = parse_text(args.text) if getattr(args, "text", None) else {}
    notes = list(parsed.get("unknown_notes", []))
    parsed_time = parsed.get("time")
    # 家长在 --text 里写「要固定」「长期」「每周三」，跟加 --fixed 是一回事
    want_fixed = bool(getattr(args, "fixed", False)) or bool(
        re.search(r"固定|长期|包月|每周", str(getattr(args, "text", "") or "")))

    audience = args.audience or parsed.get("audience")
    if not audience:
        age = args.age or parsed.get("age")
        audience = "adult" if (age and age >= 18) else "kid"

    goal_list = args.goal if args.goal else parsed.get("goals", [])
    target_goals, unknown_goals = parse_goals(goal_list) if goal_list else (set(), [])

    want_type = parse_type(args.type) if args.type else parsed.get("type")

    # 目标教材：显式 series > Y级推断 > 目标反推
    target_series = set()
    if args.series:
        for s in args.series:
            if s in cfg:
                target_series.add(s)
            else:
                for sid, v in cfg.items():
                    if s.lower() in norm(v["name"]) or s in v["cn"]:
                        target_series.add(sid)
    level = args.level or parsed.get("level")
    level_series = []
    if not target_series and level:
        key = str(level).upper()
        if key in LEVEL_SERIES:
            target_series = set(LEVEL_SERIES[key])
            level_series = LEVEL_SERIES[key]
    if not target_series and target_goals:
        for sid, v in cfg.items():
            if set(v["goals"]) & target_goals:
                target_series.add(sid)
        # 人群过滤：给孩子的需求，不该推青少年/成人段教材
        ok = {sid for sid in target_series if cfg[sid]["audience"] and audience in cfg[sid]["audience"]}
        if ok:
            target_series = ok

    ctx = {
        "cfg": cfg,
        "audience": audience,
        "target_goals": target_goals,
        "target_series": target_series,
        "want_type": want_type,
        "teacher_series": {t["id"]: teacher_series(t, tag2sid) for t in teachers},
    }

    # 师资偏好是硬条件，不是加减分：家长说欧美，就不能回菲教
    pool = [t for t in teachers if want_type in t["type"]] if want_type else teachers
    if not pool:
        pool = teachers
    # 需要固定上课时，只在固定课表名单里挑
    if want_fixed:
        fpool = [t for t in pool if t["id"] in FIXED_IDS]
        if fpool:
            pool = fpool

    # ---- 时间 ----
    # 时段来自订课系统的实时可约数据（data/slots.json）。没有这份数据就不能装作能按时间排。
    time_raw = getattr(args, "time", None) or parsed_time
    wd = hhmm = None
    slot_hits = {}
    slots = load_slots()
    time_exact = None
    if time_raw:
        wd, hhmm, _ = parse_time_spec(time_raw)
        if slots:
            slot_hits = free_at(slots, wd, hhmm, 0)
            time_exact = bool(slot_hits)
            if not slot_hits and hhmm:
                # 整点对不上，退一步给前后 25 分钟内的
                slot_hits = free_at(slots, wd, hhmm, 25)
            tpool = [t for t in pool if t["id"] in slot_hits]
            if tpool:
                pool = tpool

    scored = []
    for t in pool:
        s, detail, hits = score_teacher(t, ctx)
        scored.append({"teacher": t, "score": s, "detail": detail, "hits": hits})
    scored.sort(key=lambda x: (-x["score"], x["teacher"]["name"]))

    # ---- 同档处理 ----
    # 分数挤在一起时（教材覆盖相同、只是教龄零头之差），不要假装精确排序。
    # 少儿段没指定师资时，按业务主线（菲教主推）优先给菲教，同时把欧美升级项说清楚。
    kid_auto = want_type is None and audience in ("kid", "teen")
    band_w = LOCAL_BAND if kid_auto else TIE_BAND
    band = [r for r in scored if r["score"] >= scored[0]["score"] - band_w]
    tie_info = None
    if len(band) > 1:
        if kid_auto:
            phi = [r for r in band if "菲律宾" in r["teacher"]["type"]]
            if phi:
                pick = phi[0]
                rest = [r for r in scored if r is not pick]
                scored = [pick] + rest
                tie_info = {"main_line": "菲律宾"}
        # 「实力相当」只算分差 6 分以内的，宽档只用来选主推，不能拿来吓唬家长
        tight = [r for r in scored if r["score"] >= scored[0]["score"] - TIE_BAND]
        tie_info = tie_info or {}
        tie_info.update({"count": len(tight),
                         "spread": round(scored[0]["score"] - tight[-1]["score"], 1),
                         "types": sorted({r["teacher"]["type"] for r in tight})})
        eu = [r for r in tight
              if "欧美" in r["teacher"]["type"] and r is not scored[0]]
        if kid_auto and eu:
            tie_info["premium"] = {
                "name": eu[0]["teacher"]["name"],
                "type": eu[0]["teacher"]["type"],
                "score": round(eu[0]["score"], 1),
                "price": PRICE.get(eu[0]["teacher"]["type"]),
            }

    # 生成理由
    for rec in scored:
        t = rec["teacher"]
        why = []
        if rec["hits"]:
            why.append("教材方向正好对口")
        elif rec["detail"].get("goal"):
            why.append("教材方向对得上")
        if rec["detail"].get("audience"):
            why.append("带过同类学生")
        exp, assumed = parse_exp(t.get("experience", ""))
        if exp >= 5:
            exp_txt = re.sub(r"(\d)\s*年", r"\1 年", t.get("experience", ""))
            why.append(f"教龄 {exp_txt}" + ("（估算）" if assumed else ""))
        rec["reason"] = "，".join(why) if why else "综合排序靠前，但没有直接命中项"

        risks = []
        ts = ctx["teacher_series"][t["id"]]
        if not rec["hits"] and target_series:
            risks.append("没有目标方向的确切教材标签，属于旁证推荐")
        if audience == "adult" and ts and all(cfg[s]["audience"] == ["kid"] for s in ts):
            risks.append("教材标签集中在少儿段，成人商务/考试承接力需先核实")
        if not ts:
            risks.append("教材标签无法识别")
        rec["risks"] = risks

    # ---- 有空的先上 ----
    # 主推的老师这一周一个空位都没有，等于约不上。往后找一位能约的，别让家长自己发现。
    offline = bool(getattr(args, "no_slots", False))
    picked_note = None
    if not offline and not time_raw:
        window = scored[:8]
        head_type = scored[0]["teacher"]["type"]
        # 先找同师资类型的（菲教换欧美价差 3 倍，不能悄悄换）
        order = ([r for r in window if r["teacher"]["type"] == head_type]
                 + [r for r in window if r["teacher"]["type"] != head_type])
        for r in order:
            if first_open(r["teacher"]["id"], offline=offline):
                if r is not scored[0]:
                    skipped = scored[0]
                    scored.remove(r)
                    scored.insert(0, r)
                    changed = r["teacher"]["type"] != skipped["teacher"]["type"]
                    picked_note = (f"{skipped['teacher']['name']} 本周在订课系统里没有空位，"
                                   f"换成了同样对口、能约上的 {r['teacher']['name']}")
                    if changed:
                        picked_note += (f"；注意师资类型也变了（{TYPE_LABEL.get(skipped['teacher']['type'], skipped['teacher']['type'])}"
                                        f" → {TYPE_LABEL.get(r['teacher']['type'], r['teacher']['type'])}）")
                break

    top = scored[0]
    intro = clean_intro(top["teacher"])
    # 老师自述里的年限经常没更新（说 2 年、档案写 6 年）。对不上就不引用，宁可不说。
    exp_v, _ = parse_exp(top["teacher"].get("experience", ""))
    if intro[1] and exp_v:
        m = re.search(r"(\d{1,2})\s*(?:\+|多)?\s*(?:years?|年)", intro[1], re.I)
        if m and abs(float(m.group(1)) - exp_v) > 1.5:
            intro = (intro[0], "")
    top["intro"] = intro

    # 备选：两位同一类型时，换一位分差在档内的、另一类型的，家长想比价才有得比
    alts = scored[1:3]
    if len(alts) == 2 and alts[0]["teacher"]["type"] == alts[1]["teacher"]["type"]:
        other = next((r for r in scored[3:]
                      if r["teacher"]["type"] != alts[0]["teacher"]["type"]
                      and r["score"] >= scored[0]["score"] - band_w), None)
        if other:
            alts[1] = other

    # 主推不能固定，就给一个能固定的兜底，别让家长问完才发现走不通
    fix_hint = None
    if not want_fixed and top["teacher"]["id"] not in FIXED_IDS:
        fix_pool = [r for r in scored if r["teacher"]["id"] in FIXED_IDS and r is not top]
        if fix_pool and kid_auto:
            same = [r for r in fix_pool if r["teacher"]["type"] == top["teacher"]["type"]]
            fix_pool = same or fix_pool
        if fix_pool:
            cand = fix_pool[0]
            fix_hint = {"name": cand["teacher"]["name"],
                        "type": cand["teacher"]["type"],
                        "price": PRICE.get(cand["teacher"]["type"]),
                        "experience": cand["teacher"].get("experience"),
                        "score": round(cand["score"], 1)}

    # ---- 可约时段：默认就查，不用家长问 ----
    # 「这位老师什么时候有空」是推荐的一部分，不是附加题。
    top_slots = slot_view(top["teacher"]["id"], offline=offline, days=3, per_day=4)
    alt_slots = {r["teacher"]["id"]: slot_view(r["teacher"]["id"], offline=offline, days=2, per_day=2)
                 for r in alts} if alts else {}

    result = {
        "query": {            "audience": audience,
            "level": level,
            "goals": sorted(target_goals),
            "unknown_goals": unknown_goals,
            "series": sorted(target_series)[:12],
            "type": want_type or "不限",
            "time": time_raw or "",
        },
        "library": {"fetched_at": tmeta.get("fetched_at", ""), "count": len(teachers),
                    "fixed_total": FIXED_TOTAL, "fixed_resolved": len(FIXED_IDS)},
        "primary": {
            "name": top["teacher"]["name"],
            "type": top["teacher"]["type"],
            "experience": top["teacher"].get("experience"),
            "degree": top["teacher"].get("degree"),
            "accent": top["teacher"].get("accent", ""),
            "score": round(top["score"], 1),
            "reason": top["reason"],
            "risks": top["risks"],
            "price": PRICE.get(top["teacher"]["type"]),
            "can_fix": top["teacher"]["id"] in FIXED_IDS,
            "slots": top_slots,
            "series_cn": [series_cn(s, cfg) for s in _ordered_series(top, ctx)],
            "series_short": [series_short(s, cfg) for s in _ordered_series(top, ctx)][:4],
            "feature": intro[0].get("feature", ""),
            "quote": intro[1],
            "photo": "",
        },
        "alternates": [
            {
                "name": r["teacher"]["name"],
                "type": r["teacher"]["type"],
                "experience": r["teacher"].get("experience"),
                "score": round(r["score"], 1),
                "reason": r["reason"],
                "risks": r["risks"],
                "price": PRICE.get(r["teacher"]["type"]),
                "can_fix": r["teacher"]["id"] in FIXED_IDS,
                "slots": alt_slots.get(r["teacher"]["id"], []),
                "series_cn": [series_cn(s, cfg) for s in _ordered_series(r, ctx)][:4],
                "series_short": [series_short(s, cfg) for s in _ordered_series(r, ctx)][:4],
            }
            for r in alts
        ],
        "tie": tie_info,
        "fixable_alt": fix_hint,
        "data_gaps": [],
    }
    if audience == "adult":
        result["data_gaps"].append("成人商务/考试向师资很薄（纯成人向只有 2 位），这条建议人工复核")
    if time_raw:
        if not slots:
            result["data_gaps"].append("还没有拉过可约时段，这次没有按时间筛。先跑 refresh.py slots")
        elif not slot_hits:
            result["data_gaps"].append(f"没找到 {time_raw} 有空的可固定老师（订课系统只放本周的时段，可能是本周排满了）")
        elif wd and not any(slot_hits.get(t["id"]) for t in pool):
            result["data_gaps"].append(f"{time_raw} 没有完全对上的老师")
    if unknown_goals:
        result["data_gaps"].append(f"这些目标没识别出来：{unknown_goals}")
    # 固定课表相关，必须说清楚，别让家长事后才发现
    prim_fix = result["primary"].get("can_fix")
    if want_fixed:
        if prim_fix:
            note = f"已只在固定课表名单里挑（{FIXED_TOTAL} 个席位 / {len(FIXED_IDS)} 位老师，资料齐全）"
            if FIXED_MISSING:
                note += f"，其中 {len(FIXED_MISSING)} 位资料待补"
            result["data_gaps"].append(note)
    elif not prim_fix and not result.get("fixable_alt"):
        result["data_gaps"].append("这位老师不在固定课表名单里，要固定上课得另外换一位（加 --fixed 即可）")
    if picked_note:
        result["data_gaps"].append(picked_note)
    if top_slots:
        src = "刚查的" if not offline else "缓存"
        result["data_gaps"].append(f"可约时段是{src}订课系统实时排课，只到本周；约课前在系统里再确认一次")
    elif not offline:
        result["data_gaps"].append("这位老师本周在订课系统里没有放出可约时段（可能已排满，或系统还没发下周）")
    if time_raw and slot_hits.get(top["teacher"]["id"]):
        d0, t0 = slot_hits[top["teacher"]["id"]][0]
        result["time_hit"] = {
            "date": d0,
            "weekday": WD_CN_LIST[datetime.date.fromisoformat(d0).isoweekday() - 1],
            "time": t0[0], "times": t0, "asked": time_raw,
        }
        if time_exact is False:
            result["data_gaps"].append(f"{time_raw} 整点没人有空，给的是前后 25 分钟内的最接近时段")
    result["time_exact"] = time_exact
    # 时间卡死时，同档里可能一个菲教都没有（菲教能教这个方向的少）。给一条换时间的路。
    if time_raw and slot_hits and audience in ("kid", "teen") and want_type is None:
        if "菲律宾" not in top["teacher"]["type"]:
            result["alt_time"] = best_alt_time(teachers, ctx, slot_hits, fel_only=True, prefer_wd=wd)
    if level_series:
        result["data_gaps"].append(f"{level} 已按课程体系自动选教材：{'、'.join(series_cn(s, cfg) for s in level_series[:4])}")

    # 升级项如果已经出现在备选里，就不重复占位
    if result["tie"] and result["tie"].get("premium"):
        if result["tie"]["premium"]["name"] in {a["name"] for a in result["alternates"]}:
            result["tie"].pop("premium")

    # 照片落地：用预先转好的 jpg（ASCII 文件名），聊天里才能稳定显示
    OUT_DIR.mkdir(exist_ok=True)
    pid = top["teacher"]["id"]
    fn = PHOTO_INDEX.get(pid, "")
    jpg = PHOTO_DIR / fn if fn else None
    if jpg and jpg.is_file():
        dst = OUT_DIR / jpg.name
        if not dst.exists():
            shutil.copyfile(jpg, dst)
        result["primary"]["photo"] = str(dst.resolve())
        result["primary"]["photo_exists"] = True
    else:
        result["primary"]["photo"] = ""
        result["primary"]["photo_exists"] = False
        result["primary"]["initials"] = top["teacher"].get("initials", "")

    return result


def render_chat(res):
    """渲染成可直接发到对话里的 markdown：先图，后字。"""
    p = res["primary"]
    tl = TYPE_LABEL.get(p["type"], p["type"])
    price = f"¥{p['price']}/节" if p.get("price") else "价格待定"
    head = f"**Teacher {p['name']} · {tl} · {price}**"

    if p.get("photo_exists") and p.get("photo"):
        photo_line = f"![Teacher {p['name']}]({p['photo']})"
    else:
        photo_line = f"**（这位老师的照片源站已失效，用姓名首字母 {p.get('initials','')} 代替）**"

    lines = [photo_line, "", head, ""]
    exp = re.sub(r"(\d)\s*年", r"\1 年", p["experience"] or "未知")
    lines.append(f"教龄 {exp} · {p['degree'] or '学历未知'}")
    if p.get("accent"):
        lines.append(f"口音：{p['accent']}")
    mats = p.get("series_short") or p["series_cn"]
    if mats:
        lines.append(f"擅长：{'、'.join(mats[:4])}")
    if p.get("can_fix"):
        lines.append("**可固定上课**（在这套固定课表名单里）")
    hit = res.get("time_hit")
    if hit:
        lines.append(f"**你要的 周{hit['weekday']} {hit['time']} 有空**（订课系统实时）")
    sc = p.get("slots") or []
    if sc:
        bits = []
        for x in sc[:2]:
            times = "、".join(x["times"][:3])
            bits.append(f"周{x['weekday']} {times}")
        lines.append(f"**可约时段**：" + "；".join(bits))
    else:
        lines.append("**可约时段**：本周订课系统里没放出空位，约课前问一下教务")
    lines.append("")
    lines.append(p["reason"])
    if p.get("quote"):
        lines.append("")
        lines.append(f"> {p['quote']}")
    lines.append("")
    lines.append("—")
    alts = [f"Teacher {a['name']}（{TYPE_LABEL.get(a['type'],a['type'])} ¥{a['price'] if a.get('price') else '待定'}"
            + ("·可固定" if a.get("can_fix") else "") + "）"
            for a in res["alternates"]]
    if alts:
        lines.append(f"备选：{'、'.join(alts)}")

    fh = res.get("fixable_alt")
    if fh and not p.get("can_fix"):
        lines.append(f"想固定上课：Teacher {fh['name']}（{TYPE_LABEL.get(fh['type'], fh['type'])} ¥{fh['price'] if fh.get('price') else '待定'}，同一档可固定）")

    at = res.get("alt_time")
    if at:
        lines.append(f"想压成本：换到 周{at['weekday']} {at['slots'][0]}，Teacher {at['name']}"
                     f"（{TYPE_LABEL.get(at['type'], at['type'])} ¥{at['price'] if at.get('price') else '待定'}）也有空")

    if res.get("alternates"):
        sca = []
        for a in res["alternates"]:
            s_ = a.get("slots") or []
            if s_:
                sca.append(f"{a['name']}（周{s_[0]['weekday']} {s_[0]['times'][0]}）")
            else:
                sca.append(f"{a['name']}（本周无空位）")
        if sca:
            lines.append("备选时段：" + "、".join(sca))

    t = res.get("tie")
    if t and (t.get("count") or t.get("premium")):
        types = t.get("types") or []
        if len(types) <= 1:
            note = f"\n同档说明：有 {t['count']} 位老师实力相当，都是{TYPE_LABEL.get(types[0], types[0]) if types else '同类'}，差别主要在教龄和口音。"
        else:
            note = f"\n同档说明：有 {t['count']} 位老师实力相当，差别主要在师资类型和价格。"
        if t.get("premium"):
            note += f"想升级欧美的，可以看 Teacher {t['premium']['name']}（¥{t['premium']['price']}/节）。"
        lines.append(note)

    for g in res.get("data_gaps", []):
        lines.append(f"\n⚠ {g}")
    return "\n".join(lines)


def main():
    p = argparse.ArgumentParser(description="外教匹配器")
    p.add_argument("--text", help="直接说需求，如「8岁孩子想练口语，喜欢活泼的菲教」")
    p.add_argument("--audience", choices=["kid", "teen", "adult"], help="人群：kid 少儿 / teen 青少年 / adult 成人")
    p.add_argument("--age", type=int, help="年龄（用于推断人群）")
    p.add_argument("--level", help="水平：Y1-Y6 或 1-10 级")
    p.add_argument("--goal", nargs="*", help="目标，可多个：口语 阅读 启蒙 应试KET 商务 旅行 ...")
    p.add_argument("--series", nargs="*", help="指定教材系列，如 reading_a_z / lets_go / think")
    p.add_argument("--type", help="师资偏好：菲教/菲律宾/欧美/中教")
    p.add_argument("--time", help="期望时间（当前无法真实匹配，仅作提示）")
    p.add_argument("--fixed", action="store_true", help="只在「可固定上课」老师名单里挑（名单来自固定课表）")
    p.add_argument("--no-slots", action="store_true", dest="no_slots",
                   help="不现查可约时段（离线/批量跑时用，只吃缓存）")
    p.add_argument("--json", action="store_true", help="输出 JSON")
    p.add_argument("--chat", action="store_true", help="输出可直接发到对话的 markdown（先图后字）")
    args = p.parse_args()

    res = match(args)
    if args.json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    elif args.chat:
        print(render_chat(res))
    else:
        q, prim = res["query"], res["primary"]
        print(f"需求识别：{q['audience']}｜水平 {q['level'] or '未指定'}｜目标 {q['goals'] or '未指定'}｜师资 {q['type']}")
        print(f"照片：{prim['photo']}")
        print()
        price = f"¥{prim['price']}/节（25分钟）" if prim["price"] else "价格待定"
        print(f"【主推】Teacher {prim['name']}（{TYPE_LABEL.get(prim['type'], prim['type'])}）　{price}")
        print(f"教龄 {prim['experience']}　学历 {prim['degree']}" + (f"　口音 {prim['accent']}" if prim.get("accent") else ""))
        print(f"擅长教材：{'、'.join(prim['series_cn'][:6])}")
        if prim["feature"]:
            print(f"教学特色：{prim['feature']}")
        if prim["quote"]:
            print(f"老师原话：{prim['quote']}")
        print(f"为什么是他：{prim['reason']}")
        if prim["risks"]:
            print(f"需要注意：{'；'.join(prim['risks'])}")
        print()
        for i, a in enumerate(res["alternates"], 1):
            ap = f"¥{a['price']}/节" if a["price"] else "价格待定"
            print(f"备选 {i}：Teacher {a['name']}（{TYPE_LABEL.get(a['type'], a['type'])}，{ap}）— {a['reason']}")
        if res["tie"]:
            t = res["tie"]
            print()
            print(f"同档说明：有 {t['count']} 位老师得分相差不到 {t['spread']} 分，实力相当，主要差别在师资类型和价格。")
            if t.get("premium"):
                p = t["premium"]
                print(f"　升级项：Teacher {p['name']}（欧美）¥{p['price']}/节，适合更看重口音或预算充足的家庭。")
        if res["data_gaps"]:
            print()
            for g in res["data_gaps"]:
                print(f"⚠ {g}")

if __name__ == "__main__":
    main()
