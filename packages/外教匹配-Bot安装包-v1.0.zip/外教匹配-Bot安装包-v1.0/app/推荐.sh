#!/usr/bin/env bash
# 外教匹配 —— 找 python3，跑匹配器
#
# 为什么有这个：
#   匹配器是 Python，不同电脑上 python3 的位置不一样（系统自带、Homebrew、conda、pyenv 都可能）。
#   直接写 python3 在有些机器上会 command not found。这里自动找一圈，找不到才报错。
#
# 用法：
#   bash 推荐.sh --text "8岁孩子练口语"
#   bash 推荐.sh --text "三年级补阅读" --type 菲律宾
#   bash 推荐.sh --audience adult --goal 商务
#   bash 推荐.sh --text "准备KET" --json
#   bash 推荐.sh 刷新              # 重拉老师资料 + 补照片 + 对齐固定名单 + 拉可约时段
#   bash 推荐.sh 刷新 slots        # 只刷新可约时段
#
# 位置：需要和 match.py 放在同一个目录。

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENTRY="$HERE/match.py"
REFRESH="$HERE/refresh.py"

# 第一个参数是「刷新」时，转去跑数据刷新（同一个运行时）
if [ "${1:-}" = "刷新" ]; then
  shift
  ENTRY="$REFRESH"
  set -- "${@:-all}"
  [ -z "${1:-}" ] && set -- all
fi

if [ ! -f "$ENTRY" ]; then
  echo "找不到 $(basename "$ENTRY")（应该和本脚本在同一个文件夹）" >&2
  exit 1
fi

find_runtime() {
  # 1) PATH 里的 python3
  if command -v python3 >/dev/null 2>&1 && python3 -c "import sys" >/dev/null 2>&1; then
    echo "python3"; return 0
  fi

  # 2) 系统自带
  local p
  for p in /usr/bin/python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
    if [ -x "$p" ] && "$p" -c "import sys" >/dev/null 2>&1; then echo "$p"; return 0; fi
  done

  # 3) pyenv 装的最新一个
  local pv
  for pv in $(ls -d "$HOME"/.pyenv/versions/*/bin/python3 2>/dev/null | sort -V -r); do
    [ -x "$pv" ] && { echo "$pv"; return 0; }
  done

  # 4) conda
  local c
  for c in "$HOME"/miniconda3/bin/python3 "$HOME"/anaconda3/bin/python3 /opt/miniconda3/bin/python3; do
    [ -x "$c" ] && { echo "$c"; return 0; }
  done

  return 1
}

PY="$(find_runtime)" || {
  cat >&2 <<'MSG'
没找到能跑 Python 3 的运行时。

三个办法，任选一个：
  · 装了 DSH Desktop 的话，用 DSH 里的终端跑，它通常能拿到系统 python3
  · 装 Python：https://www.python.org/downloads/ （选 3.x，一路下一步）
  · 只想看文字结果：匹配规则是确定的，按教材对照表人工比对也能给出老师

MSG
  exit 1
}

exec "$PY" "$ENTRY" "$@"
