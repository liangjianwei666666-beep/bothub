#!/usr/bin/env python3
"""Create a portable RUN migration-research workspace from the bundled template."""
from __future__ import annotations
import argparse
from datetime import date
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--title', default='润途移居研究工作台')
    parser.add_argument('--out', required=True, help='Output HTML file path')
    parser.add_argument('--template', help='Template path; defaults to ../templates relative to this script')
    args = parser.parse_args()
    template = Path(args.template) if args.template else Path(__file__).resolve().parents[1] / 'templates' / '移居研究工作台模板.html'
    output = Path(args.out)
    if not template.is_file():
        parser.error(f'template not found: {template}')
    if output.exists():
        parser.error(f'refusing to overwrite existing file: {output}')
    html = template.read_text(encoding='utf-8').replace('{{TITLE}}', args.title.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding='utf-8')
    source = output.with_suffix('.md')
    source.write_text(
        f'# {args.title}\n\n'
        f'- 创建日期：{date.today().isoformat()}\n'
        '- 研究对象：待填写\n'
        '- 当前状态：模板已生成；目标国家与政策尚未核实\n\n'
        '## 申请人画像\n\n待补充：护照/国籍、家庭成员、收入来源、职业学历、语言、预算、工作需求、时间目标与约束。\n\n'
        '## 候选路线\n\n待补充，初筛最多 3–5 条。每条说明适用前提、工作权、家属、续签/永居、税务风险、材料及未确定点。\n\n'
        '## 已核实事实\n\n暂无。当前政策必须以官方来源实时核验并记录访问日期。\n\n'
        '## RUN 项目资料\n\nRUN · 润：https://github.com/BryceYuuu/RUN 。仅作研究起点，不是官方数据库。\n\n'
        '## 待核实事项与下一步\n\n- 确认目标国家及申请人关键条件。\n- 查阅目的国政府、移民局、使领馆或税务机关页面。\n- 记录来源 URL、访问日期、结论适用范围及未确认点。\n\n'
        '免责声明：信息整理不构成移民、法律、税务或投资意见。\n', encoding='utf-8')
    print(f'HTML: {output.resolve()}')
    print(f'Markdown: {source.resolve()}')
    print('Status: blank research template; no current immigration policy verified')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
