#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""选品八维评分器：按锅圈选品方法论给候选打分，≥70 进候选池。零依赖。
维度权重（固定，不随项目改）：需求热度20 场景15 心智15 供应链15 价格毛利15 复购10 竞争5 合规5
每维原始分 0-5（5=最好），缺失必须留空，不许拍脑袋补分。
用法:
  python3 score.py candidates.csv                 # 评分并输出报告
  python3 score.py candidates.csv --md out.md     # 另存 Markdown
CSV 列: name,cat,demand,scene,mind,supply,margin,repurchase,competition,compliance,evidence,note
"""
import argparse, csv, json, sys

DIMS = [("demand","需求热度",20),("scene","场景",15),("mind","心智",15),
        ("supply","供应链",15),("margin","价格毛利",15),("repurchase","复购",10),
        ("competition","竞争",5),("compliance","合规",5)]
POOL_LINE = 70

def parse_dim(v):
    v = (v or "").strip()
    if v == "": return None
    try:
        f = float(v)
    except ValueError:
        return None
    if not (0 <= f <= 5): return None
    return f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--md", default=None)
    ap.add_argument("--json", default=None)
    a = ap.parse_args()
    rows = [r for r in csv.DictReader(open(a.csv, encoding="utf-8-sig"))
            if (r.get("name") or "").strip()]
    if not rows:
        print("CSV 为空", file=sys.stderr); sys.exit(2)

    out = []
    for r in rows:
        scores, missing = {}, []
        for key, label, w in DIMS:
            v = parse_dim(r.get(key))
            if v is None:
                missing.append(label); scores[key] = None
            else:
                scores[key] = v
        # 只按已填维度计分，并按已填权重归一化；缺项必须显式暴露
        filled = [(k, l, w, s) for (k, l, w), s in zip(DIMS, [scores[k] for k, _, _ in DIMS]) if s is not None]
        got_w = sum(w for _, _, w, _ in filled)
        raw = sum(w * (s / 5.0) for _, _, w, s in filled)
        total = (raw / got_w * 100) if got_w else 0.0
        completeness = got_w / 100.0
        out.append({
            "name": (r.get("name") or "").strip(),
            "cat": (r.get("cat") or "").strip(),
            "total": round(total, 1),
            "completeness": round(completeness * 100),
            "missing": missing,
            "scores": scores,
            "evidence": (r.get("evidence") or "").strip(),
            "note": (r.get("note") or "").strip(),
            # 入池门槛：分数够 + 八维不缺 + 必须有证据
            "weak_evidence": any(k in (r.get("evidence") or "") for k in ("未实测", "待补", "待核", "估计", "大概")),
            "in_pool": (total >= POOL_LINE and not missing
                        and bool((r.get("evidence") or "").strip())
                        and not any(k in (r.get("evidence") or "") for k in ("未实测", "待补", "待核", "估计", "大概"))),
        })

    out.sort(key=lambda x: -x["total"])

    L = ["# 选品评分结果", ""]
    L.append(f"入池线 {POOL_LINE} 分；入池还需满足：八维齐全 + 有证据。仅按已填维度归一化，缺维度会降低可信度。")
    L.append("")
    L.append("| 候选 | 品类 | 得分 | 完整度 | 入池 | 缺失维度 |")
    L.append("|---|---|---|---|---|---|")
    for x in out:
        L.append(f"| {x['name']} | {x['cat']} | {x['total']} | {x['completeness']}% | "
                 f"{'✅ 进池' if x['in_pool'] else '❌ 不入'} | {'、'.join(x['missing']) or '—'} |")
    L.append("")
    for x in out:
        L.append(f"## {x['name']}（{x['total']} 分）")
        L.append("")
        parts = []
        for key, label, w in DIMS:
            v = x["scores"][key]
            parts.append(f"{label} {'—' if v is None else v}")
        L.append("｜".join(parts))
        L.append("")
        if x["missing"]:
            L.append(f"- ⚠️ 缺数据：{'、'.join(x['missing'])}——这些维度没有实测或调研依据，不得默认满分")
        if not x["evidence"]:
            L.append("- ⚠️ 没有填 evidence（数据来源），即使分数够也不得入池")
        elif x["weak_evidence"]:
            L.append(f"- ⚠️ 证据偏弱（含「未实测/待补/待核/估计」等字样）：{x['evidence']}")
        if x["note"]:
            L.append(f"- 备注：{x['note']}")
        L.append("")
    md = "\n".join(L) + "\n"
    print(md)
    if a.md: open(a.md, "w", encoding="utf-8").write(md); print("MD=" + a.md)
    if a.json:
        json.dump(out, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("JSON=" + a.json)
    passed = sum(1 for x in out if x["in_pool"])
    print(f"共 {len(out)} 个候选，入池 {passed} 个")
    sys.exit(0)

if __name__ == "__main__":
    main()
