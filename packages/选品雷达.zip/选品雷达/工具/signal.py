#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""品类热点信号：从已验证可达的热榜抓「与火锅/烧烤/食材相关」的条目，作为需求热度的外部证据。零依赖。
用法: python3 signal.py [--days-dir ./信号] [--limit 50]
输出: 屏幕 + 信号/<日期>-品类信号.md
说明: 只做"存在该话题"的旁证，不是销量数据；热榜条目本身是情绪化表达，需人工判断。
"""
import argparse, datetime, json, os, re, sys, urllib.request

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36"
KEYWORDS = {
    "火锅": ["火锅", "涮", "锅底", "底料", "毛肚", "鸭血", "牛油", "番茄锅", "菌汤"],
    "烧烤": ["烧烤", "烤串", "撸串", "烤鱼", "烤肉", "小龙虾", "烤肠", "围炉"],
    "食材": ["羊肉", "牛肉", "虾滑", "丸子", "鱼丸", "豆制品", "豆皮", "腐竹", "午餐肉"],
    "场景": ["家庭聚餐", "露营", "年夜饭", "冬至", "天冷", "入冬", "降温", "宅家"],
    "对照": ["雪糕", "奶茶", "咖啡", "烘焙", "预制菜", "空气炸锅"],
}

def fetch(url, referer="https://www.google.com/", timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": referer})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "ignore")

def walk(obj, need):
    out = []
    if isinstance(obj, dict):
        if all(k in obj for k in need): out.append(obj)
        for v in obj.values(): out.extend(walk(v, need))
    elif isinstance(obj, list):
        for v in obj: out.extend(walk(v, need))
    return out

def get_sources(limit):
    items, status = [], {}
    try:
        d = json.loads(fetch("https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc"))
        got = [{"source": "头条", "rank": i, "title": it.get("Title", ""), "heat": it.get("HotValue")}
               for i, it in enumerate((d.get("data") or [])[:limit], 1)]
        items += got; status["头条"] = f"OK {len(got)}"
    except Exception as e:
        status["头条"] = f"FAIL {type(e).__name__}"
    try:
        d = json.loads(fetch("https://aweme.snssdk.com/aweme/v1/hot/search/list/"))
        wl = (d.get("data") or {}).get("word_list") or []
        got = [{"source": "抖音", "rank": i, "title": it.get("word", ""), "heat": it.get("hot_value")}
               for i, it in enumerate(wl[:limit], 1)]
        items += got; status["抖音"] = f"OK {len(got)}"
    except Exception as e:
        status["抖音"] = f"FAIL {type(e).__name__}"
    try:
        d = json.loads(fetch("https://top.baidu.com/api/board?platform=wise&tab=realtime"))
        got, seen = [], set()
        for it in walk(d, ["word"]):
            t = (it.get("word") or "").strip()
            if not t or t in seen: continue
            seen.add(t)
            got.append({"source": "百度", "rank": len(got) + 1, "title": t, "heat": it.get("hotScore")})
            if len(got) >= limit: break
        items += got; status["百度"] = f"OK {len(got)}"
    except Exception as e:
        status["百度"] = f"FAIL {type(e).__name__}"
    return items, status

def classify(title):
    hits = {}
    for cat, kws in KEYWORDS.items():
        for kw in kws:
            if kw in title:
                hits.setdefault(cat, []).append(kw)
    return hits

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days-dir", default="信号")
    ap.add_argument("--limit", type=int, default=50)
    a = ap.parse_args()
    today = datetime.date.today().isoformat()
    items, status = get_sources(a.limit)
    hit = []
    for it in items:
        c = classify(it["title"])
        if c: hit.append({**it, "match": c})
    cat_count = {}
    for h in hit:
        for cat in h["match"]:
            cat_count[cat] = cat_count.get(cat, 0) + 1

    L = [f"# 品类热点信号 · {today}", ""]
    L.append("数据源：" + "；".join(f"{k} {v}" for k, v in status.items()))
    L.append("")
    L.append("## 命中统计（同类话题在榜条数，只反映讨论热度，不是销量）")
    L.append("")
    L.append("| 类别 | 命中条数 |")
    L.append("|---|---|")
    for k in KEYWORDS:
        L.append(f"| {k} | {cat_count.get(k, 0)} |")
    L.append("")
    L.append("## 命中的在榜条目")
    L.append("")
    if hit:
        L.append("| 源 | 榜位 | 标题 | 命中关键词 | 热度 |")
        L.append("|---|---|---|---|---|")
        for h in hit:
            kws = "、".join(f"{c}:{'/'.join(v)}" for c, v in h["match"].items())
            L.append(f"| {h['source']} | {h['rank']} | {h['title']} | {kws} | {h['heat']} |")
    else:
        L.append("- 今日没有命中（可能是真没有，也可能是热榜本身与品类无关）")
    L.append("")
    L.append("## 怎么用")
    L.append("")
    L.append("1. 某类别命中 ≥3 条 → 说明当日该心智在公共讨论里活跃，可作为「需求热度」维度的旁证之一")
    L.append("2. 命中条目里的具体食材/做法词，可作为新品概念的关键词候选")
    L.append("3. **不要**把命中条数直接当销量或搜索指数；热榜是舆论场，不是销售场")
    L.append("4. 「对照」类别只用来判断整体食物类话题是否活跃，不参与本品类判断")
    L.append("")
    L.append("> 数据源：头条热榜、抖音热榜、百度热搜（2026-11-05 实测可达）。微博/知乎/B站/小红书需登录或 Key，未纳入。")
    md = "\n".join(L) + "\n"

    os.makedirs(a.days_dir, exist_ok=True)
    p = os.path.join(a.days_dir, f"{today}-品类信号.md")
    open(p, "w", encoding="utf-8").write(md)
    print(md[:1800])
    print("...\nMD=" + p)
    print("命中 " + str(len(hit)) + " 条，各类：" + json.dumps(cat_count, ensure_ascii=False))

if __name__ == "__main__":
    main()
