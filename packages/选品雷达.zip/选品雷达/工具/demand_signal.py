#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""需求意图信号：拉品类词的百度联想词，按搜索意图归类，看"消费者到底在问什么"。零依赖。
用法: python3 demand_signal.py [--seeds 火锅底料,羊肉卷,虾滑] [--out 信号/意图-日期.md]
原理: 联想词 = 真实搜索行为的候选表达，能反映需求意图（比品牌/比价/找做法/担心健康/找批发）。
边界: 没有绝对搜索量，只能做定性/相对判断，不能当销量或热度排名。
"""
import argparse, datetime, json, os, time, urllib.parse, urllib.request

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36"
DEFAULT_SEEDS = ["火锅底料", "羊肉卷", "牛肉卷", "虾滑", "毛肚", "丸子", "烤鱼", "烧烤食材",
                 "烤肉腌料", "蘸料", "酸菜鱼", "预制菜"]
INTENTS = [
    ("品牌比较", ["哪个品牌", "十大", "排行榜", "排名", "牌子", "哪家好", "推荐", "哪种好", "什么牌子"]),
    ("做法教程", ["怎么做", "做法", "怎么腌", "腌制", "制作", "教程", "怎么自己", "怎么", "如何", "配方"]),
    ("价格采购", ["多少钱", "价格", "批发", "厂家", "进货", "一斤", "便宜", "划算"]),
    ("健康顾虑", ["危害", "健康", "热量", "胖", "减肥", "添加剂", "安全", "致癌", "过期", "能吃吗", "保质期", "防腐"]),
    ("认知疑问", ["是什么", "什么意思", "有哪些", "区别", "好处", "配料", "成分", "属于"]),
    ("场景搭配", ["配什么", "搭配", "一起吃", "适合", "套餐", "几个人", "怎么吃"]),
    ("视觉素材", ["图片", "高清", "壁纸", "视频"]),
    ("品质来源", ["合成肉", "部位", "真假", "纯", "原切", "进口", "产地", "新鲜", "是不是", "区别在哪"]),
    ("烹饪参数", ["煮多久", "涮多久", "几分钟", "火候", "温度", "多久能熟", "煮多长时间"]),
]

def sug(wd, retry=2):
    u = "https://www.baidu.com/sugrec?prod=pc&wd=" + urllib.parse.quote(wd)
    req = urllib.request.Request(u, headers={"User-Agent": UA, "Referer": "https://www.google.com/"})
    for i in range(retry + 1):
        try:
            d = json.loads(urllib.request.urlopen(req, timeout=12).read().decode("utf-8", "ignore"))
            return [g.get("q", "") for g in d.get("g", []) if g.get("q")]
        except Exception:
            if i == retry: return []
            time.sleep(1.0)
    return []

def classify(text):
    for name, kws in INTENTS:
        if any(k in text for k in kws):
            return name
    return "其他"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="", help="逗号分隔的种子词，留空用默认品类词")
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    seeds = [s.strip() for s in a.seeds.split(",") if s.strip()] or DEFAULT_SEEDS
    today = datetime.date.today().isoformat()
    rows, intent_total, fails = [], {}, []
    for s in seeds:
        got = sug(s)
        if not got:
            fails.append(s); continue
        per = {}
        for t in got:
            i = classify(t); per[i] = per.get(i, 0) + 1
            intent_total[i] = intent_total.get(i, 0) + 1
        others = [t for t in got if classify(t) == "其他"]
        rows.append({"seed": s, "suggests": got, "intents": per, "others": others})
        time.sleep(0.5)

    total = sum(intent_total.values()) or 1
    L = [f"# 需求意图信号 · {today}", ""]
    L.append(f"种子词 {len(rows)} 个，累计联想词 {total} 条。")
    L.append("")
    L.append("## 一、意图分布（消费者在问什么）")
    L.append("")
    L.append("| 意图 | 条数 | 占比 |")
    L.append("|---|---|---|")
    for name, _ in INTENTS + [("其他", [])]:
        c = intent_total.get(name, 0)
        if c: L.append(f"| {name} | {c} | {c/total*100:.0f}% |")
    L.append("")
    L.append("## 二、每个品类的 Top 联想词")
    L.append("")
    for r in rows:
        L.append(f"### {r['seed']}")
        L.append("")
        L.append("意图：" + "、".join(f"{k} {v}" for k, v in sorted(r["intents"].items(), key=lambda x: -x[1])))
        L.append("")
        for t in r["suggests"][:8]:
            L.append(f"- [{classify(t)}] {t}")
        L.append("")
    unclassified = [t for r in rows for t in r.get("others", [])]
    if unclassified:
        L.append("## 三、未归类的联想词（分类器的边界，原样列出）")
        L.append("")
        L.append(f"共 {len(unclassified)} 条没匹配上意图词典。这类词往往是新概念或细分需求，值得人看一眼：")
        L.append("")
        for t in unclassified[:15]:
            L.append(f"- {t}")
        L.append("")
    L.append("## 四、怎么读这份信号（重要）")
    L.append("")
    L.append("- **有「哪个品牌好/十大/排行榜」** → 该品类消费者在做比较决策，新品牌进场的说服成本高，需要明确差异点")
    L.append("- **有「怎么做/做法/腌制」** → 用户有做饭意愿但缺方案，**连带销售**（底料+食材+蘸料组合）有机会")
    L.append("- **有「多少钱一斤/批发/厂家」** → 价格敏感度或 B 端需求，定价要能对上心理价位")
    L.append("- **有「危害/添加剂/减肥」** → 健康顾虑是真实阻力，宣称合规比卖点更重要")
    L.append("- **有「合成肉吗/哪个部位/原切」** → 品质疑虑是这个品类的真实门槛，**溯源和规格说明比促销更管用**")
    L.append("- **有「煮多久/涮多久」** → 用户缺操作参数，包装上印清烹饪时间能直接降低退货和差评")
    L.append("- **联想词没有绝对搜索量** → 只能判断\"在问什么\"，不能判断\"问得多不多\"。要数量必须靠平台指数或 API，本机目前拿不到")
    L.append("")
    L.append("> 数据源：百度联想词接口（2026-11-05 实测 200 可用）。每条种子词只取一次，结果随时会变。")
    md = "\n".join(L) + "\n"
    out = a.out or os.path.join("信号", f"{today}-需求意图.md")
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    open(out, "w", encoding="utf-8").write(md)
    print(md[:1500]); print("...\nMD=" + out)
    if fails: print("WARN 以下种子词没取到联想词：" + "、".join(fails))

if __name__ == "__main__":
    main()
