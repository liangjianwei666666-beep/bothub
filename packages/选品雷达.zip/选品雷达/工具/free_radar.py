#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""纯免费选品雷达：不用任何付费 Key，把 6 个已实测可用的免费源拼成一份简报。零依赖。
用法: python3 free_radar.py --kw 火锅底料 [--kw2 烤鱼] [--out 信号]
数据源（2026-11-05 实测）：
  百度联想词 · 搜狗微信文章 · 头条搜索 · 苏宁在售 · 头条/抖音热榜 · Crossref 学术
边界：价格与销量拿不到真实值；所有数字都是"讨论热度/条数"，不是销售数据。
"""
import argparse, datetime, json, os, re, sys, time, urllib.parse, urllib.request
from collections import Counter

UA_PC = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36"
UA_MO = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148"

STOP = set("的了是吗我你他她它们这那有和与在就都也很不没最更太啊吧呢个一二三四五六七八九十百千万元克斤份人天年月日".split() if False else
           list("的了是吗我你他她它这那有和与在就都也很不没最更太啊吧呢个一二三四五六七八九十"))
STOP_WORDS = {"火锅", "底料", "怎么", "什么", "哪个", "可以", "多少", "一下", "我们", "你们", "他们",
              "自己", "现在", "时候", "一个", "这个", "那个", "就是", "还是", "已经", "非常", "真的"}

def get(url, ua=UA_PC, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": ua, "Referer": "https://www.google.com/"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "ignore")

def curl_get(url, ua=UA_PC, timeout=25):
    """用系统 curl 取页面。部分站点（如头条搜索）对 urllib 的默认头返回不同变体，curl 更接近真实浏览器。"""
    import subprocess
    try:
        r = subprocess.run(["curl", "-s", "-m", str(timeout), "-A", ua,
                            "-H", "Referer: https://www.google.com/",
                            "-H", "Accept-Language: zh-CN,zh;q=0.9", url],
                           capture_output=True, text=True)
        return r.stdout or ""
    except Exception:
        return ""

def clean_html(s):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", s)).strip()

# ---------- 1 需求意图（百度联想词） ----------
def baidu_sug(kw):
    u = "https://www.baidu.com/sugrec?prod=pc&wd=" + urllib.parse.quote(kw)
    try:
        d = json.loads(get(u))
        return [g.get("q", "") for g in d.get("g", []) if g.get("q")]
    except Exception:
        return []

INTENTS = [
    ("品牌比较", ["哪个品牌", "十大", "排行榜", "排名", "牌子", "哪家好", "推荐", "哪种好"]),
    ("做法教程", ["怎么做", "做法", "腌制", "怎么自己", "怎么", "如何", "配方", "秘方"]),
    ("价格采购", ["多少钱", "价格", "批发", "厂家", "进货", "一斤", "便宜", "划算"]),
    ("健康顾虑", ["危害", "健康", "热量", "胖", "减肥", "添加剂", "安全", "致癌", "过期", "能吃吗"]),
    ("品质来源", ["合成肉", "部位", "真假", "纯", "原切", "进口", "产地", "新鲜"]),
    ("烹饪参数", ["煮多久", "涮多久", "几分钟", "火候", "多久能熟"]),
    ("认知疑问", ["是什么", "什么意思", "有哪些", "区别", "好处", "配料", "成分"]),
    ("场景搭配", ["配什么", "搭配", "一起吃", "适合", "套餐", "几个人", "怎么吃"]),
]
def intent_of(t):
    for n, ks in INTENTS:
        if any(k in t for k in ks): return n
    return "其他"

# ---------- 2 内容侧：搜狗微信 ----------
def sogou_wechat(kw):
    u = "https://weixin.sogou.com/weixin?type=2&query=" + urllib.parse.quote(kw)
    try:
        h = get(u)
    except Exception:
        return []
    if "验证码" in h: return []
    ts = re.findall(r"<h3>\s*<a[^>]*>(.*?)</a>", h, re.S)
    return [clean_html(t) for t in ts if clean_html(t)]

# ---------- 3 内容侧：头条搜索 ----------
def toutiao_search(kw, retry=2):
    """头条搜索：实测间歇可用（连续请求易被限流），失败重试 + 退避。"""
    u = "https://so.toutiao.com/search?keyword=" + urllib.parse.quote(kw)
    h = None
    for i in range(retry + 1):
        h = curl_get(u)
        if h and '"title"' in h: break
        time.sleep(3.0)
    if not h:
        return []
    raw = re.findall(r'"title":"([^"]{8,80})"', h)
    out = []
    for t in raw:
        t = t.encode().decode("unicode_escape", "ignore")
        t = re.sub(r"</?em>", "", t).strip()
        if t and t not in out and not t.endswith(("视频", "小视频")):
            out.append(t)
    return out[:30]

# ---------- 4 在售侧：苏宁 ----------
def suning(kw):
    u = "https://search.suning.com/" + urllib.parse.quote(kw) + "/"
    try:
        h = get(u)
    except Exception:
        return {"hits": 0, "titles": [], "note": "抓取失败"}
    titles = [t for t in re.findall(r'title="([^"]{8,60})"', h) if kw in t or "火锅" in t]
    return {"hits": h.count(kw), "titles": list(dict.fromkeys(titles))[:8],
            "note": "hits=页面中关键词出现次数，只表示结果页有货，不等于 SKU 数"}

# ---------- 5 热榜旁证 ----------
def hot_board():
    out = {}
    try:
        d = json.loads(get("https://www.toutiao.com/hot-event/hot-board/?origin=toutiao_pc"))
        out["头条"] = [it.get("Title", "") for it in (d.get("data") or [])[:60]]
    except Exception: out["头条"] = []
    try:
        d = json.loads(get("https://aweme.snssdk.com/aweme/v1/hot/search/list/"))
        out["抖音"] = [it.get("word", "") for it in ((d.get("data") or {}).get("word_list") or [])[:60]]
    except Exception: out["抖音"] = []
    return out

# ---------- 6 学术趋势 ----------
def crossref(query, rows=5):
    u = ("https://api.crossref.org/works?query=" + urllib.parse.quote(query)
         + f"&rows={rows}&select=title,issued,DOI")
    try:
        d = json.loads(get(u))
        return [(i.get("title") or [""])[0][:80] for i in d["message"]["items"]]
    except Exception:
        return []

# ---------- 高频词 ----------
SIGNALS = {
    "教程做法": ["教程", "做法", "配方", "秘方", "步骤", "教你", "自制", "在家做"],
    "测评对比": ["测评", "评测", "对比", "哪个好", "试吃", "红黑榜", "推荐榜"],
    "避雷负面": ["翻车", "避雷", "难吃", "踩雷", "智商税", "不推荐", "别再买", "后悔"],
    "种草推荐": ["推荐", "种草", "必买", "安利", "宝藏", "好吃到", "回头客"],
    "价格促销": ["便宜", "优惠", "9.9", "平替", "性价比", "打折", "特价"],
    "场景季节": ["冬季", "入冬", "露营", "聚餐", "年夜饭", "一人食", "早餐", "宵夜"],
    "健康诉求": ["低脂", "无糖", "减脂", "高蛋白", "干净配料", "0添加", "健身"],
    "B端批发": ["批发", "厂家", "代理", "供应链", "代工", "加盟"],
}

def signal_hits(titles):
    """统计内容信号词的命中：看这个品类的内容是"教你怎么做"还是"测评吐槽"还是"带货"。"""
    hits, detail = Counter(), {}
    for t in titles:
        for name, words in SIGNALS.items():
            for w in words:
                if w in t:
                    hits[name] += 1
                    detail.setdefault(name, []).append(w)
    return hits, detail

def run(kw, en=None):
    res = {"kw": kw}
    res["suggests"] = baidu_sug(kw)
    res["sogou"] = sogou_wechat(kw)
    res["toutiao"] = toutiao_search(kw)
    res["suning"] = suning(kw)
    res["crossref"] = crossref(en) if en else []
    intents = Counter(intent_of(s) for s in res["suggests"])
    res["intents"] = dict(intents)
    res["signals"], res["signal_words"] = signal_hits(res["sogou"] + res["toutiao"])
    return res

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--kw", action="append", required=True, help="品类关键词，可重复")
    ap.add_argument("--en", action="append", default=[], help="英文关键词（用于学术检索），与 --kw 顺序对应")
    ap.add_argument("--out", default="信号")
    a = ap.parse_args()
    today = datetime.date.today().isoformat()
    boards = hot_board()
    all_res = []
    for i, kw in enumerate(a.kw):
        en = a.en[i] if i < len(a.en) else None
        print(f"采集 {kw} ..." + (f"（学术用 {en}）" if en else "（未给英文词，跳过学术检索）"), flush=True)
        all_res.append(run(kw, en)); time.sleep(2.0)

    L = [f"# 纯免费选品雷达 · {today}", ""]
    L.append("零付费 Key。数据源：百度联想词、搜狗微信文章、头条搜索、苏宁在售页、头条/抖音热榜、Crossref。")
    L.append("")
    L.append("> **读法**：所有数字都是「讨论条数 / 页面命中数」，不是销量、不是搜索指数。价格与 SKU 拿不到真实值。")
    L.append("")
    for r in all_res:
        kw = r["kw"]
        L.append(f"## {kw}")
        L.append("")
        L.append(f"**① 需求意图**（{len(r['suggests'])} 条联想词）")
        L.append("")
        if r["intents"]:
            L.append("| 意图 | 条数 |")
            L.append("|---|---|")
            for k, v in sorted(r["intents"].items(), key=lambda x: -x[1]):
                L.append(f"| {k} | {v} |")
            L.append("")
        L.append(f"**② 内容侧讨论**：公众号 {len(r['sogou'])} 篇 / 综合搜索 {len(r['toutiao'])} 条")
        L.append("")
        if r["sogou"]:
            L.append("公众号标题样例：")
            for t in r["sogou"][:5]: L.append(f"- {t}")
            L.append("")
        L.append(f"**③ 在售情况**（苏宁）：{r['suning']['note']}，命中 {r['suning']['hits']} 次")
        L.append("")
        if r["suning"]["titles"]:
            for t in r["suning"]["titles"][:4]: L.append(f"- 在售标题：{t}")
            L.append("")
        L.append("**④ 内容倾向**（标题里出现的信号词，反映这个品类的内容生态）")
        L.append("")
        if r["signals"]:
            L.append("| 内容类型 | 命中次数 | 命中词 |")
            L.append("|---|---|---|")
            for name, cnt in r["signals"].most_common():
                words = "、".join(sorted(set(r["signal_words"].get(name, []))))
                L.append(f"| {name} | {cnt} | {words} |")
            L.append("")
            top = r["signals"].most_common(1)[0][0]
            tips = {
                "教程做法": "用户缺方案 → 卖**组合装/半成品**比卖单品更有说服力",
                "测评对比": "用户在做比较决策 → 必须有明确差异点，否则被比下去",
                "避雷负面": "⚠️ 品类已有负面口碑 → 先解决品质/体验问题再谈卖点",
                "种草推荐": "内容生态偏种草 → KOC 铺量比硬广有效",
                "价格促销": "价格敏感 → 定价与规格要能对标",
                "场景季节": "有明确使用场景 → 按场景做套装与文案",
                "健康诉求": "健康是关注点 → 配料表干净是可传播卖点",
                "B端批发": "存在 B 端需求 → 可考虑小 B 供货",
            }
            L.append(f"**判读**：主导内容是「{top}」。{tips.get(top, '')}")
            L.append("")
        else:
            L.append("- 未命中信号词（语料太少或标题中性）")
            L.append("")
        if r["crossref"]:
            L.append("**⑤ 学术/行业侧**（Crossref，英文检索）")
            L.append("")
            for t in r["crossref"][:3]: L.append(f"- {t}")
            L.append("")
        else:
            L.append("**⑤ 学术/行业侧**：未提供英文关键词，跳过（中文检索 Crossref 结果不相关，已禁用）")
            L.append("")
        hot_hits = [b for b, arr in boards.items() for t in arr if kw[:2] in t]
        L.append(f"**⑥ 热榜旁证**：{len(hot_hits)} 条（热榜命中率极低，仅作旁证）")
        L.append("")

    L.append("## 免费方案的能力边界（务必看）")
    L.append("")
    L.append("| 想要的数据 | 免费能拿到吗 | 说明 |")
    L.append("|---|---|---|")
    L.append("| 消费者在问什么 | ✅ 能 | 百度联想词，意图可直接读 |")
    L.append("| 有多少人在讨论 | ⚠️ 相对 | 公众号/搜索条数，只能比多少，不是绝对值 |")
    L.append("| 内容在讲什么 | ✅ 能 | 标题 + 高频词，可看表达习惯 |")
    L.append("| 在售商品 | ⚠️ 粗略 | 苏宁结果页命中数，不是 SKU 数 |")
    L.append("| 真实售价 / 销量 / 竞品价格 | ❌ 不能 | 电商接口全部需登录或反爬 |")
    L.append("| 小红书笔记与评论 | ❌ 不能 | SocialDataX 余额 0；网页端需登录 |")
    L.append("")
    L.append("## 怎么把免费方案用到最强")
    L.append("")
    L.append("1. **每个候选都跑一遍**：把 `--kw` 换成候选名，看意图结构差异（做法多=教育型新品，比价多=红海）")
    L.append("2. **用高频词写文案**：标题里反复出现的说法就是用户原话，比你自己编的卖点更准")
    L.append("3. **拿不到的数据不要编**：售价/销量/竞品价在 `score.py` 里留空并标「人工调研」")
    L.append("4. **热榜只做旁证**：命中率低于 1%，排在最后看")
    L.append("5. **每周固定跑**：免费源结构会变，变异了立刻能看出来")
    md = "\n".join(L) + "\n"
    os.makedirs(a.out, exist_ok=True)
    p = os.path.join(a.out, f"{today}-免费选品雷达.md")
    open(p, "w", encoding="utf-8").write(md)
    json.dump(all_res, open(os.path.join(a.out, f"{today}-免费选品雷达.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(md[:1200]); print("...\nMD=" + p)

if __name__ == "__main__":
    main()
