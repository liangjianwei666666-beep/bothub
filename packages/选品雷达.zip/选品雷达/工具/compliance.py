#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""食品广告合规预检：绝对化用语、功效宣称、食品特有限制、敏感表述。零依赖。
用法:
  python3 compliance.py 文案.txt
  python3 compliance.py "我们的火锅底料是最好吃的，还能降血压"
  echo "文案" | python3 compliance.py -
输出: 命中清单（原文位置 + 风险类型 + 建议改法）+ 总判。
边界: 这是预检不是法律意见；最终以广告法、食品安全法与平台规则为准。
"""
import json, re, sys, os

# 依据《广告法》第九条（绝对化用语等禁止情形）与食品广告常见违规表述整理
RULES = [
    ("绝对化用语", ["最好", "最佳", "最强", "最优", "最先进", "最便宜", "最高级", "第一", "No.1", "NO.1",
                    "顶级", "极品", "国家级", "世界级", "唯一", "独家", "史无前例", "绝无仅有", "万能"]),
    ("功效宣称(医疗)", ["治疗", "治愈", "疗效", "根治", "药效", "消炎", "降血压", "降血糖", "降血脂",
                        "防癌", "抗癌", "增强免疫力", "提高免疫力", "壮阳", "丰胸", "减肥特效"]),
    ("保健功能暗示", ["保健", "养生功效", "延年益寿", "排毒", "祛湿", "调理身体", "补气养血"]),
    ("虚假时效/稀缺", ["全网最低", "史上最低", "限时唯一", "仅此一次", "最后一次", "永不再有", "错过再无"]),
    ("对比贬低", ["比同行好", "比其他品牌好", "比别家好", "吊打", "碾压", "秒杀一切", "完爆", "吊锤", "好太多"]),
    ("食品安全敏感", ["零添加", "无添加", "纯天然", "绿色食品", "有机", "无公害", "非转基因"]),
]
# 「零添加/纯天然/有机」等并非一律禁止，但没有认证或不符合标准时属于虚假宣传 → 单独提示
CONDITIONAL = {"零添加", "无添加", "纯天然", "绿色食品", "有机", "无公害", "非转基因"}
# 未成年人/疾病相关，一律加重提示
HEAVY = ["儿童", "婴幼儿", "孕妇", "病人", "三高", "糖尿病"]

def scan(text):
    hits = []
    for kind, words in RULES:
        for w in words:
            for m in re.finditer(re.escape(w), text):
                hits.append({"kind": kind, "word": w, "pos": m.start(),
                             "context": text[max(0, m.start() - 12): m.start() + len(w) + 12],
                             "conditional": w in CONDITIONAL})
    for w in HEAVY:
        if w in text:
            hits.append({"kind": "特殊人群提及", "word": w, "pos": text.find(w),
                         "context": text[max(0, text.find(w) - 12): text.find(w) + len(w) + 12],
                         "conditional": False})
    hits.sort(key=lambda x: x["pos"])
    return hits

SUGGEST = {
    "绝对化用语": "删掉或改为可验证表述（如「2026 年冬季销量领先」需有依据）",
    "功效宣称(医疗)": "食品不得宣称疾病治疗或保健功能，整句删除",
    "保健功能暗示": "删掉功效暗示，只描述口味、原料、做法",
    "虚假时效/稀缺": "去掉极端稀缺表述，改成真实的促销周期",
    "对比贬低": "改为自我描述，不做同业比较",
    "食品安全敏感": "无认证不得使用；有认证须标明证书编号与适用范围",
    "特殊人群提及": "涉及未成年人/孕妇/病人需格外谨慎，建议删除或加限定",
}

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(2)
    src = sys.argv[1]
    text = sys.stdin.read() if src == "-" else (open(src, encoding="utf-8").read() if os.path.exists(src) else src)
    hits = scan(text)
    print(f"文案长度 {len(text)} 字，命中 {len(hits)} 处\n")
    if not hits:
        print("✅ 未命中本规则库。注意：这不等于合规，本工具只覆盖常见违规表述。")
        sys.exit(0)
    for h in hits:
        flag = " ⚠️条件性用语(需认证)" if h["conditional"] else ""
        print(f"[{h['kind']}]{flag} 「{h['word']}」 @{h['pos']}")
        print(f"    上下文：…{h['context']}…")
        print(f"    建议：{SUGGEST.get(h['kind'], '人工复核')}")
    kinds = {}
    for h in hits: kinds[h["kind"]] = kinds.get(h["kind"], 0) + 1
    print("\n汇总：" + "、".join(f"{k} {v} 处" for k, v in kinds.items()))
    print("判定：❌ 建议修改后再发布")
    print("\n> 预检依据常见广告合规规则整理，不构成法律意见；以《广告法》《食品安全法》与平台规则为准。")
    sys.exit(1)

if __name__ == "__main__":
    main()
