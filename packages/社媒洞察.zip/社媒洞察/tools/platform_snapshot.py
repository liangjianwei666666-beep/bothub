#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""计费路径：通过 SocialDataX 抓取，产出与 A 轨同构的标准快照（source=platform）。

两条铁律：
  1. 花钱前先说清预估。不带 --yes 只做估算，不发请求。
  2. 失败就是失败。余额不足/鉴权失败不重试、不编数据，直接停下给可执行的下一步。

用法：
  python3 platform_snapshot.py --keyword "AI学习机"                 # 只估算，不花钱
  python3 platform_snapshot.py --keyword "AI学习机" --pages 1 --max-items 20 --yes
  python3 platform_snapshot.py --keyword "学科AI助手" --platform douyin --yes

计费口径（官方）：基础数据 10 积分/条，列表搜索约 10 积分/页，视频转文字 10 积分/分钟；1 积分 = 0.01 元。
"""
import argparse, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from snapshot import build_snapshot, save_snapshot, normalize_items  # noqa: E402

POINTS_PER_ITEM = 10
POINTS_PER_PAGE = 10
CNY_PER_POINT = 0.01
BILLING_URL = "https://socialdatax.com/dashboard/billing"
SUPPORTED = ["xhs", "douyin", "weibo", "bilibili", "zhihu", "wechat", "x", "youtube",
             "tiktok", "instagram", "kuaishou", "toutiao"]
PLATFORM_CN = {"xhs": "小红书", "douyin": "抖音", "weibo": "微博", "bilibili": "B站", "zhihu": "知乎",
               "wechat": "视频号", "x": "X", "youtube": "YouTube", "tiktok": "TikTok",
               "instagram": "Instagram", "kuaishou": "快手", "toutiao": "头条"}


def estimate(pages, max_items):
    points = pages * POINTS_PER_PAGE + max_items * POINTS_PER_ITEM
    return points, round(points * CNY_PER_POINT, 2)


def run(args, timeout=180, env=None):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=env)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"


def classify_failure(text):
    t = (text or "").lower()
    if "insufficient_balance" in t or "积分不足" in (text or "") or "insufficient balance" in t:
        return ("余额不足", "账户积分不够，这次没有拿到任何数据。去充值后重跑同一条命令：\n  " + BILLING_URL)
    if "invalid" in t and "key" in t or "unauthorized" in t or "401" in t:
        return ("Key 无效", "API Key 鉴权失败。检查 SOCIALDATAX_API_KEY 环境变量是否有效。")
    if "timeout" in t:
        return ("超时", "请求超时，已停止，不会自动重试。网络恢复后重跑同一条命令。")
    return ("调用失败", "原始报错：\n  " + (text or "").strip()[:600])


def main():
    ap = argparse.ArgumentParser(description="计费路径快照（SocialDataX）")
    ap.add_argument("--keyword", required=True)
    ap.add_argument("--platform", default="xhs", choices=SUPPORTED)
    ap.add_argument("--pages", type=int, default=1, help="翻几页（默认 1，别一上来就 5）")
    ap.add_argument("--max-items", type=int, default=20, help="条数（默认 20，先小样本）")
    ap.add_argument("--yes", action="store_true", help="确认花钱并真的发请求；不带只估算")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(HERE), "snapshots"))
    a = ap.parse_args()

    points, cny = estimate(a.pages, a.max_items)
    print("预估花费：%d 积分 ≈ ¥%.2f（%d 页搜索 + %d 条数据）" % (points, cny, a.pages, a.max_items))
    print("平台：%s ｜ 关键词：%s" % (PLATFORM_CN[a.platform], a.keyword))
    if not a.yes:
        print("\n这是估算，没有花钱。确认后在同一条命令末尾加 --yes。")
        return

    key = os.environ.get("SOCIALDATAX_API_KEY") or os.environ.get("DSH_SECRET_SOCIALDATAX_API_KEY")
    if not key:
        print("\n[停下] 没找到 SOCIALDATAX_API_KEY 环境变量，没发请求、没花钱。", file=sys.stderr)
        sys.exit(2)
    env = dict(os.environ, SOCIALDATAX_API_KEY=key, PATH=os.path.expanduser("~/.local/bin") + ":" + os.environ.get("PATH", ""))

    cmd = ["bunx", "socialdatax-skills@latest", a.platform, "search",
           "--keyword", a.keyword, "--max-items", str(a.max_items), "--pretty",
           "--source-client", "socialdatax-skills", "--source-platform", "npm",
           "--source-skill", "media-search"]
    print("\n发起请求…（失败不会重试）")
    rc, out, err = run(cmd, timeout=240, env=env)
    if rc != 0 or not out.strip():
        kind, advice = classify_failure(err or out)
        print("\n[%s] %s" % (kind, advice), file=sys.stderr)
        sys.exit(3)

    raw = out.strip()
    try:
        d = json.loads(raw)
    except json.JSONDecodeError:
        start = raw.find("{")
        if start == -1:
            kind, advice = classify_failure(raw)
            print("\n[%s] %s" % (kind, advice), file=sys.stderr)
            sys.exit(3)
        try:
            d = json.loads(raw[start:])
        except Exception:
            print("\n[解析失败] 返回内容不是 JSON，没写入快照。原始内容前 500 字：\n" + raw[:500], file=sys.stderr)
            sys.exit(3)

    items = [i for i in normalize_items(d) if i.get("title") or i.get("link")]
    if not items:
        kind, advice = classify_failure(raw)
        print("\n[没有数据] %s" % advice, file=sys.stderr)
        sys.exit(3)

    snap = build_snapshot(
        items, "platform", PLATFORM_CN[a.platform], a.keyword,
        collector="socialdatax/media-search",
        params={"platform_cmd": a.platform, "pages": a.pages, "max_items": a.max_items},
        cost_cny=cny,
        limits=["第三方口径，与平台前台展示可能有差异",
                "条数受 max-items/pages 限制，不是平台全量"],
    )
    path = save_snapshot(snap, a.out)
    s = snap["stats"]
    print("✅ %d 条，点赞中位 %s，最高 %s，花费 ¥%.2f → %s" % (
        s["count"], s.get("like_median"), s.get("like_max"), cny, path))


if __name__ == "__main__":
    main()
