#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""快照工具：统一格式 / 统计 / 两次快照对比。

标准快照格式 sig-snapshot/1：
{
  "schema": "sig-snapshot/1",
  "source": "browser" | "platform",     # browser = 0 元浏览器读取；platform = 数据平台接口
  "source_label": "浏览器读取（0 元）",
  "platform": "小红书",
  "keyword": "AI学习机",
  "captured_at": "2026-11-03T22:27:44+08:00",
  "collector": "bsk/xhs-search",
  "params": {"max_items": 30, "scrolled": false},
  "cost_cny": 0.0,
  "items": [{"title": "...", "author": "...", "like": "1.3万", "like_num": 13000, "link": "..."}],
  "stats": {"count": 30, "like_median": 1, "like_mean": 1, "like_max": 1, "like_min": 1},
  "limits": ["只覆盖首屏", "..."]
}

用法：
  python3 snapshot.py stats 快照.json
  python3 snapshot.py diff 早.json 晚.json
  python3 snapshot.py convert 原始.json --source browser --platform 小红书 --keyword 词 --out 输出.json
"""
import json, sys, argparse, os, datetime, statistics

SCHEMA = "sig-snapshot/1"
SOURCE_LABEL = {"browser": "浏览器读取（0 元）", "platform": "数据平台接口（计费）"}


def to_num(v):
    """把 '1.3万' '2805' '10万+' '1,234' None 统一成整数。解析不了返回 None。"""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).strip().replace(",", "").replace(" ", "")
    if not s or s in ("-", "—", "暂无"):
        return None
    if s.endswith("+"):
        s = s[:-1]
    mult = 1
    if s.endswith("万") or s.endswith("w") or s.endswith("W"):
        mult = 10000
        s = s[:-1]
    elif s.endswith("亿"):
        mult = 100000000
        s = s[:-1]
    try:
        return int(round(float(s) * mult))
    except ValueError:
        return None


def _first(d, keys, default=None):
    for k in keys:
        if isinstance(d, dict) and d.get(k) not in (None, ""):
            return d[k]
    return default


def normalize_item(it):
    """兼容三种来源：标准快照 item / bsk extract row / SocialDataX item。"""
    title = _first(it, ["title", "desc", "content", "note_title"]) or ""
    author = _first(it, ["author", "nickname", "user_name", "author_name"]) or ""
    if isinstance(author, dict):
        author = author.get("nickname") or author.get("name") or ""
    like = _first(it, ["like", "liked_count", "like_count", "digg_count", "likes", "fav_count"])
    comment = _first(it, ["comment", "comment_count", "comments_count"])
    link = _first(it, ["link", "url", "note_url", "share_url", "share_link"]) or ""
    return {
        "title": str(title).strip(),
        "author": str(author).strip(),
        "like": like,
        "like_num": to_num(like),
        "comment": comment,
        "comment_num": to_num(comment),
        "link": str(link),
    }


def normalize_items(raw):
    if isinstance(raw, dict):
        for path in (("items",), ("rows",), ("data", "items"), ("data", "notes"), ("data", "list")):
            cur = raw
            for p in path:
                cur = cur.get(p) if isinstance(cur, dict) else None
            if isinstance(cur, list) and cur:
                raw = cur
                break
        else:
            raise SystemExit("这个 JSON 里找不到 items / rows / data.items，无法识别")
    return [normalize_item(x) for x in raw if isinstance(x, dict)]


def local_iso(ts):
    """把 '...Z' / 带偏移的 ISO 时间统一成本机时区，避免 diff 里 UTC 和本地混着显示。"""
    if not ts:
        return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    try:
        t = str(ts).strip().replace("Z", "+00:00")
        d = datetime.datetime.fromisoformat(t[:26]) if "." in t else datetime.datetime.fromisoformat(t)
        if d.tzinfo is None:
            d = d.replace(tzinfo=datetime.timezone.utc)
        return d.astimezone().isoformat(timespec="seconds")
    except Exception:
        return str(ts)


def build_snapshot(items, source, platform, keyword, captured_at=None, collector="", params=None,
                   cost_cny=None, limits=None):
    nums = [i["like_num"] for i in items if i.get("like_num") is not None]
    stats = {"count": len(items)}
    if nums:
        stats.update({
            "like_median": statistics.median(nums),
            "like_mean": round(statistics.mean(nums), 1),
            "like_max": max(nums),
            "like_min": min(nums),
            "like_sum": sum(nums),
        })
    if cost_cny is None:
        cost_cny = 0.0 if source == "browser" else None
    return {
        "schema": SCHEMA,
        "source": source,
        "source_label": SOURCE_LABEL.get(source, source),
        "platform": platform,
        "keyword": keyword,
        "captured_at": local_iso(captured_at),
        "collector": collector,
        "params": params or {},
        "cost_cny": cost_cny,
        "items": items,
        "stats": stats,
        "limits": limits or [],
    }


def load_snapshot(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    if d.get("schema") == SCHEMA:
        return d
    # 兼容别人直接扔过来的原始抓取结果
    items = normalize_items(d)
    d2 = build_snapshot(items, "browser", d.get("platform", "未标注"), d.get("keyword", "未标注"),
                        collector="import/" + os.path.basename(path))
    return d2


def save_snapshot(snap, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    safe = "".join(c for c in snap["keyword"] if c not in '\\/:*?"<>|').strip() or "未命名"
    stamp = snap["captured_at"].replace(":", "").replace("-", "")[:15]
    path = os.path.join(out_dir, "snap_%s_%s_%s.json" % (snap["source"], safe, stamp))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(snap, f, ensure_ascii=False, indent=2)
    return path


def fmt_stats(snap):
    s = snap["stats"]
    head = "%s · %s · %s ｜ 来源：%s ｜ %s" % (
        snap["platform"], snap["keyword"], snap.get("captured_at", ""),
        snap.get("source_label") or snap.get("source"), snap["collector"])
    if "like_median" in s:
        body = ("有效条数 %d ｜ 点赞中位 %s ｜ 均值 %s ｜ 最高 %s ｜ 最低 %s" % (
            s["count"], s["like_median"], s["like_mean"], s["like_max"], s["like_min"]))
    else:
        body = "条数 %d（没有可解析的点赞数）" % s["count"]
    return head + "\n" + body


def diff_markdown(a, b):
    if a["keyword"] != b["keyword"]:
        return "两个快照关键词不同（%s / %s），不能直接比。" % (a["keyword"], b["keyword"])
    if a["platform"] != b["platform"]:
        return "两个快照平台不同，不能直接比。"
    sa, sb = a["stats"], b["stats"]
    rows = []
    warn = []
    if a.get("source") != b.get("source"):
        warn.append("⚠ 两次快照来源不同（%s → %s）：数据口径可能不一致，变化不能全归因于平台表现。"
                    % (a.get("source_label"), b.get("source_label")))

    def line(name, x, y):
        if x is None or y is None:
            rows.append("| %s | %s | %s | — |" % (name, x if x is not None else "—", y if y is not None else "—"))
            return
        d = y - x
        p = ("%+.0f%%" % ((y - x) / x * 100)) if x else "—"
        rows.append("| %s | %s | %s | %+g（%s） |" % (name, x, y, d, p))

    line("返回条数", sa.get("count"), sb.get("count"))
    line("点赞中位数", sa.get("like_median"), sb.get("like_median"))
    line("点赞均值", sa.get("like_mean"), sb.get("like_mean"))
    line("点赞最高", sa.get("like_max"), sb.get("like_max"))
    out = []
    if warn:
        out.extend(warn + [""])
    out.append("**%s · %s：%s → %s**" % (a["platform"], a["keyword"], a["captured_at"][:16], b["captured_at"][:16]))
    out.append("")
    out.append("| 指标 | 早 | 晚 | 变化 |")
    out.append("|---|---|---|---|")
    out.extend(rows)
    out.append("")
    # 同题内容重叠度，辅助判断「是不是同一批内容被重新排序」
    ta = {i["title"] for i in a["items"] if i.get("title")}
    tb = {i["title"] for i in b["items"] if i.get("title")}
    if ta and tb:
        overlap = len(ta & tb)
        out.append("两次快照的标题重叠：%d 篇（早 %d / 晚 %d）。重叠高说明还是同一批内容，条数变化更可能是排序或返回量差异。" % (overlap, len(ta), len(tb)))
    out.append("")
    out.append("口径提醒：条数受检索上限影响；点赞中位数比均值抗爆款；单次快照不能证明趋势，两次才有方向。")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="快照统计与对比")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("stats"); p1.add_argument("file")
    p2 = sub.add_parser("diff"); p2.add_argument("a"); p2.add_argument("b")
    p3 = sub.add_parser("convert")
    p3.add_argument("file"); p3.add_argument("--source", default="browser", choices=["browser", "platform"])
    p3.add_argument("--platform", default="未标注"); p3.add_argument("--keyword", default="未标注")
    p3.add_argument("--out", default="snapshots")
    a = ap.parse_args()
    if a.cmd == "stats":
        print(fmt_stats(load_snapshot(a.file)))
    elif a.cmd == "diff":
        print(diff_markdown(load_snapshot(a.a), load_snapshot(a.b)))
    elif a.cmd == "convert":
        with open(a.file, encoding="utf-8") as f:
            raw = json.load(f)
        items = [i for i in normalize_items(raw) if i.get("title") or i.get("link")]
        snap = build_snapshot(items, a.source, a.platform, a.keyword, collector="import/" + os.path.basename(a.file))
        print("写入：", save_snapshot(snap, a.out))


if __name__ == "__main__":
    main()
