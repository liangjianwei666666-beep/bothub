#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""0 元路径：用使用者自己的浏览器读小红书搜索结果，产出标准快照。

前提（每人一次）：
  1. Edge/Chrome 开着，BrowserSkill 扩展已装并连上（bsk doctor 显示 extension connected 1 browser）
  2. 使用者已经在小红书网页端登录（登录态是数据权限来源，本工具不碰账号密码）

用法：
  python3 xhs_browser_snapshot.py --keyword "AI学习机"                     # 跑一个词
  python3 xhs_browser_snapshot.py --keyword "学科AI助手" --keyword "语数英AI提效"
  python3 xhs_browser_snapshot.py --keyword "AI学习机" --browser 3c3be1f9   # 多浏览器时指定
  python3 xhs_browser_snapshot.py --keyword "AI学习机" --max-items 60       # 最多滚两屏

花费：0 元。只读页面，不登录、不发布、不点赞、不评论。
"""
import argparse, json, os, subprocess, sys, time, urllib.parse

BSK = os.path.expanduser("~/.local/bin/bsk")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from snapshot import build_snapshot, save_snapshot, normalize_items  # noqa: E402

FIELDS = json.dumps({"fields": [
    {"key": "title", "name": "标题", "selector": ".footer .title span", "read": "text"},
    {"key": "author", "name": "作者", "selector": ".author .name", "read": "text"},
    {"key": "like", "name": "点赞", "selector": ".like-wrapper .count", "read": "text"},
    {"key": "link", "name": "链接", "selector": "a.cover", "read": "href"},
]}, ensure_ascii=False)

SEARCH_URL = "https://www.xiaohongshu.com/search_result?keyword=%s&source=web_explore_feed"


def run(args, timeout=120):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"


def die(msg, code=2):
    print("\n[停下] " + msg, file=sys.stderr)
    sys.exit(code)


def preflight():
    rc, out, err = run([BSK, "browsers"], timeout=30)
    if rc != 0:
        die("bsk 命令跑不起来（%s）。先确认 BrowserSkill 已安装：见《安装说明-0元浏览器版.md》。" % err.strip()[:120])
    if "edge" not in out.lower() and "chrome" not in out.lower():
        die("没有连上浏览器。请把 Edge（或 Chrome）打开，确认 BrowserSkill 扩展已启用，再重跑。\n"
            "自检：bsk doctor 应显示 extension connected 1 browser。")
    return out


def start_session(browser=None):
    args = [BSK, "session", "start", "--json"]
    if browser:
        args += ["--browser", browser]
    rc, out, err = run(args, timeout=60)
    if rc != 0:
        die("开不了浏览器会话：%s" % err.strip()[:200])
    try:
        return json.loads(out)["session_id"]
    except Exception:
        die("会话启动返回看不懂：%s" % out[:200])


def open_search(ses, url):
    rc, out, err = run([BSK, "tab", "create", "--session", ses, "--url", url, "--json"], timeout=60)
    if rc != 0:
        die("开不了标签页：%s" % err.strip()[:200])


def sync(ses, tries=4):
    last = ""
    for _ in range(tries):
        rc, out, err = run([BSK, "cooperate", "--session", ses, "sync"], timeout=60)
        if rc == 0:
            d = json.loads(out)
            return d["context_id"], d["observation_id"]
        last = err.strip()[:160]
        time.sleep(2)
    die("页面控制权同步失败：%s\n提示：把 Agent Window 里的小红书页面等它加载完，再重跑。" % last)


def goto(ses, url):
    ctx, obs = sync(ses)
    rc, out, err = run([BSK, "navigate", "--session", ses, "--context", ctx, "--observation", obs,
                        "--wait-until", "domcontentloaded", "--timeout", "45s", url], timeout=90)
    if rc != 0:
        die("跳转搜索页失败：%s" % err.strip()[:200])


def scroll(ses, times=1):
    for _ in range(times):
        ctx, obs = sync(ses)
        run([BSK, "wheel", "--session", ses, "--context", ctx, "--observation", obs, "--delta-y", "2400"], timeout=60)
        time.sleep(2.5)


def extract(ses, outfile):
    for attempt in range(3):
        ctx, obs = sync(ses)
        rc, out, err = run([BSK, "extract", "list", "--session", ses, "--context", ctx, "--observation", obs,
                            "--selector", "div.feeds-container", "--item-selector", "section.note-item",
                            "--fields-json", FIELDS, "--out", outfile, "--overwrite", "--json"], timeout=120)
        if rc == 0 and os.path.exists(outfile):
            return json.load(open(outfile, encoding="utf-8"))
        time.sleep(2)
    die("抓取失败：页面可能没加载完，或小红书改了页面结构。把窗口里的小红书页面刷新一次再跑。")


def main():
    ap = argparse.ArgumentParser(description="0 元浏览器快照（小红书）")
    ap.add_argument("--keyword", action="append", required=True, help="关键词，可重复")
    ap.add_argument("--browser", default=None, help="浏览器实例 ID（bsk browsers 可查）")
    ap.add_argument("--max-items", type=int, default=30, help="目标条数，超过一屏会滚动加载（默认 30）")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(HERE), "snapshots"))
    ap.add_argument("--keep-session", action="store_true", help="跑完不关浏览器窗口")
    a = ap.parse_args()

    preflight()
    ses = start_session(a.browser)
    print("会话：%s（0 元，只读页面）" % ses)
    results = []
    tmp = os.path.join("/tmp", "bsk_extract_%s.json" % ses)
    try:
        for idx, kw in enumerate(a.keyword):
            url = SEARCH_URL % urllib.parse.quote(kw)
            if idx == 0:
                open_search(ses, url)
            else:
                goto(ses, url)
            time.sleep(6)
            pages = 1
            d = extract(ses, tmp)
            rows = d.get("rows", [])
            while len(rows) < a.max_items and pages < 4:
                scroll(ses)
                pages += 1
                d2 = extract(ses, tmp)
                if len(d2.get("rows", [])) <= len(rows):
                    break
                d, rows = d2, d2.get("rows", [])
            items = [i for i in normalize_items(rows) if i.get("title") or i.get("link")]
            if not items:
                print("[空结果] %s：页面没有抓到笔记。可能未登录，或平台改版。先打开 Agent Window 看一眼。" % kw)
                continue
            snap = build_snapshot(
                items, "browser", "小红书", kw,
                captured_at=d["source"]["captured_at"],
                collector="bsk/xhs-search",
                params={"session": ses, "url": url, "scrolled": pages > 1, "pages_loaded": pages,
                        "max_items_target": a.max_items, "rows_seen": len(rows)},
                cost_cny=0.0,
                limits=["只覆盖浏览器当前可见与滚动加载的部分，不是平台全量",
                        "顺序是平台此刻的排序，隔天复跑内容集可能变化",
                        "未抓评论；人群判断需要单独抓评论区"],
            )
            path = save_snapshot(snap, a.out)
            results.append((kw, path, snap["stats"]))
            s = snap["stats"]
            print("✅ %s：%d 条，点赞中位 %s，最高 %s → %s" % (
                kw, s["count"], s.get("like_median"), s.get("like_max"), path))
    finally:
        if not a.keep_session:
            run([BSK, "session", "stop", ses], timeout=30)

    if not results:
        die("一个词都没抓到。", 3)
    print("\n下一步：python3 snapshot.py diff 早.json 晚.json 做两次对比")


if __name__ == "__main__":
    main()
