#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""抖音视频口播文案提取（0 元）：抓音轨 → faster-whisper 转文字。

前提：本机 Edge/Chrome 已登录抖音，BrowserSkill 扩展连上。
成本：0 元（本地 ASR，不上传第三方）。

用法：
  python3 douyin_transcript.py --vid 7698320794799181106
  python3 douyin_transcript.py --vids-file ids.txt --model small
  python3 douyin_transcript.py --vid xxx --session lsau      # 复用已开会话

输出：transcripts/dy_<vid>.json + transcripts/文案汇总.md
注意：ASR 会有同音字错误（田埂→田边龙起、庄稼→桩架），原文与校订必须分开写。
"""
import argparse, json, os, re, subprocess, sys, time, datetime

BSK = os.path.expanduser("~/.local/bin/bsk")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "transcripts")
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0")


def run(args, timeout=180, capture=True):
    try:
        p = subprocess.run(args, capture_output=capture, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"


def sh(cmd, timeout=180):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"


def sync(ses):
    rc, out, err = run([BSK, "cooperate", "--session", ses, "sync"], timeout=60)
    if rc != 0:
        raise RuntimeError("会话同步失败（可能已超时关闭）：" + err.strip()[:150])
    d = json.loads(out)
    return d["context_id"], d["observation_id"]


def page_title(ses):
    rc, out, err = run([BSK, "observe", "--session", ses, "--json"], timeout=60)
    try:
        t = json.loads(out).get("text", "")
        m = re.search(r'RootWebArea "([^"]{2,120})"', t)
        return m.group(1) if m else ""
    except Exception:
        return ""


def navigate_retry(ses, vid, tries=4):
    """抖音页面一直在刷新，控制权校验会拦跳转；用重试换一次干净的同步。"""
    url = "https://www.douyin.com/video/%s" % vid
    last = ""
    for _ in range(tries):
        try:
            ctx, obs = sync(ses)
            rc, out, err = run([BSK, "navigate", "--session", ses, "--context", ctx, "--observation", obs,
                                "--wait-until", "domcontentloaded", "--timeout", "45s", url], timeout=90)
            if rc == 0:
                return True, ""
            last = (err or out).strip()[:120]
        except Exception as e:
            last = str(e)[:120]
        time.sleep(2)
    return False, last


def ensure_capture(ses):
    rc, out, err = run([BSK, "debug", "start", "--session", ses, "--name", "dy_transcript", "--json"], timeout=60)
    if rc != 0:
        raise RuntimeError("抓包启动失败：" + err.strip()[:150])
    return json.loads(out)["run"]["id"]


def cursor(ses, rid):
    rc, out, err = run([BSK, "debug", "status", "--session", ses, "--run-id", rid, "--json"], timeout=60)
    try:
        return json.loads(out)["run"].get("next_since", 0)
    except Exception:
        return 0


def media_since(ses, rid, since):
    rc, out, err = run([BSK, "debug", "requests", "--session", ses, "--run-id", rid,
                        "--since", str(since), "--json"], timeout=90)
    try:
        d = json.loads(out)
    except Exception:
        return [], since
    rs = d.get("requests") or []
    audio = [r["url"] for r in rs if "douyinvod.com" in (r.get("url") or "") and "audio" in r["url"]]
    if not audio:
        audio = [r["url"] for r in rs if "douyinvod.com" in (r.get("url") or "")]
    return audio, d.get("next_since", since)


def grab_audio_url(ses, vid, rid):
    """跳到视频页，用抓包游标只取这次新增的媒体请求。"""
    base = cursor(ses, rid)
    ok, why = navigate_retry(ses, vid)
    if not ok:
        raise RuntimeError("页面跳转失败：" + why)
    time.sleep(6)
    audio, base = media_since(ses, rid, base)
    if not audio:
        # 再触发一次加载
        for _ in range(2):
            try:
                ctx, obs = sync(ses)
                run([BSK, "reload", "--session", ses, "--context", ctx, "--observation", obs], timeout=90)
            except Exception:
                pass
            time.sleep(7)
            audio, base = media_since(ses, rid, base)
            if audio:
                break
    if not audio:
        raise RuntimeError("没抓到音轨（页面可能没加载或换了结构）")
    return audio[0], page_title(ses)


def download(url, path):
    cmd = ("curl -s -m 120 -o %s -H %s -H %s %s" % (
        sh_quote(path),
        sh_quote("User-Agent: " + UA),
        sh_quote("Referer: https://www.douyin.com/"),
        sh_quote(url)))
    rc, out, err = sh(cmd, timeout=150)
    return rc == 0 and os.path.exists(path) and os.path.getsize(path) > 10000


def sh_quote(s):
    return "'" + str(s).replace("'", "'\\''") + "'"


def main():
    ap = argparse.ArgumentParser(description="抖音口播文案提取（本地 ASR，0 元）")
    ap.add_argument("--vid", action="append", default=[], help="视频 ID，可重复")
    ap.add_argument("--vids-file", help="每行一个视频 ID")
    ap.add_argument("--session", default=None, help="复用已有会话；不填则自己开一个")
    ap.add_argument("--model", default="small", help="whisper 模型：tiny/base/small/medium")
    ap.add_argument("--out", default=OUT)
    a = ap.parse_args()

    vids = list(a.vid)
    if a.vids_file:
        vids += [l.strip() for l in open(a.vids_file, encoding="utf-8") if l.strip() and not l.startswith("#")]
    vids = [v for v in dict.fromkeys(vids) if v]
    if not vids:
        print("没有给视频 ID。用 --vid 或 --vids-file。", file=sys.stderr)
        sys.exit(2)
    os.makedirs(a.out, exist_ok=True)

    ses, own = a.session, False
    if not ses:
        rc, out, err = run([BSK, "session", "start", "--json"], timeout=60)
        if rc != 0:
            print("[停下] 开不了浏览器会话：%s\n先把 Edge 打开并确认扩展已连上（bsk doctor）。" % err.strip()[:150], file=sys.stderr)
            sys.exit(2)
        ses = json.loads(out)["session_id"]
        own = True
        print("会话：%s（复用浏览器里的抖音登录态）" % ses)

    from faster_whisper import WhisperModel
    model = WhisperModel(a.model, device="cpu", compute_type="int8")

    rid = ensure_capture(ses)
    rows, failed = [], []
    try:
        for i, vid in enumerate(vids, 1):
            dst = os.path.join(a.out, "dy_%s.json" % vid)
            if os.path.exists(dst):
                d = json.load(open(dst, encoding="utf-8"))
                rows.append(d); print("[%d/%d] %s 已有，跳过" % (i, len(vids), vid)); continue
            try:
                url, title = grab_audio_url(ses, vid, rid)
                if not url:
                    raise RuntimeError("没抓到音轨（页面可能没加载或换了结构）")
                audio = "/tmp/dy_%s.m4a" % vid
                if not download(url, audio):
                    raise RuntimeError("音轨下载失败")
                segs, info = model.transcribe(audio, language="zh", vad_filter=True, beam_size=5)
                text = "".join(s.text for s in segs).strip()
                if not text:
                    raise RuntimeError("转写结果为空（可能无旁白）")
                d = {
                    "vid": vid, "title": title, "duration_sec": round(info.duration, 1),
                    "model": a.model, "text_raw": text,
                    "segments": [{"s": round(s.start, 2), "e": round(s.end, 2), "t": s.text.strip()} for s in segs],
                    "captured_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
                    "method": "douyin audio track + faster-whisper（本地）",
                    "caveat": "ASR 原始输出，未校订；同音字会有错",
                }
                json.dump(d, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
                rows.append(d)
                print("[%d/%d] ✅ %s %.0fs %s" % (i, len(vids), vid, info.duration, text[:40]))
            except Exception as e:
                failed.append((vid, str(e)[:160]))
                print("[%d/%d] ❌ %s %s" % (i, len(vids), vid, str(e)[:120]))
    finally:
        if own:
            run([BSK, "session", "stop", ses], timeout=30)

    if rows:
        md = os.path.join(a.out, "文案汇总.md")
        with open(md, "w", encoding="utf-8") as f:
            f.write("# 抖音口播文案（ASR 原始输出）\n\n")
            f.write("模型：%s ｜ 条数：%d ｜ 生成：%s\n\n" % (a.model, len(rows), datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
            f.write("> 这是机器转写原文，同音字有错（例：田埂→田边龙起、庄稼→桩架）。引用前必须人工校订。\n\n")
            for d in rows:
                f.write("## %s\n\n" % (d.get("title") or d["vid"]))
                f.write("- 视频 ID：%s ｜ 时长：%ss\n\n" % (d["vid"], d.get("duration_sec")))
                f.write(d["text_raw"] + "\n\n")
        print("\n汇总：%s" % md)
    if failed:
        print("\n失败 %d 条：%s" % (len(failed), failed[:5]), file=sys.stderr)
        sys.exit(1 if not rows else 0)


if __name__ == "__main__":
    main()
