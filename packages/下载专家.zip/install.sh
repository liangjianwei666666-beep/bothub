#!/usr/bin/env bash
# 下载专家 · 一键安装依赖
#
# 用法：
#   bash install.sh              # 装到当前 python3
#   PYTHON=/usr/local/bin/python3.11 bash install.sh
#
# 说明：全部依赖都装在用户目录（--user），不需要 root。
set -u

PY="${PYTHON:-python3}"
echo "== 下载专家 安装 =="
echo "Python: $($PY -V 2>&1)"
echo

# 1) 版本检查：faster-whisper 需要 3.9+，建议 3.10+
$PY - <<'EOF'
import sys
if sys.version_info < (3, 9):
    print("❌ 需要 Python 3.9 或更高，当前是 %s" % sys.version.split()[0])
    raise SystemExit(1)
if sys.version_info < (3, 10):
    print("⚠️  当前 Python < 3.10，能跑，但部分库会提示 deprecation。建议 3.10+")
EOF
if [ $? -ne 0 ]; then
    echo "❌ Python 版本不达标，先升 Python"
    exit 1
fi

# 2) 装依赖
echo "-- 安装依赖包（第一次会下载 faster-whisper，约几百 MB，慢是正常的）"
$PY -m pip install --user --upgrade \
    faster-whisper \
    yt-dlp \
    curl-cffi \
    zhconv \
    browser-cookie3 \
    websockets \
  || { echo "❌ 依赖安装失败，看上面的报错"; exit 1; }

# 3) ffmpeg 检查（不强制装，没有也能跑转写——faster-whisper 自带 imageio-ffmpeg）
echo
if command -v ffmpeg >/dev/null 2>&1; then
    echo "✅ ffmpeg: $(command -v ffmpeg)"
elif $PY -c "import imageio_ffmpeg" 2>/dev/null; then
    echo "✅ ffmpeg: 用 imageio-ffmpeg 自带的（无需额外安装）"
else
    echo "⚠️  没找到 ffmpeg。装一个更稳："
    echo "   macOS : brew install ffmpeg"
    echo "   Ubuntu: sudo apt install ffmpeg"
    echo "   Windows: winget install ffmpeg"
fi

# 4) 自检
echo
echo "-- 自检"
$PY - "$(dirname "$0")" <<'EOF'
import sys, importlib
sys.path.insert(0, sys.argv[1] + "/scripts")
ok = True
for mod, tip in [
    ("faster_whisper", "pip install faster-whisper"),
    ("yt_dlp", "pip install yt-dlp"),
    ("curl_cffi", "pip install curl-cffi"),
    ("zhconv", "pip install zhconv"),
    ("browser_cookie3", "pip install browser-cookie3"),
    ("websockets", "pip install websockets"),
]:
    try:
        importlib.import_module(mod)
        print(f"  ✅ {mod}")
    except Exception as e:
        ok = False
        print(f"  ❌ {mod} —— {tip}（{type(e).__name__}）")

try:
    import grab
    print(f"  ✅ ffmpeg: {grab.find_ffmpeg() or '未找到'}")
    c = grab._chrome_binary()
    print(f"  {'✅' if c else '⚠️ '} Chrome: {c or '未找到（只影响抖音，其它平台不受影响）'}")
    print(f"    代理: {grab.detect_proxy() or '未探测到（YouTube/X 若不通，设 HTTPS_PROXY）'}")
except Exception as e:
    ok = False
    print(f"  ❌ 脚本加载失败：{e}")

print()
print("✅ 装好了，跑一下试试：" if ok else "⚠️ 有依赖缺失，先按上面提示装")
EOF

echo
echo "试跑："
echo "  python3 $(dirname "$0")/scripts/grab.py \"https://www.youtube.com/watch?v=jNQXAC9IVRw\""
echo
echo "产出在 $(dirname "$0")/out/ 下：.md（带时间戳）、.txt（纯文本）、.json（时间轴）"
