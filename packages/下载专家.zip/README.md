# 下载专家 · 一条链接进，一份中文稿出

把长视频、播客、讲座转成能搜能读的中文文稿。

给一条链接或一个本地文件路径，出来三份东西：

- `<标题>.md` —— 带 `[分:秒]` 时间戳、自动分段的可读稿
- `<标题>.txt` —— 纯文本，方便搜索、喂给别的 AI
- `<标题>.json` —— 结构化时间轴（逐句 start / dur / text）

## 安装

需要 Python 3.9+（建议 3.10+）。

```bash
bash install.sh
```

它会把依赖装到用户目录（不需要 root），并跑一遍自检告诉你缺什么。

装完试跑：

```bash
python3 scripts/grab.py "https://www.youtube.com/watch?v=jNQXAC9IVRw"
```

## 用法

```bash
# 一条链接
python3 scripts/grab.py "https://www.youtube.com/watch?v=xxx"

# B站（必须带登录态）
python3 scripts/grab.py "https://www.bilibili.com/video/BVxxx" --cookies-from-browser chrome

# 小红书（带 xsec_token 的完整链接最稳）
python3 scripts/grab.py "https://www.xiaohongshu.com/explore/xxx?xsec_token=yyy"

# 本地文件（最稳，跳过下载）
python3 scripts/grab.py "/path/to/audio.mp3"

# 只要现成字幕，不下音频（最快）
python3 scripts/grab.py "<链接>" --mode subtitle

# 指定模型：tiny 最快，medium 最准（默认），长视频建议先确认时长
python3 scripts/grab.py "<链接>" --model small

# 自定义输出标题
python3 scripts/grab.py "<链接>" --title "我的笔记"
```

## 支持哪些平台

| 平台 | 能不能用 | 前提 |
|---|---|---|
| **YouTube** | ✅ 优先官方字幕 | 网络到得了；不通就配代理 |
| **X / Twitter** | ✅ 优先官方字幕 | 同上；只支持**带视频**的推文 |
| **B站** | ✅ | **必须** `--cookies-from-browser chrome`，且 Chrome 里登录过 B站 |
| **小红书** | ✅ | 链接要带 `xsec_token`（App 里"复制链接"最稳） |
| **抖音** | ✅ | Chrome 里登录过抖音；本机要有 Chrome/Edge |
| **播客 RSS** | ✅ | 无 |
| **本地音视频文件** | ✅ | 无（最稳的一条路） |
| **视频号** | ❌ | 需微信扫码登录，且没有网页分享链接格式，只能走本地文件 |

## 转写相关的坑（都实测过）

- **不要给 whisper 传 `initial_prompt`。** 实测它会把 prompt 当成视频里说过的话，
  直接转写进正文。繁简靠后处理转。
- whisper 中文会吐繁体 → 自动转简体 + 清理异体标点。
- 自动过滤 `字幕by xxx`、`请订阅` 这类片尾幻觉句。
- **长视频很慢。** 30 分钟音频用 medium 要跑很久。急用 `--model tiny`。

## 术语表（提升准确率最有效的办法）

whisper 的同音字错误模型自己改不过来（耳蜗→耳窝、植入体→植物体）。
项目根目录 `glossary.txt` 一行一条：

```
耳窝=耳蜗
植物体=植入体
```

发现固定错词就加进去，脚本会自动套用，越用越准。

## 遇到问题

- **B站报 `Unable to extract initial state` 或 412** → 加 `--cookies-from-browser chrome`
- **抖音"没抓到音频流"** → 先在 Chrome 里登录抖音
- **小红书拿到空壳** → 用 App 里"复制链接"，要带 `xsec_token` 的完整链接
- **YouTube / X 超时** → 开 VPN；或手动指定代理：
  `HTTPS_PROXY=http://127.0.0.1:7890 python3 scripts/grab.py "<链接>"`
- **视频号** → 把视频存本地，直接给文件路径

## 可选环境变量

| 变量 | 作用 |
|---|---|
| `HTTPS_PROXY` | 代理。不设就自动探测系统代理 |
| `FFMPEG_BIN` | 指定 ffmpeg。不设就依次找 PATH → imageio-ffmpeg |
| `DLZJ_OUT` | 产出目录，默认 `./out` |
| `DLZJ_CHROME` | Chrome/Edge 路径（只影响抖音） |
| `DLZJ_CDP_PORT` | Chrome 调试端口，默认 9333 |

## 声明

请只抓取你有权访问、有权使用的内容。本工具不帮你批量抓取整个频道或播放列表。
