#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学科导航生成器（通用版）—— 给语文 / 数学 / 英语等学科一键建「项目文件夹 + 七板块导航页」。

用法示例：
    python3 建站.py --root "/Users/a1-6/Desktop/数学" --subject "数学" --launcher "数学导航"

默认写好七个板块文件夹（01-知识点可视化 … 07-科创项目），再生成：
    <root>/index.html                 七板块总入口（带搜索、最近产出）
    <root>/<板块>/index.html           各板块的文件清单
    ~/Desktop/<launcher>.app           双击即开的桌面入口（macOS）

每次新增产出后再跑一次本脚本，导航页就会刷新。
只覆盖 index.html，不碰你自己的任何产出文件。
"""

import argparse
import json
import os
import time
import html
from urllib.parse import quote

DEFAULT_MODULES = [
    dict(folder="01-知识点可视化", name="知识点可视化", tag="图谱 / 流程图", color="#b23a30",
         desc="把本学科的核心概念、公式、规则画成图谱和流程图，一页看全关系。",
         empty="将产出：概念图谱、公式或规则图表、知识结构流程图。"),
    dict(folder="02-游戏练习", name="游戏练习", tag="闯关 / 积分 / 连击", color="#2f6d5a",
         desc="基础项做成闯关，答对累计积分，连对触发连击，错了不卡关。",
         empty="将产出：分级闯关练习、积分与连击规则说明。"),
    dict(folder="03-阶段测试与报告", name="阶段测试与报告", tag="单元卷 / 薄弱点定位", color="#3b5b8c",
         desc="单元卷与阶段卷，判完给薄弱点报告，定位到具体失分点而不是空泛评语。",
         empty="将产出：单元试卷、阶段测评卷、判分与薄弱点报告。"),
    dict(folder="04-错题卡", name="错题卡", tag="错因 / 重练", color="#8a5a9b",
         desc="每题记原文、错因（审题／理解／计算／表达）、同型重练题，隔天按遗忘曲线再现。",
         empty="将产出：单题错题卡、错因归类汇总、同型重练题组。"),
    dict(folder="05-思辨", name="思辨", tag="议题 / 正反立论", color="#a8742c",
         desc="围绕争议议题做多角度立论与反驳，练的是判断和论证，不是背答案。",
         empty="将产出：思辨议题、正反论证路径、议论文或辩论练习。"),
    dict(folder="06-元认知", name="元认知", tag="复盘 / 策略", color="#4a6b7c",
         desc="复盘做题过程：卡在哪一步、用了什么策略、下次换什么办法，据此调整计划。",
         empty="将产出：策略清单、复盘表、学习计划调整记录。"),
    dict(folder="07-科创项目", name="科创项目", tag="项目 / 真实产出", color="#7a6a4f",
         desc="把学科用到真实项目里：选题、提纲、执行、成稿，做出可展示的成品。",
         empty="将产出：项目选题书、执行方案、成果成品。"),
]

# 这些不算「学生做出来的东西」，不计入文件数，也不列在清单里。
# 错题本.json 是错题本的内部数据；照片/ 里的原图由 错题本.html 自己显示。
SKIP_FILES = {"index.html", ".DS_Store", "错题本.json", "错题本.json.tmp"}
SKIP_DIRS = {"__pycache__", ".git", "照片"}

# 视觉风格：每个学生的工作台可以长得不一样。
# 只用颜色令牌，不改结构——结构一动，七个板块的间距和层级就会漂。
THEMES = {
    "纸墨": dict(paper="#f6f3ec", ink="#26241f", ink_soft="#6b665c", line="#e2dccf",
               card="#fffdf9", accent="#b23a30", desc="默认。米纸底，朱红印"),
    "海蓝": dict(paper="#eef3f7", ink="#1b2733", ink_soft="#5b6b7a", line="#d3dfe8",
               card="#ffffff", accent="#1f6f9c", desc="浅蓝底，像作业本的格子"),
    "森林": dict(paper="#eef4ee", ink="#1f2a22", ink_soft="#5f6f63", line="#d5e2d6",
               card="#ffffff", accent="#2f6d4f", desc="浅绿底，安静"),
    "樱粉": dict(paper="#fbf0f2", ink="#2c2225", ink_soft="#7a6670", line="#ecd8dd",
               card="#ffffff", accent="#b34d6d", desc="浅粉底，偏温柔"),
    "糖果": dict(paper="#fff8ec", ink="#2b2620", ink_soft="#7a6c58", line="#f0e0c4",
               card="#ffffff", accent="#e08a1e", desc="暖黄底，最跳，适合低年级"),
    "墨绿": dict(paper="#1e2a26", ink="#eef3ee", ink_soft="#9fb3aa", line="#33443d",
               card="#26332e", accent="#7fc9a6", desc="深色底，晚上看不刺眼"),
    "夜读": dict(paper="#1b1d22", ink="#e9e6df", ink_soft="#a09a8e", line="#33373f",
               card="#23262c", accent="#e0a45c", desc="深灰底，暖黄字"),
}
# 深色主题下，七个板块的卡色要提亮，否则压在深底上看不清。
MODULE_COLORS_DARK = ["#e0786a", "#6fb99a", "#7f9fd6", "#b48dcc", "#d9a758", "#7fa8bc", "#b3a98a"]


def resolve_theme(name="", accent=""):
    """把 --theme / --accent 解析成一份颜色令牌。认不出的主题名返回 None。"""
    t = THEMES.get(name) if name else None
    if name and t is None:
        raise SystemExit("没有叫「%s」的主题。可选的：%s" % (name, "、".join(THEMES)))
    if t is None:
        t = dict(THEMES["纸墨"])
    t = dict(t)
    if accent:
        t["accent"] = accent
    return t


def theme_css(t):
    """生成覆盖默认令牌的 <style>。只覆盖颜色，别的一概不碰。"""
    if not t:
        return ""
    keys = [("--paper", "paper"), ("--ink", "ink"), ("--ink-soft", "ink_soft"),
            ("--line", "line"), ("--card", "card"), ("--accent", "accent")]
    return ":root{" + "".join("%s:%s;" % (k, t[v]) for k, v in keys if t.get(v)) + "}"


CSS = """
:root{--paper:#f6f3ec;--ink:#26241f;--ink-soft:#6b665c;--line:#e2dccf;--card:#fffdf9;--accent:#b23a30}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{background:var(--paper);color:var(--ink);
 font-family:"PingFang SC","Hiragino Sans GB","Songti SC",system-ui,-apple-system,"Microsoft YaHei",sans-serif;
 -webkit-font-smoothing:antialiased;padding:40px 28px 64px}
.wrap{max-width:1120px;margin:0 auto}
header.top{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap;
 border-bottom:1px solid var(--line);padding-bottom:18px;margin-bottom:26px}
h1{font-size:30px;margin:0 0 6px;letter-spacing:.04em;font-weight:700}
h1 .seal{display:inline-block;background:var(--accent);color:#fff;font-size:14px;
 padding:2px 8px;border-radius:3px;margin-right:10px;vertical-align:6px;letter-spacing:.1em}
.sub{color:var(--ink-soft);font-size:14px;line-height:1.7;margin:0}
.meta{color:var(--ink-soft);font-size:13px;text-align:right;line-height:1.9}
.meta b{color:var(--ink);font-size:18px;font-variant-numeric:tabular-nums}
.search{margin:0 0 22px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.search input{flex:1;min-width:220px;padding:11px 14px;border:1px solid var(--line);
 border-radius:8px;background:var(--card);font-size:14px;color:var(--ink);outline:none}
.search input:focus{border-color:#c9bda6;box-shadow:0 0 0 3px rgba(178,58,48,.06)}
.search span{color:var(--ink-soft);font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
.card{position:relative;background:var(--card);border:1px solid var(--line);border-radius:12px;
 padding:20px 20px 18px 22px;text-decoration:none;color:inherit;display:flex;flex-direction:column;
 transition:transform .16s ease,box-shadow .16s ease,border-color .16s ease;overflow:hidden}
.card::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--c)}
.card:hover{transform:translateY(-2px);box-shadow:0 8px 22px rgba(60,50,30,.10);border-color:#d3c9b4}
.card .no{font-size:12px;letter-spacing:.18em;color:var(--c);font-weight:700;margin-bottom:8px}
.card h2{font-size:19px;margin:0 0 4px;font-weight:700;letter-spacing:.02em}
.card .tag{font-size:12px;color:var(--ink-soft);margin-bottom:10px;letter-spacing:.04em}
.card p{font-size:13.5px;line-height:1.75;color:#4a453c;margin:0 0 14px;flex:1}
.card .foot{display:flex;align-items:center;justify-content:space-between;gap:10px;
 border-top:1px dashed var(--line);padding-top:11px;font-size:12.5px;color:var(--ink-soft)}
.card .foot .go{color:var(--c);font-weight:700}
.card .count{font-variant-numeric:tabular-nums}
.card.empty p{color:#8d877b}
.card.empty::before{opacity:.35}
section.recent{margin-top:34px}
section.recent h3{font-size:15px;margin:0 0 12px;letter-spacing:.08em;color:var(--ink-soft);font-weight:700}
ul.files{list-style:none;margin:0;padding:0;background:var(--card);border:1px solid var(--line);border-radius:12px;overflow:hidden}
ul.files li{display:flex;align-items:center;gap:12px;padding:11px 16px;border-bottom:1px solid #f0ebdf;font-size:13.5px}
ul.files li:last-child{border-bottom:none}
ul.files a{color:var(--ink);text-decoration:none;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
ul.files a:hover{color:var(--accent);text-decoration:underline}
ul.files .when{color:var(--ink-soft);font-size:12.5px;font-variant-numeric:tabular-nums}
ul.files .where{color:var(--ink-soft);font-size:12px;background:#f3eee2;padding:2px 7px;border-radius:4px;white-space:nowrap}
.crumb{font-size:13px;color:var(--ink-soft);margin-bottom:18px}
.crumb a{color:var(--ink-soft);text-decoration:none}
.crumb a:hover{color:var(--accent)}
.module-head{border-left:4px solid var(--c);padding:2px 0 2px 18px;margin-bottom:24px}
.module-head h1{font-size:26px}
.filetable{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);
 border-radius:12px;overflow:hidden;font-size:13.5px}
.filetable th{text-align:left;font-weight:600;color:var(--ink-soft);font-size:12.5px;
 padding:12px 16px;background:#f2ede1;border-bottom:1px solid var(--line);letter-spacing:.05em}
.filetable td{padding:11px 16px;border-bottom:1px solid #f0ebdf;vertical-align:middle}
.filetable tr:last-child td{border-bottom:none}
.filetable a{color:var(--ink);text-decoration:none}
.filetable a:hover{color:var(--accent);text-decoration:underline}
.filetable .sz,.filetable .tm{color:var(--ink-soft);font-size:12.5px;white-space:nowrap;font-variant-numeric:tabular-nums}
.emptybox{background:var(--card);border:1px dashed #d8cfba;border-radius:12px;padding:28px 24px;color:#7d7669;font-size:14px;line-height:1.9}
.emptybox b{color:var(--ink);font-weight:600}
footer.foot{margin-top:40px;border-top:1px solid var(--line);padding-top:16px;color:#918a7c;font-size:12.5px;line-height:1.8}
@media print{body{background:#fff;padding:0}.search,footer.foot{display:none}}
"""


def esc(s):
    return html.escape(str(s), quote=True)


def url(p):
    return "/".join(quote(x) for x in p.split("/"))


def scan(root, folder):
    base = os.path.join(root, folder)
    out = []
    if not os.path.isdir(base):
        return out
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in filenames:
            if fn in SKIP_FILES or fn.startswith("."):
                continue
            full = os.path.join(dirpath, fn)
            try:
                st = os.stat(full)
            except OSError:
                continue
            out.append(dict(rel=os.path.relpath(full, root).replace(os.sep, "/"),
                            name=fn, size=st.st_size, mtime=st.st_mtime))
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def ftime(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def fsize(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return ("%d B" % n) if u == "B" else ("%.1f %s" % (n, u))
        n /= 1024.0


def page(title, body, tc=""):
    return ("<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"utf-8\">\n"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n"
            "<title>%s</title>\n<style>%s</style>\n<style>%s</style>\n</head>\n<body>\n%s\n</body>\n</html>\n"
            % (esc(title), CSS, tc, body))


def build_portal(root, subject, modules, title="", student="", theme=None):
    scans = {m["folder"]: scan(root, m["folder"]) for m in modules}
    title = title or ("%s · 七板块学习台" % subject)
    tc = theme_css(theme)
    total = sum(len(v) for v in scans.values())
    dark = bool(theme) and theme.get("paper", "").lower() in (
        "#1e2a26", "#1b1d22")
    cards = []
    for i, m in enumerate(modules, 1):
        files = scans[m["folder"]]
        n = len(files)
        latest = ftime(files[0]["mtime"]) if files else "—"
        card_color = MODULE_COLORS_DARK[i - 1] if dark else m["color"]
        cards.append("""<a class="card%s" style="--c:%s" href="%s/index.html">
  <div class="no">板块 %02d</div>
  <h2>%s</h2>
  <div class="tag">%s</div>
  <p>%s</p>
  <div class="foot"><span class="count">%s · 最近 %s</span><span class="go">进入 →</span></div>
</a>""" % ("" if n else " empty", card_color, esc(m["folder"]), i, esc(m["name"]),
           esc(m["tag"]), esc(m["desc"]),
           ("%d 个文件" % n) if n else "待产出", latest))

    allf = []
    for m in modules:
        for f in scans[m["folder"]]:
            f = dict(f); f["module"] = m["name"]; allf.append(f)
    allf.sort(key=lambda x: x["mtime"], reverse=True)
    if allf:
        rows = "\n".join('<li><a href="%s">%s</a><span class="where">%s</span><span class="when">%s</span></li>'
                         % (url(f["rel"]), esc(f["name"]), esc(f["module"]), ftime(f["mtime"]))
                         for f in allf[:10])
        recent = '<section class="recent"><h3>最近产出</h3><ul class="files">%s</ul></section>' % rows
    else:
        recent = ('<section class="recent"><h3>最近产出</h3><div class="emptybox">'
                  '七个板块都还是空的。挑一个开始，产出会自动出现在这里。</div></section>')

    body = """<div class="wrap">
<header class="top">
  <div>
    <h1><span class="seal">%s</span>%s</h1>
    <p class="sub">%s%s</p>
  </div>
  <div class="meta"><b>%d</b> 个文件<br>更新于 %s</div>
</header>
<div class="search">
  <input id="q" type="search" placeholder="搜索板块，例如：%s…" autocomplete="off">
  <span id="hit">共 %d 个板块</span>
</div>
<div class="grid" id="grid">
%s
</div>
%s
<footer class="foot">文件夹：%s<br>本页由 建站.py 生成，可离线双击打开；新增产出后再跑一次脚本即可刷新。</footer>
</div>
<script>
(function(){
  var q=document.getElementById('q'),hit=document.getElementById('hit');
  var cards=[].slice.call(document.querySelectorAll('.card'));
  var base=cards.map(function(c){return (c.textContent||'').toLowerCase();});
  q.addEventListener('input',function(){
    var k=q.value.trim().toLowerCase(),n=0;
    cards.forEach(function(c,i){
      var ok=!k||base[i].indexOf(k)>-1;
      c.style.display=ok?'':'none'; if(ok)n++;
    });
    hit.textContent=k?('匹配 '+n+' 个板块'):'共 %d 个板块';
  });
})();
</script>""" % (esc(subject), esc(title), esc(" · ".join(m["name"] for m in modules)),
               ("　·　%s" % esc(student)) if student else "",
               total, time.strftime("%Y-%m-%d %H:%M"), esc(subject), len(modules),
               "\n".join(cards), recent, esc(root), len(modules))
    return page(title, body, tc)


def build_module(root, subject, m, theme=None):
    files = scan(root, m["folder"])
    tc = theme_css(theme)
    dark = bool(theme) and theme.get("paper", "").lower() in ("#1e2a26", "#1b1d22")
    m = dict(m)
    if dark:
        # 深色主题下用提亮版卡色，跟总入口保持一致
        for i, dm in enumerate(DEFAULT_MODULES):
            if dm["folder"] == m["folder"]:
                m["color"] = MODULE_COLORS_DARK[i]
                break
    head = """<div class="wrap">
<div class="crumb"><a href="../index.html">← 七板块总入口</a></div>
<div class="module-head" style="--c:%s">
  <h1>%s</h1>
  <p class="sub">%s</p>
</div>""" % (m["color"], esc(m["name"]), esc(m["desc"]))
    if files:
        rows = []
        for f in files:
            shown = f["rel"].split("/", 1)[1] if "/" in f["rel"] else f["name"]
            rows.append('<tr><td><a href="../%s">%s</a></td><td class="sz">%s</td><td class="tm">%s</td></tr>'
                        % (url(f["rel"]), esc(shown), fsize(f["size"]), ftime(f["mtime"])))
        table = ('<table class="filetable"><thead><tr><th>文件</th><th>大小</th><th>更新</th></tr></thead>'
                 '<tbody>%s</tbody></table>' % "\n".join(rows))
    else:
        table = ('<div class="emptybox">这个板块还没有内容。<br>%s<br><br>'
                 '<b>怎么开始：</b>直接说「做一份……」，产出会落在本文件夹，再跑一次建站脚本即可出现在这里。</div>'
                 % esc(m["empty"]))
    foot = '<footer class="foot">共 %d 个文件 · 文件夹：%s</footer></div>' % (
        len(files), esc(os.path.join(root, m["folder"])))
    return page("%s · %s" % (subject, m["name"]), head + table + foot, tc)


def read_settings(root):
    """读 工作台设置.json，读不到/读坏了都返回空 dict，绝不拦建站。"""
    path = os.path.join(root, "工作台设置.json")
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        print("（工作台设置.json 读不出来，这次用命令行给的设置）")
        return {}


def build(root, subject, title="", student="", theme=None, accent=""):
    modules = DEFAULT_MODULES
    # 命令行没给的项，从 json 里补。
    # 不补会出这种事：学生改过一次名字，后来只说「换个风格」，
    # 名字就退回「数学 · 七板块学习台」——他明明没让改名字。
    old = read_settings(root)
    title = title or old.get("名字", "")
    student = student or old.get("学生", "")
    accent = accent or old.get("主色", "")
    if not theme:
        theme = old.get("风格", "")
    subject = subject or old.get("学科", "")
    t = resolve_theme(theme, accent)
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "index.html"), "w", encoding="utf-8") as f:
        f.write(build_portal(root, subject, modules, title=title, student=student, theme=t))
    for m in modules:
        d = os.path.join(root, m["folder"])
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "index.html"), "w", encoding="utf-8") as f:
            f.write(build_module(root, subject, m, theme=t))
    print("导航已更新：", os.path.join(root, "index.html"))
    if title:
        print("工作台名字：", title)
    if student:
        print("学生：", student)
    if theme:
        print("视觉风格：", theme)
    save_settings(root, subject, title, student, theme, accent)
    return root


def save_settings(root, subject, title="", student="", theme="", accent=""):
    """把这次用的名字/学生/风格记进 工作台设置.json。

    为什么必须记：_更新导航.py（学生以后刷新工作台用的那个脚本）是读这个 json
    来恢复名字和风格的。以前建站.py 只把名字写进 index.html、不写 json，
    于是学生第一次改完名字是好的，下次让助手刷新工作台时名字就悄悄退回
    「数学 · 七板块学习台」——他自己改的东西丢了，还不知道为什么。

    只写非空项；一个都没给就不动 json，免得把学生已有的设置清空。
    """
    if not (title or student or theme or accent):
        return
    path = os.path.join(root, "工作台设置.json")
    old = {}
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                old = json.load(f) or {}
        except Exception:
            old = {}
    if not isinstance(old, dict):
        old = {}
    for key, val in (("名字", title), ("学生", student), ("风格", theme),
                     ("主色", accent)):
        if val:
            old[key] = val
    old.setdefault("学科", subject)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(old, f, ensure_ascii=False, indent=1)
        print("设置已记下：", path)
    except Exception as e:
        print("（设置没写进去：%s。名字这次照样生效，但下次刷新会退回默认）" % e)


def make_launcher(root, label):
    """在桌面生成双击即开的 .app（仅 macOS）。"""
    import subprocess
    desktop = os.path.expanduser("~/Desktop")
    app = os.path.join(desktop, label + ".app")
    target = "file://" + quote(os.path.join(root, "index.html"))
    script = 'do shell script "open \\"%s\\""' % target
    subprocess.run(["osacompile", "-o", app, "-e", script], check=True)
    print("桌面入口已生成：", app)
    return app


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="学科文件夹绝对路径，如 /Users/xxx/Desktop/数学")
    ap.add_argument("--subject", required=True, help="学科名，如 数学")
    ap.add_argument("--launcher", default="", help="桌面入口 App 名称；留空则不生成")
    ap.add_argument("--title", default="", help="工作台名字，如「小满的数学基地」。留空则用「<学科>·七板块学习台」")
    ap.add_argument("--student", default="", help="学生名字，显示在页头。留空则不显示")
    ap.add_argument("--theme", default="", help="配色主题名，见 THEMES（纸墨/海蓝/森林/夜读/糖果/墨绿/樱粉）。留空用默认")
    ap.add_argument("--accent", default="", help="直接指定主色，如 #7a5c3e。给了就盖过 --theme")
    a = ap.parse_args()
    # 关键：先展开 ~，再转绝对路径。
    # 反例：--root "~/Desktop/数学" 若直接 abspath，会在当前目录建一个字面名叫「~」的文件夹，
    # 导航页生成到错的地方，用户以为没生成。（本机家目录下已经有一个这样的 ~ 目录）
    root = os.path.abspath(os.path.expanduser(a.root))
    build(root, a.subject, title=a.title, student=a.student,
          theme=a.theme, accent=a.accent)
    if a.launcher:
        make_launcher(root, a.launcher)


if __name__ == "__main__":
    main()
