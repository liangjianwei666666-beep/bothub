#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
知识点查询工具（数学 · 人教版口径）

为什么要有它：
  知识库是一个 116 KB 的 JSON、519 个知识点。让助手「自己读一遍」有三个毛病：
  读不全、容易编错编号、追不动前置关系。
  这个工具把该查的事变成一条命令，助手不用把整个库读进上下文。

用法（在包目录或工作目录里跑）：

  查册                        列出所有册，以及每册几个单元、几个知识点
  查单元 五年级上              列出这一册的单元和知识点
  查点 SM-DIV-DEC             看一个知识点的详情（含前置链）
  查词 小数除法                按关键词找知识点（跨册）
  查前置 SM-DIV-APP           往上游追前置，追到底
  查错因 只把除数变整数         把一句具体错因归到 9 类里，并给对应动作
  查路 SM-DIV-DEC             给一个知识点，输出「前置 → 本点 → 后续」的整条路

  加 --json 输出 JSON，方便程序读；不加则输出给人看的中文。

设计原则：
  - 只读，不改库。
  - 找不到就明说找不到，不编。
  - 归错因时，置信度不高会明说「不确定，建议人工判」。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# 9 类错因（人设里的口径）
CATEGORIES = ["概念没懂", "计算失误", "看错数字或符号", "不会列式",
              "审题错", "跳步", "方法选错", "表达不严", "记不住公式"]

ACTIONS = {
    "概念没懂": "先看这一步的可视化/推导，再做 3 道基础题确认",
    "计算失误": "10 分钟限时口算 + 每题强制验算",
    "看错数字或符号": "抄题训练：先圈数字和符号再动笔",
    "不会列式": "读题三问：求什么、已知什么、什么关系，写完再列式",
    "审题错": "圈条件、写「求什么」、划单位",
    "跳步": "把解析拆成填空，一步一步写全",
    "方法选错": "一题多解，两种方法各做一遍并比较",
    "表达不严": "讲给同学听，讲不清就回去补那一步",
    "记不住公式": "默写推导流程 + 3 天后再默写",
}

# 错因 → 9 类的关键词表。顺序有意义：先匹配到的优先。
#
# 重要：库里的错因是「具体错法描述」（例如「把>当<」「跳着数漏数」），
# 不是分类标签。具体描述比分类有用得多——它是能直接教学生的东西。
# 这张表只用来做「归类建议」，准确率约 3 成，**不能当判定**。
# 归不进去时明说，不要硬归。
RULES = [
    # 记不住：记成/记混/背错/进率/口诀
    ("记不住公式", ["记成", "记混", "记不住", "公式", "口诀", "默写", "记错",
                    "忘了公式", "进率", "背错", "记不牢", "混淆了公式"]),
    # 看错符号数字：看错/抄错/写反（注意「反」要先排除「说反」）
    ("看错数字或符号", ["看错", "抄错", "数字看", "符号看", "漏写负号", "正负号",
                        "抄漏", "看漏", "看错符号", "抄写错", "把0写成6"]),
    # 跳步：跳步/少写一步/不写过程
    ("跳步", ["跳步", "少写一步", "直接写", "漏一步", "省略", "不写过程",
              "漏步骤", "中间步骤"]),
    # 审题：审题/条件没看/答非所问
    ("审题错", ["审题", "看漏条件", "理解题意", "答非所问", "没看清要求",
                "单位没看", "条件没看", "题目要求", "问的是什么"]),
    # 不会列式
    ("不会列式", ["列式", "不会找", "找不到条件", "不知用哪个", "关系找",
                  "不会设", "等量关系", "不会列", "不知怎么列"]),
    # 方法选错
    ("方法选错", ["方法选错", "用错方法", "选错方法", "混用", "乱套", "用错公式"]),
    # 表达不严
    ("表达不严", ["表达", "说不清", "表述", "写不完整", "答语", "单位名称写错",
                  "过程不完整", "不写单位", "漏单位"]),
    # 计算失误
    ("计算失误", ["算错", "计算", "得数", "进位", "退位", "口算", "算成",
                  "算漏", "加错", "减错", "乘错", "除错", "多减", "多算",
                  "少算", "算重", "点错小数点", "小数点位置"]),
    # 概念没懂：最宽的一类，放最后（兜底优先给别的）
    ("概念没懂", ["概念", "没懂", "不理解", "混淆", "搞混", "分不清", "关系说反",
                  "混", "说成", "当成", "写成", "看成", "想成", "说不相等",
                  "说不等", "搞反", "说反", "反了", "错当", "误以为",
                  "认为", "以为", "当成是", "理解错", "概念错", "原理",
                  "不分", "颠倒", "弄反", "错把", "把.当", "只把", "只变",
                  "没跟着", "没同", "同扩", "忘", "漏掉", "没变", "照算",
                  "也照", "直接算"]),
]


def load(path=None):
    """读知识库。优先用学生自己的，没有就用参考库。"""
    if path and os.path.exists(path):
        return json.load(open(path, encoding="utf-8")), path
    for name in ("年级知识库.json", "参考库_人教版.json"):
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            return json.load(open(p, encoding="utf-8")), p
    sys.exit("找不到知识库：工作目录里没有 年级知识库.json，也没有 参考库_人教版.json")


def books(db):
    return [k for k in db if not k.startswith("__")]


def iter_points(db):
    """遍历所有知识点，产出 (册, 单元, kp)。"""
    for b in books(db):
        for u in db[b]["units"]:
            for kp in u["kps"]:
                yield b, u["u"], kp


def index(db):
    idx = {}
    for b, u, kp in iter_points(db):
        idx[kp[0]] = {"book": b, "unit": u, "id": kp[0], "name": kp[1],
                      "errors": [x for x in kp[2].split("|") if x.strip()],
                      "pre": kp[3]}
    # 跨册通用点
    if "__cross" in db:
        for u in db["__cross"]["units"]:
            for kp in u["kps"]:
                idx.setdefault(kp[0], {"book": "跨册通用", "unit": u["u"], "id": kp[0],
                                       "name": kp[1],
                                       "errors": [x for x in kp[2].split("|") if x.strip()],
                                       "pre": kp[3]})
    return idx


def classify(err_text):
    """把一句具体错因归到 9 类。返回 (类别, 命中的关键词) 或 (None, None)。"""
    for cat, kws in RULES:
        for kw in kws:
            if kw in err_text:
                return cat, kw
    return None, None


# ---------- 各命令 ----------

def cmd_books(db, as_json):
    rows = []
    for b in books(db):
        n_units = len(db[b]["units"])
        n_kps = sum(len(u["kps"]) for u in db[b]["units"])
        rows.append({"book": b, "grade": db[b]["grade"], "term": db[b]["term"],
                     "units": n_units, "points": n_kps})
    if as_json:
        print(json.dumps(rows, ensure_ascii=False, indent=1))
        return
    print(f"共 {len(rows)} 册\n")
    for r in rows:
        print(f"  {r['book']:<8} {r['units']:>2} 单元  {r['points']:>3} 个知识点")


def cmd_units(db, book, as_json):
    if book not in db:
        print(f"没有「{book}」这一册。可用：{'、'.join(books(db))}")
        return
    units = db[book]["units"]
    if as_json:
        out = [{"unit": u["u"], "points": [{"id": k[0], "name": k[1],
                                            "errors": [x for x in k[2].split("|") if x.strip()]}
                                           for k in u["kps"]]} for u in units]
        print(json.dumps({"book": book, "units": out}, ensure_ascii=False, indent=1))
        return
    total = sum(len(u["kps"]) for u in units)
    print(f"{book} · {len(units)} 个单元 · {total} 个知识点\n")
    for u in units:
        print(f"【{u['u']}】{len(u['kps'])} 个")
        for k in u["kps"]:
            print(f"   {k[0]:<18} {k[1]}")


def cmd_point(idx, pid, as_json):
    p = idx.get(pid)
    if not p:
        print(f"没有编号「{pid}」这个知识点。")
        near = [k for k in idx if pid.lower() in k.lower()]
        if near:
            print("你是不是要找：" + "、".join(near[:8]))
        return
    if as_json:
        print(json.dumps(p, ensure_ascii=False, indent=1))
        return
    print(f"{p['name']}  [{p['id']}]")
    print(f"  在：{p['book']} · {p['unit']}")
    print(f"  常见错因：")
    for e in p["errors"]:
        cat, kw = classify(e)
        tag = f"→ {cat}（命中「{kw}」）" if cat else "→ 未归类，需人工判"
        print(f"    · {e}  {tag}")
    if p["pre"]:
        print(f"  前置：")
        for x in p["pre"]:
            q = idx.get(x)
            print(f"    ← {q['name'] if q else x}  [{x}]" + (f"  （{q['book']}）" if q else "  ⚠ 库里没有"))
    else:
        print("  前置：无（这是起点）")


def cmd_search(idx, kw, as_json):
    hits = []
    for pid, p in idx.items():
        if kw in p["name"] or kw in p["unit"] or any(kw in e for e in p["errors"]):
            hits.append(p)
    if as_json:
        print(json.dumps(hits, ensure_ascii=False, indent=1))
        return
    if not hits:
        print(f"没找到含「{kw}」的知识点。")
        return
    print(f"找到 {len(hits)} 个含「{kw}」的知识点：\n")
    by_book = {}
    for p in hits:
        by_book.setdefault(p["book"], []).append(p)
    for b, ps in by_book.items():
        print(f"【{b}】")
        for p in ps:
            print(f"   {p['id']:<18} {p['name']}   （{p['unit']}）")
        print()


def cmd_pre(idx, pid, as_json):
    if pid not in idx:
        print(f"没有编号「{pid}」这个知识点。")
        return
    chain, seen, frontier = [], set(), [pid]
    depth = 0
    while frontier and depth < 12:
        nxt = []
        for x in frontier:
            for pre in idx[x]["pre"]:
                if pre in seen or pre == pid:
                    continue
                seen.add(pre)
                q = idx.get(pre)
                chain.append({"depth": depth + 1, "id": pre,
                              "name": q["name"] if q else "⚠库里没有",
                              "book": q["book"] if q else "?",
                              "from": x})
                nxt.append(pre)
        frontier = nxt
        depth += 1
    if as_json:
        print(json.dumps(chain, ensure_ascii=False, indent=1))
        return
    if not chain:
        print(f"{idx[pid]['name']} 没有前置，是起点。")
        return
    print(f"{idx[pid]['name']} 的前置链（越往下越基础）：\n")
    for c in chain:
        print(f"  {'  ' * (c['depth'] - 1)}← {c['name']}  [{c['id']}]  （{c['book']}）")


def cmd_error(text, as_json):
    cat, kw = classify(text)
    if as_json:
        print(json.dumps({"input": text, "suggest": cat,
                          "hit": kw, "action": ACTIONS.get(cat) if cat else None,
                          "confidence": "低，仅供参考" if cat else "无"},
                         ensure_ascii=False, indent=1))
        return
    print(f"错因原文：{text}\n")
    print("这一句本身就是「最小单位」的错因，直接用它教学生最准。")
    print("（例如「把>当<」比「概念没懂」有用得多——前者能直接练，后者不能。）\n")
    if cat:
        print(f"若要归到 9 类做报表：**建议 {cat}**（命中关键词「{kw}」，低置信度，仅供参考）")
        print(f"  对应动作：{ACTIONS[cat]}")
    else:
        print("自动归不进 9 类。**不要硬归**——按原话记下来，让老师判。")
    print(f"\n9 类对照（自己判的时候看这张）：")
    for c in CATEGORIES:
        print(f"  {c:<8} {ACTIONS[c]}")
    print("\n判断口诀：先问「他错在没想通、算错、还是没看清」，再问「这一步他跳过了吗」。")


def cmd_match(idx, pid, said, as_json):
    """把学生的原话，对到一个知识点已列出的具体错法上。"""
    p = idx.get(pid)
    if not p:
        print(f"没有编号「{pid}」这个知识点。")
        return
    best, score = None, 0
    for e in p["errors"]:
        s = len(set(said) & set(e)) / max(len(e), 1)
        if s > score:
            best, score = e, s
    if as_json:
        print(json.dumps({"point": p["name"], "said": said,
                          "best_match": best, "score": round(score, 3),
                          "all_listed": p["errors"]}, ensure_ascii=False, indent=1))
        return
    print(f"{p['name']}  [{p['id']}]")
    print(f"  学生说／你观察到：{said}")
    print(f"  库里这一点的错法：")
    for e in p["errors"]:
        mark = "  ← 最接近" if e == best else ""
        print(f"    · {e}{mark}")
    if score < 0.34:
        print(f"\n  ⚠ 都对不太上（最接近「{best}」只对上 {score:.0%}）。")
        print("    这说明可能是另一种错法，或者卡点在**前置**上，先跑：查前置 " + pid)
    else:
        print(f"\n  最接近：「{best}」（对上 {score:.0%}）")
        cat, _ = classify(best)
        if cat:
            print(f"  归到：{cat}（低置信度）→ {ACTIONS[cat]}")


def cmd_path(idx, pid, as_json):
    if pid not in idx:
        print(f"没有编号「{pid}」这个知识点。")
        return
    # 上游
    up, seen, frontier, depth = [], {pid}, [pid], 0
    while frontier and depth < 12:
        nxt = []
        for x in frontier:
            for pre in idx[x]["pre"]:
                if pre in seen:
                    continue
                seen.add(pre)
                q = idx.get(pre)
                up.append((depth + 1, q["name"] if q else pre, pre,
                           q["book"] if q else "?"))
                nxt.append(pre)
        frontier = nxt
        depth += 1
    # 下游
    down = [(pid2, p["name"], p["book"]) for pid2, p in idx.items()
            if pid in p["pre"]]
    if as_json:
        print(json.dumps({"point": idx[pid], "upstream": up, "downstream": down},
                         ensure_ascii=False, indent=1))
        return
    p = idx[pid]
    print(f"{p['name']}  [{p['id']}]  （{p['book']} · {p['unit']}）\n")
    print("往下追（前置，越往下越基础）：")
    if not up:
        print("  无，这是起点")
    for d, name, i, b in sorted(up, key=lambda x: -x[0]):
        print(f"  {'  ' * (d - 1)}← {name}  [{i}]  （{b}）")
    print("\n往上走（学完这个才能学）：")
    if not down:
        print("  无，这是末端")
    for i, name, b in down:
        print(f"  → {name}  [{i}]  （{b}）")


def main():
    args = [a for a in sys.argv[1:] if a != "--json"]
    as_json = "--json" in sys.argv[1:]
    if not args:
        print(__doc__)
        return

    db, path = load()
    idx = index(db)
    cmd, rest = args[0], args[1:]

    if cmd == "查册":
        cmd_books(db, as_json)
    elif cmd == "查单元":
        if not rest:
            sys.exit("用法：查单元 五年级上")
        cmd_units(db, rest[0], as_json)
    elif cmd == "查点":
        if not rest:
            sys.exit("用法：查点 SM-DIV-DEC")
        cmd_point(idx, rest[0], as_json)
    elif cmd == "查词":
        if not rest:
            sys.exit("用法：查词 小数除法")
        cmd_search(idx, rest[0], as_json)
    elif cmd == "查前置":
        if not rest:
            sys.exit("用法：查前置 SM-DIV-APP")
        cmd_pre(idx, rest[0], as_json)
    elif cmd == "查错因":
        if not rest:
            sys.exit("用法：查错因 只把除数变整数")
        cmd_error(rest[0], as_json)
    elif cmd == "对错":
        if len(rest) < 2:
            sys.exit("用法：对错 SM-DIV-DEC 学生把除数变成整数被除数没变")
        cmd_match(idx, rest[0], rest[1], as_json)
    elif cmd == "查路":
        if not rest:
            sys.exit("用法：查路 SM-DIV-DEC")
        cmd_path(idx, rest[0], as_json)
    else:
        print(f"不认识的命令「{cmd}」")
        print(__doc__)


if __name__ == "__main__":
    main()
