#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
错题本 · 照片为主，OCR 辅助，结构化存储

设计原则（按需求：不搞复杂）：
  1. 照片是唯一真相。原图永远留着，不裁、不压、不改名。
  2. OCR 只做「辅助录入」，不做「自动判定」。读出来给人和助手看，不直接当真。
  3. 结构化只存 8 个字段，不多一个。

为什么 OCR 只做辅助 —— 本机实测（2026-10-28）：
  Apple Vision OCR 读中文题干很准（「一根 5.6 米长的绳子，每 0.8 米剪一段」一字不差），
  但**读数学算式不可靠**：
      1.2 ÷ 0.25  →  读成  1.2-0.25   /  1.2+0.25  /  1.2 0.25（除号直接丢）
      3.6 ÷ 0.12  →  读成  3.6-0.12
      x²          →  读成  x2
  关闭 usesLanguageCorrection 也一样，是 Vision 本身的能力边界。
  所以：算式必须核对。工具会在「存进去的算式」和「OCR 读出的算式」对不上时报警。

  视觉模型（gpt-6-astra / deepseek-v4-flash-vision-exp）实测 3/3 除号全对。
  有条件就让有视觉能力的助手读，比 OCR 准得多。

用法：
  python3 错题本.py 录入 照片.jpg --题 "1.2 ÷ 0.25 =" --学生 "0.048" --正确 "4.8" --知识点 SM-DIV-DEC
  python3 错题本.py 录入 照片.jpg                      # 只存照片 + OCR，题目等信息后补
  python3 错题本.py 列表                               # 所有错题
  python3 错题本.py 查 SM-DIV-DEC                      # 按知识点查
  python3 错题本.py 补 2026-10-28-001 --正确 "4.8"      # 补字段
  python3 错题本.py 生成                               # 生成可打印的错题卡 HTML
"""
import argparse
import datetime
import json
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BOARD = "04-错题卡"          # 固定板块
PHOTO_DIR = "照片"
DB_NAME = "错题本.json"

# 本机 OCR（Apple Vision）。找不到就跳过，不报错。
OCR_CANDIDATES = [
    "/Users/a1-6/Desktop/图片生成/课件自检/ocr",
    os.path.join(HERE, "ocr"),
]

# 算式里必须原样保留的符号。OCR 最容易错的就是这些。
MATH_SYMBOLS = ["÷", "×", "−", "+", "-", "=", "²", "³", "√", "%", ":", "(", ")"]


def root_dir():
    """错题本放在工作目录的 04-错题卡/ 下。"""
    for cand in (HERE, os.path.dirname(HERE)):
        p = os.path.join(cand, BOARD)
        if os.path.isdir(p):
            return p
    p = os.path.join(HERE, BOARD)
    os.makedirs(p, exist_ok=True)
    return p


def db_path():
    return os.path.join(root_dir(), DB_NAME)


def load_db():
    p = db_path()
    if not os.path.exists(p):
        return {"cards": []}
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def save_db(db):
    p = db_path()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def find_ocr():
    for c in OCR_CANDIDATES:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def run_ocr(img):
    """跑本机 OCR，返回 (纯文本, 是否可用)。"""
    exe = find_ocr()
    if not exe:
        return "", False
    try:
        out = subprocess.run([exe, img], capture_output=True, text=True, timeout=60)
        if out.returncode != 0:
            return "", False
        lines = []
        for ln in out.stdout.splitlines():
            m = re.match(r"\[[^\]]*\]\s*(.*)$", ln)
            if m and m.group(1).strip():
                lines.append(m.group(1).strip())
        return "\n".join(lines), True
    except (OSError, subprocess.SubprocessError):
        return "", False


def normalize(s):
    """把算式压成可比较的形式：去掉所有空白。"""
    return re.sub(r"\s+", "", s or "")


def symbol_diff(typed, ocr_text):
    """比对「填进去的算式」和「OCR 读出的文本」，找出可疑之处。"""
    if not ocr_text:
        return []
    t, o = normalize(typed), normalize(ocr_text)
    if not t:
        return []
    warns = []
    # 1) 填进去有除号，OCR 里没有 → 极可能 OCR 把 ÷ 读成了别的
    if "÷" in t and "÷" not in o:
        if re.search(r"[\d.]", t):
            warns.append("你填的算式有除号 ÷，但 OCR 读出的文字里没有 ÷ —— OCR 很可能把除号读成了 + 或 -（实测常见）。请对着照片再看一眼。")
    # 2) 填进去有乘号，OCR 读成 x
    if "×" in t and ("x" in o or "X" in o):
        warns.append("你填的算式有乘号 ×，OCR 读成了字母 x。以你填的为准，但要确认照片上确实是 ×。")
    # 3) 上标丢失
    for sup in ("²", "³"):
        if sup in t and sup not in o:
            warns.append(f"你填的算式有上标 {sup}，OCR 读出的文字里没有——上标常被读成普通数字。")
    # 4) 数字序列完全对不上
    tn = re.findall(r"\d+\.?\d*", t)
    on = re.findall(r"\d+\.?\d*", o)
    if tn and on and not set(tn) & set(on):
        warns.append(f"你填的算式里的数字（{'、'.join(tn[:3])}）在 OCR 文字里一个都没出现，可能对错了行。")
    return warns


def next_id(db):
    today = datetime.date.today().strftime("%Y-%m-%d")
    n = sum(1 for c in db["cards"] if c.get("日期") == today) + 1
    return f"{today}-{n:03d}"


def lookup_point(pid):
    """用知识点查询工具补名称、单元、候选错因。"""
    tool = os.path.join(HERE, "知识点查询.py")
    if not os.path.isfile(tool) or not pid:
        return None
    try:
        out = subprocess.run([sys.executable, tool, "查点", pid, "--json"],
                             capture_output=True, text=True, timeout=30)
        if out.returncode != 0:
            return None
        return json.loads(out.stdout)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
        return None


def cmd_add(args):
    db = load_db()
    img = args.photo or ""

    # 没照片这条路：学生手打题目。不是降级方案，是并列的一条路——
    # 卷子收上去了、不让拍、照片糊了，都可能，不能因为拍不了照就做不了错题卡。
    nophoto = args.nophoto or not img
    if nophoto:
        if not args.question:
            sys.exit("没有照片就必须给 --题：至少要有题目，否则这张卡以后没用。")
        img = ""
    else:
        if not os.path.isfile(img):
            sys.exit(f"找不到照片：{img}")

    rd = root_dir()
    pdir = os.path.join(rd, PHOTO_DIR)
    os.makedirs(pdir, exist_ok=True)

    card_id = next_id(db)

    if nophoto:
        dst_name = ""
        ocr_text, ocr_ok = "", False
    else:
        ext = os.path.splitext(img)[1].lower() or ".jpg"
        dst_name = card_id + ext
        dst = os.path.join(pdir, dst_name)
        shutil.copy2(img, dst)                  # 原图原样存，不改名不改内容
        ocr_text, ocr_ok = run_ocr(img)

    point = lookup_point(args.point) if args.point else None
    card = {
        "id": card_id,
        "日期": datetime.date.today().strftime("%Y-%m-%d"),
        "照片": f"{BOARD}/{PHOTO_DIR}/{dst_name}" if dst_name else "",
        "有原图": bool(dst_name),
        "题目": args.question or "",
        "学生答案": args.student or "",
        "正确答案": args.correct or "",
        "知识点": {
            "id": args.point or "",
            "名称": (point or {}).get("name", ""),
            "册": (point or {}).get("book", ""),
            "单元": (point or {}).get("unit", ""),
        },
        "错因": args.reason or "",
        "OCR原文": ocr_text,
        "OCR可用": ocr_ok,
        "来源": args.source or "",
    }
    db["cards"].append(card)
    save_db(db)

    print(f"已存入 {card_id}")
    if card["有原图"]:
        print(f"  照片：{card['照片']}")
    else:
        print(f"  照片：无（本题无原图，题目由学生手打）")
    if point:
        print(f"  知识点：{point.get('name')}（{point.get('book')} · {point.get('unit')}）")
    if ocr_ok:
        print(f"\nOCR 读出来的原文（**只作参考，算式不要直接信**）：")
        for ln in ocr_text.splitlines():
            print("   ", ln)
        warns = symbol_diff(card["题目"], ocr_text)
        if warns:
            print("\n⚠ 核对提醒：")
            for w in warns:
                print("   ·", w)
    elif card["有原图"]:
        print("\n（这台机器没找到 OCR 工具，照片已存，文字请自己填）")
    else:
        print("\n（这张卡没有原图，题目以你打的为准）")

    if not card["题目"]:
        print(f"\n下一步：python3 错题本.py 补 {card_id} --题 \"<照照片抄的算式>\" --正确 \"<答案>\"")
    return card_id


def cmd_fill(args):
    db = load_db()
    card = next((c for c in db["cards"] if c["id"] == args.id), None)
    if not card:
        sys.exit(f"没有 {args.id} 这张卡")
    changed = []
    for field, val in (("题目", args.question), ("学生答案", args.student),
                       ("正确答案", args.correct), ("错因", args.reason),
                       ("来源", args.source)):
        if val is not None:
            card[field] = val
            changed.append(field)
    if args.point:
        p = lookup_point(args.point)
        card["知识点"] = {"id": args.point,
                          "名称": (p or {}).get("name", ""),
                          "册": (p or {}).get("book", ""),
                          "单元": (p or {}).get("unit", "")}
        changed.append("知识点")
    save_db(db)
    print(f"{args.id} 已补：{'、'.join(changed) if changed else '（没有改动）'}")
    if card.get("题目"):
        warns = symbol_diff(card["题目"], card.get("OCR原文", ""))
        for w in warns:
            print("  ⚠", w)


def cmd_list(args):
    db = load_db()
    cards = db["cards"]
    if not cards:
        print("还没有错题。用「录入」加第一张。")
        return
    print(f"共 {len(cards)} 张错题卡\n")
    for c in cards:
        p = c.get("知识点") or {}
        print(f"{c['id']}  {c.get('题目') or '（题目未填）'}")
        bits = []
        if c.get("学生答案"):
            bits.append(f"学生答 {c['学生答案']}")
        if c.get("正确答案"):
            bits.append(f"正确 {c['正确答案']}")
        if p.get("名称"):
            bits.append(f"{p['名称']}（{p.get('册','')}）")
        if c.get("错因"):
            bits.append(c["错因"])
        if bits:
            print("    " + " · ".join(bits))
        print()


def cmd_query(args):
    db = load_db()
    key = args.key
    hits = [c for c in db["cards"]
            if key in (c.get("知识点") or {}).get("id", "")
            or key in (c.get("知识点") or {}).get("名称", "")
            or key in (c.get("题目") or "")
            or key in (c.get("错因") or "")]
    if not hits:
        print(f"没有跟「{key}」相关的错题。")
        return
    print(f"跟「{key}」相关 {len(hits)} 张：\n")
    for c in hits:
        print(f"  {c['id']}  {c.get('题目','')}  →  {c.get('错因','')}")


def cmd_build(args):
    """生成一张可打印的错题卡 HTML（单文件，离线可开）。"""
    db = load_db()
    cards = db["cards"]
    if not cards:
        sys.exit("还没有错题，先生成不了。")

    rows = []
    for c in cards:
        p = c.get("知识点") or {}
        photo_rel = c.get("照片", "")
        rows.append(f"""
  <article class="card">
    <div class="head">
      <span class="id">{c['id']}</span>
      <span class="date">{c.get('日期','')}</span>
    </div>
    <div class="q">{c.get('题目') or '<span class="miss">题目未填</span>'}</div>
    <div class="answers">
      <div><span class="k">学生答</span><span class="v wrong">{c.get('学生答案') or '—'}</span></div>
      <div><span class="k">正确</span><span class="v right">{c.get('正确答案') or '—'}</span></div>
    </div>
    <div class="meta">
      {f'<span class="tag">{p.get("名称")}</span><span class="tag dim">{p.get("册","")} · {p.get("单元","")}</span>' if p.get("名称") else ''}
      {f'<span class="tag err">{c["错因"]}</span>' if c.get("错因") else ''}
    </div>
    <div class="photo">{f'<img src="{photo_rel}" alt="{c["id"]}">' if photo_rel else '<span class="nophoto">本题无原图 · 题目由学生手打</span>'}</div>
  </article>""")

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>我的错题本</title>
<style>
:root{{--accent:#b8440a;--paper:#f6efe8;--ink:#1e1b19;--ink2:#7a7169;--line:#eadfd2;--card:#fff;}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--paper);color:var(--ink);
 font:16px/1.7 -apple-system,"PingFang SC","Hiragino Sans GB",sans-serif}}
.wrap{{max-width:820px;margin:0 auto;padding:32px 22px 70px}}
h1{{font-size:28px;margin:0 0 6px}}
.sub{{color:var(--ink2);font-size:14px;margin:0 0 26px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:14px;
 padding:18px 20px;margin:0 0 16px}}
.head{{display:flex;justify-content:space-between;font-size:12.5px;color:var(--ink2);margin-bottom:10px}}
.id{{font-variant-numeric:tabular-nums}}
.q{{font-size:19px;line-height:1.8;margin:0 0 14px;font-family:"Songti SC",serif}}
.answers{{display:flex;gap:26px;margin:0 0 12px;flex-wrap:wrap}}
.k{{font-size:12.5px;color:var(--ink2);margin-right:7px}}
.v{{font-weight:600;font-size:16.5px}}
.v.wrong{{color:#c0392b}}
.v.right{{color:#2f7d4f}}
.meta{{display:flex;gap:7px;flex-wrap:wrap;margin:0 0 12px}}
.tag{{font-size:12.5px;background:var(--paper);border-radius:20px;padding:3px 10px}}
.tag.dim{{color:var(--ink2)}}
.tag.err{{background:#fbeade;color:var(--accent)}}
.photo img{{max-width:100%;border-radius:8px;border:1px solid var(--line);display:block}}
.nophoto{{display:block;padding:10px 14px;background:#f7f4ee;border:1px dashed #d9cdbb;
  border-radius:8px;font-size:13px;color:#7a7169}}
.miss{{color:#c0392b;font-size:14px}}
@media print{{
 body{{background:#fff}} .wrap{{padding:0}} .card{{break-inside:avoid;page-break-inside:avoid}}
}}
</style>
</head>
<body>
<div class="wrap">
<h1>我的错题本</h1>
<p class="sub">共 {len(cards)} 张 · 生成于 {datetime.date.today()} · 每题都留着原图，答案不对可以回看照片</p>
{''.join(rows)}
</div>
</body>
</html>
"""
    out = os.path.join(root_dir(), "错题本.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"已生成：{out}")
    print(f"  {len(cards)} 张错题卡，单文件，离线双击能开，可直接打印")

    # 顺手刷新工作台
    upd = os.path.join(HERE, "_更新导航.py")
    if os.path.isfile(upd):
        try:
            subprocess.run([sys.executable, upd], capture_output=True, timeout=60)
            print("  工作台已刷新")
        except (OSError, subprocess.SubprocessError):
            pass


def main():
    ap = argparse.ArgumentParser(description="错题本：照片为主，OCR 辅助，结构化存储")
    sub = ap.add_subparsers(dest="cmd")

    a = sub.add_parser("录入", help="加一张错题（照片可选：拍不了照就 --无图 手打）")
    a.add_argument("photo", nargs="?", default="")
    a.add_argument("--无图", dest="nophoto", action="store_true",
                   help="没有照片，题目由学生手打。卡上会标明「本题无原图」")
    a.add_argument("--题", dest="question", default="")
    a.add_argument("--学生", dest="student", default="")
    a.add_argument("--正确", dest="correct", default="")
    a.add_argument("--知识点", dest="point", default="")
    a.add_argument("--错因", dest="reason", default="")
    a.add_argument("--来源", dest="source", default="")

    f = sub.add_parser("补", help="补/改一张卡的字段")
    f.add_argument("id")
    f.add_argument("--题", dest="question")
    f.add_argument("--学生", dest="student")
    f.add_argument("--正确", dest="correct")
    f.add_argument("--知识点", dest="point")
    f.add_argument("--错因", dest="reason")
    f.add_argument("--来源", dest="source")

    sub.add_parser("列表", help="列出所有错题")

    q = sub.add_parser("查", help="按知识点/关键词查")
    q.add_argument("key")

    sub.add_parser("生成", help="生成错题卡 HTML")

    args = ap.parse_args()
    if not args.cmd:
        print(__doc__)
        return
    {"录入": cmd_add, "补": cmd_fill, "列表": cmd_list,
     "查": cmd_query, "生成": cmd_build}[args.cmd](args)


if __name__ == "__main__":
    main()
