# PPT大师 · Bot 包（v1）

**这是什么**：一个可以转交的「Bot 定义 + 技能包」。把它发给对方，对方交给自己的 **chief（主 Bot）**，
chief 就能直接建出一个叫 **PPT大师** 的机器人，并装上它做 PPT 用的全部脚本、母版、质检门。

**不用装软件、不用申请 key 也能跑**：母版和可编辑 PPTX 全在本地算，零 API。
（只有"整页生图"和"AI 视觉验收"两条支线需要 key，可选。）

## 三步

1. 把整个 zip 发给对方。
2. 对方解压后，把 `CHIEF-INSTRUCTIONS.md` 和这个压缩包一起丢给 chief，说：**按这个文件建 PPT大师**。
3. chief 装完会跑 `skill/checks/smoke-test.sh`，全绿就算成功。

## 里面有什么

```
README.md              这份说明（人看）
CHIEF-INSTRUCTIONS.md  给 chief 的执行指令（复制粘贴即可）
bot/instructions.md    PPT大师 的完整系统提示词 —— 这个 Bot 的灵魂
bot/meta.json          名字 / 角色 / 建议模型
skill/                 PPT 技能本体（装到 ~/.agents/skills/ppt-master）
  SKILL.md             技能说明，agent 读这个
  master/              深色反白母版：base.css + 四种页型 + 无字主视觉
  scripts/             渲染 / 质检 / 可编辑 PPTX / 结构预览 五个脚本
  checks/smoke-test.sh 自检
  fonts/INSTALL.md     字体安装（思源宋体·黑体 6 字重）
  docs/技术底座.md      两条链路、API、踩坑
```

## 它做成过什么

- 深色反白母版四页（封面 / 章节目录 / 编号清单 / 两栏对照），3840×2160 + 矢量 PDF
- 可编辑 PPTX 两页：每个字都是原生文本框，表格是原生表格（改字会跟着走），视觉评审 8.6/10
- 三道自动门：字体真加载、几何无溢出/无重叠、正文≥22px；外加 AI 视觉评审

## 边界（先说清，省得失望）

- 不做「整页生图当 PPT」——那条路做不出识别度，已被验证否定。
- 字体是思源宋体/黑体。对方电脑没装会降级；要发给别人用 `--safe-font` 出宋体版。
- 这个包不含任何 API key，也不含任何人的聊天记录和记忆。
