# 母版 · 深色反白 B（2026-10-21 定版）

用户选定的版式手势：**深色反白**。这一页起，所有课件页都从这套母版长出来，不再逐页猜排版。

## 一眼看懂的规格

| 项 | 值 |
|---|---|
| 画幅 | 1920×1080（16:9），出图 1x / 2x，另出矢量 PDF |
| 网格 | 文字栏 x=104，宽 1150；图条 x=1320，宽 600；分界线 x=1319（1px） |
| 底色 | 夜 `#12110D` |
| 标题 | 米白 `#EDE7D8`，思源宋体 700 |
| 正文 | `#C9C3B6`，思源黑体，**24px / 行高 1.7**（硬门槛：正文 ≥22px） |
| 强调 | 砖红 `#C2543C`（大字）；小字号用亮一档 `#D4674E`，深底上才认得出 |
| 细线 | `rgba(237,231,216,.20)` |
| 字号阶梯 | 104 / 96 / 72 / 38 / 36 / 34 / 30 / 28 / 26 / 24 / 15 / 13（不许临时造新号） |

## 四种页型

| 文件 | 页型 | 结构 | 什么时候用 |
|---|---|---|---|
| `slides/s01-cover.html` | 封面 | 眉题 → 副题 → 104px 宋体主标 → 细线 → 两句引言 → 三列动作贴底 | 每讲一张 |
| `slides/s02-section.html` | 章节页 | 96px 主标 → 细线 → 引言 → 三条索引（编号/名词/一句解释） | 换主题、换章节 |
| `slides/s03-content-list.html` | 内容页 A | 72px 主标 → 细线 → 编号清单（3 条，可扩到 4–5 条） | 步骤、方法、要点 |
| `slides/s04-content-compare.html` | 内容页 B | 两栏对照 → 「可以直接这样说」话术 → 底部判断句；图条换成米色纸带引言 | 对比、纠错、金句 |

三页内容页共用同一条底线（页脚 y=995）和同一条右边线，所以混排时不会跳。

## 加一页的正确姿势

```bash
cd ~/.agents/skills/ppt-master
cp master/slides/s03-content-list.html master/slides/s05-xxx.html
# 改 <title>、眉题、h2、rows 里的文案；要换图就换 .strip img 的 src
PY=python3
$PY scripts/render_deck.py master/slides            # 全部渲
$PY scripts/render_deck.py master/slides s05-xxx    # 只渲这一页
```

产物落在 `out/`：`<名>.png`(1920) / `<名>-2x.png`(3840) / `<名>.pdf` /
`contact-sheet.png`(四宫格) / `master-deck.pdf`(按顺序合并) / `qa-report.json`。

## 两道门（不许跳过）

1. **几何门** `master/qa.js`（页面内自动跑）：
   - 思源宋体 / 思源黑体是否**真加载**（`document.fonts.check`）
   - 任何元素右溢越过图条、竖向下沉过 1016
   - 同栏相邻元素重叠或间距 <6px
   - 正文 <20px 直接报错
   结果写进 `<pre id="qa-out">`，`render_deck.py` 会解析，**有问题退出码 1**。

2. **视觉门** `scripts/review_visual.py`（KIE 视觉模型，外挂眼睛）：
   ```bash
   $PY scripts/review_visual.py out/s01-cover.png out/s02-section.png ...
   ```
   返回评分 + 具体扣分点。**它给 7–8 分是常态，9 分以上才算可商用**；
   最终审美由用户拍板，不要拿它的分数当"通过"。

## 踩过的坑（别再踩）

- **3:2 的图不能硬裁 16:9**：图条是 600×1080（竖），生图按 `1024x1536` 竖构图出，不要用横图去裁。
- **任何文字不许进图**：主视觉只出无字静物/质感；出完用 `review_visual.py --brief` 审一遍有没有字。
- **headless 截图会漏底**：macOS 上 `--window-size` 的视口比窗口少约 143px，直接截 1920×1080 会在底部留未重绘残影。`render_deck.py` 已改成「多给 240px 再裁」。
- **CSS 被行内样式覆盖**：改 base.css 没反应，先 grep 该页 `<style>` 里有没有同名规则（引号缩进那次就是这么翻车的）。
- **像素级对齐要量，不要看**：引号"“"有 40px 左字形边距，靠肉眼永远对不齐；用 PIL 扫墨色左沿再定 `margin-left`（现在是 -53px，引号墨沿 1384 vs 正文 1383）。

## 文件

```
master/
  base.css            设计令牌 + 四种页型的基础样式（改这里，全页跟着变）
  qa.js               几何门
  slides/s01..s04     四个页型
  assets/             图条素材（全部无字）：pencil-macro / desk-still-life / desk-tools
scripts/
  render_deck.py      渲染 + 质检 + 拼图 + 合并 PDF
  review_visual.py    视觉评审（KIE gpt-6-astra）
  verify_text.py      生图文字验收门（整页生图那条线用）
out/                  产物
```
