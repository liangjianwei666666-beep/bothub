/* 母版自动质检：字体真加载 / 溢出 / 元素重叠 / 最小间距 / 正文字号门
   结果写进 <pre id="qa-out">，用 chrome --dump-dom 取回 */
window.addEventListener('load', async () => {
  const r = { problems: [], boxes: {}, fonts: {} };
  try { await document.fonts.ready } catch (e) {}

  r.fonts.serif = document.fonts.check('700 100px "Noto Serif SC"');
  r.fonts.sans  = document.fonts.check('400 20px "Noto Sans SC"');
  if (!r.fonts.serif) r.problems.push('思源宋体未加载');
  if (!r.fonts.sans)  r.problems.push('思源黑体未加载');

  const col = document.querySelector('.c');
  const cr = col.getBoundingClientRect();

  // 1) 所有元素必须在文字栏内、不越上图条
  [...col.querySelectorAll('*')].forEach(el => {
    const b = el.getBoundingClientRect();
    const key = (el.className || el.tagName).toString().replace(/\s+/g, '.');
    if (b.width === 0 || b.height === 0) return;
    if (b.right > cr.right + 0.5) r.problems.push(key + ' 右溢出 ' + Math.round(b.right - cr.right) + 'px（越过图条）');
    if (b.bottom > 1016.5) r.problems.push(key + ' 竖向溢出 ' + Math.round(b.bottom - 1016) + 'px');
    r.boxes[key] = { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height) };
  });

  // 2) 流式版面：相邻子元素不得重叠，间距不得小于 6px
  const gaps = {};
  [...col.children].forEach((el, i) => {
    const next = col.children[i + 1];
    if (!next) return;
    const a = el.getBoundingClientRect(), b = next.getBoundingClientRect();
    const gap = Math.round(b.top - a.bottom);
    const key = (el.className || el.tagName) + '→' + (next.className || next.tagName);
    gaps[key] = gap;
    if (gap < 0) r.problems.push('重叠 ' + key + ' ' + gap + 'px');
    else if (gap < 6 && gap >= 0) r.problems.push('间距过小 ' + key + ' ' + gap + 'px');
  });
  r.gaps = gaps;

  // 3) 字号门：正文 ≥20px
  col.querySelectorAll('.desc,.t,.dek,.body-text').forEach(el => {
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (fs < 20) r.problems.push('正文字号 ' + fs + 'px < 20px @ .' + el.className);
  });

  // 4) 图条不得压住文字栏
  const strip = document.querySelector('.strip');
  if (strip && strip.getBoundingClientRect().left < cr.right - 0.5) {
    r.problems.push('图条压字：strip.left ' + Math.round(strip.getBoundingClientRect().left) + ' < 栏右 ' + Math.round(cr.right));
  }

  document.getElementById('qa-out').textContent = JSON.stringify(r);
});
