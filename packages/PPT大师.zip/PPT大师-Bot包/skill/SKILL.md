---
name: ppt-master
description: 做高端视觉 PPT 的技能，含深色反白母版（1920×1080，四页型）、HTML 渲染与矢量 PDF、原生可编辑 PPTX 生成、结构预览器和两道质检门。当用户要做课件/分享/汇报的幻灯片、说"排版不够高级""要能改字"，或要修这里已有的母版时使用。
---

# PPT 技能（PPT大师 专用）

两条路线，一套令牌：

- **HTML 母版**：`master/` —— 版式用 CSS 写死，3840×2160 出图 + 矢量 PDF，视觉上限最高
- **可编辑 PPTX**：`scripts/build_pptx.py` —— 原生文本框/表格，打开就能改字

## 什么时候用哪条

| 需求 | 走哪条 |
|---|---|
| 自己讲、要好看、线上传播 | HTML 母版 |
| 要发给别人改、走正式流程 | 可编辑 PPTX |
| 两者都要 | 先出 HTML 定版式，再用同一套坐标出 PPTX（1px = 6350 EMU，字号 1px = 0.5pt） |

## 目录

```
master/base.css        设计令牌 + 四种页型（改这里整套跟着变）
master/qa.js           几何门：字体真加载 / 溢出 / 重叠 / 间距 / 正文≥22px
master/slides/         s01 封面 · s02 章节 · s03 编号清单 · s04 两栏对照
master/assets/         无字主视觉（全部不含任何文字）
scripts/render_deck.py HTML → PNG(1x/2x) + PDF + 四宫格 + 合并PDF + 跑几何门
scripts/build_pptx.py  可编辑 PPTX（表格已设 No Style No Grid）
scripts/pptx_preview.py 从 .pptx 反读成图（没有 Office 时的验收手段）
scripts/review_visual.py AI 视觉评审（需 KIE key，可选）
scripts/verify_text.py  生图错字门（需 KIE key，可选）
checks/smoke-test.sh   环境自检
fonts/INSTALL.md       思源宋体/黑体安装
docs/技术底座.md        链路、API、踩坑
```

## 最短上手

```bash
bash checks/smoke-test.sh                 # 先确认环境
python3 scripts/render_deck.py master/slides
python3 scripts/build_pptx.py             # 出可编辑 PPTX
```

产物默认在 `out/`。要改内容就复制一页母版改文案，**不要新写一套 CSS**。

## 硬规矩（细节在 master/README.md 与 docs/技术底座.md）

1. 版式用代码写死，不让模型画版式
2. 任何文字不进图；生图只出无字主视觉
3. 正文 ≥22px（1920 画布），注释 ≥15px
4. 每页必过几何门；有 key 时再过视觉门
5. 3:2/超幅图不许硬裁 16:9
