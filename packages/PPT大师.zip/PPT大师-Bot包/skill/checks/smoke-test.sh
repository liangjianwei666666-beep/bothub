#!/usr/bin/env bash
# PPT 技能自检：环境 + 依赖 + 母版完整性 + 真渲染一页 + 真生成一份 PPTX
# 用法：bash checks/smoke-test.sh        （缺字体算警告，不影响出图）
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT" || exit 1
ok=0; bad=0; warn=0
FALLBACK_PY=""
pass(){ printf "  \033[32m✓\033[0m %-8s %s\n" "$1" "$2"; ok=$((ok+1)); }
fail(){ printf "  \033[31m✗\033[0m %-8s %s\n" "$1" "$2"; bad=$((bad+1)); }
note(){ printf "  \033[33m!\033[0m %-8s %s\n" "$1" "$2"; warn=$((warn+1)); }
echo "== PPT 技能自检 · $ROOT"

# 1 python 依赖
# 优先用带 python-pptx + Pillow 的那个解释器；DSH 内置 runtime 优先
PY=""
FALLBACK_PY=""
cands="${PYTHON:-}"
for c in "$cands" python3 python \
  "$DSH_HOME"/dsh-runtimes/*/dependencies/python/bin/python3 \
  "$HOME"/.dsh/dsh-runtimes/*/dependencies/python/bin/python3; do
  [ -n "$c" ] || continue
  if [ -x "$c" ] || command -v "$c" >/dev/null 2>&1; then
    if "$c" -c "import pptx, PIL" >/dev/null 2>&1; then PY="$c"; break; fi
    [ -z "$FALLBACK_PY" ] && FALLBACK_PY="$c"
  fi
done
if [ -n "$PY" ]; then pass python "$($PY -V 2>&1) + python-pptx + Pillow"
else
  fail python "没有同时具备 python-pptx 和 Pillow 的解释器（${FALLBACK_PY:-未找到 python3}）；pip install python-pptx Pillow"
  PY="${FALLBACK_PY:-python3}"
fi

# 2 浏览器（渲染用）
CH="${CHROME:-}"
if [ -z "$CH" ]; then for c in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
  "/Applications/Chromium.app/Contents/MacOS/Chromium" "$(command -v google-chrome 2>/dev/null)" \
  "$(command -v chromium 2>/dev/null)"; do [ -n "$c" ] && [ -x "$c" ] && CH="$c" && break; done; fi
if [ -n "$CH" ] && [ -x "$CH" ]; then pass chrome "$CH"; export CHROME="$CH"
else fail chrome "找不到 Chrome/Edge/Chromium（装一个，或 export CHROME=/路径）"; fi

# 3 字体
FOUND=$(ls ~/Library/Fonts /Library/Fonts ~/.local/share/fonts ~/.fonts 2>/dev/null | grep -ciE "noto(serif|sans)sc" || true)
if [ "${FOUND:-0}" -ge 4 ]; then pass fonts "找到 $FOUND 个思源字体文件"
else note fonts "只找到 ${FOUND:-0} 个思源字体（建议按 fonts/INSTALL.md 装；不装会降级）"; fi

# 4 母版完整性
need="master/base.css master/qa.js master/slides/s01-cover.html master/slides/s02-section.html master/slides/s03-content-list.html master/slides/s04-content-compare.html master/assets/pencil-macro.png master/assets/desk-still-life.png master/assets/desk-tools.png"
miss=""; for f in $need; do [ -f "$f" ] || miss="$miss $f"; done
if [ -z "$miss" ]; then pass master "母版 9 个核心文件齐"
else fail master "缺:$miss"; fi

# 5 真渲染一页
if [ -n "${CHROME:-}" ] && [ -n "$PY" ]; then
  if "$PY" scripts/render_deck.py master/slides s01-cover >/tmp/ppt-smoke-render.log 2>&1 && [ -f out/s01-cover.png ]; then
    pass render "已生成 out/s01-cover.png"
  else fail render "渲染失败，看 /tmp/ppt-smoke-render.log"; fi
fi

# 6 真生成可编辑 PPTX
if [ -n "$PY" ]; then
  if "$PY" scripts/build_pptx.py --out /tmp/ppt-smoke.pptx >/tmp/ppt-smoke-pptx.log 2>&1 && [ -s /tmp/ppt-smoke.pptx ]; then
    SZ=$(wc -c < /tmp/ppt-smoke.pptx | tr -d ' ')
    pass pptx "已生成 /tmp/ppt-smoke.pptx (${SZ} 字节)"
  else fail pptx "生成失败，看 /tmp/ppt-smoke-pptx.log"; fi
fi

echo "== 通过 $ok / 警告 $warn / 失败 $bad"
[ "$bad" -eq 0 ] && echo "== 环境可用，可以开工" || echo "== 有硬失败项，先修再开工"
exit $([ "$bad" -eq 0 ] && echo 0 || echo 1)
