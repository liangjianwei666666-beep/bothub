# 字体安装（思源宋体 / 思源黑体）

这套母版的高级感有一半来自字体：**标题思源宋体 700，正文思源黑体 400**。
不装也能跑，但会降级到系统宋体/黑体，层次会塌；可编辑 PPTX 发给别人时也会变。

## 要装的 6 个字重

```
NotoSerifSC-Regular.otf   NotoSerifSC-SemiBold.otf   NotoSerifSC-Bold.otf
NotoSansSC-Regular.otf    NotoSansSC-Medium.otf      NotoSansSC-Bold.otf
```

## macOS（不需要管理员密码）

```bash
mkdir -p ~/Library/Fonts
cp NotoSerifSC-*.otf NotoSansSC-*.otf ~/Library/Fonts/
```

## Linux

```bash
mkdir -p ~/.local/share/fonts && cp *.otf ~/.local/share/fonts/ && fc-cache -f
```

## 下载地址

Google Fonts（OFL 许可，可自由使用）：搜 `Noto Serif SC` / `Noto Sans SC`，
在字体详情页点 **Download family**，解压后取 `static/` 里的 OTF/TTF。

## 验证

```bash
ls ~/Library/Fonts | grep -i noto
```

Chrome 里可用 `document.fonts.check('700 100px "Noto Serif SC"')` 验证是否真加载（母版 `qa.js` 每页都会验）。

## 一条重要提醒

可编辑 PPTX 里的字体是**按名字引用的**：对方电脑没装思源宋体，PowerPoint 会自动替换成别的宋体，字宽会变、可能换行。
要发给不确定环境的人，用：

```bash
python3 scripts/build_pptx.py --safe-font     # 宋体 Songti SC / 黑体 Heiti SC
```
