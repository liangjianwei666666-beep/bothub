#!/usr/bin/env python3
"""母版渲染 + 质检 + 拼图
用法：
  python3 scripts/render_deck.py master/slides            # 渲染全部
  python3 scripts/render_deck.py master/slides s01-cover  # 只渲一页
产物：out/<name>.png(1x) out/<name>-2x.png out/<name>.pdf out/contact-sheet.png out/qa-report.json
退出码：0 全部通过；1 有质检问题
"""
import json, os, re, subprocess, sys
from pathlib import Path

import os
CHROME = os.environ.get("CHROME") or next(
    (c for c in ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                 "/Applications/Chromium.app/Contents/MacOS/Chromium") if os.path.exists(c)),
    "google-chrome")
FONT_BOLD = os.path.expanduser("~/Library/Fonts/NotoSansSC-Bold.otf")
W, H = 1920, 1080

def chrome(args):
    return subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox",
                           "--user-data-dir=/tmp/chr-ppt-master", "--hide-scrollbars",
                           "--virtual-time-budget=6000"] + args,
                          capture_output=True, text=True)

def shot(html: Path, out: Path, scale: int):
    url = html.resolve().as_uri()
    chrome([f"--force-device-scale-factor={scale}", f"--window-size={W},{H}",
            f"--screenshot={out.resolve()}", url])

def pdf(html: Path, out: Path):
    url = html.resolve().as_uri()
    chrome(["--no-pdf-header-footer", f"--print-to-pdf={out.resolve()}", url])

def qa(html: Path):
    r = chrome(["--dump-dom", html.resolve().as_uri()])
    m = re.search(r'<pre id="qa-out">(.*?)</pre>', r.stdout, re.S)
    if not m or not m.group(1).strip():
        return {"problems": ["QA 脚本没跑出结果（#qa-out 为空）"], "fonts": {}, "boxes": {}}
    return json.loads(m.group(1))

def contact_sheet(rows, dest: Path):
    from PIL import Image, ImageDraw, ImageFont
    gut, cols = 16, 2
    cw = (W - gut * (cols + 1)) // cols
    ch = round(cw * H / W)
    lines = (len(rows) + cols - 1) // cols
    sh = gut + lines * (ch + gut)
    sheet = Image.new("RGB", (W, sh), "#0B0A08")
    d = ImageDraw.Draw(sheet)
    try:
        f = ImageFont.truetype(FONT_BOLD, 22)
    except Exception:
        f = ImageFont.load_default()
    for i, (name, path) in enumerate(rows):
        im = Image.open(path).convert("RGB").resize((cw, ch), Image.LANCZOS)
        x = gut + (i % cols) * (cw + gut)
        y = gut + (i // cols) * (ch + gut)
        sheet.paste(im, (x, y))
        d.rectangle([x, y, x + cw - 1, y + ch - 1], outline="#2A2822")
        d.text((x + 14, y + ch - 34), name, font=f, fill="#C2543C")
    sheet.save(dest)

def merge_pdfs(out: Path, stems):
    """按顺序合成一份 PDF。pypdf 只在系统 python3 里，所以单独起一个进程。"""
    import subprocess as sp
    code = (
        "from pypdf import PdfWriter; import sys, pathlib\n"
        "o=pathlib.Path(sys.argv[1]); w=PdfWriter()\n"
        "[w.append(str(o/f'{s}.pdf')) for s in sys.argv[2:]]\n"
        "w.write(str(o/'master-deck.pdf')); w.close()\n"
        "from pypdf import PdfReader; print('PDF',len(PdfReader(str(o/'master-deck.pdf')).pages),'页')"
    )
    r = sp.run(["/usr/bin/python3", "-c", code, str(out)] + stems, capture_output=True, text=True)
    print((r.stdout or r.stderr).strip())


def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else "master/slides")
    only = sys.argv[2:] 
    out = root.parent.parent / "out"
    out.mkdir(parents=True, exist_ok=True)
    slides = sorted(p for p in root.glob("*.html") if not only or p.stem in only)
    if not slides:
        sys.exit("没找到 slide")
    report, rows, bad = {}, [], 0
    for s in slides:
        st = s.stem
        shot(s, out / f"{st}.png", 1)
        shot(s, out / f"{st}-2x.png", 2)
        pdf(s, out / f"{st}.pdf")
        res = qa(s)
        report[st] = res
        probs = res.get("problems", [])
        for suf, want in (("", (W, H)), ("-2x", (W * 2, H * 2))):
            from PIL import Image
            got = Image.open(out / f"{st}{suf}.png").size
            if got != want:
                print(f"  ✗ {st}{suf}.png 尺寸 {got} != {want}"); bad += 1
        print(f"\n■ {st}  字体 宋{res.get('fonts',{}).get('serif')} 黑{res.get('fonts',{}).get('sans')}")
        print("  通过" if not probs else "  ✗ " + "\n  ✗ ".join(probs))
        if probs:
            bad += 1
        rows.append((st, out / f"{st}.png"))
    contact_sheet(rows, out / "contact-sheet.png")
    merge_pdfs(out, [s for s, _ in rows])
    (out / "qa-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"\n拼图 → {out/'contact-sheet.png'}")
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
