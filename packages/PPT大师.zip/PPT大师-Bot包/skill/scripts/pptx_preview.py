#!/usr/bin/env python3
"""PPTX 结构预览器 —— 本机没有 PowerPoint / LibreOffice，用它把 .pptx 反读成图。

做法：读 pptx 里每个形状的真实坐标/字号/颜色，转成绝对定位的 HTML 再截图。
所以预览反映的是**文件里真有的东西**（形状、文字、图片、表格），不是另一套设计稿。
局限：文字换行用浏览器引擎算，和 PowerPoint 会有几个像素的差异；渐变/阴影为近似。

用法：python3 scripts/pptx_preview.py out/editable-sample.pptx [--out out/preview]
"""
import argparse, hashlib, subprocess, sys
from pathlib import Path

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from lxml import etree

import os
CHROME = os.environ.get("CHROME") or next(
    (c for c in ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                 "/Applications/Chromium.app/Contents/MacOS/Chromium") if os.path.exists(c)),
    "google-chrome")
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
ROOT = Path(__file__).resolve().parent.parent
CACHE = Path("/tmp/ppt-preview-cache")


def emu2px(v):
    return round(v / 6350, 2)


def rgb_of(color_format):
    try:
        c = color_format.rgb
        return "#%02X%02X%02X" % (c[0], c[1], c[2])
    except Exception:
        return None


def alpha_of(shape_fill_xml):
    al = shape_fill_xml.find(f".//{A}srgbClr/{A}alpha") if shape_fill_xml is not None else None
    return int(al.get("val")) / 100000 if al is not None else 1.0


def pic_to_file(pic):
    """按 crop 参数把图片裁成实际可见部分，缓存复用。"""
    CACHE.mkdir(parents=True, exist_ok=True)
    blob = pic.image.blob
    key = hashlib.md5(blob).hexdigest()[:12]
    src = CACHE / f"{key}.png"
    if not src.exists():
        src.write_bytes(blob)
    cl, cr, ct, cb = (pic.crop_left or 0), (pic.crop_right or 0), (pic.crop_top or 0), (pic.crop_bottom or 0)
    if not any((cl, cr, ct, cb)):
        return src
    out = CACHE / f"{key}-{cl:.3f}-{cr:.3f}-{ct:.3f}-{cb:.3f}.png"
    if not out.exists():
        from PIL import Image
        im = Image.open(src).convert("RGB")
        w, h = im.size
        box = (round(w * cl), round(h * ct), round(w * (1 - cr)), round(h * (1 - cb)))
        im.crop(box).save(out)
    return out


def para_css(p, default_size=24):
    runs = [r for r in p.runs]
    if not runs:
        return None
    r0 = runs[0]
    size_pt = r0.font.size.pt if r0.font.size else default_size / 2
    size_px = size_pt * 2
    color = rgb_of(r0.font.color) or "#000"
    fam = r0.font.name or "Noto Sans SC"
    weight = "700" if r0.font.bold else "400"
    spc = r0._r.get_or_add_rPr().get("spc")
    track = f"letter-spacing:{int(spc)/100*2:.2f}px;" if spc else ""
    lh = p.line_spacing
    lh_css = f"line-height:{lh};" if isinstance(lh, float) else "line-height:1.25;"
    before = p.space_before.pt * 2 if p.space_before is not None else 0
    after = p.space_after.pt * 2 if p.space_after is not None else 0
    html_runs = []
    for r in runs:
        c = rgb_of(r.font.color) or color
        w = "700" if r.font.bold else "400"
        s = r.font.size.pt * 2 if r.font.size else size_px
        html_runs.append(f'<span style="color:{c};font-weight:{w};font-size:{s}px">{esc(r.text)}</span>')
    al = p.alignment
    align = "left"
    if al is not None and str(al).startswith("RIGHT"):
        align = "right"
    elif al is not None and str(al).startswith("CENTER"):
        align = "center"
    return (f'<p style="margin:{before}px 0 {after}px;{lh_css}{track}font-size:{size_px}px;'
            f'font-family:\'{fam}\',serif;text-align:{align}">' + "".join(html_runs) + "</p>")


def esc(t):
    return (t or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")


def render_slide(slide, idx):
    out = []
    for sh in slide.shapes:
        try:
            x, y = emu2px(sh.left or 0), emu2px(sh.top or 0)
            w, h = emu2px(sh.width or 0), emu2px(sh.height or 0)
        except Exception:
            continue

        if sh.shape_type == MSO_SHAPE_TYPE.PICTURE:
            f = pic_to_file(sh)
            out.append(f'<img src="{f}" style="position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;object-fit:cover">')

        elif sh.has_table if hasattr(sh, "has_table") else False:
            tbl = sh.table
            colw = [emu2px(c.width) for c in tbl.columns]
            rowh = [emu2px(r.height) for r in tbl.rows]
            cy = y
            for ri, row in enumerate(tbl.rows):
                cx = x
                for ci, cell in enumerate(row.cells):
                    fill = rgb_of(cell.fill.fore_color) if cell.fill.type == 1 else "#ffffff"
                    ml = emu2px(cell.margin_left or 0)
                    mt = emu2px(cell.margin_top or 0)
                    inner = "".join(para_css(p) or "" for p in cell.text_frame.paragraphs)
                    out.append(
                        f'<div style="position:absolute;left:{cx}px;top:{cy}px;width:{colw[ci]}px;height:{rowh[ri]}px;'
                        f'background:{fill or "#fff"};padding:{mt}px 0 0 {ml}px;box-sizing:border-box;overflow:hidden">{inner}</div>')
                    cx += colw[ci]
                cy += rowh[ri]

        else:
            fill = None
            grad = None
            if sh.fill.type is not None and str(sh.fill.type).startswith("SOLID"):
                fill = rgb_of(sh.fill.fore_color)
                al = alpha_of(sh.fill._xPr)
                if fill and al < 1:
                    r, g, b = int(fill[1:3], 16), int(fill[3:5], 16), int(fill[5:7], 16)
                    fill = f"rgba({r},{g},{b},{al:.2f})"
            elif sh.fill.type is not None and str(sh.fill.type).startswith("GRADIENT"):
                gs = sh.fill.gradient_stops
                c0, c1 = rgb_of(gs[0].color) or "#000", rgb_of(gs[1].color) or "#000"
                a0 = alpha_of(sh.fill._xPr)
                r, g, b = int(c0[1:3], 16), int(c0[3:5], 16), int(c0[5:7], 16)
                grad = f"linear-gradient(90deg, rgba({r},{g},{b},{a0:.2f}) 0%, rgba({r},{g},{b},0) 55%, rgba({r},{g},{b},0) 100%)"
            style = f"position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;"
            bg = f"background:{grad};" if grad else (f"background:{fill};" if fill else "")
            inner = ""
            if sh.has_text_frame and sh.text_frame.text.strip():
                inner = "".join(para_css(p) or "" for p in sh.text_frame.paragraphs)
            out.append(f'<div style="{style}{bg}">{inner}</div>')

    return (f'<section style="position:relative;width:1920px;height:1080px;overflow:hidden;'
            f'background:#12110D;font-family:\'Noto Sans SC\'">' + "".join(out) + "</section>")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx")
    ap.add_argument("--out", default=str(ROOT / "out"))
    a = ap.parse_args()
    prs = Presentation(a.pptx)
    outdir = Path(a.out)
    outdir.mkdir(parents=True, exist_ok=True)
    from PIL import Image
    for i, slide in enumerate(prs.slides, 1):
        html = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><style>
@page{{size:1920px 1080px;margin:0}}
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:1920px;height:1080px;overflow:hidden;background:#12110D}}
p{{white-space:pre-wrap}}
</style></head><body>{render_slide(slide, i)}</body></html>"""
        hp = outdir / f"pptx-page{i}.html"
        hp.write_text(html, encoding="utf-8")
        png = outdir / f"pptx-page{i}.png"
        pad = 240
        subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox",
                        "--user-data-dir=/tmp/chr-ppt-preview", "--hide-scrollbars",
                        "--force-device-scale-factor=2", f"--window-size=1920,{1080+pad}",
                        f"--screenshot={png.resolve()}", hp.resolve().as_uri()],
                       capture_output=True, text=True)
        im = Image.open(png)
        im = im.crop((0, 0, 3840, 2160)).resize((1920, 1080), Image.LANCZOS)
        im.save(png)
        print(f"预览 → {png}  {im.size}")


if __name__ == "__main__":
    main()
