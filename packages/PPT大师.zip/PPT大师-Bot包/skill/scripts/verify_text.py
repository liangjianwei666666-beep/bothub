#!/usr/bin/env python3
"""生图验收门：把生成的幻灯片图片交给视觉模型逐字读出来，和预期文案对账。

为什么要有这道门：整页生图的 PPT，最大风险不是难看，是**中文错字**。
一张 20 页的课件，错一个字就得重做那一页，人工逐页看很费眼。
这道门把"读图"变成机器活：图进 → 读出文字 → 和预期比 → 不通过就退出码非 0。

用法：
    python3 verify_text.py 图片.png --expect "分数加法为什么先通分" --expect "同分母"
    python3 verify_text.py 图片.png --expects-json expects.json   # ["标题","副标题",...]
    python3 verify_text.py 图片.png                                # 只读，不校验

退出码：0 = 全部命中；1 = 有缺失/不匹配；2 = 调用失败。
"""
import argparse
import base64
import io
import json
import os
import re
import sys
import urllib.request

KIE_BASE = "https://api.kie.ai"
VISION_MODEL = os.environ.get("PPT_VISION_MODEL", "gpt-6-astra")


def kie_key() -> str:
    """KIE key：先环境变量，再本地文件。"""
    k = os.environ.get("KIE_API_KEY", "").strip()
    if k:
        return k
    p = os.path.expanduser("~/.config/kie/api-key")
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    sys.exit("找不到 KIE key：设 KIE_API_KEY 或放 ~/.config/kie/api-key")


def shrink(path: str, max_side: int = 1100) -> str:
    """缩到 1100px 再发，省 token 也不影响认字。"""
    from PIL import Image

    im = Image.open(path).convert("RGB")
    im.thumbnail((max_side, max_side))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode()


def read_text(path: str) -> str:
    b64 = shrink(path)
    prompt = (
        "把这张图里出现的所有中文/英文文字逐字抄下来，保持原有顺序，一行一条。"
        "不要翻译，不要解释，不要补充图里没有的字。看不清的字写 [?]。"
        "最后另起一行：如果文字渲染正常写 TEXT_OK，有错字或乱码写 TEXT_BROKEN。"
    )
    body = json.dumps({
        "model": VISION_MODEL,
        "input": [{"role": "user", "content": [
            {"type": "input_text", "text": prompt},
            {"type": "input_image", "image_url": "data:image/jpeg;base64," + b64},
        ]}],
        "max_output_tokens": 1200,
    }).encode()

    req = urllib.request.Request(
        KIE_BASE + "/openai/v1/responses",
        data=body,
        headers={
            "Authorization": "Bearer " + kie_key(),
            "Content-Type": "application/json",
            # 不加这条拿到的是 SSE 流；加了拿整包 JSON，解析简单。
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=180) as r:
        raw = r.read().decode("utf-8", "replace")

    # 兼容两种返回：整包 JSON / SSE 流
    if raw.lstrip().startswith("event:"):
        out = []
        for line in raw.splitlines():
            if not line.startswith("data: "):
                continue
            try:
                ev = json.loads(line[6:])
            except Exception:
                continue
            if ev.get("type") == "response.output_text.delta":
                out.append(ev.get("delta", ""))
        return "".join(out)

    doc = json.loads(raw)
    if "output_text" in doc:
        return doc["output_text"]
    parts = []
    for item in doc.get("output", []):
        for c in item.get("content", []):
            if c.get("type") in ("output_text", "text"):
                parts.append(c.get("text", ""))
    return "".join(parts)


def norm(s: str) -> str:
    """比对前归一：去空白、去标点、英文小写。中文字符本身一个不动。"""
    return re.sub(r"[\s，。、；：！？,.;:!?（）()\[\]「」“”\"'']", "", s).lower()


def main() -> int:
    ap = argparse.ArgumentParser(description="生图文字验收门")
    ap.add_argument("image")
    ap.add_argument("--expect", action="append", default=[], help="预期出现的一段文字，可重复")
    ap.add_argument("--expects-json", help='JSON 文件，内容是字符串数组')
    ap.add_argument("--dump", help="把读到的文字另存为 txt")
    a = ap.parse_args()

    if not os.path.exists(a.image):
        sys.exit("图片不存在: " + a.image)

    expects = list(a.expect)
    if a.expects_json:
        expects += json.load(open(a.expects_json, encoding="utf-8"))

    try:
        got = read_text(a.image)
    except Exception as e:
        print("VISION_FAILED:", e, file=sys.stderr)
        return 2

    if a.dump:
        open(a.dump, "w", encoding="utf-8").write(got)

    lines = [l.strip() for l in got.splitlines() if l.strip()]
    print("── 图里读到的文字 ──")
    for l in lines:
        print("  " + l)

    broken = "TEXT_BROKEN" in got.upper().replace(" ", "")
    ok = True
    if expects:
        whole = norm(got)
        print("── 对账 ──")
        for e in expects:
            hit = norm(e) in whole
            print(("  ✓ " if hit else "  ✗ 缺失: ") + e)
            ok = ok and hit

    if broken:
        print("  ✗ 模型自评：TEXT_BROKEN")
        ok = False

    print("VERDICT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
