#!/usr/bin/env python3
"""可编辑 PPTX 生成器 · 深色反白母版

设计原则：
  1) 每一个字都是原生文本框里的 run，不是图片 —— 打开就能改
  2) 坐标和字号直接沿用 HTML 母版（1920×1080 px → 1px = 6350 EMU，字号 1px = 0.5pt）
  3) 母版里的"细线"用极薄矩形画，不用边框，缩放时不会忽然变粗

用法：python3 scripts/build_pptx.py [--safe-font] [--out 路径]
  --safe-font  宋体换成本机通用宋体（发给没装思源宋体的人时用）
"""
import argparse
import sys
from pathlib import Path

from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from lxml import etree

W_PX, H_PX = 1920, 1080
EMU_PER_PX = 6350

NIGHT      = RGBColor(0x12, 0x11, 0x0D)
PAPER      = RGBColor(0xED, 0xE7, 0xD8)
BODY       = RGBColor(0xC9, 0xC3, 0xB6)
DIM        = RGBColor(0x9A, 0x94, 0x84)
DIM2       = RGBColor(0xA8, 0xA2, 0x94)
RED        = RGBColor(0xC2, 0x54, 0x3C)
RED_SMALL  = RGBColor(0xD4, 0x67, 0x4E)
RULE       = RGBColor(0x3E, 0x3A, 0x33)   # rgba(237,231,216,.20) 压在夜色上的合成值
WHITE_HI   = RGBColor(0xF2, 0xEE, 0xE4)

ROOT = Path(__file__).resolve().parent.parent
SERIF = "Noto Serif SC"
SANS = "Noto Sans SC"
NS = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}


def px(v):
    return Emu(int(round(v * EMU_PER_PX)))


def pt(px_value):
    return Pt(px_value * 0.5)


def set_tracking(run, font_px, em):
    """字距：OOXML 的 spc 单位是 1/100 pt。"""
    rpr = run._r.get_or_add_rPr()
    rpr.set("spc", str(int(round(font_px * 0.5 * em * 100))))


def set_alpha(color_elm_parent, alpha):
    """给某个色值元素插 <a:alpha>（python-pptx 没有透明度 API）。"""
    a = etree.SubElement(color_elm_parent, "{http://schemas.openxmlformats.org/drawingml/2006/main}alpha")
    a.set("val", str(int(round(alpha * 100000))))


def no_line(shape):
    shape.line.fill.background()


def rect(slide, x, y, w, h, color, line=False):
    from pptx.enum.shapes import MSO_SHAPE
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, px(x), px(y), px(w), px(h))
    s.fill.solid()
    s.fill.fore_color.rgb = color
    if not line:
        no_line(s)
    s.shadow.inherit = False
    return s


def textbox(slide, x, y, w, h, anchor=MSO_ANCHOR.TOP, wrap=True):
    tb = slide.shapes.add_textbox(px(x), px(y), px(w), px(h))
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    # 关掉自动收缩，避免 PowerPoint 自己改字号
    bodyPr = tf._txBody.find("{http://schemas.openxmlformats.org/drawingml/2006/main}bodyPr")
    for tag in ("normAutofit", "spAutoFit"):
        for e in bodyPr.findall("{http://schemas.openxmlformats.org/drawingml/2006/main}" + tag):
            bodyPr.remove(e)
    etree.SubElement(bodyPr, "{http://schemas.openxmlformats.org/drawingml/2006/main}noAutofit")
    return tb


def para(tf, first=False):
    return tf.paragraphs[0] if first else tf.add_paragraph()


def run(p, text, font_px, color, serif=False, bold=False, track=None, italic=False):
    r = p.add_run()
    r.text = text
    f = r.font
    f.size = pt(font_px)
    f.name = SERIF if serif else SANS
    f.bold = bold
    f.italic = italic
    f.color.rgb = color
    if track:
        set_tracking(r, font_px, track)
    # 东亚字体也要显式设，否则中文会回落到系统字体
    rPr = r._r.get_or_add_rPr()
    ea = etree.SubElement(rPr, "{http://schemas.openxmlformats.org/drawingml/2006/main}ea")
    ea.set("typeface", SERIF if serif else SANS)
    return r


def spacing(p, line=None, before=None, after=None):
    if line is not None:
        p.line_spacing = line
    if before is not None:
        p.space_before = Pt(before)
    if after is not None:
        p.space_after = Pt(after)


def picture_cover(slide, path, x, y, w, h, grayscale=False, brightness=-8, contrast=15, zoom=1.0):
    """把图铺满给定框（等效 object-fit: cover），可选灰化与明暗调整。"""
    from PIL import Image
    iw, ih = Image.open(path).size
    box_ratio, img_ratio = w / h, iw / ih
    pic = slide.shapes.add_picture(str(path), px(x), px(y), px(w), px(h))
    if img_ratio > box_ratio:                      # 图更宽 → 裁左右
        crop = (1 - box_ratio / img_ratio) / 2
        pic.crop_left = pic.crop_right = crop
    elif img_ratio < box_ratio:                    # 图更高 → 裁上下
        crop = (1 - img_ratio / box_ratio) / 2
        pic.crop_top = pic.crop_bottom = crop
    if zoom > 1.0:                                 # 局部特写：两侧再各收一点
        extra = (1 - 1.0 / zoom) / 2
        pic.crop_left += extra
        pic.crop_right += extra
        pic.crop_top += extra
        pic.crop_bottom += extra
    blip = pic._element.blipFill.find("{http://schemas.openxmlformats.org/drawingml/2006/main}blip")
    if grayscale:
        g = etree.SubElement(blip, "{http://schemas.openxmlformats.org/drawingml/2006/main}grayscale")
    lum = etree.SubElement(blip, "{http://schemas.openxmlformats.org/drawingml/2006/main}lum")
    lum.set("bright", str(int(brightness * 1000)))
    lum.set("contrast", str(int(contrast * 1000)))
    return pic


def fade_overlay(slide, x, y, w, h, base=NIGHT):
    """图条左缘的夜底渐隐：从底色不透明过渡到全透明，让照片与文字栏咬合。"""
    s = rect(slide, x, y, w, h, base)
    s.fill.gradient()
    s.fill.gradient_angle = 0          # 左 → 右
    stops = s.fill.gradient_stops
    stops[0].color.rgb = base
    stops[0].position = 0.0
    stops[1].color.rgb = base
    stops[1].position = 0.55
    # 透明度只能走 XML：左端起底色、右端全透
    gs_el = s.fill._xPr.find("{http://schemas.openxmlformats.org/drawingml/2006/main}gradFill")
    gss = gs_el.find("{http://schemas.openxmlformats.org/drawingml/2006/main}gsLst")
    for i, gs in enumerate(gss):
        clr = gs.find("{http://schemas.openxmlformats.org/drawingml/2006/main}srgbClr")
        alpha = 95000 if i == 0 else 0
        a = etree.SubElement(clr, "{http://schemas.openxmlformats.org/drawingml/2006/main}alpha")
        a.set("val", str(alpha))
    return s


def hairline(slide, x, y, w, color=RULE, h=1):
    return rect(slide, x, y, w, max(h, 1), color)


# ---------------------------------------------------------------- 页面：封面
def page_cover(prs):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    rect(s, 0, 0, W_PX, H_PX, NIGHT)

    picture_cover(s, ROOT / "master/assets/pencil-macro.png", 1320, 0, 600, H_PX, zoom=1.2)
    fade_overlay(s, 1320, 0, 600, H_PX)
    hairline(s, 1319, 0, 1, RULE)
    s.shapes[-1].height = px(H_PX)

    # 眉题
    rect(s, 104, 90, 8, 8, RED)
    tb = textbox(s, 127, 84, 700, 26)
    p = para(tb.text_frame, first=True)
    run(p, "第 01 讲 · 学习工具", 15, DIM, track=.34)

    # 副题
    tb = textbox(s, 104, 130, 900, 40)
    p = para(tb.text_frame, first=True)
    run(p, "初中生如何用 DS Bot", 26, DIM, track=.12)

    # 主标题（第二段里 AI 用砖红）
    tb = textbox(s, 104, 190, 1010, 275)
    tf = tb.text_frame
    p = para(tf, first=True)
    spacing(p, line=1.26)
    run(p, "组建自己的学科", 104, PAPER, serif=True, bold=True)
    p = para(tf)
    spacing(p, line=1.26)
    run(p, "AI", 104, RED, serif=True, bold=True)
    run(p, " 助手", 104, PAPER, serif=True, bold=True)

    hairline(s, 104, 492, 1150)

    tb = textbox(s, 104, 515, 700, 95)
    tf = tb.text_frame
    p = para(tf, first=True)
    spacing(p, line=1.55)
    run(p, "三个动作，把一台通用聊天机器人，", 28, BODY, serif=True)
    p = para(tf)
    spacing(p, line=1.55)
    run(p, "变成只对一科负责的陪练。", 28, BODY, serif=True)

    steps = [
        ("01", "定学科", "只选一科开始，先挑最近最疼的那科。"),
        ("02", "交底细", "课本目录、单元页、错题，拍照发它。"),
        ("03", "提要求", "让它先问你，再讲答案。"),
    ]
    hairline(s, 104, 736, 1150)          # 一条线贯穿三步：表达"顺序"，不是三张卡片
    for i, (no, label, desc) in enumerate(steps):
        x = 104 + i * 399
        rect(s, x, 726, 44, 20, NIGHT)   # 用底色把线断开，编号嵌在线上
        tb = textbox(s, x, 720, 353, 180)
        tf = tb.text_frame
        p = para(tf, first=True)
        run(p, no, 15, RED_SMALL, serif=True, bold=True, track=.18)
        spacing(p, after=4)
        p = para(tf)
        run(p, label, 36, WHITE_HI, bold=True, track=.07)
        spacing(p, after=5, line=1.1)
        p = para(tf)
        run(p, desc, 28, BODY)
        spacing(p, line=1.5)

    tb = textbox(s, 104, 992, 700, 24)
    p = para(tb.text_frame, first=True)
    run(p, "DS BOT · 学科 AI 助手", 13, DIM, track=.24)

    tb = textbox(s, 1180, 992, 74, 26)
    p = para(tb.text_frame, first=True)
    p.alignment = PP_ALIGN.RIGHT
    run(p, "01", 16, RED_SMALL, serif=True)
    return s


# ---------------------------------------------------------------- 页面：对照表
def page_table(prs):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    rect(s, 0, 0, W_PX, H_PX, NIGHT)
    picture_cover(s, ROOT / "master/assets/desk-tools.png", 1320, 0, 600, H_PX, zoom=1.2)
    fade_overlay(s, 1320, 0, 600, H_PX)
    hairline(s, 1319, 0, 1, RULE)

    rect(s, 104, 90, 8, 8, RED)
    tb = textbox(s, 127, 84, 700, 26)
    p = para(tb.text_frame, first=True)
    run(p, "第 03 部分 · 用法对照", 15, DIM, track=.34)

    tb = textbox(s, 104, 126, 1060, 100)
    p = para(tb.text_frame, first=True)
    spacing(p, line=1.32)
    run(p, "搜题机 ", 72, PAPER, serif=True, bold=True)
    run(p, "vs", 72, RED, serif=True, bold=True)
    run(p, " 陪练", 72, PAPER, serif=True, bold=True)

    hairline(s, 104, 260, 1150)

    # 原生表格：单元格里是真正的文字，改字会跟着走
    rows, cols = 4, 2
    x, y, w = 104, 310, 1150
    gt = s.shapes.add_table(rows, cols, px(x), px(y), px(w), px(430)).table
    gt.columns[0].width = px(523)
    gt.columns[1].width = px(627)
    gt.first_row = False
    gt.horz_banding = False
    tblPr = gt._tbl.tblPr
    tblPr.set("firstRow", "0"); tblPr.set("bandRow", "0")
    for st in tblPr.findall("{http://schemas.openxmlformats.org/drawingml/2006/main}tableStyleId"):
        st.text = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"   # No Style, No Grid
    heights = [64, 104, 96, 96]
    for i, hgt in enumerate(heights):
        gt.rows[i].height = px(hgt)

    data = [
        [("常见用法", DIM, 15, False, .26), ("正确用法", RED_SMALL, 15, True, .26)],
        [("拍照 → 抄答案", WHITE_HI, 36, True, 0), ("先问 → 再讲 → 复述", WHITE_HI, 36, True, 0)],
        [("答案来得快，可过程没进脑子。", BODY, 24, False, 0), ("卡住的那一步，才是真没懂。", BODY, 24, False, 0)],
        [("下次同类型题，还是不会。", BODY, 24, False, 0), ("下次同类型题，自己能做。", BODY, 24, False, 0)],
    ]
    for r_i, row in enumerate(data):
        for c_i, (txt, color, size, serif, track) in enumerate(row):
            cell = gt.cell(r_i, c_i)
            cell.fill.solid()
            cell.fill.fore_color.rgb = NIGHT
            cell.margin_left = px(32 if c_i == 1 else 0)
            cell.margin_right = px(28)
            cell.margin_top = px(18)
            cell.margin_bottom = px(10)
            cell.vertical_anchor = MSO_ANCHOR.TOP
            tf = cell.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            run(p, txt, size, color, serif=serif, bold=(r_i == 1 or (r_i == 0 and c_i == 1)), track=track or None)
            if r_i == 1:
                spacing(p, line=1.4)

    # 表格线：只留表头分隔线 + 外框 + 中缝，去掉行间横线（避免"Excel 感"）
    hairline(s, 104, 310, 1150, RGBColor(0x6B, 0x66, 0x59), h=1)
    hairline(s, 104, 374, 1150)
    hairline(s, 104, 670, 1150, RGBColor(0x6B, 0x66, 0x59), h=1)
    mid = hairline(s, 627, 310, 1)
    mid.height = px(360)
    rect(s, 627, 310, 3, 360, RED)       # 推荐路径那一侧，从顶部就立起来

    # 底部判断句
    rect(s, 104, 827, 2, 44, RED)
    tb = textbox(s, 126, 822, 1120, 60)
    p = para(tb.text_frame, first=True)
    spacing(p, line=1.6)
    run(p, "判断标准只有一条：", 26, BODY, serif=True)
    run(p, "讲完之后，你能用自己的话讲一遍吗？", 26, PAPER, serif=True, bold=True)

    tb = textbox(s, 104, 992, 700, 24)
    p = para(tb.text_frame, first=True)
    run(p, "DS BOT · 学科 AI 助手", 13, DIM, track=.24)
    tb = textbox(s, 1180, 992, 74, 26)
    p = para(tb.text_frame, first=True)
    p.alignment = PP_ALIGN.RIGHT
    run(p, "02", 16, RED_SMALL, serif=True)
    return s


def main():
    global SERIF, SANS
    ap = argparse.ArgumentParser()
    ap.add_argument("--safe-font", action="store_true", help="用通用宋体/黑体，便于发给别人")
    ap.add_argument("--out", default=str(ROOT / "out/editable-sample.pptx"))
    a = ap.parse_args()
    if a.safe_font:
        SERIF, SANS = "Songti SC", "Heiti SC"

    prs = Presentation()
    prs.slide_width = px(W_PX)
    prs.slide_height = px(H_PX)
    page_cover(prs)
    page_table(prs)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out)
    print(f"OK {out}  页数={len(prs.slides.__iter__.__self__._sldIdLst)}  尺寸={W_PX}×{H_PX}px")
    print(f"字体：标题 {SERIF} / 正文 {SANS}")


if __name__ == "__main__":
    sys.exit(main())
