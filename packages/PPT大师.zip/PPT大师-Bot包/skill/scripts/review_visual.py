#!/usr/bin/env python3
"""视觉评审：把页面图交给 KIE 视觉模型，拿一份结构化批评回来。

我本地没有图像输入，所以"好看不好看"只能靠这道外挂眼睛 + 你的最终拍板。
用法：
  python3 scripts/review_visual.py out/s01-cover.png out/s02-section.png ... [--brief 文字]
退出码：0 = 评审完成；2 = 调用失败。
"""
import argparse, base64, io, json, os, re, sys, urllib.request

KIE_BASE = "https://api.kie.ai"
MODEL = os.environ.get("PPT_VISION_MODEL", "gpt-6-astra")


def kie_key():
    k = os.environ.get("KIE_API_KEY", "").strip()
    if k:
        return k
    p = os.path.expanduser("~/.config/kie/api-key")
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    sys.exit("找不到 KIE key")


def b64(path, max_w=1440):
    from PIL import Image
    im = Image.open(path).convert("RGB")
    if im.width > max_w:
        im = im.resize((max_w, round(im.height * max_w / im.width)), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=88)
    return base64.b64encode(buf.getvalue()).decode()


def call(images, brief):
    content = [{"type": "input_text", "text": brief}]
    for p in images:
        content.append({"type": "input_image", "image_url": "data:image/jpeg;base64," + b64(p)})
    body = json.dumps({"model": MODEL, "input": [{"role": "user", "content": content}],
                       "max_output_tokens": 1600}).encode()
    req = urllib.request.Request(KIE_BASE + "/openai/v1/responses", data=body,
                                 headers={"Authorization": "Bearer " + kie_key(),
                                          "Content-Type": "application/json",
                                          "Accept": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=240) as r:
        raw = r.read().decode("utf-8", "replace")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        txt = ""
        for line in raw.splitlines():
            if line.startswith("data:"):
                try:
                    d = json.loads(line[5:].strip())
                    for ev in d.get("response.output_text.delta") and [] or []:
                        pass
                    txt += d.get("delta", "")
                except Exception:
                    pass
        return txt
    out = []
    for item in data.get("output", []):
        for c in item.get("content", []) or []:
            if c.get("type") in ("output_text", "text"):
                out.append(c.get("text", ""))
    return "\n".join(out) or json.dumps(data, ensure_ascii=False)[:2000]


BRIEF = """你在给一套面向初中生的教学课件做视觉评审。这 4 页是同一套母版：深色夜底、米白思源宋体标题、砖红强调色、右侧 600px 全出血图条（最后一页换成米色引言块）。
受众是初中生和他们的老师；目标是"高端杂志内页"那级别的版面，而不是 AI 生成的模板页。

请只做视觉判断，不要改文案。按顺序回答，尽量具体到位置和像素感：
1. 这 4 页像不像同一套设计系统？哪一页脱节、为什么。
2. 每页的视觉重心在哪？有没有"空洞区"（大块没内容的死白/死黑）或"挤压区"？
3. 标题、正文、注释三层的层级是否清楚？最小的字在手机上看还能读吗？
4. 图条与文字的关系：是咬合还是各管一段？图被压暗/灰化后还有信息吗？
5. 最像"AI 模板页"的三个地方，逐条说。
6. 如果只能改 3 处，改哪三处？给出具体数值建议（字号、间距、位置）。
最后一行给：SCORE: x.x（0-10，9 分以上意味着可以直接商用）。"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("images", nargs="+")
    ap.add_argument("--brief", default=BRIEF)
    a = ap.parse_args()
    txt = call(a.images, a.brief)
    print(txt)
    m = re.search(r"SCORE:\s*([0-9.]+)", txt)
    if m:
        print("\n→ 评分", m.group(1), file=sys.stderr)


if __name__ == "__main__":
    main()
