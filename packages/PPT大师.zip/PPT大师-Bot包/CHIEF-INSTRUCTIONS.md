# 给 chief（主 Bot）的执行指令

> 你收到的是一份 **Bot 定义包**。照下面 5 步做完，这个团队里就会多一个能直接开工的 **PPT大师**。
> 不要改写 `bot/instructions.md` 的内容，那是这个 Bot 的行为规范，原样使用。

## 前置

- 解压后目录结构：`README.md`、`CHIEF-INSTRUCTIONS.md`、`bot/`、`skill/`
- 需要写两个位置：技能目录 `~/.agents/skills/ppt-master` 和用户的工作文件夹。
- 如果沙箱拦住了目录外的写入，**先向用户申请一次放行**，不要自作主张改路径。

## 第 1 步 · 装技能

```bash
mkdir -p ~/.agents/skills
rm -rf ~/.agents/skills/ppt-master            # 已装过就先清掉，避免残留旧版
cp -R <解压目录>/skill ~/.agents/skills/ppt-master
ls ~/.agents/skills/ppt-master                # 应看到 SKILL.md master scripts checks fonts docs
```

## 第 2 步 · 选工作文件夹

问用户一句：**"PPT 的产物放哪个文件夹？"**（建议 `~/Desktop/<项目名>`）。
建好它，之后这个 Bot 的 `work_dir` 就用这个路径。

## 第 3 步 · 建 Bot

用 `create_bot`，**`instructions` 参数原样传 `bot/instructions.md` 的全文**（读文件取全文，不要摘要、不要改写）：

```
create_bot(
  name: "PPT大师",
  role: "PPT",
  instructions: <bot/instructions.md 全文>,
  work_dir: <第 2 步的路径>
)
```

说明：
- **不指定 model**，让它继承当前默认模型（除非用户明确要求某个）。
- 不要给它加 `message_bot` 之外的特殊权限；默认 `workspace-write` 就够。
- 若平台支持角色色/头像，按 `bot/meta.json`：`color: green`、`avatar: star`。

## 第 4 步 · 自检（必须跑，别跳过）

```bash
bash ~/.agents/skills/ppt-master/checks/smoke-test.sh
```

全绿才算装成功。它会检查：python 依赖、Chrome、思源字体、母版文件完整性，
并真的生成一页 HTML 母版 PNG 和一页可编辑 PPTX（各几秒）。

## 第 5 步 · 汇报给用户

一句话说清三件事：
1. 建好了没有（Bot 名字 + 工作文件夹）
2. 自检结果（哪些通过、哪些缺）
3. 缺什么要补：字体（`skill/fonts/INSTALL.md`）、Chrome、可选 API key（生图/视觉验收才需要，用安全卡存）

然后让用户直接对 PPT大师 说第一句话，例如：
**「用深色反白母版，做一页初中生课件的封面给我看看」**

## 自检输出怎么看

| 行 | 含义 | 缺了怎么办 |
|---|---|---|
| `python` | 有 python3 + python-pptx + Pillow | 用 DS Bot 内置 runtime 的 python（`$DSH_*` 环境里有） |
| `chrome` | 找到 Chrome/Edge/Chromium | 装 Chrome，或 `export CHROME=/路径` |
| `fonts` | 思源宋体/黑体已装 | 按 `skill/fonts/INSTALL.md` 装，不装也能跑（会降级并提示 `--safe-font`） |
| `master` | 母版文件齐 | 重新解压 `skill/` |
| `render` | 真渲染出一页 PNG | 看报错：多半是 Chrome 路径或字体 |
| `pptx` | 真生成出 .pptx | 多半是缺 python-pptx |

## 不要做的事

- 不要把 `bot/instructions.md` 改写、精简、翻译后塞进 instructions。
- 不要把这个包里的任何脚本改成访问网络（它默认全离线）。
- 不要把用户自己的 key 写进任何文件或聊天。
