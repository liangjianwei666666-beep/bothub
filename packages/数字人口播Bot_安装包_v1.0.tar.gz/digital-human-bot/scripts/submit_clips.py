#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数字人口播 · 出镜头（H3 网关提交/轮询/下载）

两种任务：
  doodle  线稿 → 逐笔画出动画      （minimax_h3_lightx2v_v5，1–10 秒）
  talking 图 + 音频 → 对口型视频   （minimax_h3_image_audio_to_video，1–15 秒，保留输入音频）

单条:
  python3 submit_clips.py doodle --image 线稿/01.png --duration 5 --out 手绘动画/01.mp4
  python3 submit_clips.py talking --image 角色.png --audio 配音.wav --duration 12 --out 角色.mp4

批量:
  python3 submit_clips.py batch jobs.json       # [{"kind":"doodle","image":...,"duration":5,"out":...}]

Token：环境变量 AUTODL_TOKEN，或文件 ~/.dsh-autodl/token。
上传：本地文件会先传到公网图床（curl --noproxy '*'，避开系统代理卡死）。
"""
import os, sys, json, time, argparse, subprocess, tempfile

BASE = os.environ.get("AUTODL_BASE", "https://autodl.art")
UPLOAD = os.environ.get("DH_UPLOAD", "https://uguu.se/upload.php")
WF = {"doodle": "minimax_h3_lightx2v_v5", "talking": "minimax_h3_image_audio_to_video"}

DOODLE_SKELETON = (
    "Hand-drawn line doodle animation on white paper. Start on a clean white paper field. "
    "The doodle draws itself in with sketchy marker lines stroke by stroke: {motion}. "
    "Each doodle element draws in, pops or slides into place, lightly bounces, settles and "
    "locks into the completed composition exactly matching the reference image. Preserve the "
    "black marker sketch style, rough imperfect wobbling strokes, hand-drawn shading, white "
    "paper background. No camera move, no zoom, no morphing, no scene cuts, no new objects, "
    "no text, no letters, no numbers, no logos, no watermark.")


def token():
    t = os.environ.get("AUTODL_TOKEN", "").strip()
    if t:
        return t
    p = os.path.expanduser("~/.dsh-autodl/token")
    if os.path.exists(p):
        return open(p).read().strip()
    sys.exit("✗ 缺 AUTODL_TOKEN（环境变量或 ~/.dsh-autodl/token）")


def curl(args, timeout=300):
    cmd = ["curl", "--noproxy", "*", "-sS", "--max-time", str(timeout)] + args
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("✗ curl 失败: %s\n%s" % (" ".join(cmd[:4]), r.stderr[-400:]))
    return r.stdout


def upload(path):
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        sys.exit("✗ 文件不存在: " + path)
    out = curl(["-F", "files[]=@" + path, UPLOAD], timeout=600)
    try:
        data = json.loads(out)
    except Exception:
        sys.exit("✗ 图床返回无法解析: " + out[:200])
    files = data.get("files") or []
    if not files or not files[0].get("url"):
        sys.exit("✗ 上传失败: " + out[:200])
    return files[0]["url"]


def as_url(v):
    if not v:
        return ""
    return v if v.startswith("http") else upload(v)


def submit(kind, image, audio, duration, resolution, prompt, seed=None):
    wf = WF[kind]
    if kind == "doodle":
        params = {"prompt": DOODLE_SKELETON.format(motion=prompt or "the drawing appears"),
                  "duration": int(duration), "resolution": resolution,
                  "ref_image_0": as_url(image)}
    else:
        params = {"ref_image_0": as_url(image), "ref_audio_0": as_url(audio),
                  "audio_duration": int(duration), "resolution": resolution}
        if prompt:
            params["prompt"] = prompt
    if seed:
        params["seed"] = int(seed)
    body = json.dumps(params, ensure_ascii=False)
    out = curl(["-X", "POST", "%s/api/v1/comfyui/comfyui_workflow/%s" % (BASE, wf),
                "-H", "Authorization: " + token(),
                "-H", "Content-Type: application/json",
                "-d", body])
    data = json.loads(out)
    tid = data.get("task_id") or (data.get("data") or {}).get("task_id")
    if not tid:
        sys.exit("✗ 提交失败: " + out[:400])
    return tid


def poll(tid, out, interval=15, timeout=1800):
    t0 = time.time()
    while time.time() - t0 < timeout:
        time.sleep(interval)
        raw = curl(["%s/api/v1/comfyui/comfyui_workflow/result/%s" % (BASE, tid)])
        try:
            d = json.loads(raw)
        except Exception:
            continue
        data = d.get("data") if isinstance(d.get("data"), dict) else d
        st = str(data.get("status", "")).upper()
        if st in ("SUCCESS", "SUCCEED", "DONE", "COMPLETED"):
            urls = data.get("output") or data.get("urls") or data.get("videos") or []
            if isinstance(urls, dict):
                urls = list(urls.values())
            if not urls:
                sys.exit("✗ 成功但没有输出地址: " + raw[:300])
            url = urls[0] if isinstance(urls[0], str) else urls[0].get("url")
            os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
            curl(["-L", "-o", out, url], timeout=900)
            print("[saved] %s (%.1fs)" % (out, time.time() - t0))
            return out
        if st in ("FAILED", "ERROR", "CANCELED"):
            sys.exit("✗ 任务失败: " + raw[:300])
        print("[poll] %s %ds" % (st or "RUNNING", int(time.time() - t0)))
    sys.exit("✗ 轮询超时")


def one(job, interval, timeout):
    kind = job["kind"]
    if kind not in WF:
        sys.exit("✗ kind 只能是 doodle / talking")
    tid = submit(kind, job.get("image"), job.get("audio"), job.get("duration", 5),
                 job.get("resolution", "768p竖"), job.get("prompt"), job.get("seed"))
    print("[task]", tid, job.get("out"))
    return poll(tid, os.path.expanduser(job["out"]), interval, timeout)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("kind", choices=["doodle", "talking", "batch"])
    ap.add_argument("target", nargs="?", help="batch 模式下是 jobs.json")
    ap.add_argument("--image"); ap.add_argument("--audio")
    ap.add_argument("--duration", type=float, default=5)
    ap.add_argument("--resolution", default="768p竖")
    ap.add_argument("--prompt", default="")
    ap.add_argument("--seed", type=int)
    ap.add_argument("--out", default="out.mp4")
    ap.add_argument("--poll", type=int, default=15)
    ap.add_argument("--timeout", type=int, default=1800)
    a = ap.parse_args()

    if a.kind == "batch":
        jobs = json.load(open(a.target, encoding="utf-8"))
        for j in jobs:
            one(j, a.poll, a.timeout)
        return

    j = {"kind": a.kind, "image": a.image, "audio": a.audio, "duration": a.duration,
         "resolution": a.resolution, "prompt": a.prompt, "seed": a.seed, "out": a.out}
    one(j, a.poll, a.timeout)


if __name__ == "__main__":
    main()
