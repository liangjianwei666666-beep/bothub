#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数字人口播 · 配音（薄封装，核心是随包附带的 doubao_tts_core.py，已验证可跑）

用法:
  python3 tts.py --list
  python3 tts.py --text "文案" --out 配音.wav [--speaker zh_male_ruyayichen_saturn_bigtts]
  python3 tts.py --script 文案.txt --out-dir 配音/

密钥：环境变量 TTS_API_KEY / TTS_APP_ID，或 DSH_SECRET_DOUBAO_TTS_*，
     或文件 ~/.config/dsh/video.env（自动 source）。

实测可用男声（本机验证）：zh_male_ruyayichen_saturn_bigtts（儒雅沉稳）、
zh_male_wennuanahu_uranus_bigtts（温暖）、zh_male_yangguangqingnian_uranus_bigtts（阳光青年）、
zh_male_shaonianzixin_uranus_bigtts（少年自信）
不可用：zh_male_*_moon_bigtts（1.0 资源，多数账号未开通）
"""
import os, sys, subprocess, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
CORE = os.path.join(HERE, "doubao_tts_core.py")

VOICES = [
    ("zh_male_ruyayichen_saturn_bigtts", "男·儒雅沉稳"),
    ("zh_male_wennuanahu_uranus_bigtts", "男·温暖"),
    ("zh_male_yangguangqingnian_uranus_bigtts", "男·阳光青年（语速快）"),
    ("zh_male_shaonianzixin_uranus_bigtts", "男·少年自信"),
    ("zh_female_shuangkuaisisi_uranus_bigtts", "女·爽快思思（默认，慎用）"),
]
DEFAULT = "zh_male_ruyayichen_saturn_bigtts"


def load_env():
    p = os.path.expanduser("~/.config/dsh/video.env")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8", errors="replace"):
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    # 统一成核心脚本认的变量名
    if not os.environ.get("TTS_API_KEY"):
        v = os.environ.get("DSH_SECRET_DOUBAO_TTS_API_KEY") or os.environ.get("DOUBAO_TTS_API_KEY")
        if v:
            os.environ["TTS_API_KEY"] = v


def synth(text, out, speaker, rate=0):
    load_env()
    if not os.environ.get("TTS_API_KEY"):
        sys.exit("✗ 缺 TTS_API_KEY（或 DSH_SECRET_DOUBAO_TTS_API_KEY）")
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    cmd = ["/usr/bin/python3" if os.path.exists("/usr/bin/python3") else "python3",
           CORE, "--text", text, "--out", out, "--speaker", speaker,
           "--speech-rate", str(rate), "--encoding", "wav", "--sample-rate", "48000"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(out) or os.path.getsize(out) < 1200:
        sys.exit("✗ 配音失败（音色可能未开通）\n" + (r.stderr or r.stdout)[-400:])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text"); ap.add_argument("--script")
    ap.add_argument("--out"); ap.add_argument("--out-dir")
    ap.add_argument("--speaker", default=DEFAULT)
    ap.add_argument("--rate", type=int, default=0)
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()

    if a.list:
        for sid, name in VOICES:
            print("%-44s %s" % (sid, name))
        return
    if a.script:
        outdir = a.out_dir or "配音"
        os.makedirs(outdir, exist_ok=True)
        lines = [l.strip() for l in open(a.script, encoding="utf-8") if l.strip()]
        for i, line in enumerate(lines, 1):
            p = os.path.join(outdir, "s%02d.wav" % i)
            synth(line, p, a.speaker, a.rate)
            print("OK %s  %s" % (p, line))
        return
    if not (a.text and a.out):
        sys.exit("用法: --text 文案 --out 文件；或 --script 文案.txt --out-dir 目录；--list 看音色")
    synth(a.text, a.out, a.speaker, a.rate)
    print("OK", a.out)


if __name__ == "__main__":
    main()
