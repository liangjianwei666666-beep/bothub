#!/usr/bin/env bash
# 多帧联系表：从成片抽 N 帧拼成一张 PNG（交付附图为用）
# 用法: contact_sheet.sh <视频> [帧数=9] [输出png] [--cols 3]
set -euo pipefail
FF="${FFMPEG:-$(command -v ffmpeg || echo "$HOME/bin/ffmpeg")}"
FP="${FFPROBE:-$(command -v ffprobe || echo "$HOME/bin/ffprobe")}"
[ $# -ge 1 ] || { echo "用法: contact_sheet.sh <视频> [帧数=9] [输出png] [--cols 3]"; exit 2; }
IN="$1"; N=9; COLS=3; OUT=""; shift
# 其余参数：纯数字=帧数，--cols N=列数，其他=输出路径（顺序随意）
while [ $# -gt 0 ]; do
  case "$1" in
    --cols) COLS="$2"; shift 2;;
    ''|*[!0-9]*) OUT="$1"; shift;;
    *) N="$1"; shift;;
  esac
done
[ -f "$IN" ] || { echo "找不到视频: $IN"; exit 2; }
DUR=$("$FP" -v error -show_entries format=duration -of csv=p=0 "$IN")
[ -n "$OUT" ] || OUT="${IN%.*}_联系表.png"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
ROWS=$(( (N + COLS - 1) / COLS ))
i=0
while [ $i -lt "$N" ]; do
  # 均匀取点，避开首尾 5%
  T=$(python3 -c "d=$DUR; n=$N; i=$i; print(round(d*0.05 + (d*0.9)*i/max(1,n-1), 3))")
  "$FF" -v error -ss "$T" -i "$IN" -frames:v 1 -vf "scale=480:-1" "$TMP/f$(printf '%02d' $i).png" -y
  i=$((i+1))
done
"$FF" -v error -framerate 1 -i "$TMP/f%02d.png" -vf "tile=${COLS}x${ROWS}:padding=8:margin=8:color=white" -frames:v 1 "$OUT" -y
W=$("$FP" -v error -select_streams v:0 -show_entries stream=width -of csv=p=0 "$OUT" 2>/dev/null || echo "?")
H=$("$FP" -v error -select_streams v:0 -show_entries stream=height -of csv=p=0 "$OUT" 2>/dev/null || echo "?")
BYTES=$(wc -c < "$OUT" | tr -d ' ')
echo "OK 帧数=$N 网格=${COLS}x${ROWS} 尺寸=${W}x${H} 体积=${BYTES}B"
echo "OUT=$OUT"
