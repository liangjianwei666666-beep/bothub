#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数字人口播 · 安装自检

跑法：python3 selfcheck.py [--ffmpeg 路径] [--ffprobe 路径]

做三件事：
  1. 依赖体检（python/PIL/numpy/ffmpeg/ffprobe/node + 两个可选密钥）
  2. 真跑一次微端到端：画一张线稿 → 生成 2 秒镜头 → 加 2 秒静音配音 → 合成 1080×1920
  3. ffprobe 逐项核验成品规格，给 PASS / FAIL

不消耗任何 API 额度。
"""
import os, sys, json, subprocess, tempfile, shutil, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
OK, BAD, WARN = "✓", "✗", "!"


def which(name, override=None):
    if override:
        return override if os.path.exists(override) else None
    return shutil.which(name)


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ffmpeg", default=os.environ.get("FFMPEG"))
    ap.add_argument("--ffprobe", default=os.environ.get("FFPROBE"))
    a = ap.parse_args()

    fails, warns = [], []
    print("=== 1. 依赖体检 ===")
    print(f"  {PY}")

    try:
        import PIL
        print(f"  {OK} Pillow {PIL.__version__}")
    except Exception:
        fails.append("Pillow 未安装 → pip3 install pillow")
        print(f"  {BAD} Pillow 缺失")

    try:
        import numpy
        print(f"  {OK} numpy {numpy.__version__}")
    except Exception:
        fails.append("numpy 未安装 → pip3 install numpy")
        print(f"  {BAD} numpy 缺失")

    ffmpeg = which("ffmpeg", a.ffmpeg) or os.path.expanduser("~/bin/ffmpeg")
    ffprobe = which("ffprobe", a.ffprobe) or os.path.expanduser("~/bin/ffprobe")
    for name, path in (("ffmpeg", ffmpeg), ("ffprobe", ffprobe)):
        if path and os.path.exists(path):
            print(f"  {OK} {name}: {path}")
        else:
            fails.append(f"{name} 未找到 → 装 ffmpeg（brew install ffmpeg）或设 FFMPEG/FFPROBE 环境变量")
            print(f"  {BAD} {name} 未找到")

    node = which("node")
    if node:
        print(f"  {OK} node: {node}（拉片技能需要）")
    else:
        warns.append("node 未找到：拉片（video-shots）不可用，不影响出片")
        print(f"  {WARN} node 未找到（可选）")

    tok = os.environ.get("AUTODL_TOKEN") or ""
    tokfile = os.path.expanduser("~/.dsh-autodl/token")
    if not tok and os.path.exists(tokfile):
        tok = open(tokfile).read().strip()
    print(f"  {OK if tok else WARN} AutoDL token: {'已配置（可出镜头）' if tok else '未配置（只能合成已有素材）'}")
    if not tok:
        warns.append("AUTODL_TOKEN 未配置：submit_clips.py 不可用（AI 出镜头需要）")

    ttskey = os.environ.get("TTS_API_KEY") or os.environ.get("DSH_SECRET_DOUBAO_TTS_API_KEY")
    print(f"  {OK if ttskey else WARN} 豆包 TTS: {'已配置（可 AI 配音）' if ttskey else '未配置（需自备录音或 TTS）'}")
    if not ttskey:
        warns.append("TTS_API_KEY 未配置：tts.py 不可用")

    if fails:
        print("\n=== 依赖不全，先修这些 ===")
        for f in fails:
            print("  -", f)
        sys.exit(1)

    print("\n=== 2. 微端到端（不花 API）===")
    tmp = tempfile.mkdtemp(prefix="dh-selfcheck-")
    try:
        # 2.1 画一张线稿面板
        from PIL import Image, ImageDraw, ImageFont
        panel = os.path.join(tmp, "panel.png")
        img = Image.new("RGB", (1080, 1500), (250, 248, 244))
        d = ImageDraw.Draw(img)
        d.ellipse((380, 500, 700, 820), outline=(30, 28, 26), width=8)
        d.line([(200, 1100), (880, 1100)], fill=(30, 28, 26), width=6)
        img.save(panel)
        print(f"  {OK} 线稿面板已生成 1080×1500")

        # 2.2 生成 2 秒镜头（静帧微动，模拟出片素材）
        clip = os.path.join(tmp, "shot01.mp4")
        r = run([ffmpeg, "-v", "error", "-y", "-loop", "1", "-t", "2", "-i", panel,
                 "-vf", "scale=1080:1500,format=yuv420p", "-r", "24",
                 "-c:v", "libx264", "-pix_fmt", "yuv420p", clip])
        if r.returncode != 0:
            print(f"  {BAD} 生成测试镜头失败\n{r.stderr[-600:]}"); sys.exit(1)
        print(f"  {OK} 测试镜头 2s")

        # 2.3 2 秒静音配音
        aud = os.path.join(tmp, "voice.wav")
        r = run([ffmpeg, "-v", "error", "-y", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono",
                 "-t", "2", "-c:a", "pcm_s16le", aud])
        if r.returncode != 0:
            print(f"  {BAD} 生成静音失败\n{r.stderr[-600:]}"); sys.exit(1)
        print(f"  {OK} 静音配音 2s")

        # 2.4 用 build_video.py 合成
        proj = os.path.join(tmp, "project.json")
        json.dump({
            "total": 2.0,
            "audio": "voice.wav",
            "out": "out.mp4",
            "shots": [{"file": "shot01.mp4", "dur": 2.0}],
            "subs": [{"text": "这是一句自检字幕。", "start": 0.1, "end": 1.9}],
        }, open(proj, "w"), ensure_ascii=False)
        r = run([PY, os.path.join(HERE, "build_video.py"), proj,
                 "--ffmpeg", ffmpeg, "--ffprobe", ffprobe])
        if r.returncode != 0:
            print(f"  {BAD} 合成失败\n{(r.stderr or r.stdout)[-900:]}"); sys.exit(1)
        print("  " + (r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "  ✓ 合成完成"))

        # 2.5 核验规格
        out = os.path.join(tmp, "out.mp4")
        r = run([ffprobe, "-v", "error", "-show_entries",
                 "stream=codec_name,pix_fmt,width,height,r_frame_rate,sample_rate",
                 "-of", "json", out])
        info = json.loads(r.stdout)["streams"]
        v = next(s for s in info if s.get("codec_name") == "h264")
        au = next((s for s in info if s.get("codec_name") == "aac"), None)
        checks = [
            ("分辨率 1080×1920", v["width"] == 1080 and v["height"] == 1920),
            ("像素格式 yuv420p", v["pix_fmt"] == "yuv420p"),
            ("帧率 24", v["r_frame_rate"].startswith("24/")),
            ("音轨 AAC 48k", bool(au) and str(au.get("sample_rate")) == "48000"),
        ]
        print("\n=== 3. 成品规格核验 ===")
        for name, good in checks:
            print(f"  {OK if good else BAD} {name}")
        if not all(g for _, g in checks):
            print(f"  {BAD} 规格不符，自检失败"); sys.exit(1)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n=== 结论 ===")
    print("  PASS 装配成功，可以出片")
    if warns:
        print("  未启用的能力：")
        for w in warns:
            print("   -", w)
    sys.exit(0)


if __name__ == "__main__":
    main()
