#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数字人口播 · 通用合成器（配置驱动，无绝对路径依赖）

用法:
  python3 build_video.py project.json
  python3 build_video.py project.json --dry-run     # 只打印滤镜图与坐标，不渲染

project.json 结构见 templates/project.example.json。
输出：1080×1920 / H.264 High / yuv420p / 24fps / AAC 48k / faststart
"""
import os, sys, json, math, subprocess, argparse
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ---------- 版式常量（可在 project.json 的 layout 里覆盖） ----------
DEFAULTS = {
    "canvas": [1080, 1920],
    "content": {"w": 857, "h": 1500, "y": 0},          # 手绘内容缩到上部
    "char":    {"x": 60, "y": 1480, "w": 380, "h": 400, "mode": "sticker"},
    "sub":     {"font": 48, "line_height": 62, "pad_x": 32, "pad_y": 26,
                "max_text_w": 480, "right_margin": 40, "bottom": 1800},
    "paper_white": 255,                                 # 纸白归一目标
    "bw_except": [],                                    # 保留彩色的镜头文件名（不含扩展名）
}

PUNCT_END = "，。！？；：、）】」』…,.!?;:"
PUNCT_BAN = "，。！？；：、）】」』…,.!?;:"


# ---------------- 工具 ----------------
def need(cond, msg):
    if not cond:
        sys.exit("✗ " + msg)


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("命令失败:", " ".join(cmd[:6]))
        print(r.stderr[-2500:])
        sys.exit(1)
    return r


def ffprobe_dur(path, ffprobe):
    r = run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path])
    return float(r.stdout.strip())


# ---------------- 中文断行 ----------------
def wrap_cn(text, font, drawer, maxw):
    chunks, buf = [], ""
    for ch in text:
        buf += ch
        if ch in PUNCT_END:
            chunks.append(buf); buf = ""
    if buf:
        chunks.append(buf)

    lines, cur = [], ""
    for ck in chunks:
        if drawer.textlength(ck, font=font) > maxw:
            for ch in ck:
                if drawer.textlength(cur + ch, font=font) > maxw:
                    lines.append(cur); cur = ""
                cur += ch
            continue
        if cur and drawer.textlength(cur + ck, font=font) > maxw:
            lines.append(cur); cur = ck
        else:
            cur += ck
    if cur:
        lines.append(cur)

    for i in range(1, len(lines)):
        while lines[i] and lines[i][0] in PUNCT_BAN and len(lines[i - 1]) > 1:
            lines[i] = lines[i - 1][-1] + lines[i]
            lines[i - 1] = lines[i - 1][:-1]
            if lines[i - 1][-1] in PUNCT_END:
                break
    return [l for l in lines if l]


# ---------------- 纸白归一 ----------------
def paper_gain(path, ffmpeg, tmp_dir, t=2.0, target=255):
    """量这一段手绘的纸白（99.5 分位），算把纸压到纯白的增益"""
    import numpy as np
    tmp = os.path.join(tmp_dir, "_paper.png")
    subprocess.run([ffmpeg, "-v", "error", "-y", "-ss", str(t), "-i", path,
                    "-frames:v", "1", tmp], check=True)
    a = np.asarray(Image.open(tmp).convert("L")).astype(np.float32)
    paper = float(np.percentile(a, 99.5))
    return round(min(target / max(paper, 1), 1.30), 4)


# ---------------- 素材：角色贴纸框 ----------------
def make_sticker(size, out_dir, ffmpeg):
    """圆角遮罩 + 边框外框（中心透明，不能盖住角色）"""
    w, h = size
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, w - 1, h - 1), radius=34, fill=255)
    mp = os.path.join(out_dir, "mask.png")
    mask.save(mp)

    pad = 40
    fr = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    sh = Image.new("RGBA", fr.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle((pad + 6, pad + 12, pad + w + 6, pad + h + 12),
                                         radius=36, fill=(0, 0, 0, 90))
    sh = sh.filter(ImageFilter.GaussianBlur(14))
    keep = Image.new("L", fr.size, 255)
    ImageDraw.Draw(keep).rounded_rectangle((pad - 2, pad - 2, pad + w + 2, pad + h + 2),
                                           radius=38, fill=0)
    sh.putalpha(Image.composite(sh.getchannel("A"), Image.new("L", fr.size, 0), keep))
    fr = Image.alpha_composite(fr, sh)
    d = ImageDraw.Draw(fr)
    d.rounded_rectangle((pad, pad, pad + w, pad + h), radius=36, fill=None,
                        outline=(38, 36, 31, 255), width=5)
    d.rounded_rectangle((pad + 9, pad + 9, pad + w - 9, pad + h - 9), radius=28,
                        outline=(47, 79, 69, 150), width=2)
    fp = os.path.join(out_dir, "frame.png")
    fr.save(fp)
    return mp, fp, pad


# ---------------- 素材：字幕卡 ----------------
def make_subs(subs, st, canvas_w, out_dir, font_path):
    f = ImageFont.truetype(font_path, st["font"])
    md = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    LH, PADX, PADY, M = st["line_height"], st["pad_x"], st["pad_y"], 14
    out = []
    for i, s in enumerate(subs):
        lines = wrap_cn(s["text"], f, md, st["max_text_w"])
        tw = int(max(md.textlength(l, font=f) for l in lines)) + PADX * 2 + 18
        th = len(lines) * LH + PADY * 2
        img = Image.new("RGBA", (tw + M * 2, th + M * 2), (0, 0, 0, 0))
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh).rounded_rectangle((M, M + 6, M + tw, M + th + 6),
                                             radius=26, fill=(0, 0, 0, 55))
        img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(9)))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle((M, M, M + tw, M + th), radius=26,
                            fill=(255, 255, 255, 243), outline=(224, 219, 210), width=2)
        d.rounded_rectangle((M + 16, M + 18, M + 21, M + th - 18), radius=3, fill=(47, 79, 69, 255))
        yy = M + PADY + LH // 2
        for ln in lines:
            d.text((M + PADX + 14, yy), ln, font=f, fill=(28, 26, 24), anchor="lm")
            yy += LH
        p = os.path.join(out_dir, "sub_%02d.png" % i)
        img.save(p)
        cx = canvas_w - st["right_margin"] - tw
        cy = st["bottom"] - th
        out.append({"path": p, "start": s["start"], "end": s["end"],
                    "x": cx - M, "y": cy - M, "box": [cx, cy, cx + tw, cy + th], "lines": lines})
    return out


# ---------------- 主流程 ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--ffmpeg", default=os.environ.get("FFMPEG", "ffmpeg"))
    ap.add_argument("--ffprobe", default=os.environ.get("FFPROBE", "ffprobe"))
    ap.add_argument("--font", default=os.environ.get("DH_FONT", ""))
    args = ap.parse_args()

    cfg = json.load(open(args.project, encoding="utf-8"))
    root = os.path.dirname(os.path.abspath(args.project))
    lay = json.loads(json.dumps(DEFAULTS))
    for k, v in (cfg.get("layout") or {}).items():
        if isinstance(v, dict) and isinstance(lay.get(k), dict):
            lay[k].update(v)
        else:
            lay[k] = v

    W, H = lay["canvas"]
    work = os.path.join(root, cfg.get("work_dir", "工作"))
    os.makedirs(work, exist_ok=True)

    font_path = args.font or os.environ.get("DH_FONT") or (
        "/System/Library/Fonts/Supplemental/STHeiti Medium.ttc"
        if os.path.exists("/System/Library/Fonts/Supplemental/STHeiti Medium.ttc")
        else "/System/Library/Fonts/STHeiti Medium.ttc")
    need(os.path.exists(font_path), "找不到中文字体，设置环境变量 DH_FONT 指向 .ttc/.ttf")

    shots = cfg["shots"]
    total = float(cfg["total"])
    audio = os.path.join(root, cfg["audio"])
    out = os.path.join(root, cfg.get("out", "成片.mp4"))
    need(os.path.exists(audio), "找不到音频: " + audio)

    inputs, fc = [], []
    idx = 0
    info = []
    for sh in shots:
        clip = os.path.join(root, sh["file"])
        need(os.path.exists(clip), "找不到镜头: " + clip)
        d = float(sh["dur"])
        cd = ffprobe_dur(clip, args.ffprobe)
        sw = lay["content"]["w"]; shh = lay["content"]["h"]; oy = lay["content"].get("y", 0)
        ox = (W - sw) // 2
        gain = paper_gain(clip, args.ffmpeg, work, target=lay["paper_white"])
        name = os.path.splitext(os.path.basename(clip))[0]
        bw = "" if name in (lay.get("bw_except") or []) else ",hue=s=0"
        white = (f",lutrgb=r='min(255,val*{gain})':g='min(255,val*{gain})'"
                 f":b='min(255,val*{gain})'")
        base = (f"scale={sw}:{shh}:flags=lanczos,unsharp=5:5:0.6:5:5:0.0{white}{bw},"
                f"pad={W}:{H}:{ox}:{oy}:white")
        inputs += ["-i", clip]
        if cd >= d:
            fc.append(f"[{idx}:v]{base},trim=duration={d:.3f},setpts=PTS-STARTPTS,fps=24[v{idx}]")
        else:
            sp = cd / d
            fc.append(f"[{idx}:v]{base},setpts=PTS/{sp:.6f},fps=24,"
                      f"trim=duration={d:.3f},setpts=PTS-STARTPTS[v{idx}]")
        info.append({"shot": name, "need": d, "source": round(cd, 3), "paper_gain": gain})
        idx += 1
    fc.append("".join(f"[v{i}]" for i in range(len(shots))) + f"concat=n={len(shots)}:v=1:a=0[base]")

    last = "base"
    # 角色窗
    ch = cfg.get("character")
    if ch:
        c = lay["char"]
        cp = os.path.join(root, ch["file"])
        need(os.path.exists(cp), "找不到角色视频: " + cp)
        mask_p, frame_p, pad = make_sticker((c["w"], c["h"]), work, args.ffmpeg)
        inputs += ["-stream_loop", "-1", "-t", "%.3f" % total, "-i", cp]
        cw, chh = c["w"], c["h"]
        crop = ch.get("crop", "768:1000:0:40")
        eq = ch.get("eq", "")
        eqs = (",eq=" + eq) if eq else ""
        fc.append(f"[{idx}:v]crop={crop},scale=-2:{chh}{eqs},"
                  f"pad={cw}:{chh}:(ow-iw)/2:0:white,format=rgba[c0]")
        mi = idx + 1
        inputs += ["-loop", "1", "-t", "%.3f" % total, "-i", mask_p]
        fc.append(f"[c0][{mi}:v]alphamerge[c1]")
        fi = mi + 1
        inputs += ["-loop", "1", "-t", "%.3f" % total, "-i", frame_p]
        fc.append(f"[{last}][c1]overlay={c['x']}:{c['y']}[b1]")
        fc.append(f"[b1][{fi}:v]overlay={c['x'] - pad}:{c['y'] - pad}[b2]")
        last, idx = "b2", fi + 1

    # 字幕
    subs = make_subs(cfg.get("subs", []), lay["sub"], W, work, font_path)
    si = idx
    for k, s in enumerate(subs):
        inputs += ["-loop", "1", "-t", "%.3f" % total, "-i", s["path"]]
        fc.append(f"[{last}][{si + k}:v]overlay={s['x']}:{s['y']}:"
                  f"enable='between(t,{s['start']:.3f},{s['end']:.3f})'[s{k}]")
        last = f"s{k}"
    idx = si + len(subs)
    inputs += ["-i", audio]
    fc.append(f"[{last}]format=yuv420p[vout]")

    if args.dry_run:
        print(json.dumps({"shots": info, "subs": [s["box"] for s in subs],
                          "total": total, "filter": ";".join(fc)}, ensure_ascii=False, indent=1))
        return

    run([args.ffmpeg, "-v", "error", "-y"] + inputs + [
        "-filter_complex", ";".join(fc),
        "-map", "[vout]", "-map", f"{idx}:a",
        "-c:v", "libx264", "-profile:v", "high", "-pix_fmt", "yuv420p", "-r", "24",
        "-crf", "19", "-preset", "medium",
        "-c:a", "aac", "-ar", "48000", "-b:a", "192k",
        "-movflags", "+faststart", "-t", "%.3f" % total, out])
    print("OUT =", out, "(%.2fs, %.2fMB)" % (total, os.path.getsize(out) / 1e6))


if __name__ == "__main__":
    main()
