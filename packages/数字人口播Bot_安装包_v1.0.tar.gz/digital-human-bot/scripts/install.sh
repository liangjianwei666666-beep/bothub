#!/usr/bin/env bash
# 数字人口播 Bot · 一键装配
# 用法: bash install.sh [安装目录，默认 ~/.dsh-video-bot]
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${1:-$HOME/.dsh-video-bot}"
SKILL_HOME="$HOME/.agents/skills/digital-human-bot"

c_ok()   { printf '  \033[32m✓\033[0m %s\n' "$1"; }
c_warn() { printf '  \033[33m!\033[0m %s\n' "$1"; }
c_bad()  { printf '  \033[31m✗\033[0m %s\n' "$1"; }

echo "=== 数字人口播 Bot · 装配 ==="
echo "  包目录: $SRC"
echo "  安装到: $DEST"

# ---------- 1. 技能注册（让所有 Bot 的会话都能看到它） ----------
mkdir -p "$SKILL_HOME"
if [ "$SRC" != "$SKILL_HOME" ]; then
  cp -R "$SRC"/. "$SKILL_HOME"/
  c_ok "技能已注册: $SKILL_HOME"
else
  c_ok "技能已在位: $SKILL_HOME"
fi

# ---------- 2. 引擎与工具 ----------
mkdir -p "$DEST"/{bin,docs,projects,input,output}
cp "$SKILL_HOME"/scripts/*.py  "$DEST/bin"/ 2>/dev/null || true
cp "$SKILL_HOME"/scripts/*.sh  "$DEST/bin"/ 2>/dev/null || true
chmod +x "$DEST"/bin/* 2>/dev/null || true
cp "$SKILL_HOME"/references/* "$DEST/docs"/ 2>/dev/null || true
cp "$SKILL_HOME"/templates/*  "$DEST/docs"/ 2>/dev/null || true
cp "$SKILL_HOME"/bot/instructions.md "$DEST/docs/instructions.md" 2>/dev/null || true
c_ok "引擎与文档已就位: $DEST"

# ---------- 3. 工具链探测 ----------
echo
echo "--- 工具链 ---"
find_ff() {
  for p in "$(command -v ffmpeg 2>/dev/null)" "$HOME/bin/ffmpeg" "/opt/homebrew/bin/ffmpeg" "/usr/local/bin/ffmpeg"; do
    [ -n "$p" ] && [ -x "$p" ] && echo "$p" && return 0
  done
  return 1
}
find_fp() {
  for p in "$(command -v ffprobe 2>/dev/null)" "$HOME/bin/ffprobe" "/opt/homebrew/bin/ffprobe" "/usr/local/bin/ffprobe"; do
    [ -n "$p" ] && [ -x "$p" ] && echo "$p" && return 0
  done
  return 1
}
FFMPEG="$(find_ff || true)"; FFPROBE="$(find_fp || true)"
if [ -n "$FFMPEG" ]; then c_ok "ffmpeg: $FFMPEG"; else c_bad "ffmpeg 未找到 → brew install ffmpeg"; fi
if [ -n "$FFPROBE" ]; then c_ok "ffprobe: $FFPROBE"; else c_bad "ffprobe 未找到 → 随 ffmpeg 提供"; fi
command -v python3 >/dev/null && c_ok "python3: $(command -v python3)" || c_bad "python3 未找到"
command -v node >/dev/null && c_ok "node: $(command -v node)（拉片用）" || c_warn "node 未找到（拉片不可用，不影响出片）"

# python 依赖
if python3 -c "import PIL, numpy" 2>/dev/null; then
  c_ok "Pillow + numpy 已装"
else
  c_warn "缺少 Pillow/numpy，尝试安装: python3 -m pip install --user pillow numpy"
  python3 -m pip install --user pillow numpy >/dev/null 2>&1 || true
  python3 -c "import PIL, numpy" 2>/dev/null && c_ok "Pillow + numpy 已装" || c_bad "Pillow/numpy 装不上，请手动 pip 安装"
fi

# 密钥（可选能力）
[ -f "$HOME/.dsh-autodl/token" ] || [ -n "${AUTODL_TOKEN:-}" ] \
  && c_ok "AutoDL token 已配置（可 AI 出镜头）" \
  || c_warn "AutoDL token 未配置 → 只能合成已有素材（见 docs/安装补充.md）"
[ -n "${TTS_API_KEY:-}${DSH_SECRET_DOUBAO_TTS_API_KEY:-}" ] \
  && c_ok "豆包 TTS 已配置（可 AI 配音）" \
  || c_warn "豆包 TTS 未配置 → 需自备录音或用其他 TTS"

# ---------- 4. 自检 ----------
echo
echo "--- 自检（微端到端，不花 API）---"
set +e
python3 "$DEST/bin/selfcheck.py" --ffmpeg "${FFMPEG:-ffmpeg}" --ffprobe "${FFPROBE:-ffprobe}"
RC=$?
set -e
if [ $RC -ne 0 ]; then
  echo
  c_bad "自检未通过，按上面的提示补齐依赖后重跑本脚本"
  exit 1
fi

# ---------- 5. 收尾 ----------
cat > "$DEST/环境.sh" <<EOF
# 用前 source 一下，把工具链和路径摆好
export PATH="$HOME/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export DH_HOME="$DEST"
export FFMPEG="${FFMPEG:-ffmpeg}"
export FFPROBE="${FFPROBE:-ffprobe}"
EOF
c_ok "环境脚本: source $DEST/环境.sh"

echo
echo "=== 装配完成 ==="
echo "  引擎: $DEST/bin"
echo "  文档: $DEST/docs"
echo "  项目: $DEST/projects"
echo
echo "  主 Bot 下一步：按 SKILL.md 第 2 步用 create_bot 建 Bot，"
echo "  instructions 用 bot/instructions.md 的内容（安装时已复制到 $DEST/docs/）。"
