#!/usr/bin/env bash
# 口型特写条：抽帧并裁嘴部区域（画面下部居中）放大，供人工目视核对口型
# 用法: lipsync_crops.sh <视频> [帧数=8] [输出png] [--bottom 0.38] [--width 0.44]
set -euo pipefail
FF="${FFMPEG:-$(command -v ffmpeg || echo "$HOME/bin/ffmpeg")}"
FP="${FFPROBE:-$(command -v ffprobe || echo "$HOME/bin/ffprobe")}"
[ $# -ge 1 ] || { echo "用法: lipsync_crops.sh <视频> [帧数=8] [输出png] [--bottom 0.38] [--width 0.44]"; exit 2; }
IN="$1"; N=8; OUT=""; BOT=0.38; WID=0.44; shift
# 其余参数：纯数字=帧数，--bottom/--width=裁剪比例，其他=输出路径（顺序随意）
while [ $# -gt 0 ]; do
  case "$1" in
    --bottom) BOT="$2"; shift 2;;
    --width)  WID="$2"; shift 2;;
    ''|*[!0-9]*) OUT="$1"; shift;;
    *) N="$1"; shift;;
  esac
done
[ -f "$IN" ] || { echo "找不到视频: $IN"; exit 2; }
DUR=$("$FP" -v error -show_entries format=duration -of csv=p=0 "$IN")
VW=$("$FP" -v error -select_streams v:0 -show_entries stream=width -of csv=p=0 "$IN")
VH=$("$FP" -v error -select_streams v:0 -show_entries stream=height -of csv=p=0 "$IN")
[ -n "$OUT" ] || OUT="${IN%.*}_口型特写.png"
CW=$(python3 -c "print(int($VW*$WID)//2*2)")
CH=$(python3 -c "print(int($VH*$BOT)//2*2)")
X=$(python3 -c "print(max(0,($VW-$CW)//2)//2*2)")
Y=$(python3 -c "print(max(0,$VH-$CH-int($VH*0.06))//2*2)")
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
i=0
while [ $i -lt "$N" ]; do
  T=$(python3 -c "d=$DUR; n=$N; i=$i; print(round(d*0.04 + (d*0.92)*i/max(1,n-1), 3))")
  "$FF" -v error -ss "$T" -i "$IN" -frames:v 1 -vf "crop=${CW}:${CH}:${X}:${Y},scale=iw*2:ih*2" "$TMP/m$(printf '%02d' $i).png" -y
  i=$((i+1))
done
COLS=$(python3 -c "import math;n=$N;c=4 if n>=8 else (3 if n>=6 else (2 if n>=4 else n));print(max(1,c))")
ROWS=$(python3 -c "import math;n=$N;c=$COLS;print(max(1,math.ceil(n/c)))")
"$FF" -v error -framerate 1 -i "$TMP/m%02d.png" -vf "tile=${COLS}x${ROWS}:padding=8:margin=8:color=white" -frames:v 1 "$OUT" -y
echo "OK 帧数=$N 网格=${COLS}x${ROWS} 裁剪=${CW}x${CH}@(${X},${Y}) 源=${VW}x${VH}"
echo "OUT=$OUT"
echo "注意: 这是给眼睛看的图，判定要人来做或看图模型来做，脚本不下结论。"
