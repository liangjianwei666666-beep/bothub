#!/usr/bin/env bash
# 卸载：删技能注册与引擎目录（不动你的项目和密钥）
set -euo pipefail
DEST="${1:-$HOME/.dsh-video-bot}"
SKILL_HOME="$HOME/.agents/skills/digital-human-bot"
echo "将删除：$SKILL_HOME 与 $DEST"
rm -rf "$SKILL_HOME" "$DEST"
echo "已卸载。项目文件、~/.dsh-autodl/token、~/.config/dsh/video.env 均未动。"
