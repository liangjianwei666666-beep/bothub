#!/usr/bin/env python3
"""豆包 seed-tts-2.0 单句合成（命令行，无第三方依赖）。

用法：
  python3 doubao_tts.py --text "旁白文本" --speaker zh_female_shuangkuaisisi_uranus_bigtts \
      --out out.mp3 [--speech-rate 0] [--encoding mp3] [--sample-rate 24000]

密钥从环境变量读：TTS_API_KEY / DOUBAO_TTS_API_KEY（先 source ~/.config/dsh/video.env）
"""
import argparse
import base64
import json
import os
import sys
import urllib.request
import uuid


def synth(text, out, speaker, speech_rate=0, encoding="mp3", sample_rate=24000,
          timeout=120):
    key = os.environ.get("TTS_API_KEY") or os.environ.get("DOUBAO_TTS_API_KEY")
    if not key:
        sys.exit("缺密钥：先 source ~/.config/dsh/video.env（需要 TTS_API_KEY）")
    endpoint = os.environ.get("DOUBAO_TTS_ENDPOINT",
                              "https://openspeech.bytedance.com/api/v3/plan/tts/unidirectional")
    body = json.dumps({
        "req_params": {"text": text, "speaker": speaker},
        "audio_params": {"format": encoding, "sample_rate": sample_rate,
                         "speech_rate": speech_rate},
    }, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(endpoint, data=body, method="POST", headers={
        "Content-Type": "application/json",
        "X-Api-Key": key,
        "X-Api-Resource-Id": os.environ.get("DOUBAO_TTS_RESOURCE_ID", "seed-tts-2.0"),
        "X-Api-Request-Id": str(uuid.uuid4()),
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as e:
        sys.exit(f"豆包 TTS HTTP {e.code}: {e.read()[:400]!r}")
    chunks = []
    for line in raw.decode("utf-8", "ignore").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        code = obj.get("code", 0)
        if code not in (0, 20000000):
            sys.exit(f"豆包 TTS 错误 code={code}: {str(obj)[:300]}")
        if obj.get("data"):
            chunks.append(base64.b64decode(obj["data"]))
    if not chunks:
        sys.exit(f"豆包 TTS 没返回音频片：{raw[:300]!r}")
    with open(out, "wb") as f:
        f.write(b"".join(chunks))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--speaker", default="zh_female_shuangkuaisisi_uranus_bigtts")
    ap.add_argument("--speech-rate", type=int, default=0)
    ap.add_argument("--encoding", default="mp3", choices=["mp3", "wav", "pcm", "ogg_opus"])
    ap.add_argument("--sample-rate", type=int, default=24000)
    a = ap.parse_args()
    synth(a.text, a.out, a.speaker, a.speech_rate, a.encoding, a.sample_rate)
    print(f"{a.out}  {os.path.getsize(a.out)} bytes  speaker={a.speaker}")


if __name__ == "__main__":
    main()
