---
name: digital-human-bot
description: 一键装配「数字人口播 Bot」。当用户说「装一个数字人口播 Bot」「装个能做口播视频的 Bot」「我要能自己出讲解视频的机器人」时使用。本技能教主 Bot 如何：① 跑 install.sh 把引擎装到本地并自检；② 用 create_bot 建出「数字人口播」Bot；③ 告诉用户还要补哪把密钥；④ 给出第一条片子的开工方式。装好后该 Bot 能把文案 + 角色形象 + 声音做成 1080×1920 竖屏成片（手绘逐笔动画 + 左下角虚拟角色对口型 + 右下角字幕）。
---

# digital-human-bot · 一键装配「数字人口播 Bot」

**这个技能是给「主 Bot」看的操作手册**：用户说一句「装一个数字人口播 Bot」，你按下面 4 步做完，用户就得到一个能出竖屏口播片的 Bot。

## 前置检查（30 秒）

```bash
ls ~/.agents/skills/digital-human-bot/scripts/install.sh   # 包是否已解到技能目录
command -v python3 && command -v ffmpeg
```

包没到位就先解压到 `~/.agents/skills/digital-human-bot/`（解压后目录名必须叫 `digital-human-bot`，否则技能不会被识别）。

## 步骤 1 · 跑装配脚本

```bash
bash ~/.agents/skills/digital-human-bot/scripts/install.sh
```

它会：注册技能 → 把引擎装到 `~/.dsh-video-bot/` → 探测工具链 → 装缺的 python 依赖 → 跑一次**微端到端自检**（画一张线稿→生成 2 秒镜头→合成 1080×1920→ffprobe 核规格，**不消耗 API**）。

自检 PASS 再往下走。若报缺 ffmpeg，先 `brew install ffmpeg` 后重跑。

## 步骤 2 · 建 Bot

用 `create_bot`：

- **name**: `数字人口播`
- **role**: `口播`
- **instructions**: 用 `~/.dsh-video-bot/docs/instructions.md` 的全文
- **work_dir**: `~/数字人口播`（没有就先 `mkdir -p`）

## 步骤 3 · 补密钥（可选，两把，看用户要哪些能力）

| 能力 | 需要什么 | 怎么配 |
|---|---|---|
| **AI 出镜头**（手绘逐笔动画、虚拟角色对口型） | AutoDL Art token | 写进 `~/.dsh-autodl/token`，或环境变量 `AUTODL_TOKEN` |
| **AI 配音**（豆包 TTS 男声/女声） | `TTS_API_KEY` + `TTS_APP_ID` | 环境变量，或写进 `~/.config/dsh/video.env` |

两把都没有也能用：可以合成用户自备的素材、只做排版+字幕+重编码。**不要替用户去注册账号或猜测密钥**。

## 步骤 4 · 验一下那两把钥匙

```bash
cd ~/.dsh-video-bot && python3 bin/tts.py --list           # 有输出=密钥形状对
python3 bin/tts.py --text "测试" --out /tmp/t.wav          # 能出声=真能用
```

AutoDL 那把用一条最短任务验，别空跑：

```bash
python3 bin/submit_clips.py doodle --image 某张线稿.png --duration 3 --out /tmp/s.mp4
```

跑通了再让 Bot 接活。跑不通就把报错原文交回用户，不要自己换账号。

## 装好之后给用户的话（照这个说）

> 装好了。这个 Bot 做的是：文案 → 配音 → 手绘逐笔动画 + 左下角虚拟角色对口型 → 1080×1920 成片。
> 现在缺三样素材：文案、角色形象图、声音（你本人录音或指定音色）。
> 给我这三样，我出第一条。

---

## 这个 Bot 会什么（供你判断能不能接用户的活）

- **通道选择**（选错整条重做）：
  - 必须保留用户原声、要真对口型 → `minimax_h3_image_audio_to_video`（单段 ≤15 秒，保留输入音频）
  - 只要手绘逐笔画出 → `minimax_h3_lightx2v_v5`（1–10 秒）
  - **绝不**用 `zm_u24` 系做本人原声：它会替换音轨，口型对的是它自己编的声音
- **成本**（768p 实测价）：对口型/逐笔都是 50 分/秒；15 秒对口型约 857 秒渲染
- **验收纪律**：音轨相关系数高只证明音轨接对，不证明口型；口型必须抽帧目视（读不了图就明说未核验）

## 给用户的配套

`assets/workspace.html` 是自包含工作台（双击能开，无网络依赖）：通道选择器 + 成本估算 + 验收清单。装好后连同 Bot 一起交给用户。
