# 数字人口播 Bot · 安装包

一句话：**文案 + 角色形象 + 声音 → 1080×1920 竖屏口播成片**（手绘逐笔动画 + 左下角虚拟角色对口型 + 右下角字幕）。

## 怎么用

把这个文件夹发给任意 DSH 用户，让他丢给**主 Bot** 并说一句「装这个」。主 Bot 会读 `SKILL.md`，按四步：解包 → 跑 `scripts/install.sh` → `create_bot` → 补密钥。

## 目录

```
SKILL.md              主 Bot 的操作手册（四步装配）
bot/instructions.md   建 Bot 时用的 instructions 全文
scripts/
  install.sh          一键装配 + 自检
  uninstall.sh        卸载（不动项目和密钥）
  selfcheck.py        微端到端自检，不花 API
  build_video.py      通用合成器（配置驱动）
  submit_clips.py     出镜头（手绘逐笔 / 对口型）
  tts.py              配音（豆包 TTS，男声4个实测可用）
  doubao_tts_core.py  配音核心（随包附带，已验证可跑）
references/           工作流方法论、分镜模板
templates/            project.json / jobs.json 示例
assets/workspace.html 自包含工作台（双击可开）
```

## 两条硬限制（先说清，免得白花分）

1. **必须保留本人原声**时只能用 `minimax_h3_image_audio_to_video`，单段上限 15 秒；`zm_u24` 系会换掉音轨，口型必然错位。
2. **口型与"逐笔画出"必须抽帧目视**。音轨相关系数高只证明音轨接对，不证明嘴对上了。

## 需要的密钥（都可选，缺了降级用）

| 能力 | 密钥 |
|---|---|
| AI 出镜头 | AutoDL Art token（`~/.dsh-autodl/token` 或 `AUTODL_TOKEN`） |
| AI 配音 | `TTS_API_KEY` + `TTS_APP_ID`（豆包） |

两把都没有也能做：合成自备素材、排版、字幕、重编码、验收。

## 实测成本（768p）

对口型/逐笔均 50 分/秒。4 秒 ≈ 238 秒渲染；13 秒 ≈ 579 秒；15 秒 ≈ 857 秒。改字幕/配色/版式不花分。
