# 离线图像处理引擎；分发版不含密钥读取和网络请求。
import argparse
import base64
import io
import json
import os
import random
import re
import shutil
import string
import sys
import time
import zipfile
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw

BASE = Path(__file__).resolve().parent
PROJECTS = BASE / "projects"
ALPHA_MIN = 16
COLS, ROWS = 4, 4
TOTAL = COLS * ROWS

# 16 个表情固定顺序（与提示词一一对应，避免模型乱序）
CN_NAMES = [
    "开心大笑", "温柔微笑", "害羞脸红", "得意",
    "大哭", "委屈", "生气", "震惊",
    "无语", "翻白眼", "无奈", "点赞",
    "比心", "亲亲", "困了", "好吃",
]
EN_EXP = [
    "happy big laughing with open mouth",
    "gentle warm smile",
    "shy and blushing, hands on cheeks",
    "smug confident smirk",
    "crying hard with tears streaming",
    "pouty hurt feelings, about to cry",
    "angry and furious",
    "shocked, jaw dropped",
    "speechless blank deadpan face",
    "rolling eyes, annoyed",
    "helpless sighing, facepalm",
    "thumbs up, approving",
    "heart hands, showing love",
    "blowing a kiss",
    "sleepy, yawning",
    "eating something delicious, yummy",
]

STYLES = {
    "like": "near-realistic cute illustration style: the face is drawn very close to the real photo with only a light cute touch; head size and face proportions stay close to natural; clean smooth colors",
    "wechat": "cute WeChat-style cartoon sticker, light Q-version (head only slightly larger), clean thick outlines, flat vibrant colors, kawaii",
    "ugly": 'hand-drawn "ugly-cute" (chou-meng) sticker style: rough sketchy ink outlines, playful funny proportions, warm paper-like colors, lots of personality',
    "plush": "soft glossy 3D plush-toy / clay sticker style: round cute doll version, smooth shading, premium toy feel",
    "pixel": "simplified retro pixel-art sticker style: crisp chunky pixels, limited palette, retro game feel",
}
STYLE_ALIAS = {
    "本人": "like", "像本人": "like", "轻卡通": "like",
    "微信": "wechat", "q版": "wechat", "q": "wechat", "卡通": "wechat",
    "丑萌": "ugly", "手绘": "ugly", "手绘风": "ugly",
    "3d": "plush", "玩偶": "plush", "软萌": "plush", "黏土": "plush",
    "像素": "pixel", "复古像素": "pixel",
}
LIKENESS = {
    "like": [
        "LIKENESS FIRST: every sticker must look like the SAME person as in the reference photo — copy the face faithfully.",
        "The face is a faithful copy: do NOT restyle or beautify the nose, mouth, jaw, eyes or face shape beyond natural expression (a happy squint or open mouth is fine); do NOT change hairstyle, hair color, hairline, skin tone, glasses, beard, or outfit. Only the emotion/expression changes between cells.",
        "Cartoonization must stay light; when in doubt, choose likeness over cuteness.",
    ],
    "cute": [
        "Cute kawaii style first; exact likeness may be relaxed, but all 16 stickers must still be the same consistent character.",
    ],
}
LIKENESS_PHRASE = {
    "like": ", likeness to the reference face is the top priority",
    "cute": ", exaggerated cute kawaii big-head cartoon, likeness can relax",
}


def rand_suffix(n=6):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def sniff_ext(raw):
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if raw[:3] == b"\xff\xd8\xff":
        return "jpg"
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return "webp"
    return "png"


def sanitize_name(name, fallback="sticker"):
    name = re.sub(r'[\\/:*?"<>|\r\n\t]', "", str(name or "")).strip()
    name = name.strip(" .")
    return (name or fallback)[:30]


# ---------------------------------------------------------------- 提示词
def build_prompt(style="wechat", likeness="like"):
    st = STYLES.get(STYLE_ALIAS.get(str(style).lower(), str(style)), STYLES["wechat"])
    style_en = st + LIKENESS_PHRASE.get(likeness, LIKENESS_PHRASE["like"])

    def row(a, b, c, d):
        return ("  Row %d: %d) %s, %d) %s, %d) %s, %d) %s"
                % (a // 4 + 1, a + 1, EN_EXP[a], b + 1, EN_EXP[b],
                   c + 1, EN_EXP[c], d + 1, EN_EXP[d]))

    return "\n".join([
        "Personal sticker pack (emoji stickers) of the EXACT SAME person/character as in the reference photo.",
        "Study the reference photo carefully: this is the person to draw in every cell.",
        "Style: " + style_en + ".",
        "Layout: fill the ENTIRE square canvas with a 4x4 grid of 16 EQUAL cells (4 columns x 4 rows); every cell must be cleanly separated from its neighbors.",
        "Every cell: ONE independent sticker of the same person, each with a DIFFERENT exaggerated facial expression, in fixed order (row by row, left to right):",
        row(0, 1, 2, 3), row(4, 5, 6, 7), row(8, 9, 10, 11), row(12, 13, 14, 15),
        "Rules:",
        *["- " + t for t in LIKENESS.get(likeness, LIKENESS["like"])],
        "- Leave a clearly visible, fully transparent gap (margin) between every pair of cells — no sticker may touch, overlap or bleed into another cell.",
        "- Each sticker: the whole head + shoulders (upper body) fully inside its own cell with a small margin; ONE clear emotion per cell, readable at a glance.",
        "- Consistent style, colors and proportions across all 16 cells.",
        "- Background fully transparent (RGBA PNG). No text, no letters, no numbers, no grid lines, no borders, no watermark anywhere.",
    ])


# ---------------------------------------------------------------- 图像：切格
def sheet_bbox(im, trim):
    w, h = im.size
    if not trim:
        return (0, 0, w, h)
    rgba = im.convert("RGBA")
    alpha = rgba.getchannel("A")
    if alpha.getextrema()[0] < ALPHA_MIN:
        bbox = alpha.point(lambda a: 255 if a >= ALPHA_MIN else 0).getbbox()
        if bbox:
            return bbox
    rgb = rgba.convert("RGB")
    white = Image.new("RGB", im.size, (255, 255, 255))
    diff = ImageChops.difference(rgb, white).convert("L")
    bbox = diff.point(lambda v: 255 if v > 12 else 0).getbbox()
    return bbox or (0, 0, w, h)


def _split_lines(bounds_lo, bounds_hi, gap_centers, need):
    seps = sorted(set(c for c in gap_centers if bounds_lo < c < bounds_hi))
    if len(seps) == need and all(a < b for a, b in zip(seps, seps[1:])):
        return [bounds_lo] + seps + [bounds_hi]
    vals = []
    for k in range(1, need + 1):
        t = bounds_lo + (bounds_hi - bounds_lo) * k // (need + 1)
        if t <= bounds_lo:
            t = bounds_lo + k
        vals.append(t)
    return [bounds_lo] + vals + [bounds_hi]


def _gap_centers(line_is_gap, lo, hi, need):
    runs, start = [], -1
    for i in range(lo, hi):
        if line_is_gap(i):
            if start < 0:
                start = i
        elif start >= 0:
            runs.append((start, i - 1))
            start = -1
    if start >= 0:
        runs.append((start, hi - 1))
    if len(runs) < need:
        return []
    chosen = []
    for k in range(need):
        ideal = lo + (hi - lo) * (k + 1) // (need + 1)
        best, bd = -1, 10 ** 18
        for ri, (a, b) in enumerate(runs):
            if ri in chosen:
                continue
            d = abs((a + b) // 2 - ideal)
            if d < bd:
                bd, best = d, ri
        chosen.append(best)
    chosen.sort()
    return [(runs[i][0] + runs[i][1] + 1) // 2 for i in chosen]


def grid_cells(image_bytes, cols=COLS, rows=ROWS, trim_sheet=True):
    """按格子间空隙切格；找不到空隙时退回均分。返回 (cells, bbox, cw, ch)。"""
    src = Image.open(io.BytesIO(image_bytes))
    src.load()
    cols, rows = int(cols), int(rows)
    if cols < 1 or rows < 1 or cols * rows > 400:
        raise ValueError("网格参数非法")
    x0, y0, x1, y1 = sheet_bbox(src, bool(trim_sheet))
    w, h = src.size
    rgba = src.convert("RGBA")
    buf = rgba.tobytes()
    use_alpha = any(buf[i] < 16 for i in range(3, len(buf), 4))
    thr_r = max(1, w * 25 // 10000)
    thr_c = max(1, h * 25 // 10000)

    def is_content(o):
        return buf[o + 3] >= 16 if use_alpha \
            else (buf[o] <= 242 or buf[o + 1] <= 242 or buf[o + 2] <= 242)

    row_cnt, col_cnt = [0] * h, [0] * w
    for y in range(h):
        base = y * w * 4
        rc = 0
        for x in range(w):
            if is_content(base + x * 4):
                rc += 1
                col_cnt[x] += 1
        row_cnt[y] = rc
    ys = _gap_centers(lambda i: row_cnt[i] <= thr_r, y0, y1, rows - 1)
    xs = _gap_centers(lambda i: col_cnt[i] <= thr_c, x0, x1, cols - 1)
    yb = _split_lines(y0, y1, ys, rows - 1)
    xb = _split_lines(x0, x1, xs, cols - 1)
    cells = {}
    for r in range(rows):
        for c in range(cols):
            cells[r * cols + c] = src.crop((xb[c], yb[r], xb[c + 1], yb[r + 1]))
    cw = max(1, min(xb[c + 1] - xb[c] for c in range(cols)))
    ch = max(1, min(yb[r + 1] - yb[r] for r in range(rows)))
    return cells, (x0, y0, x1, y1), cw, ch


# ---------------------------------------------------------------- 图像：GIF
def rgba_to_p(res):
    mask = res.getchannel("A").point(lambda a: 0 if a >= 128 else 255)
    rgb = Image.new("RGB", res.size)
    rgb.paste(res, mask=res.getchannel("A"))
    p = rgb.quantize(colors=255, method=Image.Quantize.MEDIANCUT)
    const = Image.new("P", (1, 1), 255).resize(res.size)
    return Image.composite(const, p, mask)


def make_gif(image_bytes, order=None, duration_ms=600, pingpong=True,
             cols=COLS, rows=ROWS, tight_cells=True, scale=1):
    cells, bbox, cw, ch = grid_cells(image_bytes, cols, rows, True)
    order = list(order or range(cols * rows))
    if pingpong and len(order) > 1:
        order = order + list(reversed(order))[1:-1]
    frames = []
    for i in order:
        if i not in cells:
            raise ValueError("帧序号 %d 超出 0..%d" % (i, cols * rows - 1))
        f = cells[i].convert("RGBA")
        if tight_cells:
            x0, y0, x1, y1 = sheet_bbox(f, True)
            if x1 > x0 and y1 > y0:
                f = f.crop((x0, y0, x1, y1))
        if scale > 1:
            f = f.resize((f.width * scale, f.height * scale), Image.NEAREST)
        frames.append(f)
    if not frames:
        raise ValueError("没有可选帧")
    # 统一画布：取最大帧，居中贴，避免不同尺寸帧错位
    mw = max(f.width for f in frames)
    mh = max(f.height for f in frames)
    canvas = []
    for f in frames:
        c = Image.new("RGBA", (mw, mh), (0, 0, 0, 0))
        c.paste(f, ((mw - f.width) // 2, (mh - f.height) // 2))
        canvas.append(c)
    pfs = [rgba_to_p(f) for f in canvas]
    buf = io.BytesIO()
    pfs[0].save(buf, format="GIF", save_all=True, append_images=pfs[1:],
                duration=int(duration_ms), loop=0, transparency=255,
                disposal=2, optimize=False)
    meta = {"frames": len(pfs), "out_w": pfs[0].width, "out_h": pfs[0].height,
            "duration_ms": int(duration_ms)}
    return buf.getvalue(), meta


# ---------------------------------------------------------------- 图像：打包
def make_pack(image_bytes, indices=None, labels=None, cols=COLS, rows=ROWS, tight=True):
    cells, bbox, cw, ch = grid_cells(image_bytes, cols, rows, True)
    indices = list(indices if indices is not None else range(cols * rows))
    labels = labels or []
    out_files = []
    for pos, i in enumerate(indices):
        if i not in cells:
            raise ValueError("序号 %d 超出 0..%d" % (i, cols * rows - 1))
        img = cells[i].convert("RGBA")
        if tight:
            x0, y0, x1, y1 = sheet_bbox(img, True)
            if x1 > x0 and y1 > y0:
                img = img.crop((x0, y0, x1, y1))
        label = sanitize_name(labels[pos] if pos < len(labels) else
                              (CN_NAMES[i] if i < len(CN_NAMES) else ""))
        fname = "%02d_%s.png" % (pos + 1, label)
        out_files.append((fname, img))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, img in out_files:
            b = io.BytesIO()
            img.save(b, "PNG")
            zf.writestr(fname, b.getvalue())
    meta = {"count": len(out_files), "names": [f for f, _ in out_files],
            "cell_w": cw, "cell_h": ch}
    return buf.getvalue(), out_files, meta


# ---------------------------------------------------------------- 预览图
def _font(size):
    for p in ("/System/Library/Fonts/PingFang.ttc",
              "/System/Library/Fonts/STHeiti Light.ttc",
              "/System/Library/Fonts/Hiragino Sans GB.ttc"):
        if Path(p).exists():
            try:
                from PIL import ImageFont
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    from PIL import ImageFont
    return ImageFont.load_default()


def make_preview(stickers, labels=None, cols=COLS, cell=320, pad=18, header=54):
    """把 16 张贴纸拼成一张预览图（棋盘底，看透明）。"""
    rows = (len(stickers) + cols - 1) // cols
    W = cols * (cell + pad) + pad
    H = rows * (cell + pad) + pad + header
    bg = Image.new("RGB", (W, H), (250, 250, 252))
    d = ImageDraw.Draw(bg)
    # 棋盘格
    sq = 16
    for y in range(header, H, sq):
        for x in range(0, W, sq):
            if ((x // sq) + (y // sq)) % 2 == 0:
                d.rectangle([x, y, x + sq - 1, y + sq - 1], fill=(240, 240, 244))
    f = _font(22)
    for i, im in enumerate(stickers):
        r, c = divmod(i, cols)
        box_x = pad + c * (cell + pad)
        box_y = header + pad + r * (cell + pad)
        thumb = im.copy()
        thumb.thumbnail((cell, cell), Image.LANCZOS)
        bg.paste(thumb, (box_x + (cell - thumb.width) // 2,
                         box_y + (cell - thumb.height) // 2), thumb)
        label = (labels[i] if labels and i < len(labels)
                 else (CN_NAMES[i] if i < len(CN_NAMES) else str(i + 1)))
        d.text((box_x + 6, box_y + cell - 30), "%02d %s" % (i + 1, label),
               fill=(60, 60, 70), font=f)
    return bg


