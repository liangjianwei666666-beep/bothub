# 表情包工坊 · v1.0.0

给专属 Bot 一张明确的当前照片，再说“做表情包”，生成一张 4×4 表情底图，在本地切出 16 张图片及一个 **16 表情轮播 GIF**。它不是连续动作动画，不保证每格严格对应指定表情语义。

## 交给主 Bot 安装

把**这次收到的原始分发 zip**作为当前附件交给主 Bot，并说：“请阅读包内 INSTALL_FOR_MAIN_BOT.md，安全安装并创建表情包工坊。”主 Bot 只能用这次附件，不能扫描缓存寻找“最新版”。首次使用仅需在安全密钥卡中配置你自己的 Key；不要在聊天中明文发送密钥。

安装时须告知一次：后续你明确选择照片并要求“做表情包”，该照片会发送给 **TelangpuAI** 处理；本地也会保存参考图、底图和结果。未收到明确制作指令不会上传。实际 API 金额未知，本包不能核对或保证账单费用。安装、离线自检和验收不调用真实生图 API，也不以付费请求试 Key。

## 环境与安装器

- Python **3.9 或以上**，包含标准库 `venv`、`ensurepip`、`ssl`。
- 依赖：`Pillow>=10,<12`、`requests>=2.31,<3`。
- 默认安装位置：`Path.home() / "DSBot" / "表情包工坊"`，不依赖桌面路径，按 macOS、Windows、Linux 跨平台设计；本次 macOS 实测，Windows/Linux 未实机验证。
- 目标必须不存在或为空目录；遇到任何现有文件（包括隐藏文件）、符号链接路径或与分发目录重叠时拒绝。**不覆盖旧项目或配置；没有强制覆盖选项。**
- `--check-only` 只检查 Python、标准库、包文件、依赖声明和目标目录，不创建目录、不安装、不联网。不会保证包索引可用、磁盘足够或 API 可用。
- 正式安装创建独立 `.venv`，用其 pip 安装依赖；此步骤可能访问 Python 包索引。**“离线自检”不等于依赖安装完全离线。**

在已安全检查并解压的分发目录中，使用本机可用的 Python 3.9+：

```text
python install.py --check-only
python install.py
python install.py --target "自选的全新安装目录"
```

macOS/Linux 的启动器常为 `python3`，Windows 可使用 `py -3`。路径通过参数数组传递或按所在 shell 正确引用，不拼接来自附件的命令。不要在分发目录内安装。

安装器只复制以下 **7 个文件**：

```text
app.py
engine.py
requirements.txt
BOT_INSTRUCTIONS.md
tests/test_offline.py
README.md
VERSION
```

它不复制密钥、`.env`、缓存、已有项目、其他用户配置或安装脚本本身。安装器与主 Bot 安装手册留在经过检查的分发目录。

### 成功与失败

安装器先确认文件存在，再依次运行：

```text
<安装后的 Python> app.py doctor --offline
<安装后的 Python> tests/test_offline.py
```

**仅当依赖安装、doctor 与离线测试全部成功**，才创建安装目录内 `INSTALL_RECEIPT.json`，并在 stdout 输出一份 JSON；进度和子进程日志写 stderr。receipt 中 `work_dir`、`python`、`instructions_file` 都是绝对路径；`python` 保留虚拟环境路径，不能把它解析成系统 Python 后使用。

失败返回非零状态与 `success:false` JSON，不宣称安装成功；已经创建的目标会保留用于排查，不自动删除。若需要重装，检查失败原因后选择另一个全新/空目录，不覆盖或清理旧目录。`--check-only` 返回 `status:checked, installed:false`，不能当成安装成功。

没有 Key 仍可完成安装和离线测试，但**不能生成新图片**。仅安全配置用户自己的 `TELANGPUAI_IMAGE_API_KEY`；DSH 注入的 `DSH_SECRET_TELANGPUAI_IMAGE_API_KEY` 由应用原生支持。无需把 Key 复制到文件。

## 日常使用与恢复

- 在专属 Bot 中发送一张明确图片并说“做表情包”；只发图时 Bot 不运行生成。
- 默认 `like` 风格。先以相同参数执行 `--dry-run`，成功后才执行一次真实生成。
- 已有底图用 `app.py cut --project <项目ID>` 本地重新切图，不重新生图。
- 失败、超时或返回结果不确定时绝不自动重试。保留 `generation-attempt.json`，不能删锁、改照片、换风格或换项目绕过。
- 交付前检查预览及 GIF 的实际视觉和背景。当前 GIF 合成使用白色背景；不能凭 PNG 的 alpha 通道或提示词承诺透明背景。
- 真人照片优先私人自用；不承诺微信表情商店投稿、审核、上架或已通过客户端导入验收。输出 GIF 文件卡，并用一句话说明轮播/背景/投稿限制。

本包制作与离线验收均不需要调用真实图片 API。
