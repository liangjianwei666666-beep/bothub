#!/usr/bin/env python3
"""Offline regression suite. Run from the bundle: python tests/test_offline.py.

All application paths and credentials are isolated per test. No provider is called,
no fixture is copied from a real photo, and no production project is written.
"""
import base64
from contextlib import ExitStack, redirect_stderr, redirect_stdout
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

# Avoid even __pycache__ writes beside the distributed application.
sys.dont_write_bytecode = True
BUNDLE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BUNDLE))
import app
import engine
import requests
from PIL import Image, ImageDraw


FAKE_KEY = "offline-test-secret-NEVER-A-REAL-CREDENTIAL"


def make_sheet():
    """Draw 16 unique colored cells, with transparent separators, in row order."""
    image = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    colors = []
    for i in range(16):
        color = (30 + 13 * i, 210 - 9 * i, 35 + 11 * i, 255)
        colors.append(color)
        row, column = divmod(i, 4)
        x, y = column * 64, row * 64
        draw.rectangle((x + 8, y + 8, x + 55, y + 55), fill=color)
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue(), colors


class OfflineTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.root = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix="sticker-offline-"))).resolve()
        # Clear every inherited credential, proxy and provider setting, not just
        # the three current key aliases. patch.dict restores the environment.
        self.stack.enter_context(mock.patch.dict(os.environ, {}, clear=True))
        self.stack.enter_context(mock.patch.object(app, "ROOT", self.root))
        self.stack.enter_context(mock.patch.object(engine, "BASE", self.root))
        self.stack.enter_context(mock.patch.object(engine, "PROJECTS", self.root / "projects"))
        self.network = self.stack.enter_context(mock.patch.object(
            requests.Session, "request", side_effect=AssertionError("REAL NETWORK FORBIDDEN")))
        self.stack.callback(self.network.assert_not_called)
        # Also forbid accidental socket/DNS use outside the requests boundary.
        self.stack.enter_context(mock.patch("socket.create_connection", side_effect=AssertionError("NETWORK FORBIDDEN")))
        self.stack.enter_context(mock.patch("socket.getaddrinfo", side_effect=AssertionError("DNS FORBIDDEN")))
        self.photo = self.root / "synthetic-reference.png"
        with Image.new("RGB", (32, 32), (45, 80, 120)) as image:
            image.save(self.photo)
        self.sheet, self.colors = make_sheet()

    def cli(self, *arguments):
        stdout, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            code = app.main(list(arguments))
        text = stdout.getvalue()
        self.assertNotIn(FAKE_KEY, text + stderr.getvalue())
        self.assertEqual(stderr.getvalue(), "")
        return code, json.loads(text)

    def make(self, *extra):
        return self.cli("make", "--photo", str(self.photo), *extra)

    def set_key(self):
        os.environ["STICKER_API_KEY"] = FAKE_KEY

    def snapshot(self):
        return {str(p.relative_to(self.root)): p.read_bytes()
                for p in self.root.rglob("*") if p.is_file()}

    def assert_no_secrets_saved(self):
        for path in self.root.rglob("*"):
            if path.is_file():
                self.assertNotIn(FAKE_KEY.encode(), path.read_bytes(), str(path))

    def assert_pack(self, result):
        self.assertTrue(result["ok"])
        self.assertEqual(result["count"], 16)
        for key in ("gif", "zip", "preview"):
            path = Path(result[key]).resolve()
            self.assertTrue(path.is_relative_to(self.root))
            self.assertTrue(path.is_file())
        with Image.open(result["gif"]) as gif:
            self.assertEqual(gif.format, "GIF")
            self.assertEqual(gif.size, (320, 320))
            self.assertEqual(gif.info.get("loop"), 0)
            self.assertEqual(gif.n_frames, 30)
            self.assertEqual(result["gif_frames"], gif.n_frames)
            centers = []
            for index in range(gif.n_frames):
                gif.seek(index)
                gif.load()
                self.assertEqual(gif.size, (320, 320))
                self.assertEqual(gif.info.get("duration"), 600)
                centers.append(gif.convert("RGB").getpixel((160, 160)))
            self.assertEqual(centers[:16], [color[:3] for color in self.colors])
            self.assertEqual(centers[16:], centers[14:0:-1])
        with zipfile.ZipFile(result["zip"]) as pack:
            self.assertEqual(pack.namelist(), ["%02d.png" % n for n in range(1, 17)])
            self.assertIsNone(pack.testzip())
            for index, name in enumerate(pack.namelist()):
                with Image.open(io.BytesIO(pack.read(name))) as image:
                    image.load()
                    self.assertEqual(image.format, "PNG")
                    self.assertEqual(image.convert("RGBA").getpixel((image.width // 2, image.height // 2)), self.colors[index])
        self.assert_no_secrets_saved()

    def test_doctor_offline_does_not_contact_network_or_write_projects(self):
        before = self.snapshot()
        code, result = self.cli("doctor", "--offline")
        self.assertEqual(code, 0)
        self.assertTrue(result["offline"])
        self.assertFalse(result["api_health_verified"])
        self.assertFalse(result["key_configured"])
        self.assertEqual(Path(result["root"]), self.root)
        self.assertEqual(before, self.snapshot())
        self.assertFalse((self.root / "projects").exists())

    def test_dry_run_without_authorization_or_key_is_read_only(self):
        before = self.snapshot()
        with mock.patch.object(app, "generate") as generate:
            code, result = self.make("--dry-run")
        self.assertEqual(code, 0)
        self.assertTrue(result["dry_run"])
        self.assertEqual(result["network_calls"], 0)
        self.assertTrue(result["prompt"])
        self.assertEqual(before, self.snapshot())
        self.assertFalse((self.root / "projects").exists())
        generate.assert_not_called()

    def test_missing_authorization_rejects_even_with_key(self):
        self.set_key()
        before = self.snapshot()
        with mock.patch.object(app, "generate") as generate:
            code, result = self.make()
        self.assertEqual(code, 2)
        self.assertFalse(result["ok"])
        self.assertIn("授权", result["error"])
        self.assertEqual(before, self.snapshot())
        generate.assert_not_called()

    def test_missing_key_rejects_before_project_creation(self):
        before = self.snapshot()
        with mock.patch.object(app, "generate") as generate:
            code, result = self.make("--authorized")
        self.assertEqual(code, 2)
        self.assertFalse(result["ok"])
        self.assertIn("密钥", result["error"])
        self.assertEqual(before, self.snapshot())
        self.assertFalse((self.root / "projects").exists())
        generate.assert_not_called()

    def test_make_once_then_reuse_even_renamed_photo_without_key(self):
        self.set_key()
        with mock.patch.object(app, "generate", return_value=self.sheet) as generate:
            code, first = self.make("--authorized")
            self.assertEqual(code, 0)
            self.assert_pack(first)
            generate.assert_called_once()
            self.assertEqual(generate.call_args.args[2], FAKE_KEY)
            attempt = self.root / "projects" / first["project_id"] / "generation-attempt.json"
            record = json.loads(attempt.read_text())
            self.assertEqual(record["status"], "sheet_saved")
            self.assertFalse(record["retry"])
            os.environ.clear()
            code, second = self.make("--authorized")
            self.assertEqual(code, 0)
            self.assertEqual(first["project_id"], second["project_id"])
            renamed = self.root / "renamed-reference.png"
            renamed.write_bytes(self.photo.read_bytes())
            code, third = self.cli("make", "--photo", str(renamed), "--authorized")
            self.assertEqual(code, 0)
            self.assertEqual(first["project_id"], third["project_id"])
            generate.assert_called_once()
            self.assert_pack(third)
            code, unauthorized = self.make()
            self.assertEqual(code, 2)
            self.assertIn("授权", unauthorized["error"])

    def test_failed_generation_keeps_attempt_and_blocks_second_submission(self):
        for label, behavior in (("provider", app.UserError("模拟提交失败")),
                                ("exception", RuntimeError(FAKE_KEY)),
                                ("invalid-image", b"not-an-image")):
            with self.subTest(failure=label):
                # Different synthetic visible pixels create independent test cases.
                Image.new("RGB", (32, 32), (10, 20, len(label) * 10)).save(self.photo)
                self.set_key()
                kwargs = {"side_effect": behavior} if isinstance(behavior, BaseException) else {"return_value": behavior}
                with mock.patch.object(app, "generate", **kwargs) as generate:
                    code, result = self.make("--authorized")
                    self.assertNotEqual(code, 0)
                    self.assertFalse(result["ok"])
                    _, dry = self.make("--dry-run")
                    project = self.root / "projects" / dry["project_id"]
                    attempt = project / "generation-attempt.json"
                    self.assertTrue(attempt.is_file())
                    self.assertEqual(json.loads(attempt.read_text())["status"], "submitting")
                    self.assertFalse((project / "sheets" / "sheet.png").exists())
                    old_record = attempt.read_bytes()
                    code, repeated = self.make("--authorized")
                    self.assertEqual(code, 2)
                    self.assertIn("禁止", repeated["error"])
                    self.assertEqual(attempt.read_bytes(), old_record)
                    generate.assert_called_once()
                self.assert_no_secrets_saved()

    def test_cut_failure_recovers_saved_sheet_without_resubmission(self):
        self.set_key()
        with mock.patch.object(app, "generate", return_value=self.sheet) as generate:
            with mock.patch.object(engine, "make_pack", side_effect=RuntimeError(FAKE_KEY)):
                code, result = self.make("--authorized")
            self.assertEqual(code, 1)
            self.assertFalse(result["ok"])
            _, dry = self.make("--dry-run")
            project = self.root / "projects" / dry["project_id"]
            self.assertTrue((project / "sheets" / "sheet.png").is_file())
            self.assertTrue((project / "generation-attempt.json").is_file())
            os.environ.clear()
            code, recovered = self.make("--authorized")
            self.assertEqual(code, 0)
            generate.assert_called_once()
            self.assert_pack(recovered)

    def test_cut_rejects_traversal_absolute_and_external_symlink_paths(self):
        outside = self.root / "outside"
        (outside / "sheets").mkdir(parents=True)
        (outside / "sheets" / "sheet.png").write_bytes(self.sheet)
        projects = self.root / "projects"
        projects.mkdir()
        (projects / "escape").symlink_to(outside, target_is_directory=True)
        before = self.snapshot()
        for project in ("..", "../outside", "../../outside", str(outside), "escape", ".", "missing"):
            with self.subTest(project=project), mock.patch.object(app, "cut_project") as cut:
                code, result = self.cli("cut", "--project", project)
                self.assertEqual(code, 2)
                self.assertFalse(result["ok"])
                cut.assert_not_called()
        self.assertEqual(before, self.snapshot())
        self.assertFalse((outside / "out").exists())

    def test_changing_style_cannot_bypass_failed_photo_lock(self):
        self.set_key()
        with mock.patch.object(app, "generate", side_effect=app.UserError("模拟失败")) as generate:
            code, _ = self.make("--authorized", "--style", "like")
            self.assertEqual(code, 2)
            code, result = self.make("--authorized", "--style", "pixel")
            self.assertEqual(code, 2)
            self.assertIn("禁止", result["error"])
            generate.assert_called_once()
        self.assertEqual(len(list((self.root / "projects").glob("*/generation-attempt.json"))), 1)

    def test_reentrant_submission_sees_exclusive_attempt_before_generator(self):
        self.set_key()
        nested = []

        def generate_once(*args):
            nested.append(self.make("--authorized"))
            return self.sheet

        with mock.patch.object(app, "generate", side_effect=generate_once) as generate:
            code, result = self.make("--authorized")
        self.assertEqual(code, 0)
        self.assertEqual(nested[0][0], 2)
        self.assertIn("禁止", nested[0][1]["error"])
        generate.assert_called_once()
        self.assert_pack(result)

    def test_cut_rejects_internal_project_alias_and_symlinked_output(self):
        projects = self.root / "projects"
        real = projects / "real"
        (real / "sheets").mkdir(parents=True)
        (real / "sheets" / "sheet.png").write_bytes(self.sheet)
        (projects / "alias").symlink_to(real, target_is_directory=True)
        code, result = self.cli("cut", "--project", "alias")
        self.assertEqual(code, 2)
        self.assertFalse(result["ok"])
        outside = self.root / "outside-output"
        outside.mkdir()
        (real / "out").symlink_to(outside, target_is_directory=True)
        code, result = self.cli("cut", "--project", "real")
        self.assertEqual(code, 2)
        self.assertFalse(result["ok"])
        self.assertEqual(list(outside.iterdir()), [])

    def test_preexisting_state_tmp_symlinks_cannot_overwrite_other_files(self):
        self.set_key()
        _, dry = self.make("--dry-run")
        project = self.root / "projects" / dry["project_id"]
        project.mkdir(parents=True)
        sentinel = self.root / "do-not-overwrite.txt"
        original = b"synthetic private content; must remain unchanged"
        sentinel.write_bytes(original)
        for name in ("generation-attempt.tmp", "result.tmp"):
            (project / name).symlink_to(sentinel)
        with mock.patch.object(app, "generate", return_value=self.sheet) as generate:
            code, result = self.make("--authorized")
        self.assertEqual(code, 0)
        generate.assert_called_once()
        self.assert_pack(result)
        self.assertEqual(sentinel.read_bytes(), original)
        for name in ("generation-attempt.tmp", "result.tmp"):
            self.assertTrue((project / name).is_symlink())
        self.assertEqual(list(project.glob(".state-*.tmp")), [])

    def test_actual_generate_rejects_untrusted_download_host_without_get(self):
        body = json.dumps({"data": [{"url": "https://untrusted.example/image.png"}]}).encode()
        session, _ = self.fake_session(body=body)
        with mock.patch.object(requests, "Session", return_value=session):
            with self.assertRaises(app.UserError):
                app.generate(self.photo.read_bytes(), "offline test prompt", FAKE_KEY)
        self.assert_single_post(session)

    def fake_session(self, *, status=200, body=b"", error=None):
        session = mock.MagicMock(spec=requests.Session)
        session.__enter__.return_value = session
        response = mock.MagicMock()
        response.__enter__.return_value = response
        response.status_code = status
        response.iter_content.return_value = [body]
        response.text = FAKE_KEY + " RAW_PROVIDER_RESPONSE"
        if error is not None:
            session.post.side_effect = error
        else:
            session.post.return_value = response
        return session, response

    def assert_single_post(self, session):
        session.post.assert_called_once()
        args, kwargs = session.post.call_args
        self.assertEqual(args, (app.API_URL,))
        self.assertEqual(kwargs["data"]["n"], "1")
        self.assertFalse(kwargs["allow_redirects"])
        self.assertTrue(kwargs["stream"])
        self.assertEqual(kwargs["headers"], {"Authorization": "Bearer " + FAKE_KEY})
        self.assertEqual(kwargs["files"]["image"][2], "image/png")
        session.mount.assert_called_once()
        scheme, adapter = session.mount.call_args.args
        self.assertEqual(scheme, "https://")
        self.assertEqual(adapter.max_retries.total, 0)
        session.get.assert_not_called()

    def test_actual_generate_uses_single_nonretrying_nonredirecting_post(self):
        body = json.dumps({"data": [{"b64_json": base64.b64encode(self.sheet).decode()}]}).encode()
        session, response = self.fake_session(body=body)
        with mock.patch.object(requests, "Session", return_value=session):
            generated = app.generate(self.photo.read_bytes(), "offline test prompt", FAKE_KEY)
        self.assertEqual(generated, self.sheet)
        self.assert_single_post(session)
        response.iter_content.assert_called_once_with(65536)

    def test_actual_generate_http500_never_retries_or_leaks_response(self):
        session, response = self.fake_session(status=500, body=FAKE_KEY.encode())
        self.set_key()
        with mock.patch.object(requests, "Session", return_value=session):
            code, result = self.make("--authorized")
            self.assertEqual(code, 2)
            self.assertIn("HTTP 500", result["error"])
            self.assertNotIn("RAW_PROVIDER_RESPONSE", result["error"])
            code, _ = self.make("--authorized")
            self.assertEqual(code, 2)
        self.assert_single_post(session)
        response.iter_content.assert_not_called()
        self.assertEqual(len(list((self.root / "projects").glob("*/generation-attempt.json"))), 1)
        self.assert_no_secrets_saved()

    def test_actual_generate_timeout_never_retries_or_leaks_exception(self):
        session, _ = self.fake_session(error=requests.Timeout("Bearer " + FAKE_KEY + " PRIVATE_DETAIL"))
        self.set_key()
        with mock.patch.object(requests, "Session", return_value=session):
            code, result = self.make("--authorized")
            self.assertEqual(code, 2)
            self.assertIn("网络", result["error"])
            self.assertNotIn("PRIVATE_DETAIL", result["error"])
            code, _ = self.make("--authorized")
            self.assertEqual(code, 2)
        self.assert_single_post(session)
        self.assertEqual(len(list((self.root / "projects").glob("*/generation-attempt.json"))), 1)
        self.assert_no_secrets_saved()


if __name__ == "__main__":
    unittest.main(verbosity=2)
