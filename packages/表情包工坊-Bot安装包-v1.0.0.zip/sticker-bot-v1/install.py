#!/usr/bin/env python3
"""Install this inspected distribution only; stdout is one JSON result."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
from datetime import datetime, timezone

COPY_FILES = (
    "app.py", "engine.py", "requirements.txt", "BOT_INSTRUCTIONS.md",
    "tests/test_offline.py", "README.md", "VERSION",
)
MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024
REQUIRED_DEPENDENCIES = {"Pillow>=10,<12", "requests>=2.31,<3"}


class InstallError(Exception):
    pass


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise InstallError("Invalid arguments: " + message)


def emit(payload):
    # ensure_ascii keeps the protocol usable even on legacy Windows consoles.
    print(json.dumps(payload, ensure_ascii=True, sort_keys=True))


def absolute_path(value):
    return Path(os.path.abspath(os.path.expanduser(str(value))))


def reject_symlink_components(path):
    for part in (path,) + tuple(path.parents):
        if part.is_symlink():
            raise InstallError("Symbolic-link paths are not allowed: " + str(part))
        # Windows junctions are also unsafe installation destinations.
        if hasattr(part, "is_junction") and part.is_junction():
            raise InstallError("Junction paths are not allowed: " + str(part))
        if part.exists() and os.name == "nt":
            attributes = getattr(part.lstat(), "st_file_attributes", 0)
            if attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
                raise InstallError("Reparse-point paths are not allowed: " + str(part))


def validate_source(source):
    total = 0
    for relative in COPY_FILES:
        file = source / relative
        # Check members and their in-package parents, without following links.
        cursor = file
        while cursor != source:
            if cursor.is_symlink():
                raise InstallError("Package member is a symbolic link: " + relative)
            if os.name == "nt" and cursor.exists():
                attributes = getattr(cursor.lstat(), "st_file_attributes", 0)
                if attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
                    raise InstallError("Package member is a reparse point: " + relative)
            cursor = cursor.parent
        if not file.is_file() or not stat.S_ISREG(file.stat().st_mode):
            raise InstallError("Required regular package file is missing: " + relative)
        size = file.stat().st_size
        if size > MAX_FILE_BYTES:
            raise InstallError("Package member exceeds 20 MiB: " + relative)
        total += size
    if total > MAX_TOTAL_BYTES:
        raise InstallError("Package exceeds the 64 MiB installation limit")
    dependencies = {
        line.strip() for line in (source / "requirements.txt").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    }
    if dependencies != REQUIRED_DEPENDENCIES:
        raise InstallError("Unexpected requirements; inspect the distribution before installing")
    return (source / "VERSION").read_text(encoding="utf-8").strip()


def validate_target(target, source):
    reject_symlink_components(target)
    if target == source or source in target.parents or target in source.parents:
        raise InstallError("Installation target and package source must not overlap")
    if target.exists():
        if not target.is_dir():
            raise InstallError("Target exists and is not a directory: " + str(target))
        if next(target.iterdir(), None) is not None:
            raise InstallError("Target is not empty; refusing to overwrite: " + str(target))
    parent = target.parent
    while not parent.exists():
        parent = parent.parent
    if not parent.is_dir() or not os.access(parent, os.W_OK | os.X_OK):
        raise InstallError("Target parent is not a writable directory: " + str(parent))


def preflight(source, target):
    if sys.version_info < (3, 9):
        raise InstallError("Python 3.9 or newer is required")
    for module in ("venv", "ensurepip", "ssl"):
        if importlib.util.find_spec(module) is None:
            raise InstallError("Missing Python prerequisite: " + module)
    # Importing verifies that the modules are actually usable; no bootstrap runs.
    import venv  # noqa: F401
    import ensurepip  # noqa: F401
    import ssl  # noqa: F401
    version = validate_source(source)
    validate_target(target, source)
    return version


def child_environment():
    env = dict(os.environ)
    for key in (
        "TELANGPUAI_IMAGE_API_KEY", "DSH_SECRET_TELANGPUAI_IMAGE_API_KEY", "STICKER_API_KEY",
        "PYTHONPATH", "PYTHONHOME",
    ):
        env.pop(key, None)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    env["PIP_NO_INPUT"] = "1"
    return env


def run_step(command, cwd, label, timeout):
    print("[installer] " + label, file=sys.stderr)
    result = subprocess.run(
        [str(item) for item in command], cwd=str(cwd), env=child_environment(),
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        encoding="utf-8", errors="replace", timeout=timeout, check=False,
    )
    if result.stdout:
        print(result.stdout, end="" if result.stdout.endswith("\n") else "\n", file=sys.stderr)
    if result.returncode != 0:
        raise InstallError(label + " failed (exit " + str(result.returncode) + ")")


def install(source, target, version):
    # Check again immediately before the first write. Never clean up on failure.
    validate_target(target, source)
    target.mkdir(parents=True, exist_ok=True)
    validate_target(target, source)
    for relative in COPY_FILES:
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        with (source / relative).open("rb") as input_file, destination.open("xb") as output_file:
            shutil.copyfileobj(input_file, output_file)
    run_step([sys.executable, "-I", "-m", "venv", str(target / ".venv")], target,
             "Create isolated virtual environment", 180)
    # Do not resolve this symlink: the venv executable path must remain in .venv.
    python = target / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not python.is_file():
        raise InstallError("Virtual environment Python was not created")
    run_step([python, "-I", "-m", "pip", "install", "--requirement", str(target / "requirements.txt")],
             target, "Install dependencies (package-index network access may be required)", 900)
    app = target / "app.py"
    tests = target / "tests/test_offline.py"
    if not app.is_file() or not tests.is_file():
        raise InstallError("Offline self-check entrypoints are missing; installation is incomplete")
    run_step([python, "-B", str(app), "doctor", "--offline"], target, "Offline doctor", 120)
    run_step([python, "-B", str(tests)], target, "Offline test suite", 180)
    receipt = {
        "status": "installed", "success": True, "version": version,
        "work_dir": str(target), "python": str(python),
        "instructions_file": str(target / "BOT_INSTRUCTIONS.md"),
        "receipt_file": str(target / "INSTALL_RECEIPT.json"),
        "offline_checks": {"doctor": "passed", "tests/test_offline.py": "passed"},
        "generation_verified": False, "key_configuration_verified": False,
        "notice": "Offline installation only. Image generation requires the user's own key; no image API was called.",
        "installed_at": datetime.now(timezone.utc).isoformat(),
    }
    # A success receipt is created only after every required check passed.
    with (target / "INSTALL_RECEIPT.json").open("x", encoding="utf-8") as output:
        json.dump(receipt, output, ensure_ascii=False, indent=2)
        output.write("\n")
    return receipt


def main(argv=None):
    target = None
    try:
        parser = JsonArgumentParser(description=__doc__)
        parser.add_argument("--target", default=str(Path.home() / "DSBot" / "表情包工坊"),
                            help="New or empty installation directory; existing content is never overwritten")
        parser.add_argument("--check-only", action="store_true",
                            help="Check prerequisites/package/target only; no writes, installation, or network")
        args = parser.parse_args(argv)
        source = Path(__file__).resolve().parent
        target = absolute_path(args.target)
        version = preflight(source, target)
        if args.check_only:
            emit({"success": True, "status": "checked", "installed": False,
                  "work_dir": str(target), "version": version,
                  "python_version": ".".join(str(v) for v in sys.version_info[:3]),
                  "notice": "Prerequisites checked only; dependencies and API access were not tested."})
            return 0
        receipt = install(source, target, version)
        emit(receipt)
        return 0
    except (Exception, KeyboardInterrupt) as error:
        message = "Interrupted by user" if isinstance(error, KeyboardInterrupt) else str(error)
        emit({"success": False, "status": "failed", "error": message,
              "work_dir": str(target) if target is not None else None,
              "notice": "Installation was not confirmed. Any target files are retained; inspect them and choose a new empty target to retry."})
        return 1


if __name__ == "__main__":
    sys.exit(main())
