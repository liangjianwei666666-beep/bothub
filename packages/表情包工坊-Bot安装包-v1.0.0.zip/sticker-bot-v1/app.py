#!/usr/bin/env python3
"""表情包工坊分发入口：显式照片、明确授权、单次提交、离线恢复。"""
import argparse
import base64
import hashlib
import io
import ipaddress
import json
import os
from pathlib import Path
import socket
import sys
import time
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
API_URL = 'https://telangpuai.com/v1/images/edits'
MODEL = 'gpt-image-2'
MAX_IMAGE_BYTES = 30 * 1024 * 1024
MAX_RESPONSE_BYTES = 80 * 1024 * 1024


class UserError(Exception):
    pass


def emit(data):
    print(json.dumps(data, ensure_ascii=False))


def key_value():
    # 不扫描其他用户/工具的凭据文件；仅接受本应用环境变量。
    return (os.environ.get('DSH_SECRET_TELANGPUAI_IMAGE_API_KEY') or
            os.environ.get('TELANGPUAI_IMAGE_API_KEY') or
            os.environ.get('STICKER_API_KEY') or '').strip()


def modules():
    import engine
    import requests
    from PIL import Image, ImageOps
    return engine, requests, Image, ImageOps


def atomic_json(path, data):
    import tempfile
    # 独占创建随机临时文件，不跟随预置的*.tmp符号链接。
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', prefix='.state-',
                                     suffix='.tmp', dir=str(path.parent), delete=False) as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        tmp = Path(f.name)
    tmp.replace(path)


def photo_data(path):
    _, _, Image, ImageOps = modules()
    p = Path(path).expanduser().resolve()
    if not p.is_file() or p.stat().st_size > MAX_IMAGE_BYTES:
        raise UserError('照片不存在或超过30MB；只用本条消息明确的图片附件。')
    raw = p.read_bytes()
    try:
        with Image.open(io.BytesIO(raw)) as im:
            if im.width * im.height > 40_000_000:
                raise UserError('图片超过4000万像素，请先缩小。')
            im.load()
            out = io.BytesIO()
            ImageOps.exif_transpose(im).convert('RGB').save(out, format='PNG')
    except UserError:
        raise
    except Exception:
        raise UserError('无法读取图片；支持常见PNG/JPEG/WebP，请先转换HEIC。') from None
    # 用可见像素的规范化内容做去重，改文件名/EXIF不再提交。
    normalized = out.getvalue()
    return normalized, hashlib.sha256(normalized).hexdigest()


def safe_remote(url):
    u = urlparse(url)
    # 只允许服务商同域下载；不信任上游响应中的任意URL/CDN。
    if u.scheme != 'https' or u.hostname != 'telangpuai.com' or u.username or u.password or u.port not in (None, 443):
        raise UserError('图片下载地址不是安全的HTTPS地址；未重复生成。')
    try:
        ips = socket.getaddrinfo(u.hostname, 443)
        if not ips or any(not ipaddress.ip_address(x[4][0]).is_global for x in ips):
            raise UserError('拒绝内部网络图片下载地址；未重复生成。')
    except OSError:
        raise UserError('图片下载域名解析失败；未重复生成。') from None
    return url


def bounded_body(response, limit):
    chunks, size = [], 0
    for chunk in response.iter_content(65536):
        size += len(chunk)
        if size > limit:
            raise UserError('接口响应过大，已停止；不要自动重复生成。')
        chunks.append(chunk)
    return b''.join(chunks)


def generate(raw, prompt, key):
    _, requests, _, _ = modules()
    # requests 默认重试为0；显式禁重试/重定向。任何错误均不再POST。
    with requests.Session() as session:
        session.mount('https://', requests.adapters.HTTPAdapter(max_retries=0))
        try:
            with session.post(API_URL, headers={'Authorization': 'Bearer ' + key},
                              files={'image': ('reference.png', raw, 'image/png')},
                              data={'model': MODEL, 'prompt': prompt, 'n': '1'},
                              timeout=(30, 600), allow_redirects=False, stream=True) as r:
                if r.status_code != 200:
                    raise UserError('生图接口返回HTTP %d；是否计费未知，禁止自动重试。' % r.status_code)
                body = bounded_body(r, MAX_RESPONSE_BYTES)
            try:
                item = json.loads(body)['data'][0]
                encoded = item.get('b64_json')
                url = item.get('url')
            except (ValueError, KeyError, IndexError, TypeError, AttributeError):
                raise UserError('接口返回结构异常；是否计费未知，禁止自动重试。') from None
            if encoded:
                try:
                    return base64.b64decode(encoded, validate=True)
                except (ValueError, TypeError):
                    raise UserError('图片编码无效；是否计费未知，禁止自动重试。') from None
            if url:
                safe_remote(url)
                with session.get(url, timeout=(30, 180), allow_redirects=False, stream=True) as r:
                    if r.status_code != 200:
                        raise UserError('图片下载失败；不要重新提交生图。')
                    return bounded_body(r, MAX_RESPONSE_BYTES)
            raise UserError('接口没有图片内容；是否计费未知，禁止自动重试。')
        except requests.RequestException:
            # 不输出原始异常/响应，以免密钥或个人数据回显。
            raise UserError('网络连接失败或超时；提交可能已计费，已锁定，禁止自动重试。') from None


def guard_project(p):
    base = ROOT / 'projects'
    if base.is_symlink() or p.is_symlink() or p.parent != base:
        raise UserError('项目路径无效或包含符号链接。')
    for name in ('ref', 'sheets', 'out', 'generation-attempt.json', 'result.json', 'prompt.txt'):
        if (p / name).is_symlink():
            raise UserError('项目内容不能是符号链接。')
    for sub in ('ref', 'sheets', 'out'):
        folder = p / sub
        if folder.exists():
            if not folder.is_dir() or any(x.is_symlink() for x in folder.iterdir()):
                raise UserError('项目子目录无效或包含符号链接。')


def project_path(project):
    base = ROOT / 'projects'
    if Path(project).name != project or project in ('.', '..'):
        raise UserError('项目无效；请使用输出中的project_id，不传任意路径。')
    p = base / project
    guard_project(p)
    if not p.is_dir():
        raise UserError('项目不存在。')
    return p


def cut_project(p):
    guard_project(p)
    engine, _, Image, ImageOps = modules()
    sheet = p / 'sheets' / 'sheet.png'
    if not sheet.is_file():
        raise UserError('没有已保存的底图；不要自动重新生成。')
    raw = sheet.read_bytes()
    with Image.open(io.BytesIO(raw)) as im:
        im.load()
        transparent = 'A' in im.getbands() and im.getchannel('A').getextrema()[0] < 255
    _, files, _ = engine.make_pack(raw)
    out = p / 'out'
    out.mkdir(exist_ok=True)
    # 不宣称模型严格按表情含义出图；散图使用中性的数字名称。
    import zipfile
    pack = out / '表情图片.zip'
    with zipfile.ZipFile(pack, 'w', zipfile.ZIP_DEFLATED) as z:
        for i, (_, im) in enumerate(files, 1):
            b = io.BytesIO()
            im.save(b, format='PNG')
            z.writestr('%02d.png' % i, b.getvalue())
    preview = out / '预览.png'
    engine.make_preview([im for _, im in files], labels=['%02d' % i for i in range(1, 17)]).save(preview)
    frames = []
    order = list(range(16)) + list(range(14, 0, -1))
    for i in order:
        f = ImageOps.contain(files[i][1].convert('RGBA'), (320, 320), Image.Resampling.LANCZOS)
        canvas = Image.new('RGB', (320, 320), 'white')
        canvas.paste(f, ((320-f.width)//2, (320-f.height)//2), f)
        frames.append(canvas.quantize(colors=128))
    gif = out / '表情轮播.gif'
    frames[0].save(gif, save_all=True, append_images=frames[1:], duration=600,
                   loop=0, disposal=2, optimize=True)
    with Image.open(gif) as im:
        nframes = im.n_frames
        if nframes < 2 or im.size != (320, 320) or im.info.get('loop') != 0:
            raise UserError('GIF校验失败；底图已保留，可免费重新切图。')
        for i in range(nframes):
            im.seek(i)
            im.load()
    result = {'ok': True, 'project_id': p.name, 'gif': str(gif), 'preview': str(preview),
              'zip': str(pack), 'count': 16, 'gif_frames': nframes,
              'gif_bytes': gif.stat().st_size, 'sheet_has_transparency': transparent,
              'gif_background': 'white', 'type': 'expression_slideshow_not_continuous_animation',
              'wechat_import_tested': False, 'visual_review_required': True}
    atomic_json(p / 'result.json', result)
    return result


def make(args):
    engine, _, Image, _ = modules()
    raw, digest = photo_data(args.photo)
    prompt = engine.build_prompt(args.style, 'like')
    identifier = digest[:24]
    p = ROOT / 'projects' / identifier
    if args.dry_run:
        return {'ok': True, 'dry_run': True, 'network_calls': 0, 'project_id': identifier,
                'model': MODEL, 'endpoint': API_URL, 'prompt': prompt,
                'reference_sha256': digest, 'reference_upload_notice': '真实生成会把这张图片发送至TelangpuAI'}
    if not args.authorized:
        raise UserError('没有生成授权；只有用户明确给图并要求做表情包才允许--authorized。')
    guard_project(p)
    if (p / 'sheets' / 'sheet.png').is_file():
        return cut_project(p)
    attempt = p / 'generation-attempt.json'
    if attempt.exists():
        raise UserError('这张照片已提交过但没有完整底图；可能已计费，禁止自动重试或换项目绕过。')
    key = key_value()
    if not key:
        raise UserError('尚未配置生图密钥；请主Bot用安全密钥卡配置TELANGPUAI_IMAGE_API_KEY。')
    p.mkdir(parents=True, exist_ok=True)
    for sub in ('ref', 'sheets', 'out'):
        (p / sub).mkdir(exist_ok=True)
    # 原子独占创建：两个并发任务最多只有一个能提交。
    try:
        with attempt.open('x', encoding='utf-8') as f:
            json.dump({'status': 'submitting', 'time': time.strftime('%Y-%m-%dT%H:%M:%S'),
                       'source_sha256': digest, 'model': MODEL, 'retry': False}, f)
    except FileExistsError:
        raise UserError('同一照片任务已经启动，不重复提交。') from None
    (p / 'ref' / 'reference.png').write_bytes(raw)
    (p / 'prompt.txt').write_text(prompt, encoding='utf-8')
    try:
        generated = generate(raw, prompt, key)
        with Image.open(io.BytesIO(generated)) as im:
            if im.width * im.height > 40_000_000:
                raise UserError('底图超过安全像素上限。')
            im.load()
            tmp = p / 'sheets' / 'sheet.pending.png'
            im.save(tmp, format='PNG')
            tmp.replace(p / 'sheets' / 'sheet.png')
        atomic_json(attempt, {'status': 'sheet_saved', 'source_sha256': digest, 'retry': False})
        return cut_project(p)
    except BaseException:
        # 无论断网/解析/切图失败，保留尝试记录和已有底图，绝不删除锁。
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    doctor = sub.add_parser('doctor')
    doctor.add_argument('--offline', action='store_true', help='仅检查本地依赖，不联网')
    run = sub.add_parser('make')
    run.add_argument('--photo', required=True)
    run.add_argument('--style', choices=['like', 'wechat', 'ugly', 'plush', 'pixel'], default='like')
    run.add_argument('--dry-run', action='store_true')
    run.add_argument('--authorized', action='store_true')
    cut = sub.add_parser('cut')
    cut.add_argument('--project', required=True)
    sub.add_parser('list')
    args = parser.parse_args(argv)
    try:
        if args.command == 'doctor':
            import PIL
            import requests
            modules()
            emit({'ok': True, 'offline': True, 'python': sys.version.split()[0],
                  'pillow': PIL.__version__, 'requests': requests.__version__,
                  'key_configured': bool(key_value()), 'api_health_verified': False,
                  'root': str(ROOT)})
        elif args.command == 'make':
            emit(make(args))
        elif args.command == 'cut':
            emit(cut_project(project_path(args.project)))
        elif args.command == 'list':
            emit({'projects': sorted(p.name for p in (ROOT/'projects').glob('*') if p.is_dir())})
        return 0
    except UserError as e:
        emit({'ok': False, 'error': str(e)})
        return 2
    except KeyboardInterrupt:
        emit({'ok': False, 'error': '已中断，可能已提交；先检查项目，禁止自动重试。'})
        return 130
    except Exception as e:
        emit({'ok': False, 'error': '本地处理失败：%s；保留已有文件，禁止自动重新生成。' % type(e).__name__})
        return 1


if __name__ == '__main__':
    sys.exit(main())
