#!/usr/bin/env bash
# 塔罗抽牌 —— 自动找运行时，找不到才报错
#
# 为什么有这个：
#   抽牌器是 .mjs，需要 JS 运行时。但很多电脑上 node 装了却不在 PATH 里
#   （nvm 装的、Homebrew 装的都可能这样），直接 `node xxx.mjs` 会报 command not found。
#   DSH Desktop 自己就带一个 node（Electron），可以当运行时用，不用用户另装东西。
#
# 用法：
#   bash ~/塔罗师/塔罗.sh --spread three-card --topic love --question "他心里还有我吗"
#   bash ~/塔罗师/塔罗.sh --spread three-card --topic love --image ./牌面.jpg
#
# 位置：需要和 tarot-draw.mjs 放在同一个目录。

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENTRY="$HERE/tarot-draw.mjs"

if [ ! -f "$ENTRY" ]; then
  echo "找不到 tarot-draw.mjs（应该和本脚本在同一个文件夹）" >&2
  exit 1
fi

try() {
  # $1 描述，$2 命令，$3 可选环境变量
  local desc="$1"; shift
  local bin="$1"; shift
  [ -x "$bin" ] || return 1
  if [ $# -gt 0 ]; then
    env "$1" "$bin" "$ENTRY" "$@" >/dev/null 2>&1 && {
      echo "$desc"
      return 0
    }
    return 1
  fi
  "$bin" "$ENTRY" "$@" >/dev/null 2>&1 && { echo "$desc"; return 0; }
  return 1
}

find_runtime() {
  # 1) PATH 里的 node
  if command -v node >/dev/null 2>&1; then
    if node -v >/dev/null 2>&1; then
      echo "node"; return 0
    fi
  fi

  # 2) nvm 装的最新一个 node
  local nvm_node
  for nvm_node in $(ls -d "$HOME"/.nvm/versions/node/*/bin/node 2>/dev/null | sort -V -r); do
    [ -x "$nvm_node" ] && { echo "$nvm_node"; return 0; }
  done

  # 3) Homebrew / 官方安装包常见位置
  local p
  for p in /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done

  # 4) bun
  if [ -x "$HOME/.bun/bin/bun" ]; then echo "$HOME/.bun/bin/bun"; return 0; fi
  if command -v bun >/dev/null 2>&1; then echo "bun"; return 0; fi

  # 5) DSH Desktop 自带的运行时（Electron 能以纯 node 方式跑）
  local app
  for app in "/Applications/DSH Desktop.app/Contents/MacOS/DSH Desktop" \
             "$HOME/Applications/DSH Desktop.app/Contents/MacOS/DSH Desktop"; do
    if [ -x "$app" ]; then echo "electron:$app"; return 0; fi
  done

  return 1
}

RUNTIME="$(find_runtime)" || {
  cat >&2 <<'MSG'
没找到能跑 JavaScript 的运行时。

三个办法，任选一个：
  · 装了 DSH Desktop 的话，本脚本会自动用它自带的运行时（检查一下 DSH 是不是装在「应用程序」里）
  · 装 node：https://nodejs.org （选 LTS，一路下一步）
  · 或者先只做文字解读：塔罗师的读法不依赖脚本，抽牌自己随机也能读

MSG
  exit 1
}

case "$RUNTIME" in
  electron:*)
    EL="${RUNTIME#electron:}"
    ELECTRON_RUN_AS_NODE=1 "$EL" "$ENTRY" "$@"
    ;;
  *)
    "$RUNTIME" "$ENTRY" "$@"
    ;;
esac
