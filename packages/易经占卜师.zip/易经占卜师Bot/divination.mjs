#!/usr/bin/env node
/**
 * 铜钱法起卦器（零依赖，node / bun 直接跑）
 *
 * 用法：
 *   node scripts/divination.mjs --question "要不要换工作" --tone 犀利直接
 *   node scripts/divination.mjs --question "..." --seed abc123        # 同一种子同一卦
 *   node scripts/divination.mjs --json --question "..."               # 只要 JSON，给程序读
 *   node scripts/divination.mjs --gua 24 --moving 1,3                 # 不起卦，直接查某一卦
 *
 * 三枚铜钱掷六次，自下而上成爻。每枚钱 字(阳)=3 背(阴)=2，三枚相加：
 *   6 = 老阴（三背）→ 阴，变阳   概率 1/8
 *   7 = 少阳（两背一字）→ 阳，不变 概率 3/8
 *   8 = 少阴（一背两字）→ 阴，不变 概率 3/8
 *   9 = 老阳（三字）→ 阳，变阴   概率 1/8
 * 变爻合计 1/8+1/8 = 1/4，六爻中至少一个变爻的概率约 82%。
 */

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));
const GUA_PATH = resolve(HERE, './data/gua64.json');
const TEXTS_PATH = resolve(HERE, './data/gua_texts.json');
const CARDS_DIR = resolve(HERE, './卦图');

// 卦牌图路径：cards_final/001_乾.jpg（image2 逐卦生成 + 验爻通过）
function cardPath(gua) {
  if (!gua) return null;
  return resolve(CARDS_DIR, `${String(gua.id).padStart(3, '0')}_${gua.name}.jpg`);
}

// ── 参数 ────────────────────────────────────────────────
function arg(name, fallback = '') {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}
const hasFlag = (n) => process.argv.includes(`--${n}`);

const question = arg('question', '');
const toneArg = arg('tone', '温柔共情');
const TONES = ['犀利直接', '温柔共情', '理性分析'];
const tone = TONES.includes(toneArg) ? toneArg : '温柔共情';
const asJson = hasFlag('json');

// ── 种子随机：同一 seed 必定同一卦 ───────────────────────
// xmur3 + mulberry32：确定性、跨平台、无依赖
function xmur3(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    return (h ^= h >>> 16) >>> 0;
  };
}
function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function randomSeed() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

const seed = arg('seed', '') || randomSeed();
const rand = mulberry32(xmur3(seed)());

// ── 卦库 ────────────────────────────────────────────────
const DB = JSON.parse(readFileSync(GUA_PATH, 'utf-8'));
const TEXTS = JSON.parse(readFileSync(TEXTS_PATH, 'utf-8'));
const TRIGRAMS = DB.trigrams; // 名称 -> [自下而上三爻]
const NAME_BY_BITS = {};
for (const [name, bits] of Object.entries(TRIGRAMS)) NAME_BY_BITS[bits.join('')] = name;

function lookupByLines(lines) {
  const key = lines.join('');
  const lowerBits = key.slice(0, 3).split('').map(Number);
  const upperBits = key.slice(3, 6).split('').map(Number);
  const upper = NAME_BY_BITS[upperBits.join('')];
  const lower = NAME_BY_BITS[lowerBits.join('')];
  const g = DB.gua.find((x) => x.upper === upper && x.lower === lower);
  return g || null;
}

// ── 掷铜钱 ──────────────────────────────────────────────
/** 掷一次：三枚钱，返回 {sum, coins}，coins 1=字(阳) 0=背(阴) */
function tossOnce() {
  const coins = [rand() < 0.5 ? 1 : 0, rand() < 0.5 ? 1 : 0, rand() < 0.5 ? 1 : 0];
  const sum = coins.reduce((a, c) => a + (c ? 3 : 2), 0); // 6/7/8/9
  return { coins, sum };
}

/** 六个爻，自下而上 */
function castSix() {
  const lines = [];
  for (let i = 0; i < 6; i++) {
    const t = tossOnce();
    // sum: 6 老阴(变) / 7 少阳 / 8 少阴 / 9 老阳(变)
    const yang = t.sum === 7 || t.sum === 9;
    const moving = t.sum === 6 || t.sum === 9;
    lines.push({
      pos: i + 1,            // 初=1 ... 上=6
      sum: t.sum,
      coins: t.coins,
      yang,
      moving,
      value: yang ? 1 : 0,   // 本卦阴阳
    });
  }
  return lines;
}

const YAO_NAME = ['初', '二', '三', '四', '五', '上'];
function yaoLabel(i, yang) {
  // 初、上 用「初九/初六」「上九/上六」，其余「九二/六二」
  const num = yang ? '九' : '六';
  if (i === 0) return `初${num}`;
  if (i === 5) return `上${num}`;
  return `${num}${YAO_NAME[i]}`;
}

// ── 起卦 ────────────────────────────────────────────────
function cast() {
  const movingArg = arg('moving', '');
  const guaArg = arg('gua', '');
  let lines;
  if (guaArg) {
    // 直接指定某一卦（查卦用），可配 --moving 指定变爻（逗号分隔，1=初爻）
    const gid = Number(guaArg);
    const g = DB.gua.find((x) => x.id === gid);
    if (!g) throw new Error(`没有第 ${guaArg} 卦`);
    const mv = new Set(
      (movingArg || '').split(',').map((s) => Number(s.trim())).filter((n) => n >= 1 && n <= 6)
    );
    lines = g.lines.map((v, i) => ({
      pos: i + 1, sum: v ? 7 : 8, coins: null, yang: !!v, moving: mv.has(i + 1), value: v,
    }));
  } else {
    lines = castSix();
  }

  const movingIdx = lines.filter((l) => l.moving).map((l) => l.pos);
  const benLines = lines.map((l) => l.value);
  const ben = lookupByLines(benLines);

  // 变卦：变爻翻转；无变爻则无变卦
  let bian = null;
  if (movingIdx.length > 0) {
    const bianLines = lines.map((l) => (l.moving ? (l.value ? 0 : 1) : l.value));
    bian = lookupByLines(bianLines);
  }

  const marked = lines.map((l) => {
    const label = yaoLabel(l.pos - 1, l.yang);
    return {
      pos: l.pos,
      label,
      sum: l.sum,
      coins: l.coins,
      yang: l.yang,
      moving: l.moving,
      // 视觉：阳 ━━━  阴 ━ ━  变爻加 ○(老阳)/×(老阴)
      mark: l.moving ? (l.yang ? '○' : '×') : ' ',
    };
  });

  // 文本：卦辞/象传 + 每爻爻辞
  const benText = ben ? TEXTS[String(ben.id)] : null;
  const bianText = bian ? TEXTS[String(bian.id)] : null;
  const yaoTexts = benText
    ? marked.map((l) => benText.yaos[l.pos - 1])
    : marked.map(() => null);

  return { seed, question, tone, lines: marked, ben, bian, movingIdx, benText, bianText, yaoTexts };
}

// ── 渲染：文字卦象（不依赖任何外部资源） ─────────────────
function renderGlyph(lines) {
  // 自上而下画（上爻在最上面）
  const out = [];
  for (let i = lines.length - 1; i >= 0; i--) {
    const l = lines[i];
    const bar = l.yang ? '████████' : '████ ████';
    out.push(`  ${String(l.pos).padStart(1)}  ${bar}  ${l.mark}  ${l.label}`);
  }
  return out.join('\n');
}

// ── 如果这一卦是错的，那么一切皆错，所以这里做自检 ───────
function selfCheck() {
  const errs = [];

  // 1. 64 卦完整
  if (DB.gua.length !== 64) errs.push(`卦数应为 64，实为 ${DB.gua.length}`);
  const combos = new Set(DB.gua.map((g) => `${g.upper}${g.lower}`));
  if (combos.size !== 64) errs.push(`上下卦组合应唯一 64，实为 ${combos.size}`);

  // 2. 往返：每卦的爻 → 查回自己
  for (const g of DB.gua) {
    const back = lookupByLines(g.lines);
    if (!back || back.id !== g.id) errs.push(`第 ${g.id} 卦 ${g.name} 往返查回失败`);
  }

  // 3. 纯卦
  for (const [n, id] of [['乾', 1], ['坤', 2], ['坎', 29], ['离', 30], ['震', 51], ['艮', 52], ['巽', 57], ['兑', 58]]) {
    const g = DB.gua.find((x) => x.id === id);
    if (g.name !== n || g.upper !== n || g.lower !== n) errs.push(`纯卦 ${n} 校验失败`);
  }

  // 4. 变卦：本卦变爻翻转后，变卦的爻差必须正好是那些位置
  const r = cast();
  if (r.bian) {
    // 注意：r.lines 是输出对象，阳爻用 boolean 的 yang 表示，没有 value 字段
    const benBits = r.lines.map((l) => (l.yang ? 1 : 0));
    const bianBits = r.bian.lines;
    const diff = benBits.map((v, i) => (v !== bianBits[i] ? i + 1 : 0)).filter(Boolean);
    if (diff.join(',') !== r.movingIdx.join(',')) errs.push(`变卦爻差异 ${diff} != 变爻 ${r.movingIdx}`);
  }

  // 5. 概率分布：掷 60000 次，老阴/少阳/少阴/老阳 应接近 1:3:3:1
  const cnt = { 6: 0, 7: 0, 8: 0, 9: 0 };
  const N = 60000;
  for (let i = 0; i < N; i++) cnt[tossOnce().sum]++;
  const exp = { 6: 0.125, 7: 0.375, 8: 0.375, 9: 0.125 };
  for (const k of [6, 7, 8, 9]) {
    const p = cnt[k] / N;
    if (Math.abs(p - exp[k]) > 0.02) errs.push(`铜钱概率 ${k} 实为 ${p.toFixed(3)}，期望 ${exp[k]}`);
  }

  // 6. 同种子必同卦
  const castWith = (s) => {
    const r2 = mulberry32(xmur3(s)());
    const ls = [];
    for (let i = 0; i < 6; i++) {
      const c = [r2() < 0.5 ? 1 : 0, r2() < 0.5 ? 1 : 0, r2() < 0.5 ? 1 : 0];
      ls.push(c.reduce((a, x) => a + (x ? 3 : 2), 0));
    }
    return ls.join(',');
  };
  if (castWith('abc123') !== castWith('abc123')) errs.push('同种子两次结果不一致');

  // 7. 六爻中至少一个变爻的概率 ≈ 1-(3/4)^6 ≈ 82.2%
  let anyMoving = 0;
  const M = 20000;
  for (let i = 0; i < M; i++) {
    const rt = mulberry32(xmur3('seed' + i)());
    let has = false;
    for (let j = 0; j < 6; j++) {
      const c = [rt() < 0.5 ? 1 : 0, rt() < 0.5 ? 1 : 0, rt() < 0.5 ? 1 : 0];
      const s = c.reduce((a, x) => a + (x ? 3 : 2), 0);
      if (s === 6 || s === 9) has = true;
    }
    if (has) anyMoving++;
  }
  const ratio = anyMoving / M;
  if (Math.abs(ratio - 0.822) > 0.02) errs.push(`至少一变爻概率 ${ratio.toFixed(3)}，期望 0.822`);

  return { errs, sample: { cnt, N, ratio, M } };
}

// ── 主流程 ──────────────────────────────────────────────
if (hasFlag('selfcheck')) {
  const { errs, sample } = selfCheck();
  console.log('=== 自检 ===');
  console.log(`卦库: ${DB.gua.length} 卦`);
  console.log(`铜钱分布(样本 ${sample.N}): 6=${sample.cnt[6]} 7=${sample.cnt[7]} 8=${sample.cnt[8]} 9=${sample.cnt[9]}`);
  console.log(`至少一变爻: ${(sample.ratio * 100).toFixed(1)}% (样本 ${sample.M})`);
  if (errs.length) {
    console.log('\n❌ 失败:');
    for (const e of errs) console.log('  -', e);
    process.exit(1);
  }
  console.log('\n✅ 全部通过');
  process.exit(0);
}

const r = cast();

if (asJson) {
  console.log(JSON.stringify({
    seed: r.seed, question: r.question, tone: r.tone,
    ben: r.ben ? { id: r.ben.id, name: r.ben.name, upper: r.ben.upper, lower: r.ben.lower, symbol: r.ben.symbol } : null,
    bian: r.bian ? { id: r.bian.id, name: r.bian.name, upper: r.bian.upper, lower: r.bian.lower, symbol: r.bian.symbol } : null,
    moving: r.movingIdx,
    lines: r.lines,
    benText: r.benText,
    bianText: r.bianText,
    movingYao: r.movingIdx.map((i) => r.yaoTexts[i - 1]).filter(Boolean),
    card: cardPath(r.ben),
    bianCard: cardPath(r.bian),
  }, null, 1));
  process.exit(0);
}

// ── 人读输出 ────────────────────────────────────────────
const L = r.lines;
console.log('');
console.log(`　问题：${r.question || '（未填写）'}`);
console.log(`　种子：${r.seed}`);
console.log('');
console.log('　　○ 老阳（变）　× 老阴（变）');
console.log('');
console.log(renderGlyph(L));
console.log('');
if (r.ben) console.log(`　本卦：${r.ben.symbol} 第${r.ben.id}卦 ${r.ben.name}（${r.ben.upper}上${r.ben.lower}下）`);
if (r.ben) console.log(`　牌图：${cardPath(r.ben)}`);
if (r.movingIdx.length) {
  console.log(`　变爻：${r.movingIdx.map((i) => L[i - 1].label).join('、')}`);
  if (r.bian) {
    console.log(`　变卦：${r.bian.symbol} 第${r.bian.id}卦 ${r.bian.name}（${r.bian.upper}上${r.bian.lower}下）`);
    console.log(`　变卦图：${cardPath(r.bian)}`);
  }
} else {
  console.log('　变爻：无（六爻皆静，只读本卦）');
}
console.log('');

// ── 经文 ──────────────────────────────────────────────
if (r.benText) {
  console.log('　【本卦经文】');
  console.log(`　卦辞：${r.benText.ci}`);
  console.log(`　象曰：${r.benText.xiang}`);
  console.log('');

  // 按变爻数，给出该读哪几条爻辞（与心法第四节一致）
  const n = r.movingIdx.length;
  const pick = (positions) =>
    positions.map((p) => {
      const t = r.benText.yaos[p - 1];
      return `　　${L[p - 1].label}：${t.text}`;
    });

  if (n === 0) {
    console.log('　【读法】六爻皆静，只读本卦卦辞，看大格局。');
  } else if (n === 1) {
    console.log('　【读法】一爻变，只读这一爻：');
    console.log(pick(r.movingIdx).join('\n'));
  } else if (n === 2) {
    const sorted = [...r.movingIdx].sort((a, b) => a - b);
    console.log('　【读法】二爻变，两爻都读，以上爻为主：');
    console.log(pick(sorted).join('\n'));
  } else if (n === 3) {
    console.log('　【读法】三爻变，本卦与变卦卦辞对读：');
    console.log(pick(r.movingIdx).join('\n'));
  } else if (n === 4) {
    const still = [1, 2, 3, 4, 5, 6].filter((p) => !r.movingIdx.includes(p));
    console.log('　【读法】四爻变，读变卦里没变的那两爻，以下爻为主：');
    if (r.bianText) still.forEach((p) => console.log(`　　${L[p - 1].label}：${r.bianText.yaos[p - 1].text}`));
  } else if (n === 5) {
    const still = [1, 2, 3, 4, 5, 6].filter((p) => !r.movingIdx.includes(p));
    console.log('　【读法】五爻变，读变卦里唯一没变的那一爻：');
    if (r.bianText) still.forEach((p) => console.log(`　　${L[p - 1].label}：${r.bianText.yaos[p - 1].text}`));
  } else {
    const use = r.benText.use;
    console.log('　【读法】六爻全变，' + (use ? '读用九/用六并参变卦：' : '读变卦卦辞：'));
    if (use) console.log(`　　${use}`);
  }
  console.log('');

  if (r.bianText) {
    console.log('　【变卦经文】');
    console.log(`　卦辞：${r.bianText.ci}`);
    console.log(`　象曰：${r.bianText.xiang}`);
    console.log('');
  }
}
