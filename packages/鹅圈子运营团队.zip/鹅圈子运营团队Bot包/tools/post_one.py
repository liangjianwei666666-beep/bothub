#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发一条圈子动态（文章动态）。在 xiaoetong.py run 环境里执行。

用法：
    post_one('从这一条开始：WE星球怎么用', '01-欢迎帖.txt', ['#公告'])

流程：进发帖页 → 填标题 → UEditor 写正文 → 选发布人 → 勾标签 → 点发布 → 回读确认
"""

import os
from pathlib import Path

# 通用包不预置任何圈子 ID。首次接入时写入同目录的圈子档案.md，
# 或在运行环境中设置 XIAOETONG_COMMUNITY_ID。
PACKAGE_DIR = Path(__file__).resolve().parents[1]
ARCHIVE = PACKAGE_DIR / '圈子档案.md'
COMMUNITY_ID = os.environ.get('XIAOETONG_COMMUNITY_ID', '').strip()
POSTS_DIR = str(PACKAGE_DIR / '内容')
COMPOSE_URL = ''


def configure(community_id=None):
    """设置本次任务的圈子 ID；调用前必须由团队确认目标圈子。"""
    global COMMUNITY_ID, COMPOSE_URL
    COMMUNITY_ID = (community_id or COMMUNITY_ID).strip()
    if not COMMUNITY_ID:
        raise RuntimeError('未配置 communityId，请先完成首次接入并确认目标圈子')
    COMPOSE_URL = (
        'https://admin.xiaoe-tech.com/t/community_admin/miniCommunity'
        f'#/edit_dynamic/rich_feed?community_id={COMMUNITY_ID}'
    )
    return COMMUNITY_ID


if not COMMUNITY_ID and ARCHIVE.exists():
    # 只读取明确的配置行，避免把其他文字误当成 ID。
    for line in ARCHIVE.read_text(encoding='utf-8').splitlines():
        if line.startswith('- communityId：'):
            configure(line.split('：', 1)[1])
            break


def _read_body(filename):
    with open(os.path.join(POSTS_DIR, filename), encoding='utf-8') as f:
        return f.read().strip()


def _body_to_html(body):
    html = []
    for line in body.split('\n'):
        html.append(f'<p>{line}</p>' if line.strip() else '<p><br/></p>')
    return ''.join(html)


def _open_compose():
    """从动态列表点「发布动态」进入发帖页（直接 goto 常常拿不到编辑器实例）。"""
    configure()
    page.goto(
        'https://admin.xiaoe-tech.com/t/community_admin/miniCommunity'
        f'#/community_manage/content_settings/feed_list?communityId={COMMUNITY_ID}&type=manage',
        wait_until='domcontentloaded',
    )
    page.wait_for_timeout(6000)
    b = page.evaluate("""() => {
        for (const el of document.querySelectorAll('button')) {
            if ((el.innerText||'').trim() === '发布动态') {
                const r = el.getBoundingClientRect();
                if (r.width > 0) return {x: Math.round(r.x+r.width/2), y: Math.round(r.y+r.height/2)};
            }
        }
        return null;
    }""")
    if not b:
        return '找不到「发布动态」按钮'
    page.mouse.click(b['x'], b['y'])
    page.wait_for_timeout(5000)
    # 等编辑器实例就绪
    for _ in range(10):
        ok = page.evaluate("""() => {
            const insts = window.UE && window.UE.instants ? Object.keys(window.UE.instants) : [];
            return insts.length > 0 && !!document.querySelector("input[placeholder='请输入标题名称']");
        }""")
        if ok:
            return 'ok'
        page.wait_for_timeout(1500)
    return '编辑器未就绪'


def _fill_title(title):
    page.click("input[placeholder='请输入标题名称']")
    page.fill("input[placeholder='请输入标题名称']", title)
    page.wait_for_timeout(600)
    got = page.input_value("input[placeholder='请输入标题名称']")
    return got == title


def _fill_body(body_html):
    """写入正文。

    坑：页面会堆积多个 UEditor 实例（ueditorInstant0..N），
    只有最后一个真正就绪。取 insts[0] 会报
    『Cannot read properties of undefined (reading 'forEach')』。
    所以按「body 存在 + 能读内容」筛出可用实例，优先取最后一个。
    """
    r = page.evaluate("""(html) => {
        const insts = window.UE && window.UE.instants ? Object.keys(window.UE.instants) : [];
        if (!insts.length) return {err: 'no ueditor'};
        const usable = [];
        for (const k of insts) {
            const u = window.UE.instants[k];
            try {
                if (u && u.body && typeof u.getContent === 'function') {
                    u.getContent();
                    usable.push(k);
                }
            } catch (e) { /* 坏实例，跳过 */ }
        }
        if (!usable.length) return {err: 'no usable ueditor', insts: insts};
        const key = usable[usable.length - 1];
        const ue = window.UE.instants[key];
        ue.setContent(html);
        ue.fireEvent && ue.fireEvent('contentchange');
        ue.sync && ue.sync();
        const f = document.querySelector('iframe[id^=ueditor_]');
        const doc = f && f.contentDocument;
        return {key: key,
                usableN: usable.length,
                len: (ue.getContent()||'').length,
                iframeLen: doc ? (doc.body.innerText||'').length : -1};
    }""", body_html)
    return r


def _pick_publisher(name='匪叔'):
    # 点开发布人下拉
    sel = page.locator("input[placeholder='请先选择发布人']")
    sel.click()
    page.wait_for_timeout(2500)
    item = page.evaluate("""(kw) => {
        const items = Array.from(document.querySelectorAll('.el-select-dropdown__item, [class*=dropdown] li'))
            .filter(e => {
                const r = e.getBoundingClientRect();
                return r.width > 0 && r.height > 0 && (e.innerText||'').includes(kw);
            });
        if (!items.length) return null;
        const r = items[0].getBoundingClientRect();
        return {x: Math.round(r.x+r.width/2), y: Math.round(r.y+r.height/2),
                txt: (items[0].innerText||'').replace(/\\s+/g,' ').trim()};
    }""", name)
    if not item:
        return '下拉里没有发布人'
    page.mouse.click(item['x'], item['y'])
    page.wait_for_timeout(1800)
    val = page.evaluate("""() => {
        const inp = Array.from(document.querySelectorAll('input')).find(i => (i.placeholder||'').includes('发布人') || (i.value||'').includes('匪叔'));
        return inp ? inp.value : null;
    }""")
    return {'picked': item['txt'], 'inputValue': val}


def _add_tags(tags):
    # 点「添加标签」
    b = page.evaluate("""() => {
        const el = document.querySelector('.addTag-button');
        if (!el) return null;
        const r = el.getBoundingClientRect();
        return {x: Math.round(r.x+r.width/2), y: Math.round(r.y+r.height/2)};
    }""")
    if not b:
        return '找不到添加标签按钮'
    page.mouse.click(b['x'], b['y'])
    page.wait_for_timeout(2800)

    result = page.evaluate("""(tags) => {
        const dlgs = Array.from(document.querySelectorAll('.ss-dialog'))
            .filter(d => {
                const r = d.getBoundingClientRect();
                return r.width > 250 && (d.innerText||'').includes('新建标签');
            });
        const d = dlgs[0];
        if (!d) return {err: '标签弹窗没打开'};

        // 标签现在是表格：行首 td 里是 .ss-checkbox__inner，标签名在另一个 td
        const picked = [], missing = [];
        for (const tag of tags) {
            const cell = Array.from(d.querySelectorAll('td .cell'))
                .find(c => (c.innerText||'').trim() === tag);
            if (!cell) { missing.push(tag); continue; }
            const row = cell.closest('tr');
            const box = row && row.querySelector('.ss-checkbox__inner');
            if (!box) { missing.push(tag); continue; }
            box.click();
            picked.push(tag);
        }
        return {picked, missing};
    }""", tags)

    if result.get('err'):
        return result

    page.wait_for_timeout(1200)
    # 点弹窗里的「确认」（ss-button）
    c = page.evaluate("""() => {
        const dlgs = Array.from(document.querySelectorAll('.ss-dialog'))
            .filter(d => d.getBoundingClientRect().width > 250 && (d.innerText||'').includes('新建标签'));
        const d = dlgs[0];
        if (!d) return null;
        const btn = Array.from(d.querySelectorAll('button'))
            .find(b => (b.innerText||'').trim() === '确认' && b.getBoundingClientRect().width > 0);
        if (!btn) return null;
        const r = btn.getBoundingClientRect();
        return {x: Math.round(r.x+r.width/2), y: Math.round(r.y+r.height/2)};
    }""")
    if c:
        page.mouse.click(c['x'], c['y'])
        page.wait_for_timeout(2000)
    else:
        result['no_confirm_btn'] = True
    return result


def _publish():
    b = page.evaluate("""() => {
        for (const el of document.querySelectorAll('button')) {
            if ((el.innerText||'').trim() === '发布动态') {
                const r = el.getBoundingClientRect();
                if (r.width > 0 && r.y > 800) return {x: Math.round(r.x+r.width/2), y: Math.round(r.y+r.height/2)};
            }
        }
        return null;
    }""")
    if not b:
        return '找不到发布按钮'
    page.mouse.click(b['x'], b['y'])
    page.wait_for_timeout(5000)
    return page.evaluate("""() => ({
        url: location.href,
        body: (document.body.innerText||'').replace(/\\n+/g,' | ').slice(0, 400)
    })""")


def post_one(title, filename, tags):
    """发一条。返回每步结果，便于排查。"""
    log = {}
    log['open'] = _open_compose()
    if log['open'] != 'ok':
        return log

    log['title'] = _fill_title(title)
    log['body'] = _fill_body(_body_to_html(_read_body(filename)))
    log['publisher'] = _pick_publisher('匪叔')
    log['tags'] = _add_tags(tags)
    log['publish'] = _publish()
    return log
