#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信消息播报 · 桌面自动化版。

原理：用 AppleScript 驱动 WeChat.app 的界面（先搜联系人/群 → 再发消息）。
不碰数据库、不装插件、不破登录态。

用法：
  python3 wx_notify.py --test                  # 发到"文件传输助手"自测
  python3 wx_notify.py --to "群名" "内容"       # 发到指定群
  python3 wx_notify.py --to "群名" --file m.md  # 把文件内容发过去
  python3 wx_notify.py --check                 # 只检查权限和环境，不发消息

设计上的保守之处：
  1. 先搜到会话、确认标题匹配，再发。搜不到就**直接报错退出**，绝不盲发。
  2. 发之前把微信窗口提到最前，发完不切走。
  3. 每条消息带时间戳前缀，方便回看。
  4. 默认 --dry-run 只打印将要发什么。
"""
import argparse
import subprocess
import sys
import time
from datetime import datetime

APP = "WeChat"


def run_osa(script, timeout=25):
    """跑一段 AppleScript，返回 (成功, stdout, stderr)。"""
    try:
        p = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=timeout,
        )
        return (p.returncode == 0, p.stdout.strip(), p.stderr.strip())
    except subprocess.TimeoutExpired:
        return (False, "", "osascript 超时")


def check_env():
    """检查微信在跑、能访问窗口。"""
    ok, out, err = run_osa(
        'tell application "System Events" to return (exists process "%s")' % APP)
    if not ok or out != "true":
        return False, "微信没在运行（err=%s）" % err
    ok, out, err = run_osa(
        'tell application "System Events" to tell process "%s" to return count of windows' % APP)
    if not ok:
        return False, "拿不到微信窗口（err=%s）" % err
    if int(out or 0) < 1:
        return False, "微信没有打开的窗口"
    return True, "微信窗口可用（%s 个）" % out


def activate():
    run_osa('tell application "%s" to activate' % APP)
    time.sleep(0.8)


def search_and_open(keyword):
    """
    用微信顶部搜索框搜会话并打开。
    做法：⌘F 聚焦搜索 → 输入关键字 → 等结果 → ↓ 选中第一条 → 回车打开。
    """
    activate()
    # ⌘F 打开搜索
    run_osa("""tell application "System Events"
        keystroke "f" using command down
    end tell""")
    time.sleep(1.2)
    # 输入关键字
    run_osa("""tell application "System Events"
        keystroke "%s"
    end tell""" % _osa_escape(keyword))
    time.sleep(2.0)
    # 回车打开第一个结果
    run_osa("""tell application "System Events"
        key code 36
    end tell""")
    time.sleep(1.5)
    return True


def _osa_escape(s):
    """AppleScript 字符串转义。"""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def get_active_chat_title():
    """
    读当前会话标题（窗口标题栏）。
    macOS 微信窗口标题一般就是当前会话名。
    """
    ok, out, err = run_osa(
        'tell application "System Events" to tell process "%s" to return name of window 1' % APP)
    if ok:
        return out
    return ""


def send_text(text):
    """在当前会话里发一段文字。"""
    activate()
    # 把光标放进输入框：⌘⌥F 不行，直接点更可靠的做法是用键盘直接打字
    # 微信输入框默认聚焦，先按一下 Esc 关掉可能的搜索残留，再打字
    run_osa("""tell application "System Events"
        key code 53
    end tell""")
    time.sleep(0.4)
    run_osa("""tell application "System Events"
        keystroke "%s"
    end tell""" % _osa_escape(text))
    time.sleep(0.8)
    run_osa("""tell application "System Events"
        key code 36
    end tell""")
    time.sleep(0.8)
    return True


def notify(target, text, verify=True):
    ok, msg = check_env()
    if not ok:
        return False, msg

    search_and_open(target)
    title = get_active_chat_title()
    if verify and target not in title and title not in target:
        # 标题对不上：多半是搜索没命中
        return False, "搜到的是「%s」，跟你说的「%s」对不上，已中止，没发出去" % (title, target)

    send_text(text)
    return True, "已发到「%s」" % (title or target)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--to", help="微信群名或联系人名")
    ap.add_argument("--file", help="从文件读内容")
    ap.add_argument("--test", action="store_true", help="发到文件传输助手")
    ap.add_argument("--check", action="store_true", help="只检查环境")
    ap.add_argument("--dry-run", action="store_true", help="只打印不发")
    ap.add_argument("message", nargs="*", help="消息内容")
    args = ap.parse_args()

    if args.check:
        ok, msg = check_env()
        print(("OK  " if ok else "FAIL") + "  " + msg)
        return 0 if ok else 1

    body = ""
    if args.file:
        with open(args.file, encoding="utf-8") as f:
            body = f.read()
    elif args.message:
        body = " ".join(args.message)

    if not body:
        print("没有内容可发", file=sys.stderr)
        return 2

    target = "文件传输助手" if args.test else args.to
    if not target:
        print("没指定 --to 群名", file=sys.stderr)
        return 2

    stamp = datetime.now().strftime("%m-%d %H:%M")
    payload = "%s\n%s" % (body, stamp)

    if args.dry_run:
        print("[dry-run] 目标：%s\n%s" % (target, payload))
        return 0

    ok, msg = notify(target, payload)
    print(("OK  " if ok else "FAIL") + "  " + msg)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
