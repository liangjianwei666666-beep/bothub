#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小鹅通商家后台（admin.xiaoe-tech.com）自动化入口 · 常驻有头模式。

架构：一个「永远开着的可见浏览器」+ 所有命令通过 CDP 接管这同一个窗口。
所以你在屏幕侧边能一直看着它，我每点一下、每跳一页，你当场就看见。

登录态与窗口都存在 ~/.xiaoetong/profile/（权限 700，不进项目、不进 git）。

用法：
  python3 xiaoetong.py serve          # 起一个常驻可见浏览器（后台跑，别关）
  python3 xiaoetong.py status         # 检查：窗口活着吗、登录了吗
  python3 xiaoetong.py goto <url>     # 在同一个窗口里跳转
  python3 xiaoetong.py text [url]     # 读正文（不给 url 就读当前页）
  python3 xiaoetong.py shot [out]     # 截图当前页
  python3 xiaoetong.py links          # 列当前页链接
  python3 xiaoetong.py run <file.py>  # 跑任意脚本，page 就是那个可见窗口
  python3 xiaoetong.py log            # 看最近 40 条操作记录

操作记录写在 ~/.xiaoetong/actions.log（每行：时间 + 我做了什么）。
"""
import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

HOME = Path.home() / ".xiaoetong"
PROFILE = HOME / "profile"
SHOTS = HOME / "shots"
LOGFILE = HOME / "actions.log"
PIDFILE = HOME / "serve.pid"
PORT = int(os.environ.get("XT_PORT", "9222"))
ADMIN = "https://admin.xiaoe-tech.com/"
LOGIN_PATH = "/t/login"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")


def ensure_dirs():
    for d in (HOME, SHOTS):
        d.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(HOME, 0o700)
    except OSError:
        pass


def log(msg):
    ensure_dirs()
    line = "%s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    with open(LOGFILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")
    print("[%s]" % line, flush=True)


def cdp_up():
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/json/version" % PORT, timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def spawn_serve():
    ensure_dirs()
    logf = open(HOME / "serve.log", "ab")
    subprocess.Popen(
        [sys.executable, os.path.abspath(__file__), "serve"],
        stdout=logf, stderr=logf,
        start_new_session=True,
    )
    for _ in range(60):
        time.sleep(0.5)
        if cdp_up():
            return True
    return False


def ensure_server():
    if cdp_up():
        return True
    log("窗口没开，自动起一个常驻可见浏览器（port %d）" % PORT)
    return spawn_serve()


def cmd_serve(args):
    ensure_dirs()
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            str(PROFILE),
            headless=args.headless,
            viewport={"width": 1440, "height": 940},
            locale="zh-CN",
            timezone_id="Asia/Shanghai",
            user_agent=UA,
            accept_downloads=True,
            args=[
                "--remote-debugging-port=%d" % PORT,
                "--disable-blink-features=AutomationControlled",
                "--no-first-run",
                "--no-default-browser-check",
                "--window-position=40,40",
            ],
        )
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(45000)
        PIDFILE.write_text(str(os.getpid()))
        log("常驻浏览器已就绪，pid=%d，可直接操作这个窗口" % os.getpid())
        try:
            page.goto(ADMIN, wait_until="domcontentloaded")
        except Exception as e:
            log("初始跳转失败：%s" % e)
        while True:
            time.sleep(5)
            try:
                if not ctx.pages and not ctx.browser:
                    break
            except Exception:
                break


class Win:
    """接管那个可见窗口。"""

    def __init__(self, p):
        self.browser = p.chromium.connect_over_cdp("http://127.0.0.1:%d" % PORT)
        self.ctx = self.browser.contexts[0]
        self.page = self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        self.page.set_default_timeout(45000)

    def close(self):
        self.browser.close()  # 只断开 CDP，不关浏览器


def with_win(fn):
    def wrapper(args):
        if not ensure_server():
            print("起不来常驻浏览器，看 ~/.xiaoetong/serve.log")
            return 3
        with sync_playwright() as p:
            w = Win(p)
            page = w.page
            try:
                return fn(args, page, w)
            finally:
                w.close()
    return wrapper


LOGIN_MARKERS = ("微信扫码 安全登录", "免费注册", "还没有账号")


def logged_in(page):
    try:
        if LOGIN_PATH in page.url:
            return False
        body = page.inner_text("body")[:3000]
        return not any(m in body for m in LOGIN_MARKERS)
    except Exception:
        return False


def _body(page, timeout=15000):
    try:
        return page.inner_text("body", timeout=timeout)
    except Exception:
        return page.evaluate("() => document.body ? document.body.innerText : ''")


@with_win
def cmd_status(args, page, w):
    if "xiaoe-tech" not in page.url:
        page.goto(ADMIN, wait_until="domcontentloaded")
        page.wait_for_timeout(3000)
    ok = logged_in(page)
    print("窗口：活着（port %d）" % PORT)
    print("登录态：%s" % ("有效" if ok else "已失效"))
    print("当前页：%s" % page.title())
    print("URL：%s" % page.url)
    log("status → %s | %s" % ("登录有效" if ok else "未登录", page.url))
    return 0 if ok else 2


@with_win
def cmd_goto(args, page, w):
    page.goto(args.url, wait_until="domcontentloaded")
    page.wait_for_timeout(args.wait)
    print("URL:", page.url)
    print("TITLE:", page.title())
    print(_body(page)[: args.limit])
    log("goto %s" % args.url)
    return 0


@with_win
def cmd_text(args, page, w):
    if args.url:
        page.goto(args.url, wait_until="domcontentloaded")
        page.wait_for_timeout(args.wait)
        log("读页面 %s" % args.url)
    print(_body(page)[: args.limit])
    return 0


@with_win
def cmd_shot(args, page, w):
    out = Path(args.out) if args.out else SHOTS / ("shot-%d.png" % int(time.time()))
    out.parent.mkdir(parents=True, exist_ok=True)
    page.screenshot(path=str(out), full_page=args.full)
    print(out)
    log("截图 → %s (%s)" % (out, page.url))
    return 0


@with_win
def cmd_links(args, page, w):
    for a in page.query_selector_all("a"):
        t = (a.inner_text() or "").strip().replace("\n", " ")[:40]
        h = a.get_attribute("href") or ""
        if t or h:
            print("%-42s %s" % (t, h))
    return 0


@with_win
def cmd_run(args, page, w):
    def goto_text(url, wait=4000):
        page.goto(url, wait_until="domcontentloaded")
        page.wait_for_timeout(wait)
        return _body(page)

    def shot(path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(path), full_page=True)
        return path

    ns = {
        "page": page, "ctx": w.ctx, "p": w.p if hasattr(w, "p") else None,
        "goto_text": goto_text, "shot": shot, "logged_in": logged_in,
        "log": log, "SHOTS": SHOTS, "ADMIN": ADMIN, "time": time,
    }
    code = Path(args.file).read_text(encoding="utf-8")
    exec(compile(code, args.file, "exec"), ns)
    return 0


def cmd_log(args):
    if LOGFILE.exists():
        lines = LOGFILE.read_text(encoding="utf-8").strip().split("\n")
        for line in lines[-args.n:]:
            print(line)
    else:
        print("还没有操作记录")
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("serve")
    s.add_argument("--headless", action="store_true")
    s.set_defaults(fn=cmd_serve)

    sub.add_parser("status").set_defaults(fn=cmd_status)

    s = sub.add_parser("goto")
    s.add_argument("url")
    s.add_argument("--limit", type=int, default=3000)
    s.add_argument("--wait", type=int, default=6000)
    s.set_defaults(fn=cmd_goto)

    s = sub.add_parser("text")
    s.add_argument("url", nargs="?")
    s.add_argument("--limit", type=int, default=6000)
    s.add_argument("--wait", type=int, default=4000)
    s.set_defaults(fn=cmd_text)

    s = sub.add_parser("shot")
    s.add_argument("out", nargs="?")
    s.add_argument("--full", action="store_true")
    s.set_defaults(fn=cmd_shot)

    sub.add_parser("links").set_defaults(fn=cmd_links)

    s = sub.add_parser("run")
    s.add_argument("file")
    s.set_defaults(fn=cmd_run)

    s = sub.add_parser("log")
    s.add_argument("-n", type=int, default=40)
    s.set_defaults(fn=cmd_log)

    args = ap.parse_args()
    sys.exit(args.fn(args) or 0)


if __name__ == "__main__":
    main()
