#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""学科助手 · 安装

由学生自己运行，或由主 Bot 代跑：
  1. 把 工作区/ 复制到桌面「学科助手」
  2. 刷新学习台
  3. 在桌面放一个「学习台」入口（mac .app / Windows .url / Linux .desktop）

用法：
    python3 安装.py
    python3 安装.py --dest "~/Desktop/我的学科助手"
    python3 安装.py --force          # 目标已存在时覆盖
不需要联网，也不需要装第三方库。
"""

import argparse
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(HERE), "工作区")


def copy_workspace(src, dst):
    ignore = shutil.ignore_patterns(".DS_Store", "__pycache__", "生图API.txt", "*.tmp")
    shutil.copytree(src, dst, ignore=ignore, dirs_exist_ok=True)


def hide_internal(dst):
    """装完后把内部脚本隐藏：学生只看到学习台、咒语和三个学科。"""
    names = ["_建总台.py", "_皮肤.py", "生图.py", "自定义主题_示例.css", "生图API.txt", "_文档"]
    if sys.platform == "darwin":
        for n in names:
            p = os.path.join(dst, n)
            if os.path.exists(p):
                subprocess.run(["chflags", "hidden", p], check=False)
        for sub in ("01-语文", "02-数学", "03-英语"):
            sd = os.path.join(dst, sub)
            if not os.path.isdir(sd):
                continue
            for name in os.listdir(sd):
                p = os.path.join(sd, name)
                if (os.path.isfile(p) and name.endswith((".py", ".json"))) or name == "_素材":
                    subprocess.run(["chflags", "hidden", p], check=False)
    elif os.name == "nt":
        for n in names:
            p = os.path.join(dst, n)
            if os.path.exists(p):
                subprocess.run(["attrib", "+H", p], shell=True, check=False)
        for sub in ("01-语文", "02-数学", "03-英语"):
            sd = os.path.join(dst, sub)
            if not os.path.isdir(sd):
                continue
            for name in os.listdir(sd):
                p = os.path.join(sd, name)
                if (os.path.isfile(p) and name.endswith((".py", ".json"))) or name == "_素材":
                    subprocess.run(["attrib", "+H", p], shell=True, check=False)


def refresh(dst):
    script = os.path.join(dst, "_建总台.py")
    if os.path.isfile(script):
        subprocess.run([sys.executable, script], cwd=dst, check=False)


def make_entry(dst, desktop):
    """桌面放一个 HTML 启动页：双击必然走浏览器，不依赖 .app 签名或 .url 关联。"""
    index = os.path.join(dst, "index.html")
    url = "file://" + index.replace(" ", "%20")
    html = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta http-equiv="refresh" content="0; url=%s">
<title>学习台</title>
<style>body{margin:0;height:100vh;display:grid;place-items:center;background:#F6F3ED;
font-family:-apple-system,"PingFang SC",sans-serif;color:#3A3A34;text-align:center}
a{color:#B05B4F;font-size:15px}</style></head>
<body><div><p style="font-size:18px;letter-spacing:.08em">正在打开学习台…</p>
<p><a href="%s">如果没有自动跳转，点这里</a></p></div>
<script>location.replace("%s");</script>
</body></html>
""" % (url, url, url)
    out = os.path.join(desktop, "学习台.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    return out


def main():
    ap = argparse.ArgumentParser(description="安装学科助手到桌面")
    ap.add_argument("--src", default=SRC, help="工作区来源，默认同目录 工作区/")
    ap.add_argument("--dest", default=os.path.join(os.path.expanduser("~"), "Desktop", "学科助手"))
    ap.add_argument("--desktop", default=os.path.join(os.path.expanduser("~"), "Desktop"))
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()

    src = os.path.abspath(os.path.expanduser(a.src))
    dst = os.path.abspath(os.path.expanduser(a.dest))
    desktop = os.path.abspath(os.path.expanduser(a.desktop))

    if not os.path.isdir(src):
        sys.exit("找不到 工作区/，请把整个包解压后，在包目录里运行这个脚本。")
    if os.path.exists(dst) and os.listdir(dst) and not a.force:
        sys.exit("桌面已经有「%s」文件夹了。要重新安装就加 --force（会覆盖里面的文件）。" % os.path.basename(dst))

    os.makedirs(desktop, exist_ok=True)
    print("正在安装到：", dst)
    copy_workspace(src, dst)
    hide_internal(dst)
    print("正在刷新学习台……")
    refresh(dst)
    entry = make_entry(dst, desktop)
    print("")
    print("完成：")
    print("  1) 文件夹：", dst)
    print("  2) 桌面入口：", entry)
    print("  3) 双击桌面「学习台」就能开始；右上角有魔法咒语。")
    print("")
    print("以后新增内容，刷新一次：python3 \"%s\"" % os.path.join(dst, "_建总台.py"))


if __name__ == "__main__":
    main()
