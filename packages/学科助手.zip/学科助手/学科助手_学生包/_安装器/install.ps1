﻿# 学科助手 · Windows 安装（不需要 Python 也能装）
# 由 安装.bat 调用，或右键「使用 PowerShell 运行」
param([switch]$Auto, [switch]$NoOpen)
$ErrorActionPreference = 'Stop'
if ($Auto) { $env:AUTO = '1' }
if ($NoOpen) { $env:SKIP_OPEN = '1' }
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath('Desktop')
$dest = Join-Path $desktop '学科助手'

if (Test-Path $dest) {
  $items = Get-ChildItem $dest -Force -ErrorAction SilentlyContinue
  if ($items) {
    if ($env:AUTO -eq '1') { Write-Host '已存在同名文件夹，按自动安装继续覆盖' }
    else {
      $ans = Read-Host '桌面已经有「学科助手」文件夹，覆盖安装吗？(y/N)'
      if ($ans -ne 'y') { Write-Host '已取消'; exit 1 }
    }
  }
}

Write-Host "正在安装到：$dest"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Path (Join-Path (Split-Path -Parent $here) '工作区\*') -Destination $dest -Recurse -Force

# 隐藏内部文件：学生只看到学习台、咒语和三个学科
$hideRoot = @('_建总台.py','_皮肤.py','生图.py','自定义主题_示例.css','生图API.txt','_文档')
foreach ($n in $hideRoot) {
  $p = Join-Path $dest $n
  if (Test-Path $p) { (Get-Item $p -Force).Attributes = (Get-Item $p -Force).Attributes -bor [IO.FileAttributes]::Hidden }
}
foreach ($sub in @('01-语文','02-数学','03-英语')) {
  $sd = Join-Path $dest $sub
  if (Test-Path $sd) {
    Get-ChildItem $sd -File -Force | Where-Object { $_.Extension -in '.py','.json' } | ForEach-Object {
      $_.Attributes = $_.Attributes -bor [IO.FileAttributes]::Hidden
    }
    $mat = Join-Path $sd '_素材'
    if (Test-Path $mat) { (Get-Item $mat -Force).Attributes = (Get-Item $mat -Force).Attributes -bor [IO.FileAttributes]::Hidden }
  }
}

# 桌面「学习台」入口：一个 HTML 启动页，双击必然走浏览器
$index = Join-Path $dest 'index.html'
$url = 'file:///' + (($index -replace '\\', '/') -replace ' ', '%20')
$html = @"
<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta http-equiv="refresh" content="0; url=$url">
<title>学习台</title>
<style>body{margin:0;height:100vh;display:grid;place-items:center;background:#F6F3ED;
font-family:-apple-system,"PingFang SC",sans-serif;color:#3A3A34;text-align:center}
a{color:#B05B4F;font-size:15px}</style></head>
<body><div><p style="font-size:18px;letter-spacing:.08em">正在打开学习台…</p>
<p><a href="$url">如果没有自动跳转，点这里</a></p></div>
<script>location.replace("$url");</script>
</body></html>
"@
Set-Content -Path (Join-Path $desktop '学习台.html') -Value $html -Encoding UTF8

# 有 Python 就顺手刷新
if (Get-Command python -ErrorAction SilentlyContinue) {
  Push-Location $dest; & python '_建总台.py' | Out-Null; Pop-Location; Write-Host '学习台已刷新'
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
  Push-Location $dest; & py '_建总台.py' | Out-Null; Pop-Location; Write-Host '学习台已刷新'
} else {
  Write-Host '没检测到 Python：学习台能打开，暂时不能自动刷新。'
}

Write-Host ''
Write-Host '完成：'
Write-Host "  文件夹：$dest"
Write-Host "  入口：  $(Join-Path $desktop '学习台.html')"
if ($env:SKIP_OPEN -ne '1') { Start-Process $index }
