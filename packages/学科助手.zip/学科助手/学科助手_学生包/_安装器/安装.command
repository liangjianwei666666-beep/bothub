#!/bin/bash
# 学科助手 · Mac 安装（不需要 Python 也能装）
# 双击运行，或由主 Bot 执行：bash 安装.command
set -e
if [ "${1:-}" = "--auto" ]; then
  AUTO=1; SKIP_OPEN=1; SKIP_PAUSE=1
fi
HERE="$(cd "$(dirname "$0")" && pwd)"
DESKTOP="$(cd "$HOME/Desktop" 2>/dev/null && pwd || echo "$HOME/Desktop")"
DEST="$DESKTOP/学科助手"

if [ -e "$DEST" ] && [ "$(ls -A "$DEST" 2>/dev/null)" ]; then
  if [ "${AUTO:-}" = "1" ]; then
    echo "已存在同名文件夹，按自动安装继续覆盖"
  else
    read -r -p "桌面已经有「学科助手」文件夹，覆盖安装吗？(y/N) " ans
    [ "$ans" = "y" ] || { echo "已取消"; read -r -p "按回车关闭" _; exit 1; }
  fi
fi

echo "正在安装到：$DEST"
mkdir -p "$DEST"
cp -R "$HERE/../工作区/." "$DEST/"

# 隐藏内部文件：学生只看到学习台、咒语和三个学科
for f in "_建总台.py" "_皮肤.py" "生图.py" "自定义主题_示例.css" "生图API.txt" "_文档"; do
  [ -e "$DEST/$f" ] && chflags hidden "$DEST/$f" 2>/dev/null || true
done
for sub in "01-语文" "02-数学" "03-英语"; do
  if [ -d "$DEST/$sub" ]; then
    find "$DEST/$sub" -maxdepth 1 -type f \( -name "*.py" -o -name "*.json" \) -exec chflags hidden {} \; 2>/dev/null || true
    [ -d "$DEST/$sub/_素材" ] && chflags hidden "$DEST/$sub/_素材" 2>/dev/null || true
  fi
done

# 桌面「学习台」入口：一个 HTML 启动页，双击必然走浏览器，不依赖 .app 签名
URL="file://$(printf '%s' "$DEST/index.html" | sed 's/ /%20/g')"
cat > "$DESKTOP/学习台.html" <<HTML
<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta http-equiv="refresh" content="0; url=$URL">
<title>学习台</title>
<style>body{margin:0;height:100vh;display:grid;place-items:center;background:#F6F3ED;
font-family:-apple-system,"PingFang SC",sans-serif;color:#3A3A34;text-align:center}
a{color:#B05B4F;font-size:15px}</style></head>
<body><div><p style="font-size:18px;letter-spacing:.08em">正在打开学习台…</p>
<p><a href="$URL">如果没有自动跳转，点这里</a></p></div>
<script>location.replace("$URL");</script>
</body></html>
HTML
xattr -dr com.apple.quarantine "$DESKTOP/学习台.html" 2>/dev/null || true

# 有 Python 就顺手刷新；没有也能打开，只是暂不刷新
if command -v python3 >/dev/null 2>&1; then
  (cd "$DEST" && python3 _建总台.py >/dev/null 2>&1) || true
  echo "学习台已刷新"
else
  echo "没检测到 Python 3：学习台能打开，但暂时不能自动刷新。让老师或主 Bot 装一下 Python 3。"
fi

echo ""
echo "完成："
echo "  文件夹：$DEST"
echo "  入口：  $DESKTOP/学习台.html"
[ "${SKIP_OPEN:-}" = "1" ] || open "$DEST/index.html"
[ "${SKIP_PAUSE:-}" = "1" ] || read -r -p "按回车关闭" _
