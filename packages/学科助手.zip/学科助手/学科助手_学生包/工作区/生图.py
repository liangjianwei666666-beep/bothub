#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生图小工具（TelangpuAI，OpenAI 兼容接口）。

用法：
    python3 生图.py --prompt "一张手绘风的知识图谱，留白多" --out "素材/2026-11-03_图谱_01.png"
    python3 生图.py --prompt "..." --out ... --model gpt-image-2.5-flare --size 1536x1024 --quality low
    python3 生图.py --list-models

Key 读取顺序（不会打印 key）：
    1. 环境变量 TELANGPUAI_IMAGE_API_KEY
    2. 同目录的 生图API.txt，里面写一行 key:sk-xxx
接口固定 https://telangpuai.com/v1/images/generations。
"""

import argparse
import base64
import io
import json
import os
import sys
import urllib.request

try:
    from PIL import Image
except ImportError:
    Image = None

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = "https://telangpuai.com"
CONF = os.path.join(HERE, "生图API.txt")


def load_key():
    key = os.environ.get("TELANGPUAI_IMAGE_API_KEY", "").strip()
    if key:
        return key
    if os.path.isfile(CONF):
        for line in open(CONF, encoding="utf-8"):
            line = line.strip()
            if line.lower().startswith("key:"):
                return line.split(":", 1)[1].strip()
    sys.exit("没找到生图 key。请把 key 写进 生图API.txt（一行 key:sk-...），或设置环境变量 TELANGPUAI_IMAGE_API_KEY。")


def call(path, key, payload=None):
    data = json.dumps(payload).encode() if payload else None
    req = urllib.request.Request(BASE + path, data=data,
                                 headers={"Authorization": "Bearer " + key,
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=240) as r:
        return json.loads(r.read().decode())


def main():
    ap = argparse.ArgumentParser(description="用 TelangpuAI 生图")
    ap.add_argument("--prompt", default="")
    ap.add_argument("--out", default="")
    ap.add_argument("--model", default="gpt-image-2")
    ap.add_argument("--quality", default="low", help="low / medium / high（2.5 系还有 xhigh/max/auto）")
    ap.add_argument("--size", default="1024x1024")
    ap.add_argument("--max-kb", type=int, default=300, help="超过就把 PNG 自动转成同名 webp")
    ap.add_argument("--list-models", action="store_true")
    a = ap.parse_args()

    key = load_key()

    if a.list_models:
        d = call("/v1/models", key)
        for m in d.get("data", []):
            print(m.get("id"))
        return

    if not a.prompt:
        sys.exit("要 --prompt，比如 --prompt \"一张手绘图谱\"")
    if not a.out:
        sys.exit("要 --out，比如 --out \"素材/2026-11-03_图_01.png\"")

    d = call("/v1/images/generations", key, {
        "model": a.model, "prompt": a.prompt, "n": 1,
        "size": a.size, "quality": a.quality,
    })
    items = d.get("data") or []
    if not items:
        sys.exit("接口没返回图片：" + json.dumps(d, ensure_ascii=False)[:300])
    it = items[0]
    if it.get("b64_json"):
        raw = base64.b64decode(it["b64_json"])
    elif it.get("url"):
        with urllib.request.urlopen(it["url"], timeout=240) as r:
            raw = r.read()
    else:
        sys.exit("返回里既没有 b64_json 也没有 url")

    out = os.path.abspath(os.path.expanduser(a.out))
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    ext = os.path.splitext(out)[1].lower()
    if Image and ext in (".webp", ".jpg", ".jpeg"):
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        if max(img.size) > 2048:
            img.thumbnail((2048, 2048))
        if ext == ".webp":
            img.save(out, "WEBP", quality=82, method=6)
        else:
            img.save(out, "JPEG", quality=85)
    else:
        with open(out, "wb") as f:
            f.write(raw)
    if Image and ext == ".png" and os.path.getsize(out) > a.max_kb * 1024:
        webp = os.path.splitext(out)[0] + ".webp"
        img = Image.open(out).convert("RGB")
        if max(img.size) > 2048:
            img.thumbnail((2048, 2048))
        img.save(webp, "WEBP", quality=82, method=6)
        print("原图偏大，已另存压缩版：%s" % webp)
        out = webp
    print("已保存：%s" % out)
    print("模型：%s · 尺寸：%s · 质量：%s · %.0f KB" % (a.model, a.size, a.quality, len(raw) / 1024))


if __name__ == "__main__":
    main()
