#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
语文学习台 · 导航生成器

作用：扫描四个板块文件夹，重新生成
  1) 学科根目录 index.html —— 语文学习台（四板块入口，上一级是统一学习台）
  2) 每个板块内的 index.html —— 该板块的文件清单

用法：python3 _更新导航.py
每次新增产出后跑一次即可，不需要联网、不需要装任何东西。
"""

import os
import time
import html
from urllib.parse import quote

ROOT = os.path.dirname(os.path.abspath(__file__))

import sys as _sys
_sys.path.insert(0, os.path.dirname(ROOT))
import _皮肤

MODULES = [
    dict(folder="01-知识点可视化", name="知识点可视化", tag="图谱 / 流程图",
         color="#b23a30",
         desc="文言实词虚词按义项织成图谱，修辞与文章结构画成流程图，特殊句式套模板。",
         empty="将产出：文言实词虚词图谱、词类活用与特殊句式模板、修辞与结构流程图。"),
    dict(folder="02-游戏练习", name="游戏练习", tag="闯关 / 积分 / 连击",
         color="#2f6d5a",
         desc="字词听写与古诗文默写闯关，答对累计积分，连对触发连击，错了不卡关。",
         empty="将产出：字词闯关、古诗文默写闯关、积分与连击规则说明。"),
    dict(folder="03-阶段测试与报告", name="阶段测试与报告", tag="单元卷 / 薄弱点定位",
         color="#3b5b8c",
         desc="单元卷与阶段卷，判完给薄弱点报告，直接定位到「哪类题错、错在哪个能力点」。",
         empty="将产出：单元试卷、阶段测评卷、判分与薄弱点报告（定位到具体失分点）。"),
    dict(folder="04-错题卡", name="错题卡", tag="错因 / 重练",
         color="#8a5a9b",
         desc="每题记原文、错因（审题／理解／表达）、针对性重练题，隔天按遗忘曲线再现。",
         empty="将产出：单题错题卡、错因归类汇总、同型重练题组。"),
]

SKIP_FILES = {"index.html", ".DS_Store", "_更新导航.py"}
SKIP_DIRS = {"__pycache__", ".git"}


def esc(s):
    return html.escape(str(s), quote=True)


def url(path_rel):
    return "/".join(quote(p) for p in path_rel.split("/"))


def scan(folder):
    """返回该板块下的所有文件（相对路径、显示名、大小、修改时间）"""
    base = os.path.join(ROOT, folder)
    out = []
    if not os.path.isdir(base):
        return out
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in filenames:
            if fn in SKIP_FILES or fn.startswith("."):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, ROOT).replace(os.sep, "/")
            try:
                st = os.stat(full)
            except OSError:
                continue
            out.append(dict(rel=rel, name=fn, size=st.st_size, mtime=st.st_mtime))
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def fmt_time(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def fmt_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0


def main():
    """生成学科页与四个板块页（与数学/英语同一套皮肤）。"""
    modules = [dict(folder=m["folder"], name=m["name"], files=scan(m["folder"]))
               for m in MODULES]
    cfg = _皮肤.read_settings(ROOT)
    title = cfg.get("名字") or "语文"
    student = cfg.get("学生", "")
    ac, tn = "#B05B4F", "#FAF0ED"

    with open(os.path.join(ROOT, "index.html"), "w", encoding="utf-8") as f:
        f.write(_皮肤.subject_page(ROOT, "语文", title, student, modules, ac, tn))
    for m in modules:
        d = os.path.join(ROOT, m["folder"])
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "index.html"), "w", encoding="utf-8") as f:
            f.write(_皮肤.module_page(ROOT, "语文", m["folder"], m["name"], m["files"], ac, tn))
    print("导航已更新：", os.path.join(ROOT, "index.html"))


if __name__ == "__main__":
    main()
