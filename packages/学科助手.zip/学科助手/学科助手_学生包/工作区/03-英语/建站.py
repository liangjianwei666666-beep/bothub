#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学科导航生成器（通用版）—— 给语文 / 数学 / 英语等学科一键建「项目文件夹 + 学习台导航页」。

用法示例：
    python3 建站.py --root "/Users/a1-6/Desktop/数学" --subject "数学" --launcher "数学导航"

默认写好四个板块文件夹（01-知识点可视化 … 04-错题卡），再生成：
    <root>/index.html                 学科学习台（四板块入口，带搜索、最近产出）
    <root>/<板块>/index.html           各板块的文件清单
    ~/Desktop/<launcher>.app           双击即开的桌面入口（macOS）

每次新增产出后再跑一次本脚本，导航页就会刷新。
只覆盖 index.html，不碰你自己的任何产出文件。
"""

import argparse
import json
import os
import time
import html
import sys
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import _皮肤

DEFAULT_MODULES = [
    dict(folder="01-知识点可视化", name="知识点可视化", tag="图谱 / 流程图", color="#b23a30",
         desc="把本学科的核心概念、公式、规则画成图谱和流程图，一页看全关系。",
         empty="将产出：概念图谱、公式或规则图表、知识结构流程图。"),
    dict(folder="02-游戏练习", name="游戏练习", tag="闯关 / 积分 / 连击", color="#2f6d5a",
         desc="基础项做成闯关，答对累计积分，连对触发连击，错了不卡关。",
         empty="将产出：分级闯关练习、积分与连击规则说明。"),
    dict(folder="03-阶段测试与报告", name="阶段测试与报告", tag="单元卷 / 薄弱点定位", color="#3b5b8c",
         desc="单元卷与阶段卷，判完给薄弱点报告，定位到具体失分点而不是空泛评语。",
         empty="将产出：单元试卷、阶段测评卷、判分与薄弱点报告。"),
    dict(folder="04-错题卡", name="错题卡", tag="错因 / 重练", color="#8a5a9b",
         desc="每题记原文、错因（审题／理解／计算／表达）、同型重练题，隔天按遗忘曲线再现。",
         empty="将产出：单题错题卡、错因归类汇总、同型重练题组。"),
]

# 这些不算「学生做出来的东西」，不计入文件数，也不列在清单里。
# 错题本.json 是错题本的内部数据；照片/ 里的原图由 错题本.html 自己显示。
SKIP_FILES = {"index.html", ".DS_Store", "错题本.json", "错题本.json.tmp"}
SKIP_DIRS = {"__pycache__", ".git", "照片"}

# 视觉风格：每个学生的工作台可以长得不一样。
# 只用颜色令牌，不改结构——结构一动，四个板块的间距和层级就会漂。
def esc(s):
    return html.escape(str(s), quote=True)


def url(p):
    return "/".join(quote(x) for x in p.split("/"))


def scan(root, folder):
    base = os.path.join(root, folder)
    out = []
    if not os.path.isdir(base):
        return out
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in filenames:
            if fn in SKIP_FILES or fn.startswith("."):
                continue
            full = os.path.join(dirpath, fn)
            try:
                st = os.stat(full)
            except OSError:
                continue
            out.append(dict(rel=os.path.relpath(full, root).replace(os.sep, "/"),
                            name=fn, size=st.st_size, mtime=st.st_mtime))
    out.sort(key=lambda x: x["mtime"], reverse=True)
    return out


def ftime(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def fsize(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return ("%d B" % n) if u == "B" else ("%.1f %s" % (n, u))
        n /= 1024.0


def read_settings(root):
    """读 工作台设置.json；本目录没有就读上一级（工作区根目录）。"""
    for cand in (root, os.path.dirname(root)):
        path = os.path.join(cand, "工作台设置.json")
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                return d
        except Exception:
            print("（工作台设置.json 读不出来，这次用命令行给的设置）")
            return {}
    return {}


def build(root, subject, title="", student="", theme=None, accent=""):
    """生成学科页与四个板块页（统一皮肤，风格读 工作台设置.json）。"""
    old = read_settings(root)
    title = title or old.get("名字", "")
    student = student or old.get("学生", "")
    subject = subject or old.get("学科", "")
    style = theme if theme else old.get("风格", "")
    os.makedirs(root, exist_ok=True)

    modules = [dict(folder=m["folder"], name=m["name"], files=scan(root, m["folder"]))
               for m in DEFAULT_MODULES]
    tints = {"数学": ("#3F6B58", "#EEF4F0"),
             "英语": ("#40597F", "#EEF2F8"),
             "语文": ("#B05B4F", "#FAF0ED")}
    ac, tn = tints.get(subject, ("#B05B4F", "#FAF0ED"))
    if accent:
        ac = accent

    with open(os.path.join(root, "index.html"), "w", encoding="utf-8") as f:
        f.write(_皮肤.subject_page(root, subject, title, student, modules, ac, tn))
    for m in modules:
        d = os.path.join(root, m["folder"])
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, "index.html"), "w", encoding="utf-8") as f:
            f.write(_皮肤.module_page(root, subject, m["folder"], m["name"], m["files"], ac, tn))

    print("导航已更新：", os.path.join(root, "index.html"))
    if title:
        print("工作台名字：", title)
    if student:
        print("学生：", student)
    if style:
        print("视觉风格：", style)
    return root


def save_settings(root, subject, title="", student="", theme="", accent=""):
    """把这次用的名字/学生/风格记进 工作台设置.json。

    为什么必须记：_更新导航.py（学生以后刷新工作台用的那个脚本）是读这个 json
    来恢复名字和风格的。以前建站.py 只把名字写进 index.html、不写 json，
    于是学生第一次改完名字是好的，下次让助手刷新工作台时名字就悄悄退回
    「数学 · 学习台」——他自己改的东西丢了，还不知道为什么。

    只写非空项；一个都没给就不动 json，免得把学生已有的设置清空。
    """
    if not (title or student or theme or accent):
        return
    path = os.path.join(root, "工作台设置.json")
    old = {}
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                old = json.load(f) or {}
        except Exception:
            old = {}
    if not isinstance(old, dict):
        old = {}
    for key, val in (("名字", title), ("学生", student), ("风格", theme),
                     ("主色", accent)):
        if val:
            old[key] = val
    old.setdefault("学科", subject)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(old, f, ensure_ascii=False, indent=1)
        print("设置已记下：", path)
    except Exception as e:
        print("（设置没写进去：%s。名字这次照样生效，但下次刷新会退回默认）" % e)


def make_launcher(root, label):
    """在桌面生成双击即开的 .app（仅 macOS）。"""
    import subprocess
    desktop = os.path.expanduser("~/Desktop")
    app = os.path.join(desktop, label + ".app")
    target = "file://" + quote(os.path.join(root, "index.html"))
    script = 'do shell script "open \\"%s\\""' % target
    subprocess.run(["osacompile", "-o", app, "-e", script], check=True)
    print("桌面入口已生成：", app)
    return app


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="学科文件夹绝对路径，如 /Users/xxx/Desktop/数学")
    ap.add_argument("--subject", required=True, help="学科名，如 数学")
    ap.add_argument("--launcher", default="", help="桌面入口 App 名称；留空则不生成")
    ap.add_argument("--title", default="", help="工作台名字，如「小满的数学基地」。留空则用「<学科>·学习台」")
    ap.add_argument("--student", default="", help="学生名字，显示在页头。留空则不显示")
    ap.add_argument("--theme", default="", help="风格名：纸墨 / 小屋 / 花园。留空读 工作台设置.json")
    ap.add_argument("--accent", default="", help="直接指定主色，如 #7a5c3e。给了就盖过 --theme")
    a = ap.parse_args()
    # 关键：先展开 ~，再转绝对路径。
    # 反例：--root "~/Desktop/数学" 若直接 abspath，会在当前目录建一个字面名叫「~」的文件夹，
    # 导航页生成到错的地方，用户以为没生成。（本机家目录下已经有一个这样的 ~ 目录）
    root = os.path.abspath(os.path.expanduser(a.root))
    build(root, a.subject, title=a.title, student=a.student,
          theme=a.theme, accent=a.accent)
    if a.launcher:
        make_launcher(root, a.launcher)


if __name__ == "__main__":
    main()
