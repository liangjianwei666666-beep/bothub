#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
知识点查询工具（数学 · 人教版口径）

为什么要有它：
  知识库是一个 116 KB 的 JSON、519 个知识点。让助手「自己读一遍」有三个毛病：
  读不全、容易编错编号、追不动前置关系。
  这个工具把该查的事变成一条命令，助手不用把整个库读进上下文。

用法（在包目录或工作目录里跑）：

  查册                        列出所有册，以及每册几个单元、几个知识点
  查单元 五年级上              列出这一册的单元和知识点
  查点 SM-DIV-DEC             看一个知识点的详情（含前置链）
  查词 小数除法                按关键词找知识点（跨册）
  查前置 SM-DIV-APP           往上游追前置，追到底
  查错因 只把除数变整数         把一句具体错因归到 9 类里，并给对应动作
  查路 SM-DIV-DEC             给一个知识点，输出「前置 → 本点 → 后续」的整条路

  加 --json 输出 JSON，方便程序读；不加则输出给人看的中文。

设计原则：
  - 只读，不改库。
  - 找不到就明说找不到，不编。
  - 归错因时，置信度不高会明说「不确定，建议人工判」。
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# 9 类错因（英语口径，人设里的九类，不许换成数学那套）
CATEGORIES = ["单词不认识", "语法规则记混", "听不出连读弱读", "看漏关键词",
              "中文习惯直译", "拼写错", "时态选错", "句子结构搭不起来", "答非所问"]

ACTIONS = {
    "单词不认识": "把这个词放进本单元词卡，先听音跟读 3 遍，再放进句子说一遍",
    "语法规则记混": "只挑这一个规则，做「对/错」两句对比，说清差别再练 3 句",
    "听不出连读弱读": "把原句放慢听两遍，标出连读处，跟读到能和原速同步",
    "看漏关键词": "读题先圈疑问词和名词，再动笔写答案",
    "中文习惯直译": "先给英文原句，让他换个说法说同一件事，再对照差别",
    "拼写错": "按音节切块抄 3 遍，当天和隔天各默写一次",
    "时态选错": "先问「什么时候发生」，再定时态，最后补动词形式",
    "句子结构搭不起来": "用句子结构树摆主语+动词+其他，先摆卡片再开口",
    "答非所问": "先复述问题再答，答完回头对一遍问的是什么",
}

# 错因 → 9 类的关键词表。顺序有意义：先匹配到的优先。
#
# 库里的「常见错因」是具体错法描述（例如「答成 I'm fine」），
# 比分类标签更能直接教学生。这张表只做归类建议，归不进去就明说，不硬归。
RULES = [
    # 答非所问：问什么不答什么
    ("答非所问", ["答非所问", "答成", "答错", "回应指令", "问的是什么",
                  "用 yes 回应", "不理解问", "乱答"]),
    # 听力：连读、弱读、重音、语速
    ("听不出连读弱读", ["连读", "弱读", "听不清", "听成", "重音", "听不出",
                        "语速", "听力", "吞音"]),
    # 看漏关键词
    ("看漏关键词", ["看漏", "漏看", "忽略关键词", "没看到", "圈疑问词",
                    "看错要求", "只看到一半"]),
    # 拼写
    ("拼写错", ["拼写", "少写", "多写", "写反", "漏写字母", "大小写",
                "字母顺序", "拼不全", "写错字母"]),
    # 时态
    ("时态选错", ["时态", "过去式", "现在进行", "第三人称单数", "动词形式"]),
    # 中文习惯直译
    ("中文习惯直译", ["直译", "中文习惯", "中式", "按中文", "汉语顺序",
                      "说成 I am call", "说成 I very like", "说成 I want eat",
                      "说成 This is I"]),
    # 句子结构
    ("句子结构搭不起来", ["句子结构", "不成句", "只蹦单词", "语序", "漏 is",
                          "漏 my", "漏 a", "漏 some", "漏 old", "不成句子",
                          "单词堆在一起"]),
    # 语法规则记混
    ("语法规则记混", ["记混", "规则", "混淆", "混用", "互串", "混了",
                      "分不清", "用错形式", "三种问句"]),
    # 单词不认识：兜底
    ("单词不认识", ["不认识", "不知道意思", "生词", "词义", "没学过", "看不懂"]),
]


def load(path=None):
    """读知识库。优先用学生自己的，没有就用参考库。"""
    if path and os.path.exists(path):
        return json.load(open(path, encoding="utf-8")), path
    for name in ("年级知识库.json", "参考库_人教版.json"):
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            return json.load(open(p, encoding="utf-8")), p
    sys.exit("找不到知识库：工作目录里没有 年级知识库.json，也没有 参考库_人教版.json")


def books(db):
    # 只认真正带 units 的册次，跳过「说明」这类字符串字段
    return [k for k in db
            if not k.startswith("__")
            and isinstance(db.get(k), dict) and "units" in db[k]]


def iter_points(db):
    """遍历所有知识点，产出 (册, 单元, kp)。"""
    for b in books(db):
        for u in db[b]["units"]:
            for kp in u["kps"]:
                yield b, u["u"], kp


def index(db):
    idx = {}
    for b, u, kp in iter_points(db):
        idx[kp[0]] = {"book": b, "unit": u, "id": kp[0], "name": kp[1],
                      "errors": [x for x in kp[2].split("|") if x.strip()],
                      "pre": kp[3], "note": (kp[4] if len(kp) > 4 else "")}
    # 跨册通用点
    if "__cross" in db:
        for u in db["__cross"]["units"]:
            for kp in u["kps"]:
                idx.setdefault(kp[0], {"book": "跨册通用", "unit": u["u"], "id": kp[0],
                                       "name": kp[1],
                                       "errors": [x for x in kp[2].split("|") if x.strip()],
                                       "pre": kp[3], "note": (kp[4] if len(kp) > 4 else "")})
    return idx


def classify(err_text):
    """把一句具体错因归到 9 类。返回 (类别, 命中的关键词) 或 (None, None)。"""
    for cat, kws in RULES:
        for kw in kws:
            if kw in err_text:
                return cat, kw
    return None, None


# ---------- 各命令 ----------

def cmd_books(db, as_json):
    rows = []
    for b in books(db):
        n_units = len(db[b]["units"])
        n_kps = sum(len(u["kps"]) for u in db[b]["units"])
        rows.append({"book": b, "grade": db[b]["grade"], "term": db[b]["term"],
                     "units": n_units, "points": n_kps})
    if as_json:
        print(json.dumps(rows, ensure_ascii=False, indent=1))
        return
    print(f"共 {len(rows)} 册\n")
    for r in rows:
        print(f"  {r['book']:<8} {r['units']:>2} 单元  {r['points']:>3} 个知识点")


def cmd_units(db, book, as_json):
    if book not in db:
        print(f"没有「{book}」这一册。可用：{'、'.join(books(db))}")
        return
    units = db[book]["units"]
    if as_json:
        out = [{"unit": u["u"], "points": [{"id": k[0], "name": k[1],
                                            "errors": [x for x in k[2].split("|") if x.strip()]}
                                           for k in u["kps"]]} for u in units]
        print(json.dumps({"book": book, "units": out}, ensure_ascii=False, indent=1))
        return
    total = sum(len(u["kps"]) for u in units)
    print(f"{book} · {len(units)} 个单元 · {total} 个知识点\n")
    for u in units:
        print(f"【{u['u']}】{len(u['kps'])} 个")
        for k in u["kps"]:
            print(f"   {k[0]:<18} {k[1]}")


def cmd_point(idx, pid, as_json):
    p = idx.get(pid)
    if not p:
        print(f"没有编号「{pid}」这个知识点。")
        near = [k for k in idx if pid.lower() in k.lower()]
        if near:
            print("你是不是要找：" + "、".join(near[:8]))
        return
    if as_json:
        print(json.dumps(p, ensure_ascii=False, indent=1))
        return
    print(f"{p['name']}  [{p['id']}]")
    print(f"  在：{p['book']} · {p['unit']}")
    if p.get("note"):
        print(f"  具体要点：{p['note']}")
    print(f"  常见错因：")
    for e in p["errors"]:
        cat, kw = classify(e)
        tag = f"→ {cat}（命中「{kw}」）" if cat else "→ 未归类，需人工判"
        print(f"    · {e}  {tag}")
    if p["pre"]:
        print(f"  前置：")
        for x in p["pre"]:
            q = idx.get(x)
            print(f"    ← {q['name'] if q else x}  [{x}]" + (f"  （{q['book']}）" if q else "  ⚠ 库里没有"))
    else:
        print("  前置：无（这是起点）")


def cmd_search(idx, kw, as_json):
    hits = []
    for pid, p in idx.items():
        if kw in p["name"] or kw in p["unit"] or any(kw in e for e in p["errors"]):
            hits.append(p)
    if as_json:
        print(json.dumps(hits, ensure_ascii=False, indent=1))
        return
    if not hits:
        print(f"没找到含「{kw}」的知识点。")
        return
    print(f"找到 {len(hits)} 个含「{kw}」的知识点：\n")
    by_book = {}
    for p in hits:
        by_book.setdefault(p["book"], []).append(p)
    for b, ps in by_book.items():
        print(f"【{b}】")
        for p in ps:
            print(f"   {p['id']:<18} {p['name']}   （{p['unit']}）")
        print()


def cmd_pre(idx, pid, as_json):
    if pid not in idx:
        print(f"没有编号「{pid}」这个知识点。")
        return
    chain, seen, frontier = [], set(), [pid]
    depth = 0
    while frontier and depth < 12:
        nxt = []
        for x in frontier:
            for pre in idx[x]["pre"]:
                if pre in seen or pre == pid:
                    continue
                seen.add(pre)
                q = idx.get(pre)
                chain.append({"depth": depth + 1, "id": pre,
                              "name": q["name"] if q else "⚠库里没有",
                              "book": q["book"] if q else "?",
                              "from": x})
                nxt.append(pre)
        frontier = nxt
        depth += 1
    if as_json:
        print(json.dumps(chain, ensure_ascii=False, indent=1))
        return
    if not chain:
        print(f"{idx[pid]['name']} 没有前置，是起点。")
        return
    print(f"{idx[pid]['name']} 的前置链（越往下越基础）：\n")
    for c in chain:
        print(f"  {'  ' * (c['depth'] - 1)}← {c['name']}  [{c['id']}]  （{c['book']}）")


def cmd_error(text, as_json):
    cat, kw = classify(text)
    if as_json:
        print(json.dumps({"input": text, "suggest": cat,
                          "hit": kw, "action": ACTIONS.get(cat) if cat else None,
                          "confidence": "低，仅供参考" if cat else "无"},
                         ensure_ascii=False, indent=1))
        return
    print(f"错因原文：{text}\n")
    print("这一句本身就是「最小单位」的错因，直接用它教学生最准。")
    print("（例如「把>当<」比「概念没懂」有用得多——前者能直接练，后者不能。）\n")
    if cat:
        print(f"若要归到 9 类做报表：**建议 {cat}**（命中关键词「{kw}」，低置信度，仅供参考）")
        print(f"  对应动作：{ACTIONS[cat]}")
    else:
        print("自动归不进 9 类。**不要硬归**——按原话记下来，让老师判。")
    print(f"\n9 类对照（自己判的时候看这张）：")
    for c in CATEGORIES:
        print(f"  {c:<8} {ACTIONS[c]}")
    print("\n判断口诀：先问「他是没听懂问什么、没听懂音、还是没用对句子」，再问「这是新词还是旧词」。")


def cmd_match(idx, pid, said, as_json):
    """把学生的原话，对到一个知识点已列出的具体错法上。"""
    p = idx.get(pid)
    if not p:
        print(f"没有编号「{pid}」这个知识点。")
        return
    best, score = None, 0
    for e in p["errors"]:
        s = len(set(said) & set(e)) / max(len(e), 1)
        if s > score:
            best, score = e, s
    if as_json:
        print(json.dumps({"point": p["name"], "said": said,
                          "best_match": best, "score": round(score, 3),
                          "all_listed": p["errors"]}, ensure_ascii=False, indent=1))
        return
    print(f"{p['name']}  [{p['id']}]")
    print(f"  学生说／你观察到：{said}")
    print(f"  库里这一点的错法：")
    for e in p["errors"]:
        mark = "  ← 最接近" if e == best else ""
        print(f"    · {e}{mark}")
    if score < 0.34:
        print(f"\n  ⚠ 都对不太上（最接近「{best}」只对上 {score:.0%}）。")
        print("    这说明可能是另一种错法，或者卡点在**前置**上，先跑：查前置 " + pid)
    else:
        print(f"\n  最接近：「{best}」（对上 {score:.0%}）")
        cat, _ = classify(best)
        if cat:
            print(f"  归到：{cat}（低置信度）→ {ACTIONS[cat]}")


def cmd_path(idx, pid, as_json):
    if pid not in idx:
        print(f"没有编号「{pid}」这个知识点。")
        return
    # 上游
    up, seen, frontier, depth = [], {pid}, [pid], 0
    while frontier and depth < 12:
        nxt = []
        for x in frontier:
            for pre in idx[x]["pre"]:
                if pre in seen:
                    continue
                seen.add(pre)
                q = idx.get(pre)
                up.append((depth + 1, q["name"] if q else pre, pre,
                           q["book"] if q else "?"))
                nxt.append(pre)
        frontier = nxt
        depth += 1
    # 下游
    down = [(pid2, p["name"], p["book"]) for pid2, p in idx.items()
            if pid in p["pre"]]
    if as_json:
        print(json.dumps({"point": idx[pid], "upstream": up, "downstream": down},
                         ensure_ascii=False, indent=1))
        return
    p = idx[pid]
    print(f"{p['name']}  [{p['id']}]  （{p['book']} · {p['unit']}）\n")
    print("往下追（前置，越往下越基础）：")
    if not up:
        print("  无，这是起点")
    for d, name, i, b in sorted(up, key=lambda x: -x[0]):
        print(f"  {'  ' * (d - 1)}← {name}  [{i}]  （{b}）")
    print("\n往上走（学完这个才能学）：")
    if not down:
        print("  无，这是末端")
    for i, name, b in down:
        print(f"  → {name}  [{i}]  （{b}）")


def main():
    args = [a for a in sys.argv[1:] if a != "--json"]
    as_json = "--json" in sys.argv[1:]
    if not args:
        print(__doc__)
        return

    db, path = load()
    idx = index(db)
    cmd, rest = args[0], args[1:]

    if cmd == "查册":
        cmd_books(db, as_json)
    elif cmd == "查单元":
        if not rest:
            sys.exit("用法：查单元 五年级上")
        cmd_units(db, rest[0], as_json)
    elif cmd == "查点":
        if not rest:
            sys.exit("用法：查点 SM-DIV-DEC")
        cmd_point(idx, rest[0], as_json)
    elif cmd == "查词":
        if not rest:
            sys.exit("用法：查词 小数除法")
        cmd_search(idx, rest[0], as_json)
    elif cmd == "查前置":
        if not rest:
            sys.exit("用法：查前置 SM-DIV-APP")
        cmd_pre(idx, rest[0], as_json)
    elif cmd == "查错因":
        if not rest:
            sys.exit("用法：查错因 只把除数变整数")
        cmd_error(rest[0], as_json)
    elif cmd == "对错":
        if len(rest) < 2:
            sys.exit("用法：对错 SM-DIV-DEC 学生把除数变成整数被除数没变")
        cmd_match(idx, rest[0], rest[1], as_json)
    elif cmd == "查路":
        if not rest:
            sys.exit("用法：查路 SM-DIV-DEC")
        cmd_path(idx, rest[0], as_json)
    else:
        print(f"不认识的命令「{cmd}」")
        print(__doc__)


if __name__ == "__main__":
    main()
