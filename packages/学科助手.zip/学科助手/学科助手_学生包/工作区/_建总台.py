#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一学习台生成器 —— 语文 / 数学 / 英语合成一个入口。

设计原则：一次只看一个学科；每个学科四个大图标块；数字和状态代替说明文字。
支持三套皮肤（纯 CSS，无外链图）：
    纸墨  —— 默认，暖纸底极简
    小屋  —— 木色底、屋顶、窗格，四个板块叫「房间」
    花园  —— 草色底、花坛边，四个板块叫「花坛」
皮肤存在 工作台设置.json 的「风格」里；也可以临时指定：
    python3 _建总台.py --theme 小屋
    python3 _建总台.py --preview "_主题预览.html"     # 出对比预览页

层级固定四层：
    L1 学习台（本页 index.html）
    L2 学科（01-语文 / 02-数学 / 03-英语）
    L3 板块（01-知识点可视化 … 04-错题卡）
    L4 产出文件

用法：python3 "<工作目录>/_建总台.py"
它会先跑三科各自的 _更新导航.py（刷新学科页），再重建根 index.html。
离线可开，不联网；本模板只有四个板块，要加板块就在 MODULES 里加一条。
"""

import argparse
import html
import json
import os
import subprocess
import sys
import time
from urllib.parse import quote

ROOT = os.path.dirname(os.path.abspath(__file__))

SUBJECTS = [
    dict(folder="01-语文", name="语文", accent="#B05B4F", tint="#FAF0ED"),
    dict(folder="02-数学", name="数学", accent="#3F6B58", tint="#EEF4F0"),
    dict(folder="03-英语", name="英语", accent="#40597F", tint="#EEF2F8"),
]

MODULES = [
    dict(folder="01-知识点可视化", name="知识点可视化", icon="nodes"),
    dict(folder="02-游戏练习", name="游戏练习", icon="play"),
    dict(folder="03-阶段测试与报告", name="阶段测试与报告", icon="sheet"),
    dict(folder="04-错题卡", name="错题卡", icon="card"),
]

SKIP_FILES = {"index.html", ".DS_Store", "错题本.json", "错题本.json.tmp"}
SKIP_DIRS = {"__pycache__", ".git", "照片", ".gstack", ".工作台素材", ".检查"}

ICONS = {
    "nodes": '<circle cx="6.2" cy="6" r="2.3"/><circle cx="17.8" cy="6" r="2.3"/>'
             '<circle cx="12" cy="18" r="2.3"/><path d="M8.2 7.6l2.4 8.2M15.8 7.6l-2.4 8.2M8.5 6h7"/>',
    "play": '<rect x="3.6" y="5" width="16.8" height="14" rx="4.2"/>'
            '<path d="M10.6 9.6l4.4 2.9-4.4 2.9z" fill="currentColor" stroke="none"/>',
    "sheet": '<rect x="5" y="3.6" width="14" height="16.8" rx="2.6"/>'
             '<path d="M9 9h6M9 12.6h6M9 16.2h3.4"/>',
    "card": '<path d="M6.6 4.4h10.8a1.6 1.6 0 011.6 1.6v13.6l-7-4.2-7 4.2V6a1.6 1.6 0 011.6-1.6z"/>',
}

# 三套皮肤：文案跟着空间隐喻换，结构不动
THEMES = {
    "纸墨": dict(cls="", unit="份作品", board="板块",
                 blank="这一格还空着", empty="还没有作品",
                 tab_hint="4 个板块"),
    "小屋": dict(cls="t-house", unit="件作品", board="房间",
                 blank="这个房间还空着", empty="还没有作品，先把房间布置起来",
                 tab_hint="4 个房间"),
    "花园": dict(cls="t-garden", unit="份作品", board="花坛",
                 blank="这个花坛还没种东西", empty="还没有作品，先种下一棵",
                 tab_hint="4 个花坛"),
}


def read_settings():
    p = os.path.join(ROOT, "工作台设置.json")
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def esc(s):
    return html.escape(str(s), quote=True)


def read_style():
    """工作台设置.json 里写的风格名，原样返回（可能是自定义主题名）。"""
    p = os.path.join(ROOT, "工作台设置.json")
    if not os.path.isfile(p):
        return ""
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return str((d or {}).get("风格", "")).strip()
    except (OSError, ValueError):
        return ""


def read_custom_css():
    """学生自己设计的主题：工作目录里放一个 自定义主题.css 就生效。"""
    p = os.path.join(ROOT, "自定义主题.css")
    if not os.path.isfile(p):
        return ""
    try:
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def scan(subject_folder, module_folder):
    d = os.path.join(ROOT, subject_folder, module_folder)
    out = []
    if not os.path.isdir(d):
        return out
    for name in sorted(os.listdir(d)):
        if name in SKIP_FILES or name in SKIP_DIRS:
            continue
        p = os.path.join(d, name)
        if not os.path.isfile(p):
            continue
        st = os.stat(p)
        out.append(dict(name=name,
                        rel="%s/%s/%s" % (subject_folder, module_folder, name),
                        mtime=st.st_mtime, size=st.st_size))
    out.sort(key=lambda f: f["mtime"], reverse=True)
    return out


def fmt_date(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def build_data():
    data = []
    for s in SUBJECTS:
        mods = []
        for m in MODULES:
            files = scan(s["folder"], m["folder"])
            mods.append(dict(m, files=files))
        data.append(dict(s, mods=mods, total=sum(len(m["files"]) for m in mods)))
    return data


def refresh_subject_pages():
    for s in SUBJECTS:
        script = os.path.join(ROOT, s["folder"], "_更新导航.py")
        if not os.path.isfile(script):
            continue
        r = subprocess.run([sys.executable, script], cwd=os.path.join(ROOT, s["folder"]),
                           stdout=subprocess.DEVNULL)
        if r.returncode != 0:
            print("警告：%s 的学科页没刷新成功，总台继续生成。" % s["name"])


CSS = r"""
:root{
  --paper:#F6F3ED; --ink:#221F1A; --ink-2:#716B60; --line:rgba(34,31,26,.10);
  --card:#FFFFFF; --accent:#B05B4F; --tint:#FAF0ED; --radius:20px;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{background:var(--paper);color:var(--ink);line-height:1.5;
  font-family:"PingFang SC","Hiragino Sans GB",system-ui,-apple-system,"Microsoft YaHei",sans-serif;
  -webkit-font-smoothing:antialiased;padding:0 0 64px}
button{font:inherit;color:inherit}
a{color:inherit;text-decoration:none}

/* 顶栏 */
.bar{max-width:1180px;margin:0 auto;padding:22px 32px 0;display:flex;align-items:center;gap:18px}
.brand{display:flex;align-items:center;gap:9px;font-size:14px;letter-spacing:.14em;color:var(--ink-2)}
.brand i{width:8px;height:8px;border-radius:50%;background:var(--accent);display:block}
.bar-right{margin-left:auto;display:flex;align-items:center;gap:14px}
.search{display:flex;align-items:center;gap:8px;height:38px;padding:0 14px;border-radius:999px;
  background:#fff;border:1px solid var(--line);transition:box-shadow .2s ease,border-color .2s ease}
.search:focus-within{border-color:rgba(34,31,26,.22);box-shadow:0 6px 20px rgba(40,32,18,.06)}
.search svg{width:15px;height:15px;color:var(--ink-2);flex:none}
.search input{border:0;outline:0;background:transparent;width:130px;font-size:13.5px;color:var(--ink)}
.search input::placeholder{color:#A9A296}
.manual-link{font-size:13.5px;color:var(--ink-2);padding:9px 2px;border-bottom:1px solid transparent}
.manual-link:hover{color:var(--ink);border-bottom-color:var(--line)}

main{max-width:1180px;margin:0 auto;padding:34px 32px 0}

/* 学科切换 */
.tabs{display:inline-flex;padding:5px;border-radius:999px;background:#ECE6DA;gap:4px;margin-bottom:44px}
.tab{border:0;background:transparent;cursor:pointer;padding:10px 26px;border-radius:999px;
  font-size:15px;font-weight:600;letter-spacing:.06em;color:#7A7367;
  transition:background .22s ease,color .22s ease,box-shadow .22s ease}
.tab:hover{color:var(--ink)}
.tab.is-on{background:#fff;color:var(--ink);box-shadow:0 2px 10px rgba(40,32,18,.09)}
.tab.is-on::before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;
  background:var(--c);margin-right:9px;vertical-align:1px}

/* 学科舞台 */
.stage{display:none}
.stage.is-on{display:block;animation:rise .28s ease both}
@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.stage-head{display:flex;align-items:flex-end;gap:20px;flex-wrap:wrap;margin-bottom:30px}
.stage-head h1{font-family:"Songti SC","STSong","SimSun",serif;font-size:46px;font-weight:600;
  letter-spacing:.02em;margin:0;line-height:1.1}
.stage-head .sum{color:var(--ink-2);font-size:14px;padding-bottom:6px}
.stage-head .sum b{color:var(--ink);font-weight:600;font-variant-numeric:tabular-nums}
.stage-head .hit{margin-left:auto;color:var(--accent);font-size:13px}

/* 四个板块 */
.tiles{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}
.tile{position:relative;display:flex;flex-direction:column;align-items:flex-start;
  min-height:190px;padding:22px;border:1px solid var(--line);border-radius:var(--radius);
  background:var(--card);cursor:pointer;text-align:left;
  transition:transform .22s ease,box-shadow .22s ease,border-color .22s ease}
.tile:hover{transform:translateY(-3px);box-shadow:0 16px 34px rgba(45,35,18,.09);border-color:rgba(34,31,26,.16)}
.tile .ico{display:flex;align-items:center;justify-content:center;width:44px;height:44px;
  border-radius:14px;background:var(--tint);color:var(--accent);margin-bottom:auto;position:relative}
.tile .ico svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.6;
  stroke-linecap:round;stroke-linejoin:round}
.tile .name{font-size:18px;font-weight:600;letter-spacing:.02em;margin:20px 0 4px}
.tile .num{font-size:13.5px;color:var(--ink-2);font-variant-numeric:tabular-nums}
.tile .num b{font-size:15px;color:var(--ink);font-weight:600}
.tile .go{position:absolute;right:20px;bottom:20px;width:30px;height:30px;border-radius:50%;
  border:1px solid var(--line);display:flex;align-items:center;justify-content:center;
  color:var(--ink-2);opacity:0;transform:translateX(-4px);transition:.22s ease}
.tile:hover .go{opacity:1;transform:none}
.tile .go svg{width:13px;height:13px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.tile[hidden]{display:none}

/* 产出面板 */
.panel{display:none}
.stage.is-open .tiles,.stage.is-open .stage-head .sum{display:none}
.stage.is-open .panel.is-on{display:block;animation:rise .24s ease both}
.panel-head{display:flex;align-items:center;gap:16px;margin:0 0 22px}
.back{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);background:#fff;
  border-radius:999px;padding:9px 16px;font-size:13.5px;color:var(--ink-2);cursor:pointer;
  transition:.2s ease}
.back:hover{color:var(--ink);border-color:rgba(34,31,26,.2)}
.back svg{width:13px;height:13px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.panel-head h2{font-size:24px;margin:0;font-weight:600;letter-spacing:.02em}
.panel-head .cnt{margin-left:auto;font-size:13.5px;color:var(--ink-2)}
.files{list-style:none;margin:0;padding:0;border-top:1px solid var(--line)}
.files li{border-bottom:1px solid var(--line)}
.files a{display:flex;align-items:center;gap:16px;padding:17px 6px;transition:padding .18s ease,background .18s ease}
.files a:hover{padding-left:14px;background:rgba(255,255,255,.65)}
.files .fn{flex:1;min-width:0;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.files .dt{font-size:12.5px;color:var(--ink-2);font-variant-numeric:tabular-nums;white-space:nowrap}
.files .ext{font-size:11.5px;letter-spacing:.1em;color:var(--ink-2);border:1px solid var(--line);
  border-radius:5px;padding:2px 6px;white-space:nowrap}
.blank{padding:54px 6px;text-align:center;color:#9A9386;font-size:14px}

/* 空状态 */
.empty{display:none;margin-top:38px;align-items:center;gap:16px;flex-wrap:wrap;
  border-top:1px solid var(--line);padding-top:22px;color:var(--ink-2);font-size:14px}
.stage.is-empty .empty{display:flex}
.stage.is-open .empty{display:none!important}
.empty .dot3{display:flex;gap:5px}
.empty .dot3 i{width:6px;height:6px;border-radius:50%;background:#D8D1C2}
.empty a{margin-left:auto;color:var(--accent);font-weight:600;white-space:nowrap;
  border-bottom:1px solid rgba(176,91,79,.28);padding-bottom:1px}
.empty a:hover{border-bottom-color:var(--accent)}

.collect{position:fixed;right:26px;bottom:26px;z-index:20;display:none;align-items:center;gap:10px;
  background:var(--ink);color:#fff;border:0;border-radius:999px;padding:13px 20px;font-size:14px;
  box-shadow:0 18px 40px -16px rgba(20,25,22,.6);cursor:pointer;transition:transform .2s ease,background .2s ease}
.collect.on{display:inline-flex}
.collect:hover{transform:translateY(-2px);background:#000}
.collect b{background:rgba(255,255,255,.18);border-radius:999px;padding:1px 9px;font-size:13px;font-weight:600}
.collect-toast{position:fixed;right:26px;bottom:82px;z-index:20;background:var(--ink);color:#fff;
  font-size:13px;padding:10px 16px;border-radius:10px;opacity:0;transform:translateY(6px);
  transition:.22s ease;pointer-events:none;max-width:280px;line-height:1.6}
.collect-toast.on{opacity:1;transform:none}
@media(max-width:640px){.collect{right:16px;bottom:16px;padding:11px 16px;font-size:13px}}

footer{max-width:1180px;margin:64px auto 0;padding:0 32px;color:#A49D8F;font-size:12px;letter-spacing:.02em}

@media (max-width:1040px){.tiles{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:640px){
  .bar{padding:16px 18px 0}
  .brand{font-size:13px}
  .search{display:none}
  .manual-link{font-size:13px;color:var(--ink)}
  main{padding:22px 18px 0}
  .tabs{width:100%;justify-content:space-between;margin-bottom:30px}
  .tab{flex:1;padding:9px 0;text-align:center}
  .stage-head h1{font-size:34px}
  .tiles{gap:12px}
  .tile{min-height:150px;padding:16px;border-radius:16px}
  .tile .name{font-size:15.5px;margin-top:14px}
  .tile .go{display:none}
  .files .ext{display:none}
  footer{margin-top:44px;padding:0 18px}
}
@media (prefers-reduced-motion:reduce){
  *{animation:none!important;transition:none!important}
}
"""

# 两套空间皮肤：只叠在基础样式上，不动布局和结构
THEME_CSS = r"""
/* ---------- 小屋 ---------- */
body.t-house{background:linear-gradient(180deg,#FAF2E6 0%,#F0E3D1 60%,#EADBC6 100%)}
.t-house .brand i{background:#8B5E3C}
.t-house .tabs{background:#E7D7BF}
.t-house .tab{color:#7D6448}
.t-house .tab.is-on{box-shadow:0 2px 10px rgba(90,60,30,.14)}
.t-house .stage-head h1{color:#4A3524}
.t-house .stage-head .sum{color:#8A7358}
.t-house .stage-head .sum b{color:#4A3524}
.t-house .tiles{row-gap:26px;margin-top:16px}
.t-house .tile{background:linear-gradient(180deg,#FFFDF7 0%,#FBF3E5 100%);
  border-color:#E4D2B7;padding-top:26px}
.t-house .tile::before{content:"";position:absolute;top:-14px;left:8px;right:8px;height:18px;
  background:linear-gradient(180deg,#C98A5C,#B3744A);
  clip-path:polygon(0 100%,50% 0,100% 100%)}
.t-house .tile:hover{border-color:#D8C0A0;box-shadow:0 18px 36px rgba(96,62,32,.13)}
.t-house .tile .ico{background:#F5E6CE;border:1px solid #E2CDA9;color:#8B5E3C}
.t-house .tile .ico::before,.t-house .tile .ico::after{content:"";position:absolute;background:#D3B183;opacity:.75}
.t-house .tile .ico::before{width:1px;top:7px;bottom:7px;left:50%}
.t-house .tile .ico::after{height:1px;left:7px;right:7px;top:50%}
.t-house .tile .name{color:#4A3524}
.t-house .tile .go{border-color:#DCC9AC;color:#8B5E3C}
.t-house .back{background:#FFFDF7;border-color:#E4D2B7}
.t-house .files a:hover{background:rgba(255,253,247,.8)}
.t-house footer{color:#A28B6E}

/* ---------- 花园 ---------- */
body.t-garden{background:linear-gradient(180deg,#F5F9EF 0%,#E9F1DE 60%,#E2ECD4 100%)}
.t-garden .brand i{background:#5C8A5A}
.t-garden .tabs{background:#DDE8D2}
.t-garden .tab{color:#5F735A}
.t-garden .tab.is-on{box-shadow:0 2px 10px rgba(60,90,50,.14)}
.t-garden .stage-head h1{color:#2F4A34}
.t-garden .stage-head .sum{color:#6E8467}
.t-garden .stage-head .sum b{color:#2F4A34}
.t-garden .tile{background:#FFFEF8;border-color:#D9E3CC;padding-bottom:34px;
  border-radius:26px 26px 20px 20px}
.t-garden .tile::after{content:"";position:absolute;left:-1px;right:-1px;bottom:-1px;height:16px;
  border-radius:0 0 20px 20px;
  background:linear-gradient(180deg,#D8C09A 0%,#C4A878 100%);
  border:1px solid #D0BB97;border-top:0}
.t-garden .tile:hover{border-color:#C9D8B8;box-shadow:0 18px 36px rgba(58,86,48,.12)}
.t-garden .tile .ico{background:#EDF4E4;border:1px solid #D7E4C8;color:#4E7A4E;
  border-radius:50% 50% 15px 15px}
.t-garden .tile .name{color:#2F4A34}
.t-garden .tile .go{border-color:#D2DFC4;color:#4E7A4E;bottom:26px}
.t-garden .back{background:#FFFEF8;border-color:#D9E3CC}
.t-garden .files a:hover{background:rgba(255,254,248,.85)}
.t-garden footer{color:#7C8F73}

/* ---------- 预览切换条 ---------- */
.preview-bar{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:9;
  display:flex;align-items:center;gap:6px;padding:6px;border-radius:999px;
  background:rgba(255,255,255,.94);border:1px solid rgba(34,31,26,.12);
  box-shadow:0 10px 30px rgba(40,32,18,.14);backdrop-filter:blur(6px)}
.preview-bar span{font-size:12px;color:#8E877A;padding:0 8px;letter-spacing:.06em}
.preview-bar button{border:0;background:transparent;border-radius:999px;padding:7px 14px;
  font-size:13px;color:#5F5A50;cursor:pointer}
.preview-bar button.on{background:#221F1A;color:#fff}
@media (max-width:640px){.preview-bar{bottom:12px}.preview-bar span{display:none}}
"""


def tile_html(m, n, L):
    return """<button class="tile" type="button" data-open="%s" aria-label="%s，%d %s">
  <span class="ico"><svg viewBox="0 0 24 24" aria-hidden="true">%s</svg></span>
  <span class="name">%s</span>
  <span class="num"><b>%d</b> %s</span>
  <span class="go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></span>
</button>""" % (esc(m["folder"]), esc(m["name"]), n, L["unit"], ICONS[m["icon"]],
                 esc(m["name"]), n, L["unit"])


def panel_html(m, L):
    files = m["files"]
    if files:
        rows = "\n".join(
            '<li><a href="%s"><span class="fn">%s</span><span class="dt">%s</span>'
            '<span class="ext">%s</span></a></li>'
            % (quote(f["rel"], safe="/"), esc(f["name"]), fmt_date(f["mtime"]),
               esc(f["name"].rsplit(".", 1)[-1].upper() if "." in f["name"] else "FILE"))
            for f in files)
        body = '<ul class="files">%s</ul>' % rows
    else:
        body = '<div class="blank">%s</div>' % esc(L["blank"])
    return """<div class="panel" data-panel="%s">
  <div class="panel-head">
    <button class="back" type="button"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>返回</button>
    <h2>%s</h2><span class="cnt">%d %s</span>
  </div>
  %s
</div>""" % (esc(m["folder"]), esc(m["name"]), len(files), L["unit"], body)


def stage_html(s, idx, L):
    tiles = "\n".join(tile_html(m, len(m["files"]), L) for m in s["mods"])
    panels = "\n".join(panel_html(m, L) for m in s["mods"])
    empty_cls = " is-empty" if s["total"] == 0 else ""
    on_cls = " is-on" if idx == 0 else ""
    return """<section class="stage%s%s" data-stage="%d" data-name="%s" style="--accent:%s;--tint:%s">
  <div class="stage-head">
    <h1>%s</h1>
    <div class="sum"><b>%d</b> %s · %s</div>
    <div class="hit" data-hit></div>
  </div>
  <div class="tiles">
%s
  </div>
%s
  <div class="empty">
    <span class="dot3" aria-hidden="true"><i></i><i></i><i></i></span>
    <span>%s</span>
    <a href="魔法咒语.html">打开魔法咒语开始 →</a>
  </div>
</section>""" % (empty_cls, on_cls, idx, esc(s["name"]), s["accent"], s["tint"],
                 esc(s["name"]), s["total"], L["unit"], L["tab_hint"],
                 tiles, panels, esc(L["empty"]))


PREVIEW_BAR = """<div class="preview-bar" role="group" aria-label="主题预览">
  <span>主题预览</span>
  <button type="button" data-theme="">纸墨</button>
  <button type="button" data-theme="t-house">小屋</button>
  <button type="button" data-theme="t-garden">花园</button>
</div>
<script>
(function(){
  var bar = document.querySelector('.preview-bar');
  if (!bar) return;
  var btns = [].slice.call(bar.querySelectorAll('button'));
  function set(name){
    document.body.className = name || '';
    btns.forEach(function(b){ b.classList.toggle('on', b.getAttribute('data-theme') === (name || '')); });
  }
  btns.forEach(function(b){ b.addEventListener('click', function(){ set(b.getAttribute('data-theme')); }); });
  set('t-house');
})();
</script>
"""


def build(theme="纸墨", preview=False, custom_css=""):
    L = THEMES.get(theme, THEMES["纸墨"])
    data = build_data()
    total_files = sum(s["total"] for s in data)

    tabs = "\n".join(
        '<button class="tab%s" type="button" data-tab="%d" style="--c:%s">%s</button>'
        % (" is-on" if i == 0 else "", i, s["accent"], esc(s["name"]))
        for i, s in enumerate(data))
    stages = "\n".join(stage_html(s, i, L) for i, s in enumerate(data))

    body = """<header class="bar">
  <span class="brand"><i></i>__NAME__</span>
  <div class="bar-right">
    <label class="search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M16 16l4 4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
      <input id="q" type="search" placeholder="搜作品" aria-label="搜索作品" autocomplete="off"></label>
    <a class="manual-link" href="魔法咒语.html">魔法咒语</a>
    __ADV_LINK__
  </div>
</header>

<main>
  <nav class="tabs" role="tablist" aria-label="学科">__TABS__</nav>
  __STAGES__
</main>

<footer>共 <b>__TOTAL__</b> __UNIT__</footer>
<button class="collect" id="collect" type="button">收错题 <b id="collectN">0</b></button>
<div class="collect-toast" id="collectToast"></div>
__PREVIEW__
<script>
(function(){
  var tabs = [].slice.call(document.querySelectorAll('.tab'));
  var stages = [].slice.call(document.querySelectorAll('.stage'));
  var q = document.getElementById('q');

  function show(i){
    tabs.forEach(function(t, k){
      t.classList.toggle('is-on', k === i);
      t.setAttribute('aria-selected', k === i ? 'true' : 'false');
    });
    stages.forEach(function(s, k){ s.classList.toggle('is-on', k === i); });
  }
  tabs.forEach(function(t, i){ t.addEventListener('click', function(){ show(i); }); });

  stages.forEach(function(stage){
    var tiles = [].slice.call(stage.querySelectorAll('.tile'));
    var panels = [].slice.call(stage.querySelectorAll('.panel'));
    tiles.forEach(function(tile){
      tile.addEventListener('click', function(){
        var key = tile.getAttribute('data-open');
        stage.classList.add('is-open');
        panels.forEach(function(p){ p.classList.toggle('is-on', p.getAttribute('data-panel') === key); });
        var back = stage.querySelector('.panel.is-on .back');
        if (back) back.focus({preventScroll:true});
      });
    });
    [].slice.call(stage.querySelectorAll('.back')).forEach(function(btn){
      btn.addEventListener('click', function(){
        stage.classList.remove('is-open');
        panels.forEach(function(p){ p.classList.remove('is-on'); });
        if (q.value.trim()) apply();
      });
    });
  });

  function apply(){
    var key = (q.value || '').trim().toLowerCase();
    var firstHit = -1;
    stages.forEach(function(stage, si){
      var tiles = [].slice.call(stage.querySelectorAll('.tile'));
      var panels = [].slice.call(stage.querySelectorAll('.panel'));
      var hitBox = stage.querySelector('[data-hit]');
      if (!key) {
        tiles.forEach(function(t){ t.hidden = false; });
        panels.forEach(function(p){
          p.classList.remove('is-on');
          [].slice.call(p.querySelectorAll('.files li')).forEach(function(li){ li.hidden = false; });
        });
        stage.classList.remove('is-open');
        hitBox.textContent = '';
        return;
      }
      var subjectHit = (stage.getAttribute('data-name') || '').toLowerCase().indexOf(key) > -1;
      var matchTiles = 0;
      tiles.forEach(function(t, k){
        var panel = panels[k];
        var label = (t.textContent || '').toLowerCase();
        var rows = [].slice.call(panel.querySelectorAll('.files li'));
        var rowHit = 0;
        rows.forEach(function(li){
          var ok = (li.textContent || '').toLowerCase().indexOf(key) > -1;
          li.hidden = !ok; if (ok) rowHit++;
        });
        var ok = subjectHit || label.indexOf(key) > -1 || rowHit > 0;
        t.hidden = !ok;
        if (ok) { matchTiles++; panel.classList.add('is-on'); }
        else { panel.classList.remove('is-on'); }
      });
      stage.classList.toggle('is-open', matchTiles > 0);
      hitBox.textContent = matchTiles ? (matchTiles + ' 个板块') : '没有匹配';
      if (matchTiles > 0 && firstHit < 0) firstHit = si;
    });
    if (key && firstHit > -1) show(firstHit);
  }
  if (q) q.addEventListener('input', apply);
})();

(function(){
  var KEY = 'xk_wrong_pending';
  var btn = document.getElementById('collect');
  var num = document.getElementById('collectN');
  var toast = document.getElementById('collectToast');
  var items = [];
  try { items = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch(e) { items = []; }
  if (!btn || !items.length) return;
  num.textContent = items.length;
  btn.classList.add('on');
  function say(msg){
    toast.textContent = msg; toast.classList.add('on');
    clearTimeout(say.t); say.t = setTimeout(function(){ toast.classList.remove('on'); }, 3200);
  }
  btn.addEventListener('click', function(){
    var d = new Date(), p = function(n){ return ('0' + n).slice(-2); };
    var name = '错题导入-' + d.getFullYear() + p(d.getMonth()+1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + '.json';
    var blob = new Blob([JSON.stringify({cards: items}, null, 1)], {type: 'application/json'});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function(){ URL.revokeObjectURL(a.href); }, 4000);
    localStorage.setItem('xk_wrong_collected', name);
    say('已准备好 ' + items.length + ' 道错题，对学科助手说一句「导入错题」就会自动收进错题卡。');
  });
})();
</script>"""

    adv = ('<a class="manual-link" href="进阶咒语.html">进阶咒语</a>'
           if os.path.isfile(os.path.join(ROOT, "进阶咒语.html")) else "")
    cfg = read_settings()
    name = str(cfg.get("名字") or "学科助手")
    body = (body.replace("__NAME__", esc(name))
                .replace("__ADV_LINK__", adv)
                .replace("__TABS__", tabs)
                .replace("__STAGES__", stages)
                .replace("__TOTAL__", str(total_files))
                .replace("__UNIT__", L["unit"])
                .replace("__PREVIEW__", PREVIEW_BAR if preview else ""))

    body_cls = ' class="%s"' % L["cls"] if L["cls"] else ""
    if custom_css:
        body_cls = ' class="t-custom"'
    extra_style = "<style>%s</style>" % custom_css if custom_css else ""
    page = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__NAME__ · 学习台</title>
<style>%s</style>
<style>%s</style>
__EXTRA_STYLE__
</head>
<body%s>
%s
</body>
</html>
""" % (CSS, THEME_CSS, body_cls, body)
    page = page.replace("__EXTRA_STYLE__", extra_style)
    return page.replace("__NAME__", esc(name))


def main():
    ap = argparse.ArgumentParser(description="生成学习台")
    ap.add_argument("--theme", default="", help="纸墨 / 小屋 / 花园；不给就读 工作台设置.json")
    ap.add_argument("--out", default="", help="输出文件名，默认 index.html")
    ap.add_argument("--css", default="", help="直接指定一份自定义主题 css（用于出示例）")
    ap.add_argument("--preview", nargs="?", const="_主题预览.html", default="",
                    help="输出对比预览页（带主题切换条）")
    ap.add_argument("--no-refresh", action="store_true", help="不刷新学科页")
    args = ap.parse_args()

    if not args.no_refresh and not args.preview:
        refresh_subject_pages()

    if args.preview:
        page = build(theme="小屋", preview=True)
        out = os.path.join(ROOT, args.preview)
    else:
        what = args.theme or read_style()
        if args.css:
            css_path = args.css if os.path.isabs(args.css) else os.path.join(ROOT, args.css)
            custom = open(css_path, encoding="utf-8").read().strip() if os.path.isfile(css_path) else ""
            theme = what or "自定义"
            page = build(theme=theme if theme in THEMES else "纸墨", custom_css=custom)
            out = os.path.join(ROOT, args.out or "index.html")
            with open(out, "w", encoding="utf-8") as f:
                f.write(page)
            print("学习台已生成：", out, "（主题：%s）" % theme)
            print("三科 · 四板块 · 产出 %d 份" % sum(s["total"] for s in build_data()))
            return
        custom = read_custom_css()
        if what in THEMES:
            theme, custom = what, ""
        elif custom:
            theme = what or "自定义"
        else:
            theme = "纸墨"
        page = build(theme=theme if theme in THEMES else "纸墨", custom_css=custom)
        out = os.path.join(ROOT, args.out or "index.html")

    with open(out, "w", encoding="utf-8") as f:
        f.write(page)
    data = build_data()
    total = sum(s["total"] for s in data)
    print("学习台已生成：", out, "（主题：%s）" % ("对比预览" if args.preview else theme))
    print("三科 · 四板块 · 产出 %d 份" % total)


if __name__ == "__main__":
    main()
