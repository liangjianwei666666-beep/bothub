#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""刷新工作台（只重写 index.html，不动你的产出）。

用法：python3 _更新导航.py

会读同目录的 工作台设置.json（学生自己定的名字/风格/学生名），
有就带上，没有就用默认。学生换过风格之后，靠这个文件保持住——
否则每刷新一次就变回默认，他会以为坏了。
"""
import json, os, subprocess, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SETTINGS = os.path.join(ROOT, "工作台设置.json")

# 学科名：默认取文件夹名（工作目录就叫「数学」「英语」），设置文件里写了「学科」就以设置为准。
# 写死成 "数学" 是个真 bug——英语包直接拷这份脚本，生成的页头会写「数学」。
SUBJECT = os.path.basename(ROOT) or "学科"
SUBJECT = __import__("re").sub(r"^\d+-", "", SUBJECT)


def load_settings():
    if not os.path.isfile(SETTINGS):
        return {}
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        # 设置文件写坏了不能拦住刷新——工作台能开比名字对不对重要
        print("（工作台设置.json 读不出来，这次用默认样式。让学生再说一次名字和风格就好）")
        return {}


def main():
    script = os.path.join(ROOT, "建站.py")
    if not os.path.exists(script):
        sys.exit("找不到 建站.py，工作台没法刷新。把它放回这个文件夹再试。")

    cfg = load_settings()
    subject = str(cfg.get("学科") or SUBJECT)
    cmd = [sys.executable, script, "--root", ROOT, "--subject", subject]
    if cfg.get("名字"):
        cmd += ["--title", str(cfg["名字"])]
    if cfg.get("学生"):
        cmd += ["--student", str(cfg["学生"])]
    if cfg.get("风格"):
        cmd += ["--theme", str(cfg["风格"])]
    if cfg.get("主色"):
        cmd += ["--accent", str(cfg["主色"])]

    subprocess.run(cmd, check=True)
    print("工作台已更新：", os.path.join(ROOT, "index.html"))


if __name__ == "__main__":
    main()
