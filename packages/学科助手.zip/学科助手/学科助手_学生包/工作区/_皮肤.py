# -*- coding: utf-8 -*-
"""三科页面皮肤 · 学科页 / 板块页共用。

一个风格字段，一套视觉。风格来自 工作台设置.json 的「风格」：
    纸墨（默认） / 小屋 / 花园
  · 这三个名字在两套页面里通用，不再有「学科页一套、学习台一套」。
  · 写了别的名字、同时工作目录有 自定义主题.css → 当成自定义皮肤。
  · 写了别的名字、又没有 css → 回纸墨，不报错。

用法（各科生成脚本内部调用）：
    import _皮肤
    html = _皮肤.subject_page(root, subject, title, student, modules)
    html = _皮肤.module_page(root, subject, module_name, module_folder, files)
"""

import html
import json
import os
import time

STYLES = {"纸墨": "", "小屋": "t-house", "花园": "t-garden"}

ICONS = {
    "01-知识点可视化": '<circle cx="6.2" cy="6" r="2.3"/><circle cx="17.8" cy="6" r="2.3"/>'
                      '<circle cx="12" cy="18" r="2.3"/><path d="M8.2 7.6l2.4 8.2M15.8 7.6l-2.4 8.2M8.5 6h7"/>',
    "02-游戏练习": '<rect x="3.6" y="5" width="16.8" height="14" rx="4.2"/>'
                  '<path d="M10.6 9.6l4.4 2.9-4.4 2.9z" fill="currentColor" stroke="none"/>',
    "03-阶段测试与报告": '<rect x="5" y="3.6" width="14" height="16.8" rx="2.6"/>'
                        '<path d="M9 9h6M9 12.6h6M9 16.2h3.4"/>',
    "04-错题卡": '<path d="M6.6 4.4h10.8a1.6 1.6 0 011.6 1.6v13.6l-7-4.2-7 4.2V6a1.6 1.6 0 011.6-1.6z"/>',
}


def esc(s):
    return html.escape(str(s), quote=True)


def read_settings(root):
    """先读本目录，没有再读上一级（工作区根目录）。全站一套名字/风格。"""
    for cand in (root, os.path.dirname(root)):
        p = os.path.join(cand, "工作台设置.json")
        if not os.path.isfile(p):
            continue
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict):
                return d
        except (OSError, ValueError):
            pass
    return {}


def resolve(root):
    """返回 (body_class, extra_css)。"""
    cfg = read_settings(root)
    name = str(cfg.get("风格", "")).strip()
    if name in STYLES:
        return STYLES[name], ""
    css_path = os.path.join(root, "自定义主题.css")
    if name and os.path.isfile(css_path):
        try:
            with open(css_path, encoding="utf-8") as f:
                return "t-custom", f.read()
        except OSError:
            pass
    return "", ""


def fmt_date(ts):
    return time.strftime("%Y-%m-%d", time.localtime(ts))


CSS = r"""
:root{
  --paper:#F6F3ED; --ink:#221F1A; --ink-2:#716B60; --line:rgba(34,31,26,.10);
  --card:#FFFFFF; --accent:#B05B4F; --tint:#FAF0ED; --radius:20px;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{background:var(--paper);color:var(--ink);line-height:1.5;
  font-family:"PingFang SC","Hiragino Sans GB",system-ui,-apple-system,"Microsoft YaHei",sans-serif;
  -webkit-font-smoothing:antialiased;padding:0 0 64px}
a{color:inherit;text-decoration:none}
button{font:inherit;color:inherit}

.bar{max-width:1080px;margin:0 auto;padding:22px 30px 0;display:flex;align-items:center;gap:16px}
.brand{display:flex;align-items:center;gap:8px;font-size:13.5px;letter-spacing:.08em;color:var(--ink-2)}
.brand i{width:8px;height:8px;border-radius:50%;background:var(--accent);display:block}
.who{margin-left:auto;font-size:13px;color:var(--ink-2)}
main{max-width:1080px;margin:0 auto;padding:30px 30px 0}

.crumb{font-size:13px;color:var(--ink-2);margin:0 0 22px}
.crumb a{color:var(--ink-2)}
.crumb a:hover{color:var(--ink);text-decoration:underline}
.crumb .sep{opacity:.45;margin:0 7px}

h1{font-family:"Songti SC","STSong","SimSun",serif;font-size:44px;font-weight:600;
  letter-spacing:.02em;margin:0 0 8px;line-height:1.1}
h1 .seal{display:inline-block;background:var(--accent);color:#fff;font-size:12px;
  padding:2px 8px;border-radius:3px;margin-right:10px;vertical-align:6px;letter-spacing:.1em;
  font-family:"PingFang SC",sans-serif}
.meta{color:var(--ink-2);font-size:14px;margin:0 0 30px}
.meta b{color:var(--ink);font-weight:600;font-variant-numeric:tabular-nums}

/* 学科页的四个板块 */
.tiles{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}
.tile{position:relative;display:flex;flex-direction:column;align-items:flex-start;
  min-height:186px;padding:22px;border:1px solid var(--line);border-radius:var(--radius);
  background:var(--card);cursor:pointer;text-align:left;
  transition:transform .22s ease,box-shadow .22s ease,border-color .22s ease}
.tile:hover{transform:translateY(-3px);box-shadow:0 16px 34px rgba(45,35,18,.09);
  border-color:rgba(34,31,26,.16)}
.tile .ico{display:flex;align-items:center;justify-content:center;width:44px;height:44px;
  border-radius:14px;background:var(--tint);color:var(--accent);margin-bottom:auto;position:relative}
.tile .ico svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.6;
  stroke-linecap:round;stroke-linejoin:round}
.tile .name{font-size:18px;font-weight:600;letter-spacing:.02em;margin:20px 0 4px}
.tile .num{font-size:13.5px;color:var(--ink-2);font-variant-numeric:tabular-nums}
.tile .num b{font-size:15px;color:var(--ink);font-weight:600}
.tile .go{position:absolute;right:20px;bottom:20px;width:30px;height:30px;border-radius:50%;
  border:1px solid var(--line);display:flex;align-items:center;justify-content:center;
  color:var(--ink-2);opacity:0;transform:translateX(-4px);transition:.22s ease}
.tile:hover .go{opacity:1;transform:none}
.tile .go svg{width:13px;height:13px;fill:none;stroke:currentColor;stroke-width:1.8;
  stroke-linecap:round;stroke-linejoin:round}

/* 板块页的文件清单 */
.files{list-style:none;margin:0;padding:0;border-top:1px solid var(--line)}
.files li{border-bottom:1px solid var(--line)}
.files a{display:flex;align-items:center;gap:16px;padding:16px 6px;
  transition:padding .18s ease,background .18s ease}
.files a:hover{padding-left:14px;background:rgba(255,255,255,.65)}
.files .fn{flex:1;min-width:0;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.files .dt{font-size:12.5px;color:var(--ink-2);font-variant-numeric:tabular-nums;white-space:nowrap}
.files .ext{font-size:11.5px;letter-spacing:.1em;color:var(--ink-2);border:1px solid var(--line);
  border-radius:5px;padding:2px 6px;white-space:nowrap}
.blank{padding:54px 6px;text-align:center;color:#9A9386;font-size:14px}

footer{max-width:1080px;margin:56px auto 0;padding:0 30px;color:#A49D8F;font-size:12px}

@media (max-width:1040px){.tiles{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:640px){
  .bar{padding:16px 18px 0}
  main{padding:22px 18px 0}
  h1{font-size:32px}
  .tiles{gap:12px}
  .tile{min-height:146px;padding:16px;border-radius:16px}
  .tile .name{font-size:15.5px;margin-top:14px}
  .tile .go{display:none}
  .files .ext{display:none}
  footer{padding:0 18px}
}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
@media print{body{background:#fff;padding:0}}
"""

THEME_CSS = r"""
/* 小屋 */
body.t-house{background:linear-gradient(180deg,#FAF2E6 0%,#F0E3D1 60%,#EADBC6 100%)}
.t-house .brand i{background:#8B5E3C}
.t-house h1{color:#4A3524}
.t-house .meta{color:#8A7358}
.t-house .meta b{color:#4A3524}
.t-house .tiles{row-gap:26px;margin-top:16px}
.t-house .tile{background:linear-gradient(180deg,#FFFDF7 0%,#FBF3E5 100%);
  border-color:#E4D2B7;padding-top:26px}
.t-house .tile::before{content:"";position:absolute;top:-14px;left:8px;right:8px;height:18px;
  background:linear-gradient(180deg,#C98A5C,#B3744A);
  clip-path:polygon(0 100%,50% 0,100% 100%)}
.t-house .tile:hover{border-color:#D8C0A0;box-shadow:0 18px 36px rgba(96,62,32,.13)}
.t-house .tile .ico{background:#F5E6CE;border:1px solid #E2CDA9;color:#8B5E3C}
.t-house .tile .ico::before,.t-house .tile .ico::after{content:"";position:absolute;background:#D3B183;opacity:.75}
.t-house .tile .ico::before{width:1px;top:7px;bottom:7px;left:50%}
.t-house .tile .ico::after{height:1px;left:7px;right:7px;top:50%}
.t-house .tile .name{color:#4A3524}
.t-house .tile .go{border-color:#DCC9AC;color:#8B5E3C}
.t-house .files a:hover{background:rgba(255,253,247,.8)}
.t-house footer{color:#A28B6E}

/* 花园 */
body.t-garden{background:linear-gradient(180deg,#F5F9EF 0%,#E9F1DE 60%,#E2ECD4 100%)}
.t-garden .brand i{background:#5C8A5A}
.t-garden h1{color:#2F4A34}
.t-garden .meta{color:#6E8467}
.t-garden .meta b{color:#2F4A34}
.t-garden .tile{background:#FFFEF8;border-color:#D9E3CC;padding-bottom:34px;
  border-radius:26px 26px 20px 20px}
.t-garden .tile::after{content:"";position:absolute;left:-1px;right:-1px;bottom:-1px;height:16px;
  border-radius:0 0 20px 20px;
  background:linear-gradient(180deg,#D8C09A 0%,#C4A878 100%);
  border:1px solid #D0BB97;border-top:0}
.t-garden .tile:hover{border-color:#C9D8B8;box-shadow:0 18px 36px rgba(58,86,48,.12)}
.t-garden .tile .ico{background:#EDF4E4;border:1px solid #D7E4C8;color:#4E7A4E;
  border-radius:50% 50% 15px 15px}
.t-garden .tile .name{color:#2F4A34}
.t-garden .tile .go{border-color:#D2DFC4;color:#4E7A4E;bottom:26px}
.t-garden .files a:hover{background:rgba(255,254,248,.85)}
.t-garden footer{color:#7C8F73}
"""


def shell(title, body, root, subject_accent="#B05B4F", subject_tint="#FAF0ED"):
    cls, extra = resolve(root)
    body_cls = ' class="%s"' % cls if cls else ""
    extra_style = "<style>%s</style>" % extra if extra else ""
    return ("""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>%s</title>
<style>%s</style>
<style>%s</style>
%s
<style>:root{--accent:%s;--tint:%s}</style>
</head>
<body%s>
%s
</body>
</html>
""" % (esc(title), CSS, THEME_CSS, extra_style, subject_accent, subject_tint, body_cls, body))


def subject_page(root, subject, title, student, modules, accent="#B05B4F", tint="#FAF0ED"):
    """modules: list of dict(folder, name, files)"""
    total = sum(len(m["files"]) for m in modules)
    tiles = []
    for m in modules:
        n = len(m["files"])
        icon = ICONS.get(m["folder"], ICONS["01-知识点可视化"])
        tiles.append("""<a class="tile" href="%s/index.html">
  <span class="ico"><svg viewBox="0 0 24 24" aria-hidden="true">%s</svg></span>
  <span class="name">%s</span>
  <span class="num"><b>%d</b> 份</span>
  <span class="go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></span>
</a>""" % (esc(m["folder"]), icon, esc(m["name"]), n))
    who = esc(student) if student else ""
    body = """<header class="bar">
  <a class="brand" href="../index.html"><i></i>统一学习台</a>
  <span class="who">%s</span>
</header>
<main>
  <h1><span class="seal">%s</span>%s</h1>
  <p class="meta"><b>%d</b> 份作品 · 4 个板块</p>
  <div class="tiles">
%s
  </div>
</main>
<footer>%s</footer>""" % (who, esc(subject), esc(title or subject), total, "\n".join(tiles),
                            esc(subject))
    return shell("%s · 学习台" % subject, body, root, accent, tint)


def module_page(root, subject, folder, name, files, accent="#B05B4F", tint="#FAF0ED"):
    if files:
        rows = "\n".join(
            '<li><a href="../%s"><span class="fn">%s</span><span class="dt">%s</span>'
            '<span class="ext">%s</span></a></li>'
            % (esc(f["rel"]), esc(f["name"]), fmt_date(f["mtime"]),
               esc(f["name"].rsplit(".", 1)[-1].upper() if "." in f["name"] else "FILE"))
            for f in files)
        listing = '<ul class="files">%s</ul>' % rows
    else:
        listing = '<div class="blank">这一格还空着</div>'
    body = """<header class="bar">
  <a class="brand" href="../index.html"><i></i>%s学习台</a>
</header>
<main>
  <div class="crumb"><a href="../index.html">← %s学习台</a><span class="sep">/</span><a href="../../index.html">统一学习台</a></div>
  <h1>%s</h1>
  <p class="meta"><b>%d</b> 份作品</p>
  %s
</main>
<footer>%s · %s</footer>""" % (esc(subject), esc(subject), esc(name), len(files), listing,
                                esc(subject), esc(folder))
    return shell("%s · %s" % (subject, name), body, root, accent, tint)
