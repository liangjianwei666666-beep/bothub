---
name: shot-analyst-bot
version: 1.0.0
description: 一键装配「拉片分析师 Bot」——把一条成片拆成逐镜头分析表 + 15 道质量门报告，需要文稿时先转写。当用户说「装一个拉片分析师」「装个能拆镜头的 Bot」「发你个包，装一下」「我要拉片」时使用。本技能教主 Bot 如何：① 跑 install.sh 装工作台与依赖；② 跑 selfcheck.sh 自检（全绿才算装好）；③ 用 create_bot 建出「拉片分析师」；④ 交第一条拉片。装好后那个 Bot 能把一条片拆成 shots.json + 镜头表 + 单页交互式拉片报告，切点/时长/运动量全靠 ffmpeg 量，模型只判景别/类别/运镜/画面/节奏，每条判断都被 15 道门当场对账。
---

# shot-analyst-bot · 一键装配「拉片分析师 Bot」

**这个技能是给「主 Bot」看的操作手册。** 用户说一句「装一个拉片分析师」，你按下面 5 步做完，用户就得到一个能拉片的 Bot。

全程不联网、不要 API Key、不碰用户账号密码。

---

## 第 0 步：先看包在哪

```bash
ls ~/.agents/skills/shot-analyst-bot/SKILL.md
```

**如果用户是「发了个压缩包给你」**（`.tar.gz`），先解开：

```bash
ls -lt ~/Downloads/shot-analyst-bot*.tar.gz 2>/dev/null | head
mkdir -p ~/.agents/skills
tar -xzf <包路径> -C ~/.agents/skills/
ls ~/.agents/skills/shot-analyst-bot/SKILL.md
```

解出来的目录名必须是 `shot-analyst-bot`。解完重读本文件再继续。

## 第 1 步：装配

```bash
bash ~/.agents/skills/shot-analyst-bot/scripts/install.sh ~/拉片工作室
```

默认目录 `~/拉片工作室`，可换成用户想要的位置。脚本会：建 `输入/ 输出/ 演示/` → 放工作台 HTML、头像、台账、grab.py → 检查 node / ffmpeg / ffprobe / python3 / faster-whisper → 把 video-shots 技能装到 `~/.agents/skills/video-shots/`（已存在则不覆盖）→ 生成一条 12 秒合成演示片。

**脚本输出里的 WARN 要原样转告用户，不要吞**：
- 缺 `node`/`ffmpeg`：拉片线跑不了，必须先装（`brew install node ffmpeg`）
- 缺 `faster-whisper`：拉片线照常，**只有转写**不可用（`pip3 install faster-whisper`）

## 第 2 步：自检（不许跳）

```bash
bash ~/.agents/skills/shot-analyst-bot/scripts/selfcheck.sh
```

它在临时目录生成一条 12 秒合成片，跑完整条链：场景检测 → 抽帧 → 联系表 → 填字段 → 15 道质量门 → 镜头表 + 报告，再验依赖和转写脚本。

- 最后一行 `READY 自检全过` → 继续
- `NOT READY` → 把失败项原文给用户看，修好再往下。**没过就不许说「装好了」**

## 第 3 步：建 Bot

用 `create_bot`，参数照抄：

- **name**：`拉片分析师`
- **role**：`拉片`
- **work_dir**：第 1 步用的那个目录的绝对路径（如 `/Users/<用户名>/拉片工作室`）
- **model**：不填（跟随主 Bot 当前模型）
- **avatar**：`~/.agents/skills/shot-analyst-bot/payload/头像.png`（先 `echo $HOME` 展开成绝对路径）
- **instructions**：`~/.agents/skills/shot-analyst-bot/templates/instructions.md` 的**全文原样**拷贝

## 第 4 步：交付第一条拉片

让新 Bot 拿一条真片子跑一遍。用户手头没片子就让它跑演示片：

```bash
node ~/.agents/skills/video-shots/scripts/video-shots.mjs seed \
  ~/拉片工作室/演示/合成自检片.mp4 --track ~/拉片工作室/演示/track.json --title "合成演示片" \
  > ~/拉片工作室/演示/shots.json
```

跑完把**报告路径 + 几镜 + 平均镜长 + 质量门 n/15** 给用户，别只说「做好了」。

---

## 包里有什么

```
shot-analyst-bot/
├── SKILL.md                     ← 本文件（主 Bot 操作手册）
├── README.md                    ← 给用户看的三句话说明
├── 交付说明.html                ← 双击可看的交付卡
├── payload/
│   ├── 头像.png                 ← Bot 头像（256×256）
│   ├── 拉片分析台.html          ← 工作台（生成命令、记台账、看节奏分布）
│   └── video-shots/             ← 拉片引擎：15 道质量门、报告模板（Apache-2.0，见下）
├── scripts/
│   ├── install.sh               ← 装配
│   ├── selfcheck.sh             ← 端到端自检
│   ├── make_demo.sh             ← 生成合成演示片
│   ├── grab.py                  ← 转写/下载（faster-whisper）
│   └── package.sh               ← 重新打包
└── templates/
    ├── instructions.md          ← 建 Bot 用的人设（原样拷贝）
    └── 台账模板.md
```

**依赖**：`node >= 18`、`ffmpeg`、`ffprobe`（拉片线必需）；`python3` + `faster-whisper`（只有转写线需要）。安装脚本**不会**替用户装系统依赖。

**转写线的已知限制**（原样转告，不要美化）：YouTube 在很多网络环境连不上；B站常被风控（api 412 / `Unable to extract initial state`）。本地文件最稳。

**许可证**：`payload/video-shots/` 上游为 Apache-2.0。本分发包只删除了上游 SKILL.md 末尾一段「打包机器本机路径」附录，其余原样；改动已在该文件末尾注明。

## 分发

自己再打一份包：

```bash
bash ~/.agents/skills/shot-analyst-bot/scripts/package.sh
```

产出 `~/.agents/skills/shot-analyst-bot.tar.gz`。对方拿到后：存到本地 → 发给自己的主 Bot → 说「装一个拉片分析师」。

**包里不含任何密钥。**
