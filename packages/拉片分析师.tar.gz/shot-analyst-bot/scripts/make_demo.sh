#!/usr/bin/env bash
# 生成一条 12 秒 / 5 镜的合成演示片（纯色底 + 移动方块 + 4 个硬切）。
# 用途：装机自检、第一次试跑。不依赖任何外部素材，产出可复现。
# 用法: make_demo.sh <输出.mp4>
set -euo pipefail
export PATH="$HOME/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
OUT="${1:-$PWD/demo.mp4}"
mkdir -p "$(dirname "$OUT")"
ffmpeg -y -v error \
  -f lavfi -i "color=c=0x101820:s=540x960:d=2.4:r=30" \
  -f lavfi -i "color=c=0xf2f0ea:s=540x960:d=2.4:r=30" \
  -f lavfi -i "color=c=0x7a1f1f:s=540x960:d=2.4:r=30" \
  -f lavfi -i "color=c=0xf2f0ea:s=540x960:d=2.4:r=30" \
  -f lavfi -i "color=c=0x101820:s=540x960:d=2.4:r=30" \
  -f lavfi -i "color=c=white:s=120x120:d=2.4:r=30" \
  -f lavfi -i "color=c=black:s=120x120:d=2.4:r=30" \
  -filter_complex "\
[0:v][5:v]overlay=x='mod(t*140,420)':y=420[v0];\
[1:v][6:v]overlay=x='mod(t*90,420)':y=200[v1];\
[2:v][5:v]overlay=x='mod(t*160,420)':y=620[v2];\
[3:v][6:v]overlay=x='mod(t*110,420)':y=350[v3];\
[4:v][5:v]overlay=x='mod(t*130,420)':y=500[v4];\
[v0][v1][v2][v3][v4]concat=n=5:v=1:a=0,format=yuv420p" "$OUT"
echo "DEMO=$OUT"
