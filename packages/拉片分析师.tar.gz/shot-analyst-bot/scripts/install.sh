#!/usr/bin/env bash
# 装配「拉片分析师」Bot：工作台 + video-shots 技能 + 转写脚本 + 演示片。
# 用法: install.sh [目标目录]      默认目标目录: ~/拉片工作室
# 不联网、不装系统依赖、不碰任何账号。缺什么就 WARN，不假装成功。
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-$HOME/拉片工作室}"
export PATH="$HOME/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

echo "STEP 1 建工作台目录 → $TARGET"
mkdir -p "$TARGET/输入" "$TARGET/输出" "$TARGET/演示" "$TARGET/转写"
cp "$SKILL_DIR/payload/头像.png" "$TARGET/头像.png"
[ -f "$TARGET/拉片分析台.html" ] || cp "$SKILL_DIR/payload/拉片分析台.html" "$TARGET/拉片分析台.html"
[ -f "$TARGET/台账.md" ] || cp "$SKILL_DIR/templates/台账模板.md" "$TARGET/台账.md"
echo "  OK   工作台 / 头像 / 台账"

echo "STEP 2 依赖检查（缺了不装，只报）"
MISS=0
if command -v node >/dev/null 2>&1; then
  NV="$(node -v | sed 's/^v//')"; MAJ="${NV%%.*}"
  if [ "${MAJ:-0}" -ge 18 ]; then echo "  OK   node $NV"
  else echo "  WARN node $NV 低于 18，video-shots 需要 >= 18"; MISS=1; fi
else
  echo "  WARN 缺 node（>=18）。建议 nvm 或 brew install node，装完把路径加进 PATH"; MISS=1
fi
for b in ffmpeg ffprobe; do
  if command -v "$b" >/dev/null 2>&1; then echo "  OK   $b → $(command -v $b)"
  else echo "  WARN 缺 $b。建议: brew install ffmpeg（没有 brew 就装 ffmpeg 官方静态包）"; MISS=1; fi
done
if command -v python3 >/dev/null 2>&1; then
  echo "  OK   python3 $(python3 -V 2>&1 | awk '{print $2}')"
  if python3 -c "import faster_whisper" >/dev/null 2>&1; then
    echo "  OK   faster-whisper 可用（转写线就绪）"
  else
    echo "  WARN 无 faster-whisper：拉片线照常能用，只有「转写」不可用。补装: pip3 install faster-whisper"
  fi
else
  echo "  WARN 缺 python3：拉片线照常能用，转写不可用"; MISS=1
fi

echo "STEP 3 安装 video-shots 技能"
VS="$HOME/.agents/skills/video-shots"
mkdir -p "$HOME/.agents/skills"
if [ -e "$VS" ]; then
  echo "  SKIP 已存在 $VS（保留现有版本，未覆盖）"
else
  cp -R "$SKILL_DIR/payload/video-shots" "$VS"
  echo "  OK   已装到 $VS"
fi
if [ -f "$VS/scripts/video-shots.mjs" ]; then
  echo "  OK   video-shots.mjs 就位"
else
  echo "  ERROR $VS/scripts/video-shots.mjs 不存在，拉片线不可用"; exit 3
fi

echo "STEP 4 生成演示片（供自检和第一次试跑）"
if [ -f "$TARGET/演示/合成自检片.mp4" ]; then
  echo "  SKIP 演示片已存在"
elif command -v ffmpeg >/dev/null 2>&1; then
  bash "$SKILL_DIR/scripts/make_demo.sh" "$TARGET/演示/合成自检片.mp4" >/dev/null && echo "  OK   12 秒 / 5 镜合成片"
else
  echo "  SKIP 没有 ffmpeg，跳过生成"
fi

echo "TARGET=$TARGET"
if [ "$MISS" -eq 1 ]; then
  echo "DONE 装配完成，但上面有 WARN：先补齐依赖再跑自检。"
else
  echo "DONE 装配完成，依赖齐。下一步: bash $SKILL_DIR/scripts/selfcheck.sh"
fi
