#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
下载专家 · 一条链接进，一份能搜能读的中文稿出。

用法：
  python3 scripts/grab.py "https://www.youtube.com/watch?v=xxx"
  python3 scripts/grab.py "https://www.bilibili.com/video/BVxxx" --title "自定义标题"
  python3 scripts/grab.py <url> --mode subtitle   # 只抓现成字幕，不下载音频（最快）
  python3 scripts/grab.py <url> --mode audio      # 下载音频 + whisper 转写
  python3 scripts/grab.py <url> --lang en         # 源语言（默认自动）

产出（都在 out/ 下）：
  <slug>.md       中文文稿（带时间戳、分段、关键词）
  <slug>.json     结构化数据（元信息 + 逐句时间轴）
  <slug>.txt      纯文本（无时间戳，方便搜索/喂给别的 Bot）

设计原则：
- 先抓现成字幕（最快最准），没有字幕才下载音频转写。
- 转写失败不假装成功，明确报错并说明缺什么。
- 全程不猜链接内容，抓不到就报抓不到。
"""
import argparse
import json
import os
import re
import subprocess
import sys
import warnings
from datetime import datetime
from pathlib import Path
from typing import Optional

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
# 产出目录：默认 ~/拉片工作室/转写/ ；可用环境变量覆盖 DLZJ_OUT=/some/dir
OUT = Path(os.environ.get("DLZJ_OUT") or (Path.home() / "拉片工作室" / "转写")).expanduser().resolve()
OUT.mkdir(parents=True, exist_ok=True)


def find_ffmpeg():
    """找 ffmpeg：环境变量 → PATH → imageio-ffmpeg 自带二进制。

    不写死具体机器上的路径，换一台电脑也能用。
    """
    env = os.environ.get("FFMPEG_BIN")
    if env and os.path.exists(env):
        return env
    from shutil import which

    p = which("ffmpeg")
    if p:
        return p
    try:  # faster-whisper 的依赖里通常自带 imageio-ffmpeg
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def slugify(s: str, maxlen: int = 60) -> str:
    s = re.sub(r"[\\/:*?\"<>|\n\r\t]+", "_", s).strip("_ ")
    s = re.sub(r"\s+", "_", s)
    return (s[:maxlen] if s else "untitled")


def fmt_ts(seconds: float) -> str:
    seconds = int(seconds or 0)
    h, r = divmod(seconds, 3600)
    m, s = divmod(r, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ── 元信息 ────────────────────────────────────────────────
BILI_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
           "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")


def bili_meta(url: str) -> dict:
    """B站优先走官方 view 接口拿标题/作者/时长。

    yt-dlp 在 B站经常报 `Unable to extract initial state`（此时连标题都拿不到），
    但 view 接口一直稳定可用，且不需要登录（只要带 UA + Referer）。
    """
    m = re.search(r"(BV[0-9A-Za-z]{10})", url)
    if not m:
        return {}
    try:
        import json

        # 必须用 curl_cffi 伪装浏览器指纹：urllib 的默认 TLS 指纹会被 B站判为爬虫返回 412
        from curl_cffi import requests as creq

        r = creq.get(f"https://api.bilibili.com/x/web-interface/view?bvid={m.group(1)}",
                     impersonate="chrome", timeout=12,
                     headers={"Referer": "https://www.bilibili.com", "User-Agent": BILI_UA})
        d = json.loads(r.text)
        if d.get("code") != 0:
            return {}
        x = d["data"]
        return {
            "title": x.get("title") or "",
            "uploader": (x.get("owner") or {}).get("name") or "",
            "duration": x.get("duration") or 0,
            "description": (x.get("desc") or "")[:2000],
            "webpage_url": url,
            "bvid": m.group(1),
            "cid": x.get("cid"),
        }
    except Exception:
        return {}


def get_meta(url: str) -> dict:
    """取标题/时长/作者/简介，不下载。失败不阻断。"""
    base = bili_meta(url) if "bilibili" in url else {}
    try:
        import yt_dlp

        opts = {"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True}
        opts.update(ytdlp_base_opts())
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
        got = {
            "title": info.get("title") or "",
            "uploader": info.get("uploader") or info.get("channel") or "",
            "duration": info.get("duration") or 0,
            "description": (info.get("description") or "")[:2000],
            "webpage_url": info.get("webpage_url") or url,
            "upload_date": info.get("upload_date") or "",
            "view_count": info.get("view_count"),
        }
        # 官方接口拿到的补上 yt-dlp 缺的
        for k in ("title", "uploader", "duration", "description"):
            if not got.get(k) and base.get(k):
                got[k] = base[k]
        got.update({k: v for k, v in base.items() if k in ("bvid", "cid")})
        return got
    except Exception as e:
        if base:
            base["_error"] = str(e)  # 有官方数据就继续用
            return base
        return {"title": "", "uploader": "", "duration": 0, "description": "",
                "webpage_url": url, "upload_date": "", "_error": str(e)}


# ── 路径 A3：抖音（CDP 驱动本机 Chrome）─────────────────────
# 为什么这么绕：抖音的 aweme/detail 接口要 Argus 签名，f2 算出的 a_bogus 也已被判废
# （带 cookie + 正确签名仍 403）。但真实浏览器里视频能正常播放，所以让 Chrome
# 自己加载页面、从网络事件里取出它拿到的音视频流地址，再用 curl_cffi 下载。
DY_HOST = "douyin.com"


def is_douyin(url: str) -> bool:
    return DY_HOST in url


def _chrome_binary():
    """找本机 Chrome/Edge（抖音取流要用真浏览器。不写死某台机器的路径）。"""
    env = os.environ.get("DLZJ_CHROME")
    if env and os.path.exists(env):
        return env
    if sys.platform.startswith("win"):
        cands = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ]
    elif sys.platform == "darwin":
        cands = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                 "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    else:
        cands = ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable",
                 "/usr/bin/chromium", "/usr/bin/chromium-browser",
                 "/usr/bin/microsoft-edge"]
    for p in cands:
        if os.path.exists(p):
            return p
    from shutil import which

    for n in ("google-chrome", "chromium", "chromium-browser", "msedge"):
        if which(n):
            return which(n)
    return None


def _chrome_cookies(domain: str = "douyin.com"):
    """从本机 Chrome 读该域 cookie。读不到就返回空（抖音需要登录态）。"""
    try:
        import browser_cookie3 as bc

        cj = bc.chrome(domain_name=domain)
        return list(cj)
    except Exception:
        return []


def douyin_fetch(url: str, workdir: Path):
    """用 CDP 驱动 Chrome 打开抖音页面，抓出音视频流并下载音频。

    返回 (音频路径, 标题, 作者)。
    """
    import subprocess
    import time
    import urllib.request

    try:
        import websockets.sync.client as wsclient
    except Exception as e:
        raise RuntimeError(f"缺少 websockets 库：{e}；pip install websockets") from e

    import json as _json

    chrome = _chrome_binary()
    if not chrome:
        raise RuntimeError("没找到 Chrome/Edge，无法走浏览器方案")

    aid_m = re.search(r"/video/(\d{15,25})", url)
    if not aid_m:
        raise RuntimeError("链接里找不到抖音视频 ID（形如 /video/7xxxxxxxxxxxxxxxxxx）")
    aid = aid_m.group(1)

    port = int(os.environ.get("DLZJ_CDP_PORT", "9333"))
    import tempfile

    profile = Path(os.environ.get("DLZJ_CHROME_PROFILE")
                   or (Path(tempfile.gettempdir()) / ".dlzj_chrome_dy"))
    profile.mkdir(parents=True, exist_ok=True)

    # 复用已在跑的调试实例，避免反复起进程
    def alive():
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=2).read()
            return True
        except Exception:
            return False

    proc = None
    if not alive():
        proc = subprocess.Popen(
            [chrome, f"--remote-debugging-port={port}", f"--user-data-dir={profile}",
             "--headless=new", "--no-first-run", "--no-default-browser-check",
             "--disable-extensions", "--mute-audio", "about:blank"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(20):
            if alive():
                break
            time.sleep(0.5)
        if not alive():
            raise RuntimeError("Chrome 调试端口没起来")

    cookies = _chrome_cookies("douyin.com")
    cookie_str = "; ".join(f"{c.name}={c.value}" for c in cookies)

    newtab = _json.loads(urllib.request.urlopen(urllib.request.Request(
        f"http://127.0.0.1:{port}/json/new?about:blank", method="PUT"), timeout=10).read())

    url_audio = url_video = None
    title = ""
    with wsclient.connect(newtab["webSocketDebuggerUrl"], max_size=100 * 1024 * 1024) as ws:
        mid = [0]

        def call(method, params=None):
            mid[0] += 1
            cur = mid[0]
            ws.send(_json.dumps({"id": cur, "method": method, "params": params or {}}))
            while True:
                msg = _json.loads(ws.recv())
                if msg.get("id") == cur:
                    return msg

        call("Page.enable")
        call("Network.enable")
        call("Runtime.enable")
        for c in cookies:
            call("Network.setCookie", {"name": c.name, "value": c.value,
                                       "domain": ".douyin.com", "path": "/"})
        call("Page.navigate", {"url": f"https://www.douyin.com/video/{aid}"})

        # 等页面把视频流请求发出来
        # 注意：websocket 超时后会抛异常，如果直接 continue 会变成 100% CPU 忙等
        # （实测跑满 289% CPU 28 分钟）。所以限制连续空转次数，并强制小睡。
        deadline = time.time() + 25
        idle = 0
        while time.time() < deadline:
            try:
                msg = _json.loads(ws.recv(timeout=1))
                idle = 0
            except Exception:
                idle += 1
                if idle >= 8:       # 连续 8 秒没有任何消息 → 页面没在加载，放弃
                    break
                time.sleep(0.25)
                continue
            if msg.get("method") == "Network.requestWillBeSent":
                u = msg["params"]["request"]["url"]
                if "douyinvod" in u:
                    if "media-audio" in u and not url_audio:
                        url_audio = u
                    if "media-video" in u and not url_video:
                        url_video = u
            if url_audio and url_video:
                break

        try:
            r = call("Runtime.evaluate", {"expression": "document.title", "returnByValue": True})
            title = (r.get("result", {}).get("result", {}) or {}).get("value") or ""
            title = re.sub(r"\s*-\s*抖音\s*$", "", title).strip()
        except Exception:
            pass

    if not url_audio:
        raise RuntimeError(
            "没抓到抖音音频流：页面没加载出来。多半是没登录态——"
            "请先在 Chrome 里登录抖音，再重试")

    from curl_cffi import requests as creq

    r = creq.get(url_audio, impersonate="chrome", timeout=180,
                 headers={"Referer": "https://www.douyin.com/", "Cookie": cookie_str})
    if r.status_code != 200 or not r.content:
        raise RuntimeError(f"音频下载失败：HTTP {r.status_code}")
    raw = workdir / "dy_audio.m4a"
    raw.write_bytes(r.content)

    ff = find_ffmpeg()
    out = workdir / "audio.wav"
    if ff:
        subprocess.run([ff, "-y", "-i", str(raw), "-ar", "16000", "-ac", "1", str(out)],
                       capture_output=True)
        if out.exists():
            return out, title, ""
    return raw, title, ""


# ── 路径 A：现成字幕 ──────────────────────────────────────
def try_generic_subtitle(url: str, langs, workdir: Path):
    """用 yt-dlp 抓任意平台的现成字幕（YouTube / X / 其他都适用）。

    字幕比转写准得多，有就一定优先用。返回 (segs, lang) 或 None。
    """
    import yt_dlp

    workdir.mkdir(parents=True, exist_ok=True)
    opts = {
        "quiet": True, "no_warnings": True, "noplaylist": True,
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": list(langs),
        "subtitlesformat": "vtt",
        "outtmpl": str(workdir / "sub"),
    }
    opts.update(ytdlp_base_opts())
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
    except Exception:
        return None

    vtts = sorted(workdir.glob("sub*.vtt"))
    if not vtts:
        return None
    segs = parse_vtt(vtts[0])
    if not segs:
        return None
    return segs, vtts[0].stem


def parse_vtt(path: Path) -> list:
    """把 .vtt 字幕解析成 [{start, dur, text}]，顺手去重和清格式。"""
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []
    segs = []
    block = []
    cur_start = cur_end = None
    ts = re.compile(r"(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})")

    def to_sec(m):
        h = int(m.group(1)[:-1]) if m.group(1) else 0
        return h * 3600 + int(m.group(2)) * 60 + int(m.group(3)) + int(m.group(4)) / 1000

    def flush():
        if cur_start is None or not block:
            return
        txt = " ".join(block)
        txt = re.sub(r"<[^>]+>", "", txt)           # 去 <c> 等标签
        txt = re.sub(r"\s*\n\s*", " ", txt).strip()
        txt = re.sub(r"\.\.\.$", "", txt).strip()
        if txt and (not segs or segs[-1]["text"] != txt):
            segs.append({"start": cur_start,
                         "dur": max(0.0, (cur_end or cur_start) - cur_start),
                         "text": txt})

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            flush()
            block, cur_start, cur_end = [], None, None
            continue
        if line.startswith(("WEBVTT", "NOTE", "Kind:", "Language:")):
            continue
        if "-->" in line:
            flush()
            block = []
            parts = [p.strip() for p in line.split("-->")]
            m1, m2 = ts.search(parts[0]), ts.search(parts[-1])
            cur_start = to_sec(m1) if m1 else None
            cur_end = to_sec(m2) if m2 else None
            continue
        if line.isdigit():
            continue
        block.append(line)
    flush()
    return segs


def yt_video_id(url: str):
    m = re.search(r"(?:v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def try_youtube_subtitle(url: str, langs):
    vid = yt_video_id(url)
    if not vid:
        return None
    try:
        from youtube_transcript_api import YouTubeTranscriptApi

        # youtube-transcript-api 新版是实例方法，老版是类方法；两种都兼容
        api = YouTubeTranscriptApi()
        try:
            fetched = api.fetch(vid, languages=list(langs))
        except TypeError:
            fetched = YouTubeTranscriptApi.fetch(vid, languages=list(langs))
        segs = []
        for s in fetched:
            txt = re.sub(r"\s*\n\s*", " ", (s.text or "")).strip()
            # 字幕里的 "really..." 是显示截断，合并时要去掉悬空省略号
            txt = re.sub(r"\.\.\.$", "", txt).strip()
            if not txt:
                continue
            segs.append({
                "start": float(s.start),
                "dur": float(getattr(s, "duration", 0) or 0),
                "text": txt,
            })
        return segs, getattr(fetched, "language", "") or ""
    except Exception as e:
        return {"_error": f"{type(e).__name__}: {e}"}


# ── 路径 A2：小红书（curl_cffi 伪装浏览器指纹）────────────
XHS_HOST = "xiaohongshu.com"


def is_xhs(url: str) -> bool:
    return XHS_HOST in url


def xhs_session():
    from curl_cffi import requests

    return requests


def xhs_fetch_note(url: str):
    """取小红书笔记详情。返回 (标题, 正文, 视频地址, 元信息)，失败抛异常。

    要点（2026-10 实测）：
    - 必须用 curl_cffi + impersonate="chrome"，否则 TLS 指纹被拦/跳登录。
    - 直接用 /explore/<id> 拿到的是空壳，笔记数据在 noteDetailMap 里是空字典。
      需要带 xsec_token 才能取到真实数据；token 从首页 feed 里拿同一条的，
      或由用户直接粘贴带 token 的分享链接。
    """
    import json
    import re

    requests = xhs_session()
    H = {"Referer": "https://www.xiaohongshu.com/explore"}
    # 必须用同一个 Session：先访问首页拿 abRequestId 等 cookie，再取详情，
    # 否则 noteDetailMap 是空的（2026-10 实测）
    session = requests.Session()

    def parse_state(html: str):
        m = re.search(r"window\.__INITIAL_STATE__\s*=\s*(\{.*?\})\s*</script>", html, re.S)
        if not m:
            raise RuntimeError("页面里没有 __INITIAL_STATE__（可能被风控拦了）")
        return json.loads(m.group(1).replace("undefined", "null"))

    note_id = None
    m = re.search(r"/(?:explore|discovery/item)/([0-9a-f]{24})", url)
    if m:
        note_id = m.group(1)
    if not note_id:
        raise RuntimeError("链接里找不到笔记 ID")

    # 1) 首页：建立 session + 拿 feed 里同一条的 xsecToken
    #    注意 feed 每次请求都在变，而且"刷新两次"会换内容；所以必须在
    #    同一次响应的 feed 里匹配，找不到就换一条最新视频笔记重试，
    #    最终退化成"取当前 feed 第一条"（URL 里给的就是它时才有意义）。
    home = session.get("https://www.xiaohongshu.com/explore",
                       impersonate="chrome", timeout=20, headers=H)
    hs = parse_state(home.text)
    token = None
    mt = re.search(r"xsec_token=([^&]+)", url)
    if mt:
        token = mt.group(1)
    if not token:
        for f in (hs.get("feed") or {}).get("feeds") or []:
            if f.get("id") == note_id:
                token = f.get("xsecToken")
                break

    def detail_url(tok):
        u = f"https://www.xiaohongshu.com/explore/{note_id}"
        if tok:
            u += f"?xsec_token={tok}&xsec_source=pc_feed"
        return u

    def try_detail(tok):
        r = session.get(detail_url(tok), impersonate="chrome", timeout=20, headers=H)
        if r.status_code != 200:
            return {}
        return (parse_state(r.text).get("note") or {}).get("noteDetailMap") or {}

    # 2) 详情页：先按已有 token 试，再裸试
    nd = try_detail(token) if token else {}
    if not nd:
        nd = try_detail(None)

    # 3) 还不行：重新拉一次首页，用当次 feed 里的 token 立即取详情
    if not nd:
        for _ in range(2):
            h2 = session.get("https://www.xiaohongshu.com/explore",
                             impersonate="chrome", timeout=20, headers=H)
            for f in (parse_state(h2.text).get("feed") or {}).get("feeds") or []:
                if f.get("id") == note_id and f.get("xsecToken"):
                    nd = try_detail(f["xsecToken"])
                    break
            if nd:
                break

    if not nd:
        raise RuntimeError(
            "拿不到笔记详情：token 过期，或这条已不在首页 feed 里。"
            "请在小红书 App 里点「复制链接」把完整链接（含 xsec_token）发我")

    note = list(nd.values())[0].get("note") or {}
    title = note.get("title") or (note.get("desc") or "")[:40]
    desc = note.get("desc") or ""
    author = (note.get("user") or {}).get("nickname") or ""

    video_url = None
    v = note.get("video")
    if v:
        stream = ((v.get("media") or {}).get("stream")) or {}
        for codec in ("h264", "h265", "av1"):
            arr = stream.get(codec) or []
            if arr:
                cand = arr[0]
                video_url = cand.get("masterUrl") or (cand.get("backupUrls") or [None])[0]
                if video_url:
                    break
    return {
        "title": title, "desc": desc, "author": author,
        "video_url": video_url, "type": note.get("type"),
        "duration": ((v or {}).get("media") or {}).get("video", {}).get("duration", 0) if v else 0,
        "meta": {"liked": (note.get("interactInfo") or {}).get("likedCount"),
                 "collected": (note.get("interactInfo") or {}).get("collectedCount")},
    }


def xhs_download(url: str, workdir: Path) -> tuple:
    """下载小红书视频/音频，返回 (音频路径, 笔记信息)。"""
    requests = xhs_session()
    info = xhs_fetch_note(url)
    if not info.get("video_url"):
        raise RuntimeError(f"这条笔记没有视频（类型：{info.get('type')}）；图文笔记请直接看正文")
    r = requests.get(info["video_url"], impersonate="chrome", timeout=120,
                     headers={"Referer": "https://www.xiaohongshu.com"})
    if r.status_code != 200 or not r.content:
        raise RuntimeError(f"视频下载失败：HTTP {r.status_code}")
    raw = workdir / "xhs.mp4"
    raw.write_bytes(r.content)
    # 抽音频
    ff = find_ffmpeg()
    out = workdir / "audio.wav"
    if ff:
        subprocess.run([ff, "-y", "-i", str(raw), "-ar", "16000", "-ac", "1", str(out)],
                       capture_output=True)
        if out.exists():
            return out, info
    return raw, info

# ── 路径 B：下载音频 + whisper 转写 ───────────────────────
def detect_proxy() -> Optional[str]:
    """自动找本机代理：环境变量 → macOS 系统代理 → Windows 注册表 / Linux 常见端口。

    YouTube/X 在部分网络下被 DNS 污染 + SNI 阻断，只有走代理能通。
    端口由 VPN 客户端分配，不写死；探测不到就返回 None，直连。
    """
    for k in ("HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy", "ALL_PROXY"):
        v = os.environ.get(k)
        if v:
            return v
    # macOS 系统代理
    try:
        out = subprocess.run(["scutil", "--proxy"], capture_output=True, text=True, timeout=5).stdout
        host = re.search(r"HTTPSProxy\s*:\s*(\S+)", out)
        port = re.search(r"HTTPSPort\s*:\s*(\d+)", out)
        if host and port:
            return f"http://{host.group(1)}:{port.group(1)}"
        host = re.search(r"SOCKSProxy\s*:\s*(\S+)", out)
        port = re.search(r"SOCKSPort\s*:\s*(\d+)", out)
        if host and port:
            return f"socks5://{host.group(1)}:{port.group(1)}"
    except Exception:
        pass
    # Windows：读系统代理（注册表），Linux：看环境变量已经覆盖，剩下不猜
    if sys.platform.startswith("win"):
        try:
            import winreg  # type: ignore

            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
            enabled = winreg.QueryValueEx(key, "ProxyEnable")[0]
            server = winreg.QueryValueEx(key, "ProxyServer")[0]
            if enabled and server:
                if "=" in server:  # http=1.2.3.4:8080;https=... 这种格式
                    for part in server.split(";"):
                        if part.lower().startswith("https="):
                            return f"http://{part.split('=', 1)[1]}"
                    return f"http://{server.split(';')[0].split('=', 1)[-1]}"
                return f"http://{server}"
        except Exception:
            pass
    return None


def ytdlp_base_opts() -> dict:
    """yt-dlp 公共参数：代理 + YouTube 专用 client。

    代理只在探测到的时候才用；探测不到就直连，不能因为没代理就整体不动。
    YouTube 的 player client 无论有没有代理都给——默认 web client 会报
    `The page needs to be reloaded`（SABR 流限制），android_vr 能过。
    """
    opts = {}
    proxy = detect_proxy()
    if proxy:
        opts["proxy"] = proxy
    opts["extractor_args"] = {"youtube": {"player_client": ["android_vr", "tv", "web"]}}
    return opts


def download_audio(url: str, workdir: Path, cookies_from: str = "") -> Path:
    import yt_dlp

    ff = find_ffmpeg()
    opts = {
        "quiet": True, "no_warnings": True, "noplaylist": True,
        "format": "bestaudio/best",
        "outtmpl": str(workdir / "audio.%(ext)s"),
    }
    opts.update(ytdlp_base_opts())
    if ff:
        opts["ffmpeg_location"] = ff
    if cookies_from:
        opts["cookiesfrombrowser"] = (cookies_from,)
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])

    got = sorted(workdir.glob("audio.*"))
    if not got:
        raise RuntimeError("音频下载失败：目录里没有生成文件")
    return got[0]


def to_simplified(text: str, lang: Optional[str]) -> str:
    """whisper 中文常吐繁体，统一转简体。没有 zhconv 就原样返回，不假装转过。"""
    if not text:
        return text
    if lang and not str(lang).lower().startswith("zh"):
        return text
    try:
        import zhconv

        text = zhconv.convert(text, "zh-cn")
    except Exception:
        pass
    # zhconv 会残留异体标点和半角逗号，统一回标准中文标点
    for bad, good in (("﹐", "，"), ("﹑", "、"), ("﹒", "。"), ("﹔", "；"),
                      ("﹖", "？"), ("﹗", "！"), (",", "，")):
        text = text.replace(bad, good)
    return text


# 注意：不要用 initial_prompt 塞"请用简体中文转写"这类指令。
# 实测（2026-10）：whisper 会把 prompt 当成音频里说过的话，直接转写成正文，
# 而且还会带偏真实语音的识别。繁简一律靠 zhconv 后处理解决。
ZH_PROMPT = None


def transcribe(audio: Path, lang: Optional[str], model_name: str = "medium") -> list:
    """faster-whisper（CTranslate2，不需要 torch，规避了 numpy 冲突）"""
    from faster_whisper import WhisperModel

    m = WhisperModel(model_name, device="cpu", compute_type="int8")
    segments, info = m.transcribe(
        str(audio),
        language=lang,
        vad_filter=True,
        condition_on_previous_text=False,   # 防止长音频串词/循环
        beam_size=5,
    )
    real_lang = getattr(info, "language", None) or lang
    segs = []
    for s in segments:
        txt = (s.text or "").strip()
        if not txt:
            continue
        t = to_simplified(txt, real_lang)
        if _is_junk_line(t):
            continue
        segs.append({
            "start": float(s.start or 0),
            "dur": float((s.end or 0) - (s.start or 0)),
            "text": t,
        })
    return segs


# whisper 在静音/片尾常吐的固定幻觉，不能当真内容
JUNK_PATTERNS = (
    "字幕by", "字幕提供", "字幕由", "请订阅", "订阅频道", "点赞订阅",
    "感谢观看", "谢谢观看", "amara.org", "subtitle", "中文字幕",
)


def _is_junk_line(text: str) -> bool:
    low = text.lower().replace(" ", "")
    if len(low) <= 12 and any(p.lower().replace(" ", "") in low for p in JUNK_PATTERNS):
        return True
    return False


# ── 整理成可读文稿 ────────────────────────────────────────
def load_glossary(path: Optional[Path] = None) -> dict:
    """读术语表：一行一条「错词=正词」或「错词 正词」，# 开头是注释。

    whisper 同音字错误（耳蜗→耳窝、植入体→植物体）光靠模型换不出来，
    给一份术语表最有效。默认读项目根目录 glossary.txt，没有就跳过。
    """
    p = path or (ROOT / "glossary.txt")
    table = {}
    if not p.exists():
        return table
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        for sep in ("=", "\t", " "):
            if sep in line:
                bad, _, good = line.partition(sep)
                bad, good = bad.strip(), good.strip()
                if bad and good and bad != good:
                    table[bad] = good
                break
    return table


def apply_glossary(text: str, table: dict) -> str:
    """长词优先替换，避免「耳窝」先被替换掉把「人公耳窝」拆坏。"""
    if not table:
        return text
    for bad in sorted(table, key=len, reverse=True):
        text = text.replace(bad, table[bad])
    return text


def _is_latin(text: str) -> bool:
    """判断这行主要是英文——英文不该补中文逗号/句号。"""
    letters = len(re.findall(r"[A-Za-z]", text))
    cjk = len(re.findall(r"[\u4e00-\u9fa5]", text))
    return letters > cjk


def make_paragraphs(segs: list, gap: float = 1.2, max_chars: int = 180) -> list:
    """把逐句合并成段：停顿超过 gap 秒、累积超过 max_chars、或遇到整句标点就断段。

    中文和英文分开处理：中文补「，」「。」，英文用空格、保留原标点。
    """
    CN_ENDS = ("。", "！", "？")
    EN_ENDS = (".", "!", "?")
    paras, buf, buf_start, last_end = [], [], None, None

    def flush(at):
        nonlocal buf, buf_start
        if buf:
            t = "".join(buf).strip()
            if t:
                paras.append({"start": buf_start, "text": t})
        buf, buf_start = [], at

    for s in segs:
        text = (s.get("text") or "").strip()
        if not text:
            continue
        if buf_start is None:
            buf_start = s["start"]
        # 停顿断段
        if last_end is not None and s["start"] - last_end > gap:
            flush(s["start"])
            buf_start = s["start"]

        latin = _is_latin(text)
        if latin:
            # 英文：句子之间补空格，自身标点保留
            if buf:
                buf.append(" ")
            buf.append(text)
            ended = text.endswith(EN_ENDS)
        else:
            if text.endswith(CN_ENDS):
                buf.append(text)
            elif text.endswith(("，", "；", "：", "、", ",")):
                buf.append(text)
            else:
                buf.append(text + "，")
            ended = text.endswith(CN_ENDS)

        last_end = s["start"] + (s.get("dur") or 0)
        # 整句收尾 或 累积太长 → 断段
        if ended or sum(len(x) for x in buf) >= max_chars:
            flush(s["start"] + (s.get("dur") or 0))
    flush(0)
    # 收尾句去掉末尾多余的逗号（只处理中文段落）
    for p in paras:
        if not _is_latin(p["text"]):
            p["text"] = re.sub(r"[，,、；;：:]+$", "。", p["text"])
    return paras


def keyword_hits(text: str, top: int = 18) -> list:
    """朴素关键词：中文按相邻 2-4 字窗口统计频次 + 英文单词。够用，不做花活。

    注：不能用 `[\\u4e00-\\u9fa5]{2,6}` 整段匹配——那是贪婪的，会把整句当一词，
    频次全是 1，过滤 >=2 后结果永远为空。
    """
    cn_stop = set("的了是我你他她它们这和那就都很也在了不没有一有上下来去做个说会要可能因为所以然后就是但是如果我们你们什么怎么这样那样这个那个可以还是已经非常需要应该"
                  "第一第二次第三次一个一种一些一下一直已经之后以前"
                  .replace(" ", ""))
    cn_stop |= set("，。！？；：、,.!?;: ")
    from collections import Counter

    c = Counter()
    runs = re.findall(r"[\u4e00-\u9fa5]+", text)
    for run in runs:
        n = len(run)
        for size in (2, 3, 4):
            for i in range(n - size + 1):
                w = run[i:i + size]
                if w in cn_stop:
                    continue
                # 纯虚词组合（如"的是"）不要
                if all(ch in cn_stop for ch in w):
                    continue
                c[w] += 1
    en = re.findall(r"[A-Za-z][A-Za-z\-]{3,}", text)
    c.update(w.lower() for w in en)

    # 去除被更长高频词覆盖的短词，避免"人工智能/智能"重复堆叠
    ranked = [w for w, n in c.most_common(200) if n >= 2 and len(w) >= 2]
    out = []
    for w in ranked:
        if any(w != o and w in o and c[o] >= c[w] for o in ranked):
            continue
        out.append(w)
        if len(out) >= top:
            break
    return out


# ── 主流程 ────────────────────────────────────────────────
LOCAL_EXTS = (".mp3", ".m4a", ".wav", ".aac", ".flac", ".ogg", ".opus", ".wma",
              ".mp4", ".mkv", ".mov", ".m4v", ".avi", ".flv", ".webm", ".ts")


def is_local_file(url: str) -> bool:
    """本地音视频文件（跳过下载，直接转写）。这是最稳的一条路。"""
    if url.startswith(("http://", "https://")):
        return False
    try:
        p = Path(url).expanduser()
    except Exception:
        return False
    return p.is_file() or (url.lower().endswith(LOCAL_EXTS) and p.exists())


def run(url, mode="auto", title=None, lang=None, model="medium", cookies_from=""):
    xhs_info = None
    local = is_local_file(url)
    print(f"[1/4] 读取元信息 …")
    if local:
        src = Path(url).expanduser().resolve()
        meta = {"title": title or src.stem, "uploader": "", "duration": 0,
                "webpage_url": str(src)}
        print(f"      本地文件：{src}")
        print(f"      标题：{meta['title']}")
    elif is_xhs(url):
        # 小红书 yt-dlp 解析不出内容，走专用的 curl_cffi 路径
        try:
            xhs_info = xhs_fetch_note(url)
            meta = {"title": xhs_info["title"], "uploader": xhs_info["author"],
                    "duration": xhs_info.get("duration") or 0, "webpage_url": url}
            print(f"      标题：{meta['title']}")
            if meta["uploader"]:
                print(f"      作者：{meta['uploader']}")
        except Exception as e:
            print(f"\n❌ 小红书取数失败：{str(e)[:200]}")
            return 2
    else:
        meta = get_meta(url)
        print(f"      标题：{title or meta.get('title') or url}")
        if meta.get("_error"):
            print(f"      注意：元信息没取到（{meta['_error'][:80]}），继续走内容抓取")
        if meta.get("duration"):
            print(f"      时长：{fmt_ts(meta['duration'])}")

    real_title = title or meta.get("title") or url
    source = None
    segs = None
    lang_used = ""

    if mode in ("auto", "subtitle") and not (is_xhs(url) or is_douyin(url) or local):
        print(f"[2/4] 尝试抓现成字幕 …")
        langs = [lang] if lang else ["zh-Hans", "zh-CN", "zh", "en"]
        subdir = OUT / f".sub_{slugify(real_title, 24)}"
        got = try_generic_subtitle(url, langs, subdir)
        if not got and yt_video_id(url):
            # 兜底再走一次 youtube-transcript-api
            got = try_youtube_subtitle(url, langs)
            if isinstance(got, dict) and got.get("_error"):
                print(f"      没有可用字幕（{got['_error'][:100]}）")
                got = None
        if got:
            segs, lang_used = got
            source = "subtitle"
            print(f"      ✅ 抓到字幕 {len(segs)} 句（{lang_used or '未知'}）")
        elif mode == "subtitle":
            print("\n❌ 字幕模式失败：这条没有可用字幕，也不允许下载音频。")
            return 1
        else:
            print(f"      没有现成字幕，改为下载音频转写")

    if segs is None:
        print(f"[2/4] {'准备音频（本地文件，跳过下载）' if local else '下载音频'} …")
        workdir = OUT / f".work_{slugify(real_title, 24)}"
        workdir.mkdir(exist_ok=True)
        try:
            if local:
                audio = Path(url).expanduser().resolve()
            elif is_xhs(url):
                audio, xhs_info = xhs_download(url, workdir)
            elif is_douyin(url):
                print(f"      抖音：走浏览器方案（Chrome 加载页面 → 取流地址）…")
                audio, dy_title, _ = douyin_fetch(url, workdir)
                if dy_title and not title:
                    real_title = dy_title
                    # 标题变了，输出目录也要跟着改
                    workdir_better = OUT / f".work_{slugify(real_title, 24)}"
                    if workdir_better != workdir:
                        workdir_better.mkdir(exist_ok=True)
            else:
                audio = download_audio(url, workdir, cookies_from)
        except Exception as e:
            msg = str(e).split("\n")[0][:300]
            print(f"\n❌ 下载失败：{msg}")
            print("\n常见原因，按顺序排查：")
            print("  1. 网络到不了这个站（YouTube/X 在部分网络下不通，需代理）")
            print("  2. B站风控：必须加 --cookies-from-browser chrome")
            print("  3. 抖音：需要先在 Chrome 里登录抖音（脚本会读登录态）")
            return 2
        print(f"      音频：{audio.name}（{audio.stat().st_size/1e6:.1f} MB）")

        print(f"[3/4] whisper 转写（模型 {model}，这一步慢，别急）…")
        try:
            segs = transcribe(audio, lang, model)
        except Exception as e:
            print(f"\n❌ 转写失败：{str(e)[:200]}")
            print("\n转写依赖 faster-whisper。若报 ModuleNotFoundError，先装：")
            print("  python3 -m pip install --user faster-whisper")
            print(f"音频已保留，可手动转写：{audio}")
            return 3
        source = f"whisper-{model}"
        lang_used = lang or "auto"
        print(f"      ✅ 转写完成 {len(segs)} 句")
    else:
        print(f"[3/4] 跳过转写（已有字幕）")

    print(f"[4/4] 生成中文文稿 …")
    # 术语表纠正同音字（先纠正逐句，再分段，保证时间轴也对得上）
    gtable = load_glossary()
    if gtable:
        hit = 0
        for s in segs:
            before = s["text"]
            s["text"] = apply_glossary(before, gtable)
            if s["text"] != before:
                hit += 1
        print(f"      术语表纠正 {hit} 句（共 {len(gtable)} 条规则）")

    full_text = "".join((s.get("text") or "").strip() for s in segs)
    paras = make_paragraphs(segs)
    keys = keyword_hits(full_text)

    slug = slugify(real_title)
    md_path = OUT / f"{slug}.md"
    json_path = OUT / f"{slug}.json"
    txt_path = OUT / f"{slug}.txt"

    data = {
        "title": real_title,
        "url": meta.get("webpage_url") or url,
        "uploader": meta.get("uploader", ""),
        "upload_date": meta.get("upload_date", ""),
        "duration": meta.get("duration", 0),
        "source": source,
        "language": lang_used,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "paragraphs": paras,
        "segments": segs,
    }
    json_path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")

    txt_path.write_text("\n\n".join(p["text"] for p in paras), encoding="utf-8")

    lines = [
        f"# {real_title}",
        "",
        f"- 来源：{data['url']}",
        f"- 作者：{data['uploader'] or '未知'}",
        f"- 时长：{fmt_ts(data['duration'])}" if data["duration"] else "",
        f"- 抓取方式：{source}",
        f"- 生成时间：{data['generated_at']}",
        "",
    ]
    if keys:
        lines += [f"**关键词**：{'、'.join(keys)}", ""]
    lines += ["---", ""]
    for p in paras:
        lines.append(f"**[{fmt_ts(p['start'])}]** {p['text']}")
        lines.append("")
    md_path.write_text("\n".join(l for l in lines if l is not None), encoding="utf-8")

    print(f"\n✅ 完成")
    print(f"  文稿：{md_path}")
    print(f"  纯文本：{txt_path}")
    print(f"  结构化：{json_path}")
    print(f"  字符数：{len(full_text)}｜段落：{len(paras)}｜方式：{source}")
    return 0


def main():
    ap = argparse.ArgumentParser(description="一条链接进，一份中文稿出")
    ap.add_argument("url")
    ap.add_argument("--mode", default="auto", choices=["auto", "subtitle", "audio"])
    ap.add_argument("--title", default=None, help="自定义输出标题/文件名")
    ap.add_argument("--lang", default=None, help="源语言：zh / en / ja …")
    ap.add_argument("--model", default="medium", help="whisper 模型：tiny/base/small/medium")
    ap.add_argument("--cookies-from-browser", default="", help="从哪个浏览器取登录态：chrome/safari/edge")
    a = ap.parse_args()
    return run(a.url, a.mode, a.title, a.lang, a.model, a.cookies_from_browser)


if __name__ == "__main__":
    sys.exit(main())
