#!/usr/bin/env bash
# 「拉片分析师」装机自检：在临时目录跑一条完整的拉片链，全绿才算装好。
# 用法: selfcheck.sh
# 不联网、不花钱、不调模型判断——只验脚本、依赖、产出是否真的能生成。
set -uo pipefail
export PATH="$HOME/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VS="$HOME/.agents/skills/video-shots"
VSJS="$VS/scripts/video-shots.mjs"
PASS=0; FAIL=0; WARN=0
ok(){   PASS=$((PASS+1)); echo "  PASS $1"; }
no(){   FAIL=$((FAIL+1)); echo "  FAIL $1"; }
warn(){ WARN=$((WARN+1)); echo "  WARN $1"; }

echo "== 1 文件与依赖 =="
for f in "$VSJS" "$SKILL_DIR/scripts/grab.py" "$SKILL_DIR/payload/拉片分析台.html" "$SKILL_DIR/payload/头像.png"; do
  [ -f "$f" ] && ok "存在 $(basename "$f")" || no "缺 $f"
done
command -v node >/dev/null 2>&1 && ok "node $(node -v)" || no "缺 node"
command -v ffmpeg >/dev/null 2>&1 && ok "ffmpeg 可用" || no "缺 ffmpeg"
command -v ffprobe >/dev/null 2>&1 && ok "ffprobe 可用" || no "缺 ffprobe"
command -v python3 >/dev/null 2>&1 && ok "python3 可用" || no "缺 python3"

echo "== 2 转写线（有就用，没有只报 WARN）=="
if python3 -c "import faster_whisper" >/dev/null 2>&1; then
  ok "faster-whisper 可导入（转写线就绪）"
else
  warn "无 faster-whisper：拉片线不受影响，转写不可用（pip3 install faster-whisper）"
fi
python3 "$SKILL_DIR/scripts/grab.py" --help >/dev/null 2>&1 && ok "grab.py 能跑" || no "grab.py 跑不起来"

if command -v node >/dev/null 2>&1 && command -v ffmpeg >/dev/null 2>&1 && [ -f "$VSJS" ]; then
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  # video-shots 的 frames / sheet 按「当前工作目录」写 frames/ 和 sheets/，所以整条链都在 $TMP 里跑
  vs(){ ( cd "$TMP" && node "$VSJS" "$@" ); }

  echo "== 3 合成演示片（12 秒 / 设计 5 镜 4 刀）=="
  if bash "$SKILL_DIR/scripts/make_demo.sh" "$TMP/demo.mp4" >/dev/null 2>&1 && [ -s "$TMP/demo.mp4" ]; then
    ok "演示片已生成"
  else
    no "演示片生成失败（ffmpeg 滤镜或编码有问题）"
  fi

  if [ -s "$TMP/demo.mp4" ]; then
    echo "== 4 场景检测（切点必须量出来）=="
    vs seed demo.mp4 --track track.json --title "自检片" > "$TMP/shots.json" 2>/dev/null
    CUTS="$(python3 -c "
import json;d=json.load(open('$TMP/shots.json'));print(','.join(f'{c:.1f}' for c in d['seedCuts']))")"
    N="$(python3 -c "import json;print(len(json.load(open('$TMP/shots.json'))['shots']))")"
    [ "$CUTS" = "2.4,4.8,7.2,9.6" ] && ok "切点 2.4/4.8/7.2/9.6 全部检出" || no "切点不对：实得 [$CUTS]，应为 2.4,4.8,7.2,9.6"
    [ "$N" = "5" ] && ok "镜数 5" || no "镜数是 $N，应为 5"

    echo "== 5 抽帧与联系表 =="
    FOUT="$(vs frames shots.json --video demo.mp4 2>&1)"
    FC="$(ls "$TMP/frames" 2>/dev/null | grep -c jpg)"
    [ "$FC" = "10" ] && ok "关键帧 10 张（每镜首尾各一）" \
      || no "关键帧 $FC 张，应为 10｜报错：$(echo "$FOUT" | tail -2 | tr '\n' ' ')"
    SOUT="$(vs sheet shots.json --cols 3 --rows 2 2>&1)"
    [ -f "$TMP/sheets/sheet-a01.jpg" ] && ok "联系表已拼出" \
      || no "联系表没生成｜报错：$(echo "$SOUT" | tail -2 | tr '\n' ' ')"

    echo "== 6 15 道质量门 =="
    python3 - "$TMP/shots.json" <<'PY'
import json,sys
p=sys.argv[1]; d=json.load(open(p))
sizes=['medium','close','wide','medium-close','close']
for i,s in enumerate(d['shots']):
    s['size']=sizes[i%len(sizes)]; s['category']='subject'; s['camera']='static'
    s['frame']=f'合成测试第{i+1}段：整幅底色上有一块方块沿水平方向移动，位置在中段偏上'
    s['onscreenText']=''; s['audio']=''
json.dump(d,open(p,'w'),ensure_ascii=False,indent=2)
PY
    grep -q '"size": "medium"' "$TMP/shots.json" && ok "四个判断字段可写入" || no "字段写入失败"
    VOUT="$(vs validate shots.json --track track.json --frames frames 2>&1)"
    if echo "$VOUT" | grep -q "❌"; then
      no "有门没过：$(echo "$VOUT" | grep '❌' | head -3 | tr '\n' ' ')"
    else
      ok "没有门报错"
    fi
    GATES="$(echo "$VOUT" | grep -cE '✅|⊘')"
    [ "$GATES" = "15" ] && ok "15 道门全部给出结论" || no "门只有 $GATES 条结论，应为 15"
    echo "$VOUT" | grep -q "⊘ 关键帧齐全" && no "关键帧门被跳过（说明抽帧真的没成）" || ok "关键帧门真检查了，不是跳过"
    echo "$VOUT" | grep -q "✅ 运镜实测对账" && ok "运镜实测对账门在跑" || no "运镜实测对账门缺失"

    echo "== 7 出镜头表与报告 =="
    vs render shots.json --md --track track.json > "$TMP/shots.md" 2>/dev/null
    grep -q "镜头表" "$TMP/shots.md" && ok "Markdown 镜头表已生成" || no "Markdown 镜头表异常"
    vs render shots.json --html --track track.json > "$TMP/report.html" 2>/dev/null
    HS="$(wc -c < "$TMP/report.html" 2>/dev/null | tr -d ' ')"
    if [ "${HS:-0}" -gt 20000 ]; then ok "交互式报告 $HS 字节"; else no "报告太小或没生成（${HS:-0} 字节）"; fi
    grep -q "frames/S01a.jpg" "$TMP/report.html" && ok "报告引用了关键帧" || warn "报告没引用关键帧路径（可能版本差异）"
  fi
else
  warn "缺 node/ffmpeg/video-shots，跳过第 3–7 项端到端测试"
fi

echo
echo "== 结果：PASS $PASS · FAIL $FAIL · WARN $WARN =="
if [ "$FAIL" -gt 0 ]; then
  echo "NOT READY 有 $FAIL 项没过，别对外说装好了。"
  exit 1
fi
echo "READY 自检全过，可以建 Bot 了。"
