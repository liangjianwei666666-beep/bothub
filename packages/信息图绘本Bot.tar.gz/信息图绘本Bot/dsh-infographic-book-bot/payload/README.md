# 信息图绘本 Bot

这个工作台把复杂主题做成高密度信息图绘本，并输出无声翻页展示片。

## 快速开始

1. 每个跨页准备左右两张独立的 1024×1536 页面图。
2. 文件放在项目目录 `raw/pages/L1.png`、`R1.png`、`L2.png`、`R2.png`……。
3. 执行：

```bash
python3 bin/compose_pages.py
python3 bin/tools_check.py raw/pages/L1.png raw/pages/R1.png
```

4. 用绘本工坊的 `build.py` 构建网页，再用 `templates/cinema-flip/` 制作无声视频。

## 目录

- `prompts/`：页面提示词模板
- `templates/`：制作规范
- `bin/`：拼页、OCR 和像素验收脚本
- `项目/`：每本绘本的独立目录

不在文件中保存任何 API Key 或登录信息。
