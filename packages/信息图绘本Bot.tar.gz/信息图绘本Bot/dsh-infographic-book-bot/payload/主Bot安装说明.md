# 主 Bot 自动安装说明

用户把 `dsh-infographic-book-bot.tar.gz` 发来并说“装一个信息图绘本 Bot”时，按下面步骤执行，不要只回复说明：

## 1. 解包

```bash
mkdir -p ~/.agents/skills
tar -xzf <收到的压缩包> -C ~/.agents/skills
```

解包后应存在：

```text
~/.agents/skills/dsh-infographic-book-bot/SKILL.md
```

## 2. 安装工作台

```bash
bash ~/.agents/skills/dsh-infographic-book-bot/scripts/install.sh
```

默认工作目录：`~/信息图绘本工作台`。用户指定目录时，把目录作为第一个参数传给脚本。

## 3. 跑自检

```bash
python3 ~/.agents/skills/dsh-infographic-book-bot/scripts/selfcheck.py ~/信息图绘本工作台
```

自检未通过，不得说“安装完成”。

## 4. 创建 Bot

使用 `create_bot` 创建：

- name：`信息图绘本师`
- role：`绘本`
- work_dir：安装脚本使用的工作目录绝对路径
- model：不填，跟随主 Bot 当前模型
- instructions：读取并原样传入 `~/.agents/skills/dsh-infographic-book-bot/payload/BOT_INSTRUCTIONS.md`

## 5. 告知用户

必须告诉用户：

- Bot 名称和工作目录；
- 自检是否通过；
- 生图 Key 不在安装包内；
- 没有 Key 时可以处理已有图片、拼页、构建和验收，但不能调用图像模型生成新图；
- Bot 不代用户登录或发布。
