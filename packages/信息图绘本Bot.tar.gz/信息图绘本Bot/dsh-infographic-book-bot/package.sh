#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${ROOT}/../dsh-infographic-book-bot.tar.gz"
find "$ROOT" -name '.DS_Store' -delete
find "$ROOT" -name '__pycache__' -type d -prune -exec rm -rf {} +
if find "$ROOT" -type f \( -name '*.env' -o -name '*.pem' -o -name '*api-key*' -o -name '*secret*' \) | grep -q .; then
  echo '✗ 包内发现疑似密钥文件，停止打包'
  exit 1
fi
rm -f "$OUT"
cd "$(dirname "$ROOT")"
tar --exclude='.DS_Store' -czf "$OUT" "$(basename "$ROOT")"
printf '打包完成：%s\n' "$OUT"
printf '体积：'; du -h "$OUT" | cut -f1
printf '文件数：'; tar -tzf "$OUT" | grep -vc '/$'
