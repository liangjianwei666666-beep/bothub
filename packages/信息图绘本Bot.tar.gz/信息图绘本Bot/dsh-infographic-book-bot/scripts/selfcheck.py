#!/usr/bin/env python3
import os, sys
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path.home()/"信息图绘本工作台"
required=[root/'README.md',root/'prompts/页面提示词模板.md',root/'templates/信息图绘本制作流程.md',root/'bin/compose_pages.py',root/'bin/tools_ocr.py',root/'bin/tools_check.py']
missing=[str(p) for p in required if not p.exists()]
if missing:
    print('✗ 缺少文件：')
    print('\n'.join(missing)); raise SystemExit(1)
print('✓ 文件结构完整')
try:
    import PIL
    print('✓ Pillow 可用')
except Exception:
    print('· Pillow 未安装：已有图片仍可使用，生成和拼页需要 Pillow')
print('· 生图 Key 不在安装包内，由用户本机单独配置')
print('✓ 自检通过')
