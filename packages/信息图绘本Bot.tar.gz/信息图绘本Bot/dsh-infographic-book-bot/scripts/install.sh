#!/bin/bash
set -uo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${1:-$HOME/信息图绘本工作台}"
mkdir -p "$WORK"
cp "$BASE/payload/README.md" "$WORK/README.md"
cp -R "$BASE/payload/prompts" "$WORK/prompts"
cp -R "$BASE/payload/templates" "$WORK/templates"
cp -R "$BASE/payload/信息图绘本工作台/bin" "$WORK/bin"
chmod +x "$WORK/bin/"*.py 2>/dev/null || true
printf '\n信息图绘本 Bot 工作台已安装：%s\n' "$WORK"
printf '下一步：运行 python3 %s/scripts/selfcheck.py %s\n' "$BASE" "$WORK"
