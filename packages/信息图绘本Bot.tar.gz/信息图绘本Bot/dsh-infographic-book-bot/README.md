# 信息图绘本 Bot 安装包

把这个压缩包直接发给别人的主 Bot，并说：

> 给你发了个包，装一个信息图绘本 Bot。

主 Bot 应该：

1. 解压这个包；
2. 运行 `scripts/install.sh`；
3. 运行 `scripts/selfcheck.py`；
4. 使用 `create_bot` 创建一个 Bot：
   - 名称：`信息图绘本师`
   - 角色：`绘本`
   - 工作目录：安装脚本输出的工作目录
   - instructions：原样使用 `payload/BOT_INSTRUCTIONS.md`
5. 把安装结果、工作目录和是否缺少生图 Key 告诉用户。

## 这个 Bot 做什么

把复杂主题做成高密度、整页表达的信息图绘本：左右两张独立页面生成，再拼成跨页，避免中文和图示压在书脊上；最后可构建本地电子绘本和无声 3D 翻页展示片。

## 分发

当前目录外层执行：

```bash
bash package.sh
```

会生成 `dsh-infographic-book-bot.tar.gz`。包内不包含任何密钥。

## 依赖

- Python 3
- Pillow（拼页和图片验收需要）
- Node.js + Playwright（构建翻页视频时需要）
- TelangpuAI 生图 Key（只有生成新图时需要）
