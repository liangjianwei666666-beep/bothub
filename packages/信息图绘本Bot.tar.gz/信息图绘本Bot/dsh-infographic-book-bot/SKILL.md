---
name: dsh-infographic-book-bot
description: 一键装配「信息图绘本 Bot」。把一个复杂主题做成高密度、杂志感的整页信息图绘本，并输出电子绘本、无声翻页展示片和可验证交接包。
---

# 信息图绘本 Bot 安装包

这个安装包给主 Bot 使用。别人把压缩包发给自己的主 Bot，并说：

> 给你发了个包，装一个信息图绘本 Bot。

主 Bot 应自动解包、运行安装脚本、跑自检，然后创建名为「信息图绘本师」的 Bot。

## 安装流程

```bash
bash scripts/install.sh
python3 scripts/selfcheck.py
```

也可以指定工作目录：

```bash
bash scripts/install.sh ~/信息图绘本工作台
python3 scripts/selfcheck.py ~/信息图绘本工作台
```

安装完成后，主 Bot 使用 `create_bot` 创建：

- name：`信息图绘本师`
- role：`绘本`
- work_dir：安装脚本输出的工作目录
- model：不填，跟随主 Bot 当前模型

完整 instructions 在 `payload/BOT_INSTRUCTIONS.md`，创建 Bot 时原样传入。

## 包内能力

- 图像模型生成 1024×1536 独立整页信息图
- 左右两张独立页面拼成 3600×2400 跨页，避免模型文字压书脊
- 中文 OCR 校验（macOS Vision，能用则启用）
- 中文提示词、结构化信息图页面规划
- 本地电子绘本构建
- 无声 3D 翻页展示片
- 4K / 1080p 视频输出
- 像素、OCR、编码和页面顺序验收

## 安全边界

- 包内不含任何 API Key、密码或登录态。
- 生图需要用户本机配置 TelangpuAI 生图 Key；没有 Key 时可以编辑、拼页、构建和验收已有图片。
- 不替用户登录任何账号，不操作第三方平台发布。
- 外部资料必须区分已核实与判断，查不到就明说。

## 可验证交接

每次交付必须给出：

1. 交付物绝对路径；
2. 四页内容与每页要点；
3. OCR、画面、视频编码和页面顺序验收结果；
4. 哪些部分没有人工目视验证；
5. 下一步由谁接手。
