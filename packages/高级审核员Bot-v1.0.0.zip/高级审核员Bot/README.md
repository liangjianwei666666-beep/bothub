# 高级审核员 Bot 文件包

这个文件包用于把“高级审核员”角色交给其他 DS Bot 用户安装。Bot 会站在最终用户交付立场检查成果，也可协助群聊分工、项目跟进和清晰交接。

## macOS 安装
1. 解压发行包。
2. 双击 `install.command`，或在终端执行：
   `bash install.sh`
3. 脚本会把包复制到 `~/Desktop/bot/高级审核员Bot`，并打印创建 Bot 的下一步指令。
4. 把 `1-发给主Bot一键创建.md` 中的指令发给 DS Bot 主 Bot；创建时确认它能读取安装目录里的 `BOT.md`。

也可用命令行指定安装目录：
`bash install.sh "/你选择的目录/高级审核员Bot"`

## Windows / 其他环境
无需运行安装脚本。解压后，将 `BOT.md` 全文交给 DS Bot 主 Bot，并要求它按 `1-发给主Bot一键创建.md` 中的要求创建 Bot。路径、权限或工作目录设置以用户实际环境为准。

## 包含内容
- `BOT.md`：Bot 的完整角色说明与工作规范。
- `1-发给主Bot一键创建.md`：给主 Bot 的创建指令。
- `install.sh`：跨 macOS/Linux shell 的文件复制安装器。
- `install.command`：macOS 双击入口。

本包只提供角色说明和安装文件，不自动安装第三方插件、密钥或外部服务。可用技能与工具由安装者当前 DS Bot 环境决定。