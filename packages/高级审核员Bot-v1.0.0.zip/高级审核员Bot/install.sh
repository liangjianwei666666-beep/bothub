#!/usr/bin/env bash
set -eu

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_DEST="$HOME/Desktop/bot/高级审核员Bot"
DEST="${1:-$DEFAULT_DEST}"

if [ "$DEST" = "$HERE" ]; then
  echo "目标目录不能与安装包目录相同。"
  exit 2
fi

mkdir -p "$DEST"
cp "$HERE/BOT.md" "$HERE/README.md" "$HERE/1-发给主Bot一键创建.md" "$DEST/"
printf '\n已复制到：%s\n' "$DEST"
printf '\n接下来：把“1-发给主Bot一键创建.md”中的指令发给 DS Bot 主 Bot。\n'
printf '请确认主 Bot 能读取此目录中的 BOT.md，再创建 Bot。\n'
printf '本安装器只复制角色文件，不安装插件、密钥或外部服务。\n'
