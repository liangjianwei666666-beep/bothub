#!/usr/bin/env bash
HERE="$(cd "$(dirname "$0")" && pwd)"
exec /bin/bash "$HERE/install.sh" "$@"
