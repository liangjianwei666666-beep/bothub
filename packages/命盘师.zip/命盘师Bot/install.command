#!/usr/bin/env bash
cd "$(dirname "$0")" && bash install.sh
echo
echo "按回车关闭窗口……"
read -r _
