#!/usr/bin/env bash
# 命盘师 Bot 安装脚本
# 用法：双击 install.command，或在终端里执行 bash install.sh
set -u

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$HERE/skills/mingpan"

echo "命盘师 Bot · 安装"
echo "安装目录：$HERE"
echo

# 1. 找一个可用的 python3
PY=""
for candidate in python3.12 python3.11 python3.10 python3.9 python3; do
    if command -v "$candidate" >/dev/null 2>&1; then
        if "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
            PY="$candidate"
            break
        fi
    fi
done

if [ -z "$PY" ]; then
    echo "✗ 没找到 Python 3.9 或更高版本。"
    echo "  macOS 可以执行：xcode-select --install（装完自带 python3）"
    echo "  或到 https://www.python.org/downloads/ 下载安装。"
    exit 1
fi
echo "✓ Python：$("$PY" --version 2>&1)"

# 2. 装依赖 lunar-python
if "$PY" -c 'import lunar_python' 2>/dev/null; then
    echo "✓ lunar-python：已安装"
else
    echo "· 正在安装 lunar-python（只装一次，几秒钟）……"
    if "$PY" -m pip install --user --quiet --disable-pip-version-check -r "$HERE/requirements.txt"; then
        echo "✓ lunar-python：安装完成"
    else
        echo "✗ lunar-python 安装失败。手动执行："
        echo "  $PY -m pip install --user -r \"$HERE/requirements.txt\""
        exit 1
    fi
fi

# 3. 跑自检
echo
echo "· 自检中……"
echo
"$PY" "$SKILL_DIR/scripts/doctor.py"
DOCTOR=$?
echo

if [ $DOCTOR -ne 0 ]; then
    echo "✗ 自检未通过，先按上面的提示处理。"
    exit 1
fi

# 4. 打印要粘给主助手的内容
cat <<EOF
========================================
装好了。下面两步：

1. 打开「2-主助手一键创建.md」，在「复制开始 / 复制结束」之间的内容里，
   把 SKILL_PATH 那一行换成：

   $SKILL_DIR

   然后把整段粘给 DS Bot 的主助手，它会建出一个「命盘师」Bot。

2. 建好后直接跟命盘师说你的出生信息就行。
========================================
EOF
