---
name: mingpan
description: Generate comprehensive Chinese BaZi / Four Pillars natal charts and professional psychology-oriented analysis reports from birth date-time, timezone, latitude, and longitude, delivered by default as a polished standalone HTML document whose main body is a psychology-first analysis report, with chart data kept to a compact summary and a collapsed technical appendix. Includes true solar time adjustment (including China's 1986-1991 DST), structured pillars, hidden stems, ten gods, weighted five elements, day-master strength, ten-god distribution, Na Yin, void branches, twelve growth phases, combinations/clashes/punishments, luck cycles, current luck cycle and annual flow, explicit boundary warnings, and a grounded psychological interpretation covering personality dynamics, motivation, stress patterns, relationship style, career fit, growth work, and practical recommendations. Use when the user asks for 命盘, 八字排盘, 四柱, 真太阳时, 大运流年, 五行旺衰, 用神喜忌, 心理分析报告, 性格分析, HTML报告, or a 问真-like birth chart and reading from birth time and coordinates.
---

# Mingpan

Create a psychology-first analysis report grounded in a BaZi chart. The chart is the evidence layer; the report is the product. By default, deliver a standalone HTML document saved to disk and give the user a clickable file link. Chart tables, weights, ten gods, corrections and warnings live in a compact header strip and a collapsed appendix, not in the reading. Treat the result as cultural/reflective analysis, not clinical diagnosis, medical, legal, financial, or fatalistic advice.

## Workflow

1. Ask the user for these fields every time before generating a report:
   - 姓名.
   - 性别.
   - 出生日期和时间, preferably Gregorian date and clock time.
   - 具体出生地, preferably down to city/district/county/town or hospital.

   If the user already provided some fields, only ask for the missing critical fields. If the name is missing but the user asks to proceed, use "未提供姓名" in the HTML report.

   **Coordinates rule**: never guess latitude/longitude from memory. Resolve the birthplace with a reliable map/source, or ask the user to confirm the nearest city. State the coordinate source and precision in the report (e.g. "县城中心坐标，误差约 5 公里，真太阳时误差 < 1 分钟"). Default to `Asia/Shanghai` for mainland China unless the birthplace/timezone indicates otherwise. Default to true solar time when a birthplace or coordinates are available.

2. Resolve the skill directory once, then run `scripts/generate_bazi_chart.py`. Do not hardcode any plugin-root environment variable; use the directory that actually contains this `SKILL.md`.

```bash
SKILL_DIR=/absolute/path/to/skills/mingpan   # the folder containing this SKILL.md

python3 "$SKILL_DIR/scripts/generate_bazi_chart.py" \
  --datetime "1990-01-01 12:00:00" \
  --timezone "Asia/Shanghai" \
  --latitude 31.2304 \
  --longitude 121.4737 \
  --place "上海市" \
  --gender male \
  --reference-date "2026-10-21" \
  --output /tmp/mingpan.json
```

   - `--reference-date` fixes the reference day for "current luck cycle / current annual flow". Pass today's date unless the user asks about a specific year. It keeps output reproducible.
   - `--no-true-solar-time` only when the user explicitly wants clock time.
   - If the script reports a missing dependency, install `lunar-python` (`python3 -m pip install --user -r requirements.txt`) or tell the user the deterministic calculation cannot be completed yet.

3. Read the JSON **before** writing the reading, and start from `warnings`:
   - `dst_applied`: the birth moment fell inside a DST period (e.g. China 1986-1991). The script already restored standard time; say so instead of silently converting twice.
   - `dst_transition`: the clock reading falls in a DST switch gap or overlap; the reading may not exist or may have two interpretations. Ask the user to confirm the recorded clock time.
   - `shichen_boundary` / `jieqi_boundary`: hour or month pillar is sensitive to a few minutes of birth-time error. Mark it explicitly.
   - `late_zi_hour`: 23:00-23:59 births have a day-pillar school difference.
   - `hour_pillar_changed`: true solar time changed the hour pillar; report both clock and adopted hour pillars.
   - `gender_unknown`: luck cycles are absent; do not fabricate them.

4. Read `references/interpretation-guide.md` when composing a full professional reading or psychological analysis report. Use the JSON from the script as the source of truth. For a full report, meet the professional standard in `references/professional-report-standard.md`.

5. Draft the report as Markdown in a temporary `.md` file, **psychology first**. A full report is roughly 3,000–6,000 Chinese characters. Follow the section plan in `references/interpretation-guide.md`. The renderer supports headings, paragraphs, bold/italic/code/links, ordered and nested lists, blockquotes, tables, horizontal rules, and fenced code.

6. Render the final document with `scripts/render_html_report.py`:

```bash
python3 "$SKILL_DIR/scripts/render_html_report.py" \
  --chart /tmp/mingpan.json \
  --markdown /tmp/mingpan-report.md \
  --output /tmp/mingpan-report.html \
  --name "未提供姓名" \
  --title "心理特征分析报告"
```

7. The HTML is deliberately report-first:
   - **Main document** (your Markdown): the psychological analysis. This is the product the user asked for.
   - **Compact chart context** (rendered automatically, keep it small): cover seal (日主 / 月令), one metadata strip (出生时间 / 出生地 / 四柱 / 当前大运 / 当前流年), and a **collapsed appendix** holding four pillars, element weights, ten gods, strength, relations, time corrections, warnings, and luck tables.
   - Do not duplicate the appendix tables inside the body, and do not walk through chart fields one by one. Write about the person, with the chart as occasional evidence.

8. Give the final response as a short note with a clickable absolute path to the generated `.html` file.

## Report Shape And Depth

A full report should read as one continuous analysis, not as a chart commentary.

- Default to second person ("你"). If the user is ordering for someone else, switch to third person and say whose report it is.
- Aim for 10–13 top-level sections, each 250–500 Chinese characters. A section that only restates a chart fact is too thin.
- Each section should carry at least three of these five moves: **具体现象** → **心理机制** → **现实代价** → **调节方式** → **可验证信号**. Prefer concrete scenes ("被临时加需求时，你先答应再后悔") over adjectives.
- Use at most one or two short chart clauses per section, e.g. "月令水旺、官星偏重". Never list hidden stems, Na Yin, growth phases, or correction steps in the body.
- Open with a short summary: 6–8 bullets, each specific enough that the reader could disagree with it.
- Close with a 30 天 / 90 天 / 一年 plan, 3–5 verifiable hypotheses, and one short 方法与边界 section.
- State the boundary once. Do not repeat "this is not a diagnosis" in every section.

## Data Layers And Honesty Rules

`generate_bazi_chart.py` emits three clearly separated layers. Label them correctly when writing:

| Layer | Fields | How to treat it |
| --- | --- | --- |
| Deterministic (lunar-python) | `bazi.pillars`, hidden stems, ten gods, `nayin`, `growth_phase`, `xun`/`xunkong`, `ming_gong`/`shen_gong`/`tai_yuan`/`tai_xi`, `luck.cycles` | Facts of the calculation; quote directly. |
| Time normalization | `time_corrections`, `calendar.previous_jie`/`next_jie`, `input.dst_*` | Explain the chain; note assumptions. |
| Derived / heuristic | `bazi.element_profile`, `missing_elements`, `day_master_strength`, `ten_god_stats`, `favorable_elements`, `warnings` | Directional estimates computed by script rules, not classical verdicts. Call them "启发式推导" / "参考方向" and never present as fixed 用神. |

Rules:

- Do not invent chart data absent from the script output. If a fact is missing (e.g. gender unknown), say it is unavailable.
- Do not claim a 格局 or 用神 with certainty. `favorable_elements` is a heuristic starting point; the report should present it as a hypothesis tied to chart evidence and to real-life calibration.
- Cite the anchor for each important claim, but keep it short: one clause naming a pillar, ten god, relation, or luck cycle. The appendix holds the detail.
- `calendar.current_jie` is `null` on non-jie days; that is expected. Use the `previous_jie` / `next_jie` interval instead of writing "None".
- `calendar.*_jie.datetime` values are in **UTC+08:00** (lunar-python's jieqi table), and each payload also carries `local_datetime` converted to the chart timezone. For births outside China, use `local_datetime` when stating the term time.

## Output Rules

- Do not invent chart data that is not present in the script output.
- Default to an HTML file deliverable. Only answer inline when the user explicitly asks for inline text or when file creation is impossible.
- Give the final response as a short note with a clickable absolute path to the generated `.html` file.
- Mark uncertain items explicitly, but once: a short 方法与边界 section covers warnings; the appendix shows the detail.
- Mention time corrections only when they change the reading (hour pillar changed, DST, boundary warning).
- Name the current 大运 and 当前流年 near the start or in the 当前阶段 section; if `luck` is null, say the luck layer is unavailable.
- Keep chart bookkeeping out of the body: no separate 五行统计 / 十神统计 / 纳音 / 校正流程 sections. Those are in the appendix.
- Avoid deterministic claims such as guaranteed death, illness, marriage, wealth, or disaster.
- Do not present the psychological report as a clinical diagnosis, psychiatric evaluation, or validated psychometric test. Use language such as "倾向", "可能", "在压力下容易", and "适合观察".
- When giving psychological suggestions, make them behavioral and practical: communication experiments, boundary-setting, recovery rhythms, work-design choices, journaling prompts, and relationship practices.
- If the user requests Western astrology, Vedic astrology, Zi Wei Dou Shu, or combined systems, state that this skill's reliable deterministic script is BaZi-first and use separate specialist tools or references for the other systems.
- Privacy: generated reports contain personal birth data. Keep them in a temporary or user-chosen location and do not commit real user charts to the repository.

## Quality Checklist

Before returning the file, verify:

- [ ] All four input fields were confirmed (or the missing one is explicitly stated).
- [ ] The body is roughly 3,000–6,000 Chinese characters and has 10–13 substantive sections.
- [ ] Every section offers at least three of: 现象 / 机制 / 代价 / 调节 / 验证. No section is a chart fact restated.
- [ ] Chart detail stays in the appendix; the body has no 五行/十神/纳音/校正 tables or term-by-term explanations.
- [ ] `warnings` are mentioned once in 方法与边界 (with the appendix holding detail), not repeated through the report.
- [ ] Current 大运 and 当前流年 are named with years and age.
- [ ] Any `favorable_elements.tension` (climate vs strength) is presented as a trade-off, not silently resolved.
- [ ] Relations mentioned in the body exist in `bazi.relations`.
- [ ] Derived fields are labelled as heuristic where they drive a claim.
- [ ] The report is specific enough to be disagreed with: concrete scenes, costs, and behaviours, not generic praise.
- [ ] No "必然/一定/大凶/命中注定", no clinical labels, no investment or medical advice.
- [ ] The HTML has no external CSS, fonts, images, JS libraries, or network requests, and opens offline.
- [ ] The final message contains the absolute `.html` path.

## Troubleshooting

- `Missing dependency: lunar-python`: run `python3 -m pip install --user -r requirements.txt` (requires Python 3.9+ because of `zoneinfo`).
- `Unknown IANA timezone`: use a tz database name such as `Asia/Shanghai`, `Asia/Hong_Kong`, `Asia/Taipei`, `America/New_York`; do not pass `GMT+8`.
- Historical China DST (1986-1991) is handled automatically by the IANA database; the script reports `dst_applied` and removes the artificial hour before computing true solar time.
- Birth time near midnight: check `warnings` for `late_zi_hour` / `shichen_boundary` and state the alternative hour pillar in the report.
- Coordinates off by 1° of longitude shift true solar time by 4 minutes; near a 时辰 boundary that can change the hour pillar, so prefer city-center precision or better.

## Resources

- `scripts/generate_bazi_chart.py`: deterministic BaZi chart generator (schema v2.0, includes heuristic layer and warnings).
- `scripts/render_html_report.py`: standalone HTML document renderer for the final report.
- `scripts/doctor.py`: self-check; runs the pipeline on fictional sample data and reports what is broken. Run it first when a report fails to generate (`--json` for a machine-readable result).
- `references/interpretation-guide.md`: professional reading structure and quality bar.
- `references/professional-report-standard.md`: premium report structure, evidence rules, and tone requirements.
- `examples/`: fictional sample input, chart JSON, Markdown body, and rendered HTML.
- `tests/`: run with `python3 -m unittest discover -s tests -v`.
