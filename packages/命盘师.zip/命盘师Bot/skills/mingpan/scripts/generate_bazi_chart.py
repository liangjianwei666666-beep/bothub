#!/usr/bin/env python3
"""Generate a structured BaZi (Four Pillars) chart from birth time and coordinates.

The script is deliberately deterministic: it only reports what can be computed
from the birth moment and place, plus clearly labelled heuristic derivations
(element weighting, day-master strength, ten-god distribution, favourable
element direction). Interpretive judgement is left to the report writer.

Usage
-----
    python3 generate_bazi_chart.py \
        --datetime "1990-01-01 12:00:00" \
        --timezone "Asia/Shanghai" \
        --latitude 31.2304 --longitude 121.4737 \
        --place "上海市" --gender male \
        --output /tmp/mingpan.json

Optional:
    --reference-date "2026-10-21"   reference day used for current luck cycle
                                    and current annual flow (default: today)
    --no-true-solar-time            use clock time instead of true solar time

Output: a single JSON object (schema_version 2.0). See SKILL.md for the field
reference. Derived, non-classical fields are grouped under keys containing
"heuristic" or "reference" so the report writer can label them honestly.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    from lunar_python import Solar
except ImportError:  # pragma: no cover
    print(
        "Missing dependency: lunar-python. Install with: python3 -m pip install --user lunar-python",
        file=sys.stderr,
    )
    sys.exit(2)


SCHEMA_VERSION = "2.0"

# lunar-python 输出的节气时刻表按北京时间（UTC+8）给出，与排盘地时区无关。
JIEQI_TZ = timezone(timedelta(hours=8))

ELEMENTS = ["木", "火", "土", "金", "水"]

STEM_ELEMENT = {
    "甲": "木",
    "乙": "木",
    "丙": "火",
    "丁": "火",
    "戊": "土",
    "己": "土",
    "庚": "金",
    "辛": "金",
    "壬": "水",
    "癸": "水",
}

BRANCH_ELEMENT = {
    "子": "水",
    "丑": "土",
    "寅": "木",
    "卯": "木",
    "辰": "土",
    "巳": "火",
    "午": "火",
    "未": "土",
    "申": "金",
    "酉": "金",
    "戌": "土",
    "亥": "水",
}

# 阳干 / 阴干，用于判定十神与同性异性。
STEM_POLARITY = {
    "甲": "阳",
    "乙": "阴",
    "丙": "阳",
    "丁": "阴",
    "戊": "阳",
    "己": "阴",
    "庚": "阳",
    "辛": "阴",
    "壬": "阳",
    "癸": "阴",
}

# 五行生克：GENERATES[a] 为 a 所生，CONTROLS[a] 为 a 所克。
GENERATES = {"木": "火", "火": "土", "土": "金", "金": "水", "水": "木"}
CONTROLS = {"木": "土", "土": "水", "水": "火", "火": "金", "金": "木"}
GENERATED_BY = {value: key for key, value in GENERATES.items()}
CONTROLLED_BY = {value: key for key, value in CONTROLS.items()}

PILLAR_LABELS = {
    "year": "年柱",
    "month": "月柱",
    "day": "日柱",
    "hour": "时柱",
}

# 地支藏干权重：本气、中气、余气。lunar_python 的 HideGan 按此顺序返回。
HIDDEN_STEM_WEIGHTS = {1: [1.0], 2: [0.7, 0.3], 3: [0.6, 0.3, 0.1]}

# 柱位权重：月令最重（司令），日支为自我落点，年/时较轻。
PILLAR_ELEMENT_WEIGHT = {"year": 1.0, "month": 2.5, "day": 1.2, "hour": 1.0}

SEASON_BRANCHES = {
    "春": ["寅", "卯", "辰"],
    "夏": ["巳", "午", "未"],
    "秋": ["申", "酉", "戌"],
    "冬": ["亥", "子", "丑"],
}
SEASON_ELEMENT = {"春": "木", "夏": "火", "秋": "金", "冬": "水"}

STEM_COMBOS = {
    frozenset(["甲", "己"]): "合土",
    frozenset(["乙", "庚"]): "合金",
    frozenset(["丙", "辛"]): "合水",
    frozenset(["丁", "壬"]): "合木",
    frozenset(["戊", "癸"]): "合火",
}

# 天干相冲（戊己居中，无冲）。
STEM_CHONG = {
    frozenset(["甲", "庚"]): "甲庚冲",
    frozenset(["乙", "辛"]): "乙辛冲",
    frozenset(["丙", "壬"]): "丙壬冲",
    frozenset(["丁", "癸"]): "丁癸冲",
}

BRANCH_LIUHE = {
    frozenset(["子", "丑"]): "六合化土",
    frozenset(["寅", "亥"]): "六合化木",
    frozenset(["卯", "戌"]): "六合化火",
    frozenset(["辰", "酉"]): "六合化金",
    frozenset(["巳", "申"]): "六合化水",
    frozenset(["午", "未"]): "六合化土",
}

BRANCH_CHONG = {
    frozenset(["子", "午"]),
    frozenset(["丑", "未"]),
    frozenset(["寅", "申"]),
    frozenset(["卯", "酉"]),
    frozenset(["辰", "戌"]),
    frozenset(["巳", "亥"]),
}

BRANCH_HAI = {
    frozenset(["子", "未"]),
    frozenset(["丑", "午"]),
    frozenset(["寅", "巳"]),
    frozenset(["卯", "辰"]),
    frozenset(["申", "亥"]),
    frozenset(["酉", "戌"]),
}

BRANCH_PO = {
    frozenset(["子", "酉"]),
    frozenset(["丑", "辰"]),
    frozenset(["寅", "亥"]),
    frozenset(["卯", "午"]),
    frozenset(["巳", "申"]),
    frozenset(["未", "戌"]),
}

BRANCH_SANHE = {
    frozenset(["申", "子", "辰"]): "三合水局",
    frozenset(["亥", "卯", "未"]): "三合木局",
    frozenset(["寅", "午", "戌"]): "三合火局",
    frozenset(["巳", "酉", "丑"]): "三合金局",
}

BRANCH_SANHUI = {
    frozenset(["寅", "卯", "辰"]): "三会木方",
    frozenset(["巳", "午", "未"]): "三会火方",
    frozenset(["申", "酉", "戌"]): "三会金方",
    frozenset(["亥", "子", "丑"]): "三会水方",
}

# 半三合：三合局中含中神（子午卯酉）的两支。
BRANCH_BANHE = {
    frozenset(["申", "子"]): "半合水局",
    frozenset(["子", "辰"]): "半合水局",
    frozenset(["亥", "卯"]): "半合木局",
    frozenset(["卯", "未"]): "半合木局",
    frozenset(["寅", "午"]): "半合火局",
    frozenset(["午", "戌"]): "半合火局",
    frozenset(["巳", "酉"]): "半合金局",
    frozenset(["酉", "丑"]): "半合金局",
}

# 相刑：两两成刑的组合（三刑之局另见 BRANCH_XING_GROUPS）。
BRANCH_XING_PAIRS = {
    frozenset(["寅", "巳"]): "寅巳刑",
    frozenset(["巳", "申"]): "巳申刑",
    frozenset(["寅", "申"]): "寅申刑",
    frozenset(["丑", "戌"]): "丑戌刑",
    frozenset(["戌", "未"]): "戌未刑",
    frozenset(["丑", "未"]): "丑未刑",
    frozenset(["子", "卯"]): "子卯刑",
}

BRANCH_XING_GROUPS = {
    frozenset(["寅", "巳", "申"]): "无恩之刑",
    frozenset(["丑", "戌", "未"]): "恃势之刑",
}

SELF_XING = {"辰", "午", "酉", "亥"}


@dataclass
class BirthInput:
    dt: datetime
    timezone_name: str
    latitude: float
    longitude: float
    gender: str
    place: str
    true_solar_time: bool


# ---------------------------------------------------------------------------
# Time handling
# ---------------------------------------------------------------------------


def parse_datetime(value: str, timezone_name: str) -> datetime:
    text = value.strip().replace("T", " ")
    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
    ]
    parsed = None
    for fmt in formats:
        try:
            parsed = datetime.strptime(text, fmt)
            break
        except ValueError:
            pass
    if parsed is None:
        raise SystemExit(f"Unsupported datetime format: {value!r}")
    try:
        tz = ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError as exc:
        raise SystemExit(f"Unknown IANA timezone: {timezone_name!r}") from exc
    return parsed.replace(tzinfo=tz)


def parse_reference_date(value: str | None) -> date:
    if not value:
        return date.today()
    try:
        return datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except ValueError as exc:
        raise SystemExit(f"Unsupported reference date format: {value!r} (expected YYYY-MM-DD)") from exc


def dst_offset_minutes(dt: datetime) -> float:
    """Return the DST offset in minutes (0 when DST is not in force)."""
    delta = dt.dst() or timedelta(0)
    return round(delta.total_seconds() / 60, 2)


def standard_offset_minutes(dt: datetime) -> float:
    total = dt.utcoffset() or timedelta(0)
    return round((total - (dt.dst() or timedelta(0))).total_seconds() / 60, 2)


def equation_of_time_minutes(dt: datetime) -> float:
    """NOAA-style approximation of apparent solar time correction."""
    day = dt.timetuple().tm_yday
    hour = dt.hour + dt.minute / 60 + dt.second / 3600
    gamma = 2 * math.pi / 365 * (day - 1 + (hour - 12) / 24)
    return 229.18 * (
        0.000075
        + 0.001868 * math.cos(gamma)
        - 0.032077 * math.sin(gamma)
        - 0.014615 * math.cos(2 * gamma)
        - 0.040849 * math.sin(2 * gamma)
    )


def standard_meridian_degrees(dt: datetime) -> float:
    """Meridian of the zone's *standard* time (DST removed).

    Using the DST meridian (e.g. 135E for UTC+9) would silently absorb the
    one-hour clock shift into the longitude correction, which is wrong: DST is
    an artificial offset, true solar time is not.
    """
    return standard_offset_minutes(dt) / 60 * 15


def apparent_solar_datetime(standard_dt: datetime, longitude: float) -> tuple[datetime, float, float]:
    meridian = standard_meridian_degrees(standard_dt)
    longitude_minutes = 4 * (longitude - meridian)
    eot = equation_of_time_minutes(standard_dt)
    total = longitude_minutes + eot
    return standard_dt + timedelta(minutes=total), longitude_minutes, eot


def solar_from_datetime(dt: datetime) -> Solar:
    naive = dt.replace(tzinfo=None)
    return Solar.fromYmdHms(naive.year, naive.month, naive.day, naive.hour, naive.minute, naive.second)


def shichen_boundary_minutes(dt: datetime) -> int:
    """Minutes from dt to the nearest two-hour 时辰 boundary."""
    minutes = dt.hour * 60 + dt.minute
    remainder = (minutes - 60) % 120
    return min(remainder, 120 - remainder)


# ---------------------------------------------------------------------------
# Jieqi helpers
# ---------------------------------------------------------------------------


def jieqi_solar(obj) -> Solar | None:
    if obj is None:
        return None
    try:
        return obj.getSolar()
    except AttributeError:  # pragma: no cover - defensive
        return None


def solar_to_datetime(solar: Solar | None, tz: ZoneInfo) -> datetime | None:
    if solar is None:
        return None
    return datetime(
        solar.getYear(),
        solar.getMonth(),
        solar.getDay(),
        solar.getHour(),
        solar.getMinute(),
        solar.getSecond(),
        tzinfo=tz,
    )


def jieqi_payload(obj, reference: datetime) -> dict | None:
    if obj is None:
        return None
    solar = jieqi_solar(obj)
    moment = solar_to_datetime(solar, JIEQI_TZ)
    payload = {
        "name": obj.getName(),
        "datetime": moment.isoformat() if moment else None,
        "timezone": "UTC+08:00",
        "is_jie": bool(obj.isJie()),
        "is_qi": bool(obj.isQi()),
    }
    if moment is not None:
        delta_hours = (moment - reference).total_seconds() / 3600
        payload["offset_hours_from_chart_time"] = round(delta_hours, 2)
        payload["local_datetime"] = moment.astimezone(reference.tzinfo).isoformat()
    return payload


# ---------------------------------------------------------------------------
# Pillars and classical relations
# ---------------------------------------------------------------------------


def pillar(eight, key: str) -> dict:
    prefix = "Time" if key == "hour" else key.capitalize()
    gan = getattr(eight, f"get{prefix}Gan")()
    zhi = getattr(eight, f"get{prefix}Zhi")()
    return {
        "key": key,
        "label": PILLAR_LABELS[key],
        "gan": gan,
        "zhi": zhi,
        "ganzhi": gan + zhi,
        "polarity": STEM_POLARITY.get(gan),
        "stem_element": STEM_ELEMENT.get(gan),
        "branch_element": BRANCH_ELEMENT.get(zhi),
        "hidden_stems": getattr(eight, f"get{prefix}HideGan")(),
        "ten_god_stem": getattr(eight, f"get{prefix}ShiShenGan")(),
        "ten_god_hidden": getattr(eight, f"get{prefix}ShiShenZhi")(),
        "wuxing": getattr(eight, f"get{prefix}WuXing")(),
        "nayin": getattr(eight, f"get{prefix}NaYin")(),
        "growth_phase": getattr(eight, f"get{prefix}DiShi")(),
        "xun": getattr(eight, f"get{prefix}Xun")(),
        "xunkong": getattr(eight, f"get{prefix}XunKong")(),
    }


def ten_god(day_stem: str, other_stem: str) -> str:
    """Ten-god name of other_stem relative to the day master."""
    day_element = STEM_ELEMENT[day_stem]
    other_element = STEM_ELEMENT[other_stem]
    same_polarity = STEM_POLARITY[day_stem] == STEM_POLARITY[other_stem]
    if day_element == other_element:
        return "比肩" if same_polarity else "劫财"
    if GENERATES[day_element] == other_element:
        return "食神" if same_polarity else "伤官"
    if CONTROLS[day_element] == other_element:
        return "偏财" if same_polarity else "正财"
    if CONTROLS[other_element] == day_element:
        return "七杀" if same_polarity else "正官"
    return "偏印" if same_polarity else "正印"


def relation_item(kind: str, name: str, pillars: list[dict], items: list[str]) -> dict:
    return {
        "type": kind,
        "relation": name,
        "pillars": [item["label"] for item in pillars],
        "items": items,
    }


def relations(pillars: list[dict]) -> dict:
    pair_relations: list[dict] = []
    triple_relations: list[dict] = []
    self_relations: list[dict] = []

    for i, left in enumerate(pillars):
        for right in pillars[i + 1 :]:
            stem_pair = frozenset([left["gan"], right["gan"]])
            if stem_pair in STEM_COMBOS:
                pair_relations.append(
                    relation_item("天干五合", STEM_COMBOS[stem_pair], [left, right], [left["gan"], right["gan"]])
                )
            if stem_pair in STEM_CHONG:
                pair_relations.append(
                    relation_item("天干相冲", STEM_CHONG[stem_pair], [left, right], [left["gan"], right["gan"]])
                )

            branch_pair = frozenset([left["zhi"], right["zhi"]])
            items = [left["zhi"], right["zhi"]]
            if branch_pair in BRANCH_LIUHE:
                pair_relations.append(relation_item("地支六合", BRANCH_LIUHE[branch_pair], [left, right], items))
            if branch_pair in BRANCH_BANHE:
                pair_relations.append(relation_item("地支半合", BRANCH_BANHE[branch_pair], [left, right], items))
            if branch_pair in BRANCH_CHONG:
                pair_relations.append(relation_item("地支相冲", "冲", [left, right], items))
            if branch_pair in BRANCH_XING_PAIRS:
                pair_relations.append(relation_item("地支相刑", BRANCH_XING_PAIRS[branch_pair], [left, right], items))
            if branch_pair in BRANCH_HAI:
                pair_relations.append(relation_item("地支六害", "害", [left, right], items))
            if branch_pair in BRANCH_PO:
                pair_relations.append(relation_item("地支六破", "破", [left, right], items))

    branch_positions: dict[str, list[dict]] = {}
    for item in pillars:
        branch_positions.setdefault(item["zhi"], []).append(item)
    branch_set = set(branch_positions)

    for group, name in {**BRANCH_SANHE, **BRANCH_SANHUI}.items():
        if group.issubset(branch_set):
            members = [item for item in pillars if item["zhi"] in group]
            triple_relations.append(
                relation_item("地支三合/三会", name, members, [item["zhi"] for item in members])
            )
    for group, name in BRANCH_XING_GROUPS.items():
        if group.issubset(branch_set):
            members = [item for item in pillars if item["zhi"] in group]
            triple_relations.append(
                relation_item("地支三刑", name, members, [item["zhi"] for item in members])
            )
    for branch in sorted(SELF_XING):
        hits = branch_positions.get(branch, [])
        if len(hits) >= 2:
            self_relations.append(
                relation_item("地支自刑", f"{branch}{branch}自刑", hits, [branch for _ in hits])
            )

    summary = "；".join(
        f"{rel['relation']}（{'/'.join(rel['pillars'])}）"
        for rel in pair_relations + triple_relations + self_relations
    )
    return {
        "pairs": pair_relations,
        "triples": triple_relations,
        "self": self_relations,
        "summary": summary,
    }


# ---------------------------------------------------------------------------
# Element weighting and derived structure
# ---------------------------------------------------------------------------


def element_weight_profile(pillars: list[dict]) -> dict:
    """Weighted five-element profile: stems 1.0, branches via hidden stems,
    month branch multiplied by 2.5 (司令), day branch by 1.2."""
    raw = {element: 0.0 for element in ELEMENTS}
    surface = {element: 0 for element in ELEMENTS}
    hidden = {element: 0 for element in ELEMENTS}
    for item in pillars:
        multiplier = PILLAR_ELEMENT_WEIGHT.get(item["key"], 1.0)
        if item["stem_element"] in raw:
            raw[item["stem_element"]] += 1.0
            surface[item["stem_element"]] += 1
        stems = item["hidden_stems"]
        weights = HIDDEN_STEM_WEIGHTS.get(len(stems), [1.0 / len(stems)] * len(stems))
        for stem, weight in zip(stems, weights):
            element = STEM_ELEMENT.get(stem)
            if element in raw:
                raw[element] += weight * multiplier
                hidden[element] += 1
    total = sum(raw.values()) or 1.0
    profile = {}
    for element in ELEMENTS:
        profile[element] = {
            "surface": surface[element],
            "hidden": hidden[element],
            "weighted": round(raw[element], 2),
            "percent": round(raw[element] / total * 100, 1),
        }
    return profile


def element_counts(pillars: list[dict]) -> dict:
    """Legacy unweighted counts (surface / hidden / total)."""
    counts = {element: {"surface": 0, "hidden": 0, "total": 0} for element in ELEMENTS}
    for item in pillars:
        for element in [item["stem_element"], item["branch_element"]]:
            if element in counts:
                counts[element]["surface"] += 1
                counts[element]["total"] += 1
        for stem in item["hidden_stems"]:
            element = STEM_ELEMENT.get(stem)
            if element in counts:
                counts[element]["hidden"] += 1
                counts[element]["total"] += 1
    return counts


def season_state(month_branch: str, day_element: str) -> str:
    season_element = SEASON_ELEMENT.get(month_branch, "")
    if not season_element:
        for name, branches in SEASON_BRANCHES.items():
            if month_branch in branches:
                season_element = SEASON_ELEMENT[name]
                break
    if not season_element:
        return "未知"
    if day_element == season_element:
        return "旺"
    if GENERATES[season_element] == day_element:
        return "相"
    if GENERATES[day_element] == season_element:
        return "休"
    if CONTROLS[day_element] == season_element:
        return "囚"
    return "死"


def season_of(month_branch: str) -> str | None:
    for name, branches in SEASON_BRANCHES.items():
        if month_branch in branches:
            return name
    return None


def day_master_strength(profile: dict, day_element: str, month_branch: str) -> dict:
    resource = GENERATED_BY[day_element]
    peer = day_element
    output = GENERATES[day_element]
    wealth = CONTROLS[day_element]
    officer = CONTROLLED_BY[day_element]

    same = profile[peer]["weighted"] + profile[resource]["weighted"]
    different = profile[output]["weighted"] + profile[wealth]["weighted"] + profile[officer]["weighted"]
    total = same + different or 1.0
    ratio = same / total
    score = round(ratio * 100, 1)

    if ratio >= 0.55:
        label = "偏强"
    elif ratio <= 0.45:
        label = "偏弱"
    else:
        label = "中和"

    state = season_state(month_branch, day_element)
    return {
        "label": label,
        "score": score,
        "same_group_weight": round(same, 2),
        "different_group_weight": round(different, 2),
        "season_state": state,
        "supported_by_month": state in ("旺", "相"),
        "groups": {
            "比劫": peer,
            "印星": resource,
            "食伤": output,
            "财星": wealth,
            "官杀": officer,
        },
        "method": "heuristic_weights_v1",
        "note": "按天干 1.0、地支藏干本气/中气/余气 0.6/0.3/0.1、月令 ×2.5 的启发式权重估算，只作方向参考，不替代对全局结构的判断。",
    }


def ten_god_stats(pillars: list[dict], day_stem: str) -> list[dict]:
    entries: list[dict] = []
    for item in pillars:
        multiplier = PILLAR_ELEMENT_WEIGHT.get(item["key"], 1.0)
        if item["key"] != "day":
            entries.append(
                {
                    "ten_god": ten_god(day_stem, item["gan"]),
                    "pillar": item["label"],
                    "stem": item["gan"],
                    "weight": 1.0,
                    "source": "天干",
                    "label": f"{item['label']}干{item['gan']}",
                }
            )
        stems = item["hidden_stems"]
        weights = HIDDEN_STEM_WEIGHTS.get(len(stems), [1.0 / len(stems)] * len(stems))
        for stem, weight in zip(stems, weights):
            if item["key"] == "day" and stem == day_stem:
                continue
            entries.append(
                {
                    "ten_god": ten_god(day_stem, stem),
                    "pillar": item["label"],
                    "stem": stem,
                    "weight": round(weight * multiplier, 2),
                    "source": "藏干",
                    "label": f"{item['label']}支藏{stem}",
                }
            )

    total = sum(entry["weight"] for entry in entries) or 1.0
    grouped: dict[str, dict] = {}
    for entry in entries:
        bucket = grouped.setdefault(entry["ten_god"], {"ten_god": entry["ten_god"], "weight": 0.0, "sources": []})
        bucket["weight"] += entry["weight"]
        bucket["sources"].append(entry["label"])

    stats = []
    for name, bucket in grouped.items():
        stats.append(
            {
                "ten_god": name,
                "weight": round(bucket["weight"], 2),
                "percent": round(bucket["weight"] / total * 100, 1),
                "sources": bucket["sources"],
            }
        )
    stats.sort(key=lambda item: item["weight"], reverse=True)
    return stats


def favorable_elements(profile: dict, strength: dict, month_branch: str) -> dict:
    day_element = strength["groups"]["比劫"]
    resource = strength["groups"]["印星"]
    output = strength["groups"]["食伤"]
    wealth = strength["groups"]["财星"]
    officer = strength["groups"]["官杀"]

    if strength["label"] == "偏弱":
        primary = [resource, day_element]
        avoid = [officer, wealth, output]
        rationale = "日主偏弱，先取印星生扶与比劫帮身，少用耗泄克制的力量。"
    elif strength["label"] == "偏强":
        primary = [output, wealth, officer]
        avoid = [resource, day_element]
        rationale = "日主偏强，宜用食伤泄秀、财星耗身、官杀制衡，减少再增益同类。"
    else:
        primary = []
        avoid = []
        rationale = "日主接近中和，喜忌不必单边取用，重点看流通与调节。"

    # 调候：冬月寒、夏月燥，先调温润。
    season = season_of(month_branch)
    climate = None
    if season == "冬":
        climate = {"element": "火", "reason": "生于冬月，寒湿偏重，传统取火调候（暖局）。"}
    elif season == "夏":
        climate = {"element": "水", "reason": "生于夏月，燥热偏重，传统取水调候（润局）。"}

    candidates = []
    if climate:
        candidates.append(climate["element"])
    for element in primary:
        if element not in candidates:
            candidates.append(element)

    tension = None
    if climate and climate["element"] in avoid:
        tension = (
            f"调候取{climate['element']}与旺衰忌{climate['element']}存在张力："
            "寒暖优先还是强弱优先，需要结合全局结构判断，脚本不替你裁决。"
        )

    return {
        "method": "heuristic_weights_v1",
        "day_master": day_element,
        "primary": primary,
        "avoid": avoid,
        "climate": climate,
        "candidate_elements": candidates,
        "tension": tension,
        "rationale": rationale,
        "note": "喜忌方向由旺衰与月令启发式推导，只作自我观察与写作方向参考；正式取用需结合全局格局、通根透干与实际经历判断。",
    }


# ---------------------------------------------------------------------------
# Luck cycles
# ---------------------------------------------------------------------------


def luck_cycles(eight, gender: str, reference: date) -> dict | None:
    if gender == "unknown":
        return None
    gender_num = 1 if gender == "male" else 0
    yun = eight.getYun(gender_num, 1)
    cycles = []
    for dayun in yun.getDaYun():
        annual = [
            {"year": liunian.getYear(), "age": liunian.getAge(), "ganzhi": liunian.getGanZhi()}
            for liunian in dayun.getLiuNian()
        ]
        cycles.append(
            {
                "index": dayun.getIndex(),
                "ganzhi": dayun.getGanZhi(),
                "start_year": dayun.getStartYear(),
                "end_year": dayun.getEndYear(),
                "start_age": dayun.getStartAge(),
                "end_age": dayun.getEndAge(),
                "xun": dayun.getXun(),
                "xunkong": dayun.getXunKong(),
                "annual_flows": annual,
                "is_current": dayun.getStartYear() <= reference.year <= dayun.getEndYear(),
            }
        )

    current_cycle = next((cycle for cycle in cycles if cycle["is_current"]), None)
    current_flow = None
    if current_cycle:
        current_flow = next(
            (flow for flow in current_cycle["annual_flows"] if flow["year"] == reference.year),
            None,
        )

    return {
        "gender": gender,
        "forward": yun.isForward(),
        "start_after_birth": {
            "years": yun.getStartYear(),
            "months": yun.getStartMonth(),
            "days": yun.getStartDay(),
            "hours": yun.getStartHour(),
            "start_solar": str(yun.getStartSolar()),
        },
        "cycles": cycles,
        "reference_date": reference.isoformat(),
        "current": {
            "reference_year": reference.year,
            "cycle": current_cycle,
            "annual_flow": current_flow,
            "note": "流年干支为该公历年对应的年柱；公司/财务年度与农历年边界不同，跨年时段需说明。",
        },
    }


# ---------------------------------------------------------------------------
# Warnings (explicit uncertainty)
# ---------------------------------------------------------------------------


def build_warnings(
    birth: BirthInput,
    chart_dt: datetime,
    jie_prev: dict | None,
    jie_next: dict | None,
    hour_changed: bool,
) -> list[dict]:
    warnings: list[dict] = []

    dst_minutes = dst_offset_minutes(birth.dt)
    naive = birth.dt.replace(tzinfo=None)
    tzinfo = birth.dt.tzinfo
    offset_fold0 = naive.replace(tzinfo=tzinfo, fold=0).utcoffset()
    offset_fold1 = naive.replace(tzinfo=tzinfo, fold=1).utcoffset()
    if offset_fold0 != offset_fold1:
        warnings.append(
            {
                "code": "dst_transition",
                "level": "caution",
                "message": (
                    f"出生钟表时间落在夏令时切换的临界时段（{birth.timezone_name} 当日发生过拨钟），"
                    "该读数可能不存在或存在两种解释。请与家属核对当时的钟表读数与官方切换时刻，必要时改用切换后的时间重排。"
                ),
            }
        )

    if abs(dst_minutes) >= 1:
        warnings.append(
            {
                "code": "dst_applied",
                "level": "info",
                "message": (
                    f"出生时刻处于夏令时（{birth.timezone_name} 当时钟表拨快 {dst_minutes:.0f} 分钟）。"
                    "排盘已先还原为标准时间再计算真太阳时；若出生时间来自“夏令时期间的钟表时间”，无需再自行减一小时。"
                ),
            }
        )

    boundary = shichen_boundary_minutes(chart_dt)
    if boundary <= 15:
        warnings.append(
            {
                "code": "shichen_boundary",
                "level": "caution",
                "message": (
                    f"排盘时刻距时辰交界仅约 {boundary} 分钟，出生时间若有几分钟误差，时柱可能改变。"
                    "建议核对出生记录，并在报告中同时说明相邻时柱的可能性。"
                ),
            }
        )

    if chart_dt.hour == 23:
        warnings.append(
            {
                "code": "late_zi_hour",
                "level": "caution",
                "message": (
                    "出生在 23:00-23:59 的晚子时，日柱存在流派差异（是否进位到次日）。"
                    "本盘采用 lunar-python 默认规则，报告应注明这一处不确定性。"
                ),
            }
        )

    if jie_next and jie_next.get("offset_hours_from_chart_time") is not None:
        hours = jie_next["offset_hours_from_chart_time"]
        if 0 <= hours <= 24:
            warnings.append(
                {
                    "code": "jieqi_boundary",
                    "level": "caution",
                    "message": (
                        f"距下一个节气「{jie_next['name']}」约 {hours:.1f} 小时，月柱处于节气交界附近。"
                        "出生时间若不准，月柱可能落在前一节气，需在报告中显式标注。"
                    ),
                }
            )
    if jie_prev and jie_prev.get("offset_hours_from_chart_time") is not None:
        hours = jie_prev["offset_hours_from_chart_time"]
        if -24 <= hours <= 0:
            warnings.append(
                {
                    "code": "jieqi_boundary_recent",
                    "level": "info",
                    "message": (
                        f"刚过节气「{jie_prev['name']}」约 {abs(hours):.1f} 小时，月柱已换节气，属正常但值得核对出生时间。"
                    ),
                }
            )

    if hour_changed:
        warnings.append(
            {
                "code": "hour_pillar_changed",
                "level": "info",
                "message": "真太阳时校正改变了时柱，报告需说明钟表时柱与采用时柱的差异。",
            }
        )

    if not birth.true_solar_time:
        warnings.append(
            {
                "code": "true_solar_time_disabled",
                "level": "info",
                "message": "本次排盘使用钟表时间，未按经度与均时差校正；出生地经度偏差较大时，时柱可能不同。",
            }
        )

    if not birth.place:
        warnings.append(
            {
                "code": "missing_place",
                "level": "info",
                "message": "未提供出生地名称，仅使用经纬度；报告中应说明坐标来源与精度。",
            }
        )

    if birth.gender == "unknown":
        warnings.append(
            {
                "code": "gender_unknown",
                "level": "info",
                "message": "未提供性别，无法计算大运起运方向与运程；报告中不应编造大运信息。",
            }
        )

    return warnings


# ---------------------------------------------------------------------------
# Chart assembly
# ---------------------------------------------------------------------------


def build_chart(args: argparse.Namespace) -> dict:
    birth = BirthInput(
        dt=parse_datetime(args.datetime, args.timezone),
        timezone_name=args.timezone,
        latitude=args.latitude,
        longitude=args.longitude,
        gender=args.gender,
        place=args.place or "",
        true_solar_time=not args.no_true_solar_time,
    )
    reference = parse_reference_date(getattr(args, "reference_date", None))

    dst_minutes = dst_offset_minutes(birth.dt)
    standard_tz = timezone(timedelta(minutes=standard_offset_minutes(birth.dt)))
    # 同一物理时刻按标准时区重新表示：23:35(+09:00, 夏令时) == 22:35(+08:00, 标准时)。
    standard_dt = birth.dt.astimezone(standard_tz)
    apparent_dt, longitude_minutes, eot = apparent_solar_datetime(standard_dt, birth.longitude)
    chart_dt = apparent_dt if birth.true_solar_time else birth.dt

    clock_lunar = solar_from_datetime(birth.dt).getLunar()
    chart_lunar = solar_from_datetime(chart_dt).getLunar()
    eight = chart_lunar.getEightChar()
    clock_eight = clock_lunar.getEightChar()
    jie_prev = jieqi_payload(chart_lunar.getPrevJie(), chart_dt)
    jie_next = jieqi_payload(chart_lunar.getNextJie(), chart_dt)
    current_jie = chart_lunar.getCurrentJie()
    current_jieqi = chart_lunar.getCurrentJieQi()

    pillars = [pillar(eight, key) for key in ["year", "month", "day", "hour"]]
    day_master = pillars[2]["gan"]
    day_element = STEM_ELEMENT.get(day_master, "")
    month_branch = pillars[1]["zhi"]

    profile = element_weight_profile(pillars)
    strength = day_master_strength(profile, day_element, month_branch)
    gods = ten_god_stats(pillars, day_master)
    favorable = favorable_elements(profile, strength, month_branch)
    hour_changed = clock_eight.getTime() != eight.getTime()

    missing = [element for element in ELEMENTS if profile[element]["weighted"] < 0.35]

    result = {
        "meta": {
            "schema_version": SCHEMA_VERSION,
            "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "reference_date": reference.isoformat(),
            "engine": "lunar-python",
        },
        "input": {
            "datetime": birth.dt.isoformat(),
            "timezone": birth.timezone_name,
            "latitude": birth.latitude,
            "longitude": birth.longitude,
            "place": birth.place,
            "gender": birth.gender,
            "true_solar_time_enabled": birth.true_solar_time,
            "utc_offset_hours": round((birth.dt.utcoffset().total_seconds() / 3600), 2),
            "standard_utc_offset_hours": round(standard_offset_minutes(birth.dt) / 60, 2),
            "dst_applied": abs(dst_minutes) >= 1,
            "dst_offset_minutes": dst_minutes,
        },
        "time_corrections": {
            "clock_datetime": birth.dt.isoformat(),
            "standard_datetime": standard_dt.isoformat(),
            "dst_offset_minutes": dst_minutes,
            "standard_meridian_degrees": standard_meridian_degrees(standard_dt),
            "longitude_correction_minutes": round(longitude_minutes, 2),
            "equation_of_time_minutes": round(eot, 2),
            "total_true_solar_offset_minutes": round(-dst_minutes + longitude_minutes + eot, 2),
            "true_solar_datetime": apparent_dt.isoformat(),
            "chart_datetime_used": chart_dt.isoformat(),
            "clock_hour_pillar": clock_eight.getTime(),
            "chart_hour_pillar": eight.getTime(),
            "hour_pillar_changed_by_true_solar_time": hour_changed,
        },
        "calendar": {
            "solar": str(solar_from_datetime(chart_dt)),
            "lunar": str(chart_lunar),
            "current_jie": current_jie.getName() if current_jie else None,
            "current_jieqi": current_jieqi.getName() if current_jieqi else None,
            "on_jie_day": current_jie is not None,
            "previous_jie": jie_prev,
            "next_jie": jie_next,
            "year_shengxiao": chart_lunar.getYearShengXiaoExact(),
            "month_ganzhi": eight.getMonth(),
            "season": season_of(month_branch),
        },
        "bazi": {
            "text": " ".join(item["ganzhi"] for item in pillars),
            "day_master": day_master,
            "day_master_element": day_element,
            "day_master_polarity": STEM_POLARITY.get(day_master),
            "month_branch": month_branch,
            "pillars": pillars,
            "element_counts": element_counts(pillars),
            "element_profile": profile,
            "missing_elements": missing,
            "day_master_strength": strength,
            "ten_god_stats": gods,
            "favorable_elements": favorable,
            "relations": relations(pillars),
            "ming_gong": eight.getMingGong(),
            "ming_gong_nayin": eight.getMingGongNaYin(),
            "shen_gong": eight.getShenGong(),
            "shen_gong_nayin": eight.getShenGongNaYin(),
            "tai_yuan": eight.getTaiYuan(),
            "tai_yuan_nayin": eight.getTaiYuanNaYin(),
            "tai_xi": eight.getTaiXi(),
            "tai_xi_nayin": eight.getTaiXiNaYin(),
        },
        "luck": luck_cycles(eight, birth.gender, reference),
        "warnings": build_warnings(birth, chart_dt, jie_prev, jie_next, hour_changed),
        "notes": [
            "The deterministic layer (pillars, hidden stems, ten gods, nayin, luck cycles) comes from lunar-python.",
            "Derived fields (element weights, day-master strength, ten-god distribution, favourable elements) are heuristic and labelled as such.",
            "True solar time = clock time - DST + longitude correction + equation of time.",
            "Interpretations should be treated as cultural metaphysics and reflective guidance, not deterministic prediction.",
        ],
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--datetime", required=True, help='Birth datetime, e.g. "1990-01-01 12:00:00"')
    parser.add_argument("--timezone", required=True, help='IANA timezone, e.g. "Asia/Shanghai"')
    parser.add_argument("--latitude", type=float, required=True)
    parser.add_argument("--longitude", type=float, required=True)
    parser.add_argument("--place", default="", help="Birthplace label, e.g. 广东省清远市阳山县")
    parser.add_argument("--gender", choices=["male", "female", "unknown"], default="unknown")
    parser.add_argument(
        "--reference-date",
        default=None,
        help="Reference day (YYYY-MM-DD) for current luck cycle / annual flow. Defaults to today.",
    )
    parser.add_argument("--no-true-solar-time", action="store_true")
    parser.add_argument("--output", help="Write JSON to this path. Defaults to stdout.")
    args = parser.parse_args()

    chart = build_chart(args)
    text = json.dumps(chart, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
