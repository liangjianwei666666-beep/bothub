#!/usr/bin/env python3
"""Self-check for the mingpan skill installation.

Runs the full pipeline on fictional sample data and reports what works:
Python version, lunar-python dependency, chart generation, HTML rendering,
offline output, and expected JSON fields.

Usage:
    python3 doctor.py            # human-readable check
    python3 doctor.py --json     # machine-readable result

Exit code 0 when every check passes, 1 otherwise.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent

SAMPLE_ARGS = [
    "--datetime",
    "1990-01-01 12:00:00",
    "--timezone",
    "Asia/Shanghai",
    "--latitude",
    "31.2304",
    "--longitude",
    "121.4737",
    "--place",
    "上海市",
    "--gender",
    "male",
    "--reference-date",
    "2026-10-21",
]

SAMPLE_REPORT = """# 自检报告

- 这是一次安装自检。
- 如果能读到这段文字，说明 Markdown 渲染正常。

| 检查项 | 结果 |
| --- | --- |
| 排版 | 正常 |

1. 列表
2. 也能渲染
"""


def check(name: str, ok: bool, detail: str, results: list[dict], quiet: bool = False) -> bool:
    results.append({"check": name, "ok": bool(ok), "detail": detail})
    if not quiet:
        mark = "✓" if ok else "✗"
        print(f"  {mark} {name}" + (f" —— {detail}" if detail else ""))
    return ok


def dependency_version() -> str:
    try:
        return importlib.metadata.version("lunar-python")
    except importlib.metadata.PackageNotFoundError:
        return "unknown"


def run_script(script: str, args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(SCRIPT_DIR / script)] + args,
        capture_output=True,
        text=True,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--json", action="store_true", help="print a JSON summary instead of the checklist")
    args = parser.parse_args()

    results: list[dict] = []
    if not args.json:
        print("命盘报告技能自检")
        print(f"技能目录：{SKILL_DIR}")
        print()

    ok_python = check(
        "Python 版本",
        sys.version_info >= (3, 9),
        f"{sys.version.split()[0]}（需要 3.9+）",
        results,
        quiet=args.json,
    )

    try:
        import lunar_python  # noqa: F401

        ok_dependency = check("lunar-python 依赖", True, f"已安装 {dependency_version()}", results, quiet=args.json)
    except ImportError:
        ok_dependency = check(
            "lunar-python 依赖",
            False,
            "未安装，请运行：python3 -m pip install --user lunar-python",
            results,
            quiet=args.json,
        )

    if not (ok_python and ok_dependency):
        if args.json:
            print(json.dumps({"ok": False, "checks": results}, ensure_ascii=False, indent=2))
        return 1

    with tempfile.TemporaryDirectory(prefix="mingpan-doctor-") as tmp:
        tmp_dir = Path(tmp)
        chart_path = tmp_dir / "chart.json"
        report_path = tmp_dir / "report.md"
        html_path = tmp_dir / "report.html"
        report_path.write_text(SAMPLE_REPORT, encoding="utf-8")

        chart = run_script("generate_bazi_chart.py", SAMPLE_ARGS + ["--output", str(chart_path)])
        chart_ok = chart.returncode == 0 and chart_path.exists()
        check(
            "生成命盘 JSON",
            chart_ok,
            "sample chart created" if chart_ok else (chart.stderr.strip() or "generator failed"),
            results,
            quiet=args.json,
        )

        fields_ok = False
        if chart_ok:
            data = json.loads(chart_path.read_text(encoding="utf-8"))
            expected = ["input", "time_corrections", "calendar", "bazi", "luck", "warnings"]
            missing = [key for key in expected if key not in data]
            fields_ok = not missing and data["bazi"]["text"].count(" ") == 3
            check(
                "命盘数据结构",
                fields_ok,
                "v2 fields present" if fields_ok else f"missing: {', '.join(missing) or 'pillars'}",
                results,
                quiet=args.json,
            )

        render = run_script(
            "render_html_report.py",
            [
                "--chart",
                str(chart_path),
                "--markdown",
                str(report_path),
                "--output",
                str(html_path),
                "--name",
                "自检用户",
            ],
        )
        render_ok = render.returncode == 0 and html_path.exists()
        check(
            "渲染 HTML",
            render_ok,
            f"{html_path.stat().st_size // 1024} KB" if render_ok else (render.stderr.strip() or "renderer failed"),
            results,
            quiet=args.json,
        )

        if render_ok:
            page = html_path.read_text(encoding="utf-8")
            external = [
                url for url in re.findall(r'(?:src|href)="([^"]+)"', page) if not url.startswith("#")
            ]
            check(
                "离线可用",
                not external,
                f"{len(external)} 个外部依赖" if external else "无外部依赖",
                results,
                quiet=args.json,
            )
            check(
                "报告结构",
                "命盘依据" in page and "report-body" in page,
                "appendix + body",
                results,
                quiet=args.json,
            )

    all_ok = all(item["ok"] for item in results)
    if args.json:
        print(json.dumps({"ok": all_ok, "checks": results}, ensure_ascii=False, indent=2))
    else:
        print()
        print("全部通过，可以生成报告。" if all_ok else "有检查未通过，请按上面的提示处理后重试。")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
