#!/usr/bin/env python3
"""Render a Mingpan chart JSON and Markdown report into standalone HTML.

The output is a single offline file: no external CSS, fonts, scripts or images.
Chart-derived panels degrade gracefully when older chart JSON files lack the
newer fields (element_profile, day_master_strength, warnings, luck.current).
"""

from __future__ import annotations

import argparse
import html
import json
import re
from datetime import datetime
from pathlib import Path

ELEMENTS = ["木", "火", "土", "金", "水"]
ELEMENT_CLASS = {"木": "wood", "火": "fire", "土": "earth", "金": "metal", "水": "water"}


# ---------------------------------------------------------------------------
# Markdown -> HTML
# ---------------------------------------------------------------------------

LIST_RE = re.compile(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$")
PLACEHOLDER = "\u0000{}\u0000"


def inline_markdown(text: str) -> str:
    """Escape then apply a small, safe subset of inline Markdown."""
    value = html.escape(text, quote=False)
    stash: list[str] = []

    def keep(fragment: str) -> str:
        stash.append(fragment)
        return PLACEHOLDER.format(len(stash) - 1)

    value = re.sub(r"`([^`]+)`", lambda m: keep("<code>" + m.group(1) + "</code>"), value)
    value = re.sub(
        r"\[([^\]]+)\]\(([^)\s]+)\)",
        lambda m: keep(_anchor(m.group(1), m.group(2))),
        value,
    )
    value = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", value)
    value = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<em>\1</em>", value)
    value = re.sub(r"~~([^~]+)~~", r"<del>\1</del>", value)
    for index, fragment in enumerate(stash):
        value = value.replace(PLACEHOLDER.format(index), fragment)
    return value


def _anchor(label: str, url: str) -> str:
    safe = html.escape(url, quote=True)
    if not re.match(r"^(https?://|mailto:|#|/)", safe):
        return label
    return f'<a href="{safe}" rel="noopener noreferrer">{label}</a>'


def _is_table_separator(line: str) -> bool:
    if "-" not in line or "|" not in line:
        return False
    cells = _split_row(line)
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", cell) for cell in cells)


def _split_row(line: str) -> list[str]:
    value = line.strip()
    if value.startswith("|"):
        value = value[1:]
    if value.endswith("|"):
        value = value[:-1]
    return [cell.strip() for cell in value.split("|")]


def _render_table(lines: list[str], start: int) -> tuple[str, int]:
    header = _split_row(lines[start])
    separator = _split_row(lines[start + 1])
    alignments = []
    for cell in separator:
        left = cell.startswith(":")
        right = cell.endswith(":")
        if left and right:
            alignments.append("center")
        elif right:
            alignments.append("right")
        elif left:
            alignments.append("left")
        else:
            alignments.append("")
    rows = []
    index = start + 2
    while index < len(lines) and lines[index].strip() and "|" in lines[index]:
        rows.append(_split_row(lines[index]))
        index += 1

    def cell(tag: str, content: str, position: int) -> str:
        align = alignments[position] if position < len(alignments) else ""
        style = f' style="text-align:{align}"' if align else ""
        return f"<{tag}{style}>{inline_markdown(content)}</{tag}>"

    head = "".join(cell("th", text, i) for i, text in enumerate(header))
    body_rows = []
    for row in rows:
        padded = row + [""] * (len(header) - len(row))
        body_rows.append("<tr>" + "".join(cell("td", text, i) for i, text in enumerate(padded[: len(header)])) + "</tr>")
    table = (
        '<div class="table-wrap"><table class="data-table md-table">'
        f"<thead><tr>{head}</tr></thead><tbody>{''.join(body_rows)}</tbody></table></div>"
    )
    return table, index


def _render_list(lines: list[str], start: int, indent: int) -> tuple[str, int]:
    match = LIST_RE.match(lines[start])
    tag = "ol" if match.group(2)[0].isdigit() else "ul"
    items: list[str] = []
    index = start
    while index < len(lines):
        match = LIST_RE.match(lines[index])
        if not match:
            break
        current_indent = len(match.group(1).replace("\t", "    "))
        current_tag = "ol" if match.group(2)[0].isdigit() else "ul"
        if current_indent < indent:
            break
        if current_indent == indent and current_tag != tag:
            break
        if current_indent > indent:
            if not items:
                break
            nested, index = _render_list(lines, index, current_indent)
            items[-1] += nested
            continue
        items.append(inline_markdown(match.group(3)))
        index += 1
        while (
            index < len(lines)
            and lines[index].strip()
            and not LIST_RE.match(lines[index])
            and not lines[index].strip().startswith(("#", ">", "```"))
            and (len(lines[index]) - len(lines[index].lstrip())) > indent
        ):
            items[-1] += " " + inline_markdown(lines[index].strip())
            index += 1
    body = "".join(f"<li>{item}</li>" for item in items)
    return f"<{tag}>{body}</{tag}>", index


def _join_lines(parts: list[str]) -> str:
    """Join wrapped source lines: no space between CJK, space otherwise."""
    result = ""
    for part in parts:
        if not result:
            result = part
            continue
        if re.match(r"[\u3000-\u9fff\uff00-\uffef]", result[-1]) and re.match(
            r"[\u3000-\u9fff\uff00-\uffef]", part[0]
        ):
            result += part
        else:
            result += " " + part
    return result


def markdown_to_html(markdown: str) -> str:
    lines = markdown.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    parts: list[str] = []
    index = 0
    heading_index = 0
    while index < len(lines):
        line = lines[index]
        stripped = line.strip()

        if stripped.startswith("```"):
            language = stripped[3:].strip()
            index += 1
            buffer = []
            while index < len(lines) and not lines[index].strip().startswith("```"):
                buffer.append(lines[index])
                index += 1
            index += 1
            label = f' data-lang="{html.escape(language)}"' if language else ""
            parts.append(f"<pre{label}><code>{html.escape(chr(10).join(buffer))}</code></pre>")
            continue

        if not stripped:
            index += 1
            continue

        if re.fullmatch(r"(-{3,}|\*{3,}|_{3,})", stripped):
            parts.append("<hr>")
            index += 1
            continue

        heading = re.match(r"^(#{1,6})\s+(.+?)\s*#*$", stripped)
        if heading:
            level = len(heading.group(1))
            heading_index += 1
            parts.append(f'<h{level} id="h-{heading_index}">{inline_markdown(heading.group(2))}</h{level}>')
            index += 1
            continue

        if "|" in line and index + 1 < len(lines) and _is_table_separator(lines[index + 1]):
            table, index = _render_table(lines, index)
            parts.append(table)
            continue

        if stripped.startswith(">"):
            buffer = []
            while index < len(lines) and lines[index].strip().startswith(">"):
                buffer.append(lines[index].strip()[1:].strip())
                index += 1
            quote = "".join(f"<p>{inline_markdown(item)}</p>" for item in buffer if item)
            parts.append(f"<blockquote>{quote}</blockquote>")
            continue

        if LIST_RE.match(line):
            indent = len(LIST_RE.match(line).group(1).replace("\t", "    "))
            rendered, index = _render_list(lines, index, indent)
            parts.append(rendered)
            continue

        buffer = [stripped]
        index += 1
        while index < len(lines):
            candidate = lines[index]
            candidate_stripped = candidate.strip()
            if (
                not candidate_stripped
                or candidate_stripped.startswith(("#", ">", "```"))
                or re.fullmatch(r"(-{3,}|\*{3,}|_{3,})", candidate_stripped)
                or LIST_RE.match(candidate)
                or ("|" in candidate and index + 1 < len(lines) and _is_table_separator(lines[index + 1]))
            ):
                break
            buffer.append(candidate_stripped)
            index += 1
        parts.append(f"<p>{inline_markdown(_join_lines(buffer))}</p>")

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Glossary
# ---------------------------------------------------------------------------

STEMS = {
    "甲": ("阳木", "像大树、梁柱，偏向开创、向上生长和建立方向。"),
    "乙": ("阴木", "像花草藤蔓，偏向柔韧、协调、审美和细腻生长。"),
    "丙": ("阳火", "像太阳，偏向外放、照亮、行动力和被看见。"),
    "丁": ("阴火", "像灯火，偏向专注、灵感、温度和持续点亮。"),
    "戊": ("阳土", "像高山厚土，偏向承载、规则、稳定和边界。"),
    "己": ("阴土", "像田园土壤，偏向滋养、消化、现实感和包容。"),
    "庚": ("阳金", "像矿石刀斧，偏向决断、规则、切割和执行。"),
    "辛": ("阴金", "像珠玉首饰，偏向精致、标准、审美和修正。"),
    "壬": ("阳水", "像江河大海，偏向流动、视野、适应和系统信息。"),
    "癸": ("阴水", "像雨露泉水，偏向敏感、观察、渗透和细密思考。"),
}

BRANCHES = {
    "子": ("阳水", "水气集中，常象征信息、流动、内在感受和潜意识活动。"),
    "丑": ("阴土", "湿寒之土，内藏水金土，常象征蓄积、忍耐和慢性压力。"),
    "寅": ("阳木", "初春木气，常象征启动、成长、学习和向外开拓。"),
    "卯": ("阴木", "木气纯粹，常象征关系、审美、表达和柔性生长。"),
    "辰": ("阳土", "湿土、水库，常象征复杂承载、资源储存和未完全流动的压力。"),
    "巳": ("阴火", "火气启动且藏金土，常象征热能、欲望、转化和隐性张力。"),
    "午": ("阳火", "火气最盛，常象征行动、曝光、热情和外在成果。"),
    "未": ("阴土", "燥土带木火，常象征整理、收束、现实照料和余温。"),
    "申": ("阳金", "金气启动且带水，常象征规则、技术、变化和执行系统。"),
    "酉": ("阴金", "金气纯粹，常象征标准、审美、精修和边界感。"),
    "戌": ("阳土", "燥土、火库，常象征守成、防御、价值沉淀和压力封存。"),
    "亥": ("阴水", "水气深厚且藏木，常象征潜能、直觉、远方和深层流动。"),
}

COLUMN_EXPLANATIONS = {
    "柱位": "四柱的位置：年柱、月柱、日柱、时柱。它们分别对应早年背景、社会/事业框架、自我与亲密关系、晚年方向与深层动力。",
    "干支": "每一柱由一个天干和一个地支组成。天干偏外显，地支偏根基和环境，合起来形成这一柱的核心气质。",
    "主十神": "以日主为中心，看其他天干与日主的关系。它用于描述责任、表达、资源、学习、自我等心理功能。",
    "藏干": "地支内部藏着的天干，像一个人或情境的隐性成分，常用于观察潜在动机和深层资源。",
    "藏干十神": "把藏干也换算成十神，用来解释潜在性格、隐性压力、关系需求和未直接表现出来的能力。",
    "纳音": "纳音是干支组合派生出的象名，偏象征层阅读，可辅助理解这一柱的气质背景。",
    "十二长生": "十二长生描述日主在该地支上的能量阶段，类似生命力处于萌芽、成长、成熟、收束等不同状态。",
    "旬空": "旬空表示该柱所在旬中暂缺的两个地支。白话说，是某些主题容易先显得虚、迟、远，需要后天补实。",
    "日主": "日主就是出生那一天的天干，是命盘的自我中心点，所有十神都以它为参照。",
    "月令": "月令指出生月份的地支，是八字里最有权重的环境力量，决定季节主气与旺衰基调。",
    "大运": "大运是每十年一步的阶段性环境，用来观察人生不同阶段的主题与节奏，不是事件预言。",
    "流年": "流年指某一公历年的年柱干支，用来看当年的环境气氛，需与大运和原局一起读。",
}

PILLAR_EXPLANATIONS = {
    "年柱": "年柱偏看家族背景、早年环境、公共形象和较外层的社会来源。",
    "月柱": "月柱最重，偏看成长系统、事业框架、社会角色和命盘的季节主气。",
    "日柱": "日柱以日干为日主，代表自我核心；日支也常用于观察亲密关系和内在落点。",
    "时柱": "时柱偏看深层愿望、长期方向、晚年状态、子女/下属缘分和后天输出。",
}

TEN_GOD_EXPLANATIONS = {
    "日主": "日主就是命盘的自我中心点。所有十神都以日主为参照来判断，心理上可理解为核心自我和主观感受。",
    "比肩": "比肩代表同类力量。白话说，是自我意识、独立性、同伴竞争、边界感和“我要按自己的方式来”。",
    "劫财": "劫财也是同类力量，但更外放。它常表现为争取、冒险、义气、资源竞争，也提醒边界和冲动管理。",
    "食神": "食神代表温和输出。白话说，是表达、创造、享受、照料感和把能力稳定释放出来。",
    "伤官": "伤官代表锐利输出。它常表现为批判、表达欲、创意、反规则意识，也需要学习把锋芒变成作品。",
    "正财": "正财代表稳定资源。心理上对应现实感、经营能力、秩序化收入、照顾具体生活的能力。",
    "偏财": "偏财代表流动资源。它偏机会、市场、人脉、项目感和对更大资源盘子的敏感。",
    "正官": "正官代表规则和责任。心理上对应自律、名誉、职业标准、被评价感，以及想把事情做对的压力。",
    "七杀": "七杀代表强压力和挑战。白话说，是危机感、竞争、执行力、威压和需要被驯化的强大驱动力。",
    "正印": "正印代表保护和正统学习。它对应安全感、吸收力、贵人、资格感，也可能带来依赖确定性的倾向。",
    "偏印": "偏印代表非典型学习和内在保护。它对应洞察、研究、独特理解，也可能让人想太多或保持距离。",
}

GROWTH_PHASE_EXPLANATIONS = {
    "长生": "像生命刚刚生发，有学习、成长、恢复和新机会的意味。",
    "沐浴": "像刚进入环境、敏感而容易受影响，常与探索、魅力和不稳定有关。",
    "冠带": "像开始成形并被看见，代表自我呈现、资格感和成长中的稳定。",
    "临官": "像进入职位和责任，代表能力可用、承担事务和角色感增强。",
    "帝旺": "像能量最旺，代表强势、主动、存在感，也要留意过满和冲动。",
    "衰": "像盛后回落，代表收敛、调整和从高峰进入现实管理。",
    "病": "不是疾病诊断，而是能量不顺或需要修复，提醒节奏和消耗管理。",
    "死": "不是死亡预测，而是旧模式结束、能量沉潜、需要转换方式。",
    "墓": "像能量入库，代表收藏、积累、压住，也可能显得不够流动。",
    "绝": "像旧根断开，代表重新开始前的断裂、空白和转向。",
    "胎": "像正在孕育，代表潜能、内在酝酿、尚未完全外显。",
    "养": "像被滋养，代表培育、恢复、照料和慢慢成形。",
}

NAYIN_EXPLANATIONS = {
    "海中金": "海中金像沉在海底的金属，象征价值尚未显形、需要勘探与时机，也带低调和深藏的特质。",
    "炉中火": "炉中火像受控的炉膛之火，象征集中的热量、加工与锻造，偏向有目标、有强度的行动。",
    "大林木": "大林木像成片树林，象征长期生长、系统支撑、群体环境和需要空间展开的生命力。",
    "路旁土": "路旁土像道路两旁的土，象征通行、承载与过渡，常与外部环境、往来人群相关。",
    "剑锋金": "剑锋金像开刃的刀剑，象征锋利、决断和标准，也提醒锋芒需要收束场合。",
    "山头火": "山头火像山巅的火光，象征显眼、照亮和号召力，偏向外放但不够持久。",
    "涧下水": "涧下水像山涧细流，象征清冽、灵动、绕过阻碍的能力，也带一点独行的清冷。",
    "城头土": "城头土像城墙上的土，象征防御、边界、秩序与守护，偏重安全和规则感。",
    "白蜡金": "白蜡金像可塑的白金之物，象征可打磨、可塑形，偏向精致与工艺性。",
    "杨柳木": "杨柳木像垂柳，象征柔韧、适应、关系性与审美感受，随风而不易折。",
    "泉中水": "泉中水像泉眼，象征源源不断的补给、灵感与内在活力，细小但持续。",
    "屋上土": "屋上土像屋顶的瓦土，象征遮蔽、安家、结构感与对安全空间的需要。",
    "霹雳火": "霹雳火像雷电之火，象征突发、爆发力与瞬间穿透，来得快也需防后劲不足。",
    "松柏木": "松柏木像耐寒的松柏，象征坚韧、长期主义、原则感与慢而稳的成长。",
    "长流水": "长流水像不舍昼夜的江河，象征持续流动、远行、长期积累与开阔视野。",
    "沙中金": "沙中金像混在沙里的金屑，象征价值需要筛选和提炼，常带大器晚成的意味。",
    "山下火": "山下火像山脚的篝火，象征温暖、聚集和可亲近的热度，偏重人际与日常。",
    "平地木": "平地木像平地上的树木，象征扎根、稳定、可预期的生长与务实经营。",
    "壁上土": "壁上土像墙面之土，象征依附结构、边界与保护，偏向秩序和安全感。",
    "金箔金": "金箔金像极薄的金箔，象征装饰性、精细与外在光感，也提醒价值感易被表面牵动。",
    "覆灯火": "覆灯火像灯罩里的火，象征内在照明、专注、守护与不太张扬的坚持。",
    "天河水": "天河水像天上来水，象征想象、恩泽、灵感与远距离的流动，偏理想与宏大。",
    "大驿土": "大驿土像交通要道之土，象征通行、枢纽、流动与承担往来，偏外向和忙碌。",
    "钗钏金": "钗钏金像首饰之金，象征精致、审美、被看见的价值，也带修饰与礼仪感。",
    "桑柘木": "桑柘木像可被使用和培育的木，象征实际价值、养成、可持续产出和生活经营。",
    "大溪水": "大溪水像山间大水，象征冲劲、流动中的力量，偏向快速推进与开辟通道。",
    "沙中土": "沙中土像沙土混合之地，象征松散、可塑与重组，偏向适应和重新搭建。",
    "天上火": "天上火像高悬的太阳之火，象征普惠、照耀与大局感，也提醒保持适度距离。",
    "石榴木": "石榴木像多籽的石榴树，象征密集的产出、家族与丰盛，也带一点执着的烈性。",
    "大海水": "大海水像深广之水，象征容量、远方、复杂信息、潜意识和大范围流动。",
}


def describe_term(text: str, kind: str) -> str:
    if kind == "column":
        return COLUMN_EXPLANATIONS.get(text, "这是四柱表中的字段，用来组织命盘事实层。")
    if kind == "pillar":
        return PILLAR_EXPLANATIONS.get(text, "这是四柱之一，用于定位该信息对应的人生层面。")
    if kind == "ganzhi" and len(text) == 2:
        gan, zhi = text[0], text[1]
        gan_info = STEMS.get(gan, ("天干", "代表外显倾向。"))
        zhi_info = BRANCHES.get(zhi, ("地支", "代表内在根基。"))
        return (
            f"{text}由天干{gan}和地支{zhi}组成。{gan}为{gan_info[0]}，{gan_info[1]}"
            f"{zhi}为{zhi_info[0]}，{zhi_info[1]}合看时，天干偏外显，地支偏根基。"
        )
    if kind == "stem":
        info = STEMS.get(text)
        if info:
            return f"{text}是天干，属性为{info[0]}。{info[1]}"
        return "这是一个藏干，表示地支内部隐藏的能量或潜在心理成分。"
    if kind == "ten-god":
        return TEN_GOD_EXPLANATIONS.get(text, "这是十神之一，用来描述它与日主之间的心理功能关系。")
    if kind == "nayin":
        return NAYIN_EXPLANATIONS.get(text, f"{text}是纳音象名，用于辅助理解该柱的象征气质；它不是单独断事依据，要结合四柱结构一起看。")
    if kind == "growth":
        return GROWTH_PHASE_EXPLANATIONS.get(text, "这是十二长生阶段，用来观察日主在该柱地支上的能量状态。")
    if kind == "xunkong":
        return f"{text}是旬空。白话说，这两个地支对应的主题容易先显得虚、迟、远，或需要通过经历与行动慢慢补实。"
    if kind == "element":
        return f"{text}是五行之一，用来观察能量的多寡、流通与缺失。"
    return "这是命盘术语，建议结合所在柱位和上下文一起理解。"


def term(text: str, kind: str, css_class: str = "") -> str:
    title = html.escape(str(text), quote=True)
    desc = html.escape(describe_term(str(text), kind), quote=True)
    klass = f"term term-{kind}"
    if css_class:
        klass += f" {css_class}"
    return (
        f'<button type="button" class="{klass}" data-title="{title}" '
        f'data-desc="{desc}" aria-label="查看{title}的解释">{html.escape(str(text))}</button>'
    )


def term_join(values: list[str], kind: str) -> str:
    return "、".join(term(value, kind) for value in values)


# ---------------------------------------------------------------------------
# Chart panels
# ---------------------------------------------------------------------------


def _fmt_dt(value) -> str:
    """Format an ISO datetime for display: no 'T', no microseconds."""
    if not isinstance(value, str):
        return str(value)
    text = value.replace("T", " ")
    return re.sub(r"\.\d+(?=[+-]|$)", "", text)


def _fmt_offset(hours) -> str:
    try:
        total = float(hours)
    except (TypeError, ValueError):
        return "UTC"
    sign = "+" if total >= 0 else "-"
    total = abs(total)
    whole = int(total)
    minutes = round((total - whole) * 60)
    return f"UTC{sign}{whole:02d}:{minutes:02d}"


def _jie_name(value) -> str:
    """Accept both v1 (string) and v2 (object) jieqi payloads."""
    if isinstance(value, dict):
        return value.get("name") or "—"
    if isinstance(value, str) and value and value != "None":
        return value
    return "—"


def _signed(value: float) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return html.escape(str(value))
    return f"{number:+.2f}".rstrip("0").rstrip(".") if number % 1 else f"{number:+.0f}"


def _element_profile(chart: dict) -> dict:
    profile = chart["bazi"].get("element_profile")
    if profile:
        return profile
    counts = chart["bazi"].get("element_counts", {})
    total = sum(value.get("total", 0) for value in counts.values()) or 1
    return {
        element: {
            "surface": counts.get(element, {}).get("surface", 0),
            "hidden": counts.get(element, {}).get("hidden", 0),
            "weighted": counts.get(element, {}).get("total", 0),
            "percent": round(counts.get(element, {}).get("total", 0) / total * 100, 1),
        }
        for element in ELEMENTS
    }


def pillar_table(chart: dict) -> str:
    rows = []
    for item in chart["bazi"]["pillars"]:
        rows.append(
            "<tr>"
            f"<th>{term(item['label'], 'pillar')}</th>"
            f"<td class='ganzhi'>{term(item['ganzhi'], 'ganzhi', 'term-ganzhi-main')}</td>"
            f"<td>{term(item['ten_god_stem'], 'ten-god')}</td>"
            f"<td>{term_join(item['hidden_stems'], 'stem')}</td>"
            f"<td>{term_join(item['ten_god_hidden'], 'ten-god')}</td>"
            f"<td>{term(item['nayin'], 'nayin')}</td>"
            f"<td>{term(item['growth_phase'], 'growth')}</td>"
            f"<td>{term(item['xunkong'], 'xunkong')}</td>"
            "</tr>"
        )
    head = "".join(
        f"<th>{term(label, 'column')}</th>"
        for label in ["柱位", "干支", "主十神", "藏干", "藏干十神", "纳音", "十二长生", "旬空"]
    )
    return (
        '<div class="table-wrap"><table class="data-table">'
        f"<thead><tr>{head}</tr></thead><tbody>{''.join(rows)}</tbody></table></div>"
    )


def element_bars(chart: dict) -> str:
    profile = _element_profile(chart)
    rows = []
    for element in ELEMENTS:
        info = profile.get(element, {})
        percent = info.get("percent", 0)
        weighted = info.get("weighted", 0)
        rows.append(
            f"<div class='element-row {ELEMENT_CLASS[element]}'>"
            f"<span class='element-name'>{element}</span>"
            f"<div class='bar'><i style='width:{percent}%'></i></div>"
            f"<b>{percent}%</b>"
            f"<small>权重 {weighted} · 明 {info.get('surface', 0)} / 藏 {info.get('hidden', 0)}</small>"
            "</div>"
        )
    missing = chart["bazi"].get("missing_elements") or []
    note = ""
    if missing:
        note = f"<p class='muted'>接近缺失（权重很低）：{html.escape('、'.join(missing))}</p>"
    return "<div class='element-grid'>" + "\n".join(rows) + "</div>" + note


def strength_panel(chart: dict) -> str:
    strength = chart["bazi"].get("day_master_strength")
    if not strength:
        return "<p class='muted'>未提供日主强弱推导数据。</p>"
    score = strength.get("score", 50)
    label = strength.get("label", "中和")
    state = strength.get("season_state", "")
    tone = {"偏弱": "weak", "偏强": "strong", "中和": "balanced"}.get(label, "balanced")
    return f"""
<div class="strength-panel {tone}">
  <div class="strength-head">
    <div><small>日主强弱（启发式评分）</small><strong>{html.escape(label)}</strong></div>
    <b>{score}</b>
  </div>
  <div class="gauge"><span style="left:{max(0, min(100, score))}%"></span></div>
  <div class="gauge-scale"><span>偏弱 0</span><span>中和 50</span><span>偏强 100</span></div>
  <dl class="strength-meta">
    <dt>月令状态</dt><dd>{html.escape(strength.get("season_state", "—"))}（{'得令/得生' if strength.get("supported_by_month") else '不当令'}）</dd>
    <dt>同类权重</dt><dd>{strength.get("same_group_weight", "—")}</dd>
    <dt>异类权重</dt><dd>{strength.get("different_group_weight", "—")}</dd>
  </dl>
  <p class="muted">{html.escape(strength.get("note", ""))}</p>
</div>
"""


def ten_god_panel(chart: dict) -> str:
    stats = chart["bazi"].get("ten_god_stats") or []
    if not stats:
        return "<p class='muted'>未提供十神分布统计。</p>"
    rows = []
    for item in stats:
        percent = item.get("percent", 0)
        sources = "、".join(item.get("sources", [])[:6])
        rows.append(
            f"<div class='tg-row'><span class='tg-name'>{term(item['ten_god'], 'ten-god')}</span>"
            f"<div class='bar'><i style='width:{percent}%'></i></div>"
            f"<b>{percent}%</b><small>{html.escape(sources)}</small></div>"
        )
    return "<div class='tg-grid'>" + "\n".join(rows) + "</div>"


def favorable_panel(chart: dict) -> str:
    favorable = chart["bazi"].get("favorable_elements")
    if not favorable:
        return ""
    climate = favorable.get("climate")
    primary = favorable.get("primary") or []
    avoid = favorable.get("avoid") or []
    chips = "".join(f"<span class='chip chip-good'>{html.escape(e)}</span>" for e in primary) or "<span class='muted'>不单边取用</span>"
    avoid_chips = "".join(f"<span class='chip chip-bad'>{html.escape(e)}</span>" for e in avoid) or "<span class='muted'>—</span>"
    climate_html = (
        f"<p><strong>调候：</strong>{html.escape(climate['element'])} —— {html.escape(climate['reason'])}</p>"
        if climate
        else ""
    )
    tension = favorable.get("tension")
    tension_html = f"<p class='tension'>{html.escape(tension)}</p>" if tension else ""
    return f"""
<div class="favorable-panel">
  <p><strong>参考方向：</strong>{chips}</p>
  <p><strong>需要节制：</strong>{avoid_chips}</p>
  {climate_html}
  {tension_html}
  <p>{html.escape(favorable.get('rationale', ''))}</p>
  <p class="muted">{html.escape(favorable.get('note', ''))}</p>
</div>
"""


def relations_list(chart: dict) -> str:
    relations = []
    for group in ["pairs", "triples", "self"]:
        relations.extend(chart["bazi"].get("relations", {}).get(group, []))
    if not relations:
        return "<p class='muted'>未检测到主要合冲刑害破关系。</p>"
    items = []
    for rel in relations:
        items.append(
            f"<li><strong>{html.escape(rel['type'])}</strong>：{html.escape(rel['relation'])} "
            f"<span>{html.escape(' / '.join(rel['pillars']))}</span> "
            f"<code>{html.escape(''.join(rel['items']))}</code></li>"
        )
    return "<ul class='relation-list'>" + "\n".join(items) + "</ul>"


def warnings_block(chart: dict) -> str:
    warnings = chart.get("warnings") or []
    if not warnings:
        return "<p class='muted'>未检测到时间边界或数据缺失风险。</p>"
    order = {"warning": 0, "caution": 1, "info": 2}
    items = []
    for warning in sorted(warnings, key=lambda item: order.get(item.get("level", "info"), 3)):
        items.append(
            f"<li class='warn-item {html.escape(warning.get('level', 'info'))}'>"
            f"<span class='warn-code'>{html.escape(warning.get('code', ''))}</span>"
            f"{html.escape(warning.get('message', ''))}</li>"
        )
    return "<ul class='warn-list'>" + "".join(items) + "</ul>"


def luck_summary(chart: dict) -> str:
    luck = chart.get("luck")
    if not luck:
        return "<p class='muted'>未提供性别或无法计算大运；报告中不应补写大运内容。</p>"
    cycles = luck.get("cycles", [])
    current = luck.get("current") or {}
    current_cycle = current.get("cycle") or {}
    current_flow = current.get("annual_flow") or {}
    start = luck["start_after_birth"]

    headline = (
        f"<p>起运约出生后 {start['years']} 年 {start['months']} 月 {start['days']} 日"
        f"（约 {html.escape(start['start_solar'])}），行运方向：{'顺行' if luck['forward'] else '逆行'}。</p>"
    )
    if current_cycle:
        headline += (
            f"<div class='current-luck'><div><small>当前大运</small>"
            f"<strong>{html.escape(current_cycle.get('ganzhi') or '幼运')}</strong>"
            f"<span>{current_cycle.get('start_year')}–{current_cycle.get('end_year')} 年 · "
            f"{current_cycle.get('start_age')}–{current_cycle.get('end_age')} 岁</span></div>"
            f"<div><small>当前流年</small><strong>{html.escape(current_flow.get('ganzhi', '—'))}</strong>"
            f"<span>{current_flow.get('year', '—')} 年 · 虚岁 {current_flow.get('age', '—')}</span></div></div>"
        )

    rows = []
    for cycle in cycles:
        is_current = bool(cycle.get("is_current")) or bool(
            current_cycle and cycle.get("index") == current_cycle.get("index")
        )
        klass = " class='is-current'" if is_current else ""
        badge = " <span class='badge'>当前</span>" if is_current else ""
        rows.append(
            f"<tr{klass}>"
            f"<td>{html.escape(cycle['ganzhi'] or '幼运')}{badge}</td>"
            f"<td>{cycle['start_year']} – {cycle['end_year']}</td>"
            f"<td>{cycle['start_age']} – {cycle['end_age']}</td>"
            f"<td>{html.escape(cycle['xunkong'])}</td>"
            "</tr>"
        )

    table = (
        '<div class="table-wrap"><table class="data-table luck-table">'
        "<thead><tr><th>大运</th><th>年份</th><th>年龄</th><th>旬空</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table></div>"
    )

    flows = ""
    if current_cycle and current_cycle.get("annual_flows"):
        flow_rows = []
        for flow in current_cycle["annual_flows"]:
            klass = " class='is-current'" if flow.get("year") == current.get("reference_year") else ""
            flow_rows.append(
                f"<tr{klass}><td>{flow['year']}</td><td>{flow['age']}</td>"
                f"<td>{html.escape(flow['ganzhi'])}</td></tr>"
            )
        flows = (
            "<h3>当前大运流年</h3><div class='table-wrap'><table class='data-table'>"
            "<thead><tr><th>年份</th><th>虚岁</th><th>流年干支</th></tr></thead>"
            f"<tbody>{''.join(flow_rows)}</tbody></table></div>"
        )

    return headline + table + flows


# ---------------------------------------------------------------------------
# Page assembly
# ---------------------------------------------------------------------------


def _collect_headings(markdown: str) -> list[tuple[int, str, str]]:
    """Return (level, text, anchor) for every heading, in document order."""
    headings: list[tuple[int, str, str]] = []
    in_code = False
    for raw in markdown.splitlines():
        stripped = raw.strip()
        if stripped.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        match = re.match(r"^(#{1,6})\s+(.+?)\s*#*$", stripped)
        if not match:
            continue
        level = len(match.group(1))
        text = re.sub(r"[*`_]", "", match.group(2)).strip()
        headings.append((level, text, f"h-{len(headings) + 1}"))
    return headings


def _toc_html(markdown: str) -> str:
    top = [item for item in _collect_headings(markdown) if item[0] == 1]
    if len(top) < 3:
        return ""
    links = "".join(f'<a href="#{anchor}">{html.escape(text)}</a>' for _, text, anchor in top)
    return f'<nav class="toc" aria-label="报告目录">{links}</nav>'


def _jie_line(chart: dict) -> str:
    calendar = chart.get("calendar") or {}
    parts = []
    if calendar.get("lunar"):
        parts.append(f"农历 {calendar['lunar']}")
    previous, following = _jie_name(calendar.get("previous_jie")), _jie_name(calendar.get("next_jie"))
    if previous != "—" and following != "—":
        parts.append(f"节气 {previous} 至 {following}")
    if calendar.get("year_shengxiao"):
        parts.append(f"生肖 {calendar['year_shengxiao']}")
    return " · ".join(parts)


def correction_table(chart: dict) -> str:
    corrections = chart["time_corrections"]
    input_data = chart["input"]
    dst_minutes = corrections.get("dst_offset_minutes", 0)
    rows = [
        (
            "钟表时间",
            _fmt_dt(corrections.get("clock_datetime", input_data["datetime"])),
            _fmt_offset(input_data.get("utc_offset_hours", 8)),
        ),
        (
            "还原标准时",
            _fmt_dt(corrections.get("standard_datetime", "—")),
            f"已扣除夏令时 {dst_minutes:g} 分钟" if dst_minutes else "无夏令时",
        ),
        (
            "经度校正",
            f"{_signed(corrections.get('longitude_correction_minutes', 0))} 分钟",
            f"标准子午线 {corrections.get('standard_meridian_degrees', 120):g}°，出生地 {input_data['longitude']}°",
        ),
        (
            "均时差",
            f"{_signed(corrections.get('equation_of_time_minutes', 0))} 分钟",
            "真太阳与平太阳的时差（近似公式）",
        ),
        (
            "真太阳时",
            _fmt_dt(corrections.get("true_solar_datetime", "—")),
            f"合计 {_signed(corrections.get('total_true_solar_offset_minutes', 0))} 分钟",
        ),
        (
            "时柱",
            f"{corrections['clock_hour_pillar']} → {corrections['chart_hour_pillar']}",
            "校正前后对比",
        ),
    ]
    body = "".join(
        f"<tr><th>{html.escape(label)}</th><td>{html.escape(value)}</td><td class='muted'>{html.escape(note)}</td></tr>"
        for label, value, note in rows
    )
    return (
        '<div class="table-wrap"><table class="data-table compact-table">'
        "<thead><tr><th>项目</th><th>结果</th><th>说明</th></tr></thead>"
        f"<tbody>{body}</tbody></table></div>"
    )


def appendix_html(chart: dict) -> str:
    warnings = chart.get("warnings") or []
    warning_badge = f"<span class='appendix-flag'>{len(warnings)} 项提示</span>" if warnings else ""
    bazi = chart["bazi"]
    calendar_line = _jie_line(chart)
    return f"""
<details class="appendix">
  <summary>
    <span>命盘依据与技术说明</span>
    {warning_badge}
    <small>四柱、五行权重、十神、关系、大运、时间校正与不确定项</small>
  </summary>
  <div class="appendix-body">
    <p class="muted">{html.escape(calendar_line)}</p>
    <h3>四柱</h3>
    {pillar_table(chart)}
    <div class="appendix-grid">
      <div class="panel">
        <h3>五行权重</h3>
        {element_bars(chart)}
      </div>
      <div class="panel">
        <h3>日主强弱</h3>
        {strength_panel(chart)}
      </div>
    </div>
    <div class="appendix-grid">
      <div class="panel">
        <h3>十神分布</h3>
        {ten_god_panel(chart)}
      </div>
      <div class="panel">
        <h3>喜忌参考</h3>
        {favorable_panel(chart)}
      </div>
    </div>
    <div class="panel">
      <h3>合冲刑害破</h3>
      {relations_list(chart)}
    </div>
    <h3>时间校正</h3>
    {correction_table(chart)}
    <h3>不确定项与数据提示</h3>
    {warnings_block(chart)}
    <h3>大运与流年</h3>
    {luck_summary(chart)}
  </div>
</details>
"""


def render_html(chart: dict, report_html: str, title: str, markdown: str = "") -> str:
    bazi = chart["bazi"]
    input_data = chart["input"]
    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    subject_name = chart.get("subject_name") or "未提供姓名"
    place = input_data.get("place") or f"{input_data['latitude']}, {input_data['longitude']}"
    luck = chart.get("luck") or {}
    current = luck.get("current") or {}
    current_cycle = current.get("cycle") or {}
    current_flow = current.get("annual_flow") or {}
    calendar = chart.get("calendar") or {}
    month_branch = bazi.get("month_branch") or ""
    season = calendar.get("season") or ""
    day_master = bazi.get("day_master", "")
    day_element = bazi.get("day_master_element", "")
    polarity = bazi.get("day_master_polarity", "")

    luck_card = (
        f"{html.escape(current_cycle.get('ganzhi') or '幼运')}"
        f"<span class='meta-sub'>{current_cycle.get('start_year')}–{current_cycle.get('end_year')}</span>"
        if current_cycle
        else "未提供"
    )
    flow_card = (
        f"{html.escape(current_flow.get('ganzhi', '—'))}"
        f"<span class='meta-sub'>{current_flow.get('year', '—')} 年 · 虚岁 {current_flow.get('age', '—')}</span>"
        if current_flow
        else "未提供"
    )
    toc = _toc_html(markdown)
    appendix = appendix_html(chart)

    css = """
:root{
  color-scheme:light;
  --ink:#1b2523;--muted:#66726f;--line:#dde2df;--paper:#fffefa;--soft:#f5f7f5;
  --deep:#102522;--green:#1f6b5c;--copper:#9b6a3c;--blue:#345f87;--rose:#9b4d4a;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;color:var(--ink);background:linear-gradient(180deg,#e8edeb 0,#f7f8f5 300px,#eef2f1 100%);
  font:16px/1.75 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;
  -webkit-font-smoothing:antialiased;}
.page{max-width:1120px;margin:0 auto;padding:30px 18px 58px}
.sheet{background:var(--paper);border:1px solid rgba(23,33,31,.15);box-shadow:0 28px 80px rgba(16,37,34,.13)}
.cover{position:relative;padding:44px 52px 36px;color:#f8fbf8;
  background:linear-gradient(135deg,rgba(16,37,34,.98),rgba(22,60,54,.96) 58%,rgba(91,63,42,.94));overflow:hidden}
.cover:after{content:"";position:absolute;inset:auto -80px -130px auto;width:400px;height:400px;
  border:1px solid rgba(255,255,255,.14);transform:rotate(32deg)}
.cover-inner{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,1fr) 250px;gap:36px;align-items:end}
.eyebrow{margin:0 0 16px;color:#c9d8d3;font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
h1{font-size:40px;line-height:1.18;margin:0;font-weight:760}
.subtitle{max-width:640px;margin:15px 0 0;color:#dce6e2;font-size:16px;line-height:1.75}
.seal{border:1px solid rgba(255,255,255,.26);background:rgba(255,255,255,.07);padding:18px 20px;border-radius:8px}
.seal small{display:block;color:#c9d8d3;font-size:12px}.seal strong{display:block;font-size:30px;line-height:1.2;margin:4px 0 12px;color:#fff}
.seal dl{display:grid;grid-template-columns:50px 1fr;gap:7px 12px;margin:0;font-size:13px}.seal dt{color:#c9d8d3}.seal dd{margin:0;color:#fff}
.meta-strip{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:1px;background:rgba(23,33,31,.15);border-bottom:1px solid var(--line)}
.meta-card{background:#fbfcfa;padding:16px 20px;min-width:0}
.meta-card small{display:block;color:var(--muted);font-size:12px}
.meta-card strong{display:block;margin-top:4px;font-size:16px;line-height:1.4;overflow-wrap:anywhere}
.meta-sub{display:block;margin-top:2px;color:var(--muted);font-size:12px;font-weight:400}
.content{padding:44px 52px 46px}
.article{max-width:820px;margin:0 auto}
.toc{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 34px;padding-bottom:20px;border-bottom:1px solid var(--line)}
.toc a{display:inline-block;padding:5px 12px;border:1px solid var(--line);border-radius:999px;background:#f6f8f7;
  color:#3b4a46;font-size:13px;text-decoration:none}
.toc a:hover{background:#edf7f4;color:var(--green);border-color:#c9e2d9}
.report-body{font-size:17px;line-height:1.95;color:#1e2a27}
.report-body h1{font-size:29px;line-height:1.3;margin:56px 0 18px;padding-top:26px;border-top:1px solid var(--line);color:var(--deep);font-weight:760}
.report-body h1:first-child{margin-top:0;padding-top:0;border-top:0}
.report-body h2{font-size:21px;line-height:1.4;margin:34px 0 12px;color:#1c3a34}
.report-body h3{font-size:18px;margin:26px 0 10px}
.report-body p{margin:0 0 17px}
.report-body ul,.report-body ol{padding-left:1.3em;margin:12px 0 20px}
.report-body li{margin:7px 0}
.report-body li>ul,.report-body li>ol{margin:8px 0 8px}
.report-body strong{color:#132a25;font-weight:700}
.report-body blockquote{margin:22px 0;padding:14px 18px;border-left:3px solid var(--green);background:#f0f7f4;color:#25423c;border-radius:0 6px 6px 0}
.report-body blockquote p{margin:0 0 8px}.report-body blockquote p:last-child{margin-bottom:0}
.report-body table{width:100%;border-collapse:collapse;margin:18px 0 22px;font-size:14px}
.report-body th,.report-body td{border:1px solid var(--line);padding:9px 11px;text-align:left;vertical-align:top}
.report-body th{background:#f1f5f3;font-weight:700}
.report-body hr{border:0;border-top:1px solid var(--line);margin:34px 0}
.report-body code{background:#edf1ef;border:1px solid #dce2df;border-radius:5px;padding:1px 6px;color:#23433c;font-size:.92em}
.report-body pre{background:#14201e;color:#f3f7f4;padding:16px;border-radius:8px;overflow:auto;font-size:14px;line-height:1.6}
.report-body a{color:var(--blue);text-decoration:underline;text-underline-offset:3px}
.appendix{margin:60px auto 0;max-width:1000px;border-top:1px solid var(--line);padding-top:6px}
.appendix summary{display:flex;flex-wrap:wrap;align-items:baseline;gap:10px;padding:16px 2px;cursor:pointer;list-style:none;color:var(--deep)}
.appendix summary::-webkit-details-marker{display:none}
.appendix summary>span{font-weight:750;font-size:16px}
.appendix summary small{color:var(--muted);font-size:13px}
.appendix summary::after{content:"展开 ＋";margin-left:auto;color:var(--green);font-size:13px;font-weight:600}
.appendix[open] summary::after{content:"收起 −"}
.appendix-flag{display:inline-block;padding:1px 8px;border-radius:999px;background:#fff4e5;border:1px solid #ecd6b6;color:#8a5a2b;font-size:12px;font-weight:600}
.appendix-body{padding:6px 2px 8px}
.appendix-body h3{font-size:16px;margin:30px 0 10px;color:#29433d}
.appendix-body>.muted{margin:0 0 6px;font-size:13px}
.appendix-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:16px 0}
.panel{border:1px solid var(--line);background:#fff;padding:16px 18px;border-radius:8px}
.panel h3{margin-top:0}
.muted{color:var(--muted)}
.term{appearance:none;border:0;background:transparent;color:inherit;font:inherit;line-height:inherit;margin:0;padding:1px 3px;border-radius:5px;cursor:pointer;text-align:inherit;text-decoration:underline;text-decoration-style:dotted;text-decoration-thickness:1px;text-underline-offset:4px;text-decoration-color:rgba(31,107,92,.42)}
.term:hover{color:var(--green);background:#edf7f4}.term:focus-visible{outline:3px solid rgba(31,107,92,.22);outline-offset:2px;color:var(--green);background:#edf7f4}
.term-ganzhi-main{font-size:18px;font-weight:780;color:var(--green);text-decoration-thickness:2px}
.term-popover{position:fixed;z-index:80;max-width:360px;background:#fffefa;border:1px solid rgba(23,33,31,.18);box-shadow:0 18px 55px rgba(16,37,34,.18);border-radius:10px;padding:14px 15px 13px;color:var(--ink)}
.term-popover[hidden]{display:none}.term-popover h4{margin:0 0 6px;font-size:16px;line-height:1.35;color:var(--deep)}.term-popover p{margin:0;color:#43504d;font-size:14px;line-height:1.65}.term-popover:before{content:"";position:absolute;top:-7px;left:22px;width:12px;height:12px;background:#fffefa;border-left:1px solid rgba(23,33,31,.18);border-top:1px solid rgba(23,33,31,.18);transform:rotate(45deg)}
.table-wrap{overflow-x:auto;border:1px solid var(--line);border-radius:8px;background:#fff}
.data-table{width:100%;border-collapse:collapse;margin:0;font-size:14px;min-width:680px}
.data-table th,.data-table td{border-bottom:1px solid var(--line);padding:11px 12px;text-align:left;vertical-align:top}
.data-table th{background:#f1f5f3;font-weight:700;color:#263532}
.data-table tr:last-child td,.data-table tr:last-child th{border-bottom:0}
.data-table tr.is-current td{background:#eef7f4;font-weight:700}
.compact-table{min-width:520px}
.ganzhi{font-size:18px;font-weight:780;color:var(--green)}
.element-grid{display:grid;gap:10px}
.element-row{display:grid;grid-template-columns:30px minmax(0,1fr) 50px 112px;gap:9px;align-items:center}
.element-name{font-weight:750}.bar{height:10px;background:#e7ebe8;border-radius:999px;overflow:hidden}
.bar i{display:block;height:100%;border-radius:999px;background:var(--green)}
.element-row b{font-size:14px;text-align:right}.element-row small{color:var(--muted);font-size:12px}
.wood .bar i{background:#3f8f62}.fire .bar i{background:#b95448}.earth .bar i{background:#a77943}.metal .bar i{background:#7e8d99}.water .bar i{background:#3f6f98}
.tg-grid{display:grid;gap:7px}
.tg-row{display:grid;grid-template-columns:62px minmax(0,1fr) 48px 150px;gap:8px;align-items:center;font-size:13px}
.tg-row b{text-align:right}.tg-row small{color:var(--muted);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.strength-head{display:flex;justify-content:space-between;align-items:flex-end;gap:12px}
.strength-head small{display:block;color:var(--muted);font-size:12px}.strength-head strong{font-size:20px}.strength-head b{font-size:30px;line-height:1;color:var(--green)}
.gauge{position:relative;height:11px;margin:14px 0 5px;border-radius:999px;
  background:linear-gradient(90deg,#b95448 0,#b95448 45%,#c9b06a 45%,#c9b06a 55%,#3f8f62 55%,#3f8f62 100%);opacity:.85}
.gauge span{position:absolute;top:-5px;width:4px;height:21px;margin-left:-2px;background:#102522;border-radius:2px;box-shadow:0 0 0 2px #fffefa}
.gauge-scale{display:flex;justify-content:space-between;color:var(--muted);font-size:12px}
.strength-meta{display:grid;grid-template-columns:86px 1fr;gap:5px 10px;margin:12px 0 8px;font-size:13px}
.strength-meta dt{color:var(--muted)}.strength-meta dd{margin:0}
.favorable-panel p{margin:0 0 8px}.favorable-panel p:last-child{margin-bottom:0}
.chip{display:inline-block;min-width:32px;text-align:center;padding:2px 9px;border-radius:999px;font-weight:700;margin-right:6px}
.chip-good{background:#e7f3ed;color:#1f6b5c;border:1px solid #bfe0d2}
.chip-bad{background:#fbeeed;color:#9b4d4a;border:1px solid #eccfcd}
.tension{border-left:3px solid var(--copper);background:#fff9f1;padding:8px 11px;color:#5b3d21;border-radius:4px}
.warn-list{list-style:none;margin:12px 0 0;padding:0;display:grid;gap:8px}
.warn-item{border:1px solid var(--line);border-left:4px solid var(--blue);background:#f7fafb;padding:10px 12px;border-radius:6px;font-size:13px}
.warn-item.caution{border-left-color:var(--copper);background:#fff9f1}
.warn-item.warning{border-left-color:var(--rose);background:#fdf5f4}
.warn-code{display:inline-block;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;color:var(--muted);margin-right:8px;padding:1px 5px;border-radius:4px;background:#eef1ef}
.relation-list{list-style:none;margin:0;padding:0;display:grid;gap:7px}
.relation-list li{border:1px solid var(--line);background:#fbfcfb;padding:8px 11px;border-radius:6px;font-size:13px}
.relation-list span{color:var(--muted)}
.current-luck{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:var(--line);border:1px solid var(--line);border-radius:8px;overflow:hidden;margin:12px 0 16px}
.current-luck>div{background:#eef7f4;padding:11px 14px}
.current-luck small{display:block;color:var(--muted);font-size:12px}
.current-luck strong{display:block;font-size:20px;color:var(--green)}
.current-luck span{color:var(--muted);font-size:12px}
.badge{display:inline-block;font-size:11px;font-weight:700;color:#fff;background:var(--green);padding:1px 6px;border-radius:999px;vertical-align:2px}
.footer{max-width:1000px;margin:38px auto 0;font-size:12.5px;line-height:1.7;color:var(--muted);padding-top:18px;border-top:1px solid var(--line)}
@media(max-width:900px){
  .cover-inner{grid-template-columns:1fr}.seal{max-width:420px}
  .meta-strip{grid-template-columns:repeat(2,minmax(0,1fr))}
  .content{padding:34px 26px 38px}
  .appendix-grid{grid-template-columns:1fr}
  .tg-row{grid-template-columns:56px minmax(0,1fr) 44px}.tg-row small{display:none}
  .element-row{grid-template-columns:28px minmax(0,1fr) 46px}.element-row small{display:none}
}
@media(max-width:620px){
  .page{padding:0}.sheet{border:0}
  .cover{padding:32px 20px}h1{font-size:30px}
  .meta-strip{grid-template-columns:1fr}
  .content{padding:26px 18px 32px}
  .report-body{font-size:16.5px;line-height:1.9}
  .report-body h1{font-size:25px;margin-top:44px}
  .data-table{font-size:13px;min-width:620px}
  .term-popover{left:14px!important;right:14px!important;top:auto!important;bottom:14px;max-width:none}
  .term-popover:before{display:none}
}
@media print{
  body{background:#fff}.page{max-width:none;padding:0}.sheet{box-shadow:none;border:0}
  .toc{display:none}.appendix{break-before:page}
  .table-wrap,.panel,.warn-item{break-inside:avoid}
  a{color:inherit;text-decoration:none}
}
"""

    script = """
(() => {
  const popover = document.querySelector('[data-term-popover]');
  if (!popover) return;
  const title = popover.querySelector('[data-term-title]');
  const desc = popover.querySelector('[data-term-desc]');
  let active = null;

  function hide() {
    if (active) active.setAttribute('aria-expanded', 'false');
    active = null;
    popover.hidden = true;
  }

  function show(button) {
    if (active && active !== button) active.setAttribute('aria-expanded', 'false');
    active = button;
    button.setAttribute('aria-expanded', 'true');
    title.textContent = button.dataset.title || button.textContent.trim();
    desc.textContent = button.dataset.desc || '暂无解释。';
    popover.hidden = false;
    popover.style.left = '0px';
    popover.style.top = '0px';

    const rect = button.getBoundingClientRect();
    const width = Math.min(360, window.innerWidth - 32);
    popover.style.maxWidth = width + 'px';
    const popRect = popover.getBoundingClientRect();
    const left = Math.min(Math.max(16, rect.left), window.innerWidth - width - 16);
    let top = rect.bottom + 10;
    if (top + popRect.height > window.innerHeight - 16) {
      top = Math.max(16, rect.top - popRect.height - 10);
    }
    popover.style.left = left + 'px';
    popover.style.top = top + 'px';
  }

  document.addEventListener('click', (event) => {
    const button = event.target.closest('.term');
    if (button) {
      event.preventDefault();
      event.stopPropagation();
      if (active === button && !popover.hidden) hide();
      else show(button);
      return;
    }
    if (!popover.contains(event.target)) hide();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') hide();
  });

  window.addEventListener('resize', hide);
  window.addEventListener('scroll', hide, true);
})();
"""

    version_note = ""
    if (chart.get("meta") or {}).get("schema_version"):
        version_note = f" · 数据结构 v{html.escape(chart['meta']['schema_version'])}"

    page = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="{html.escape(subject_name)}的心理特征分析报告，附命盘依据与技术说明。">
  <title>{html.escape(title)}</title>
  <style>{css}</style>
</head>
<body>
  <main class="page">
    <article class="sheet">
      <header class="cover">
        <div class="cover-inner">
          <div>
            <p class="eyebrow">Mingpan · Psychological Profile</p>
            <h1>{html.escape(title)}</h1>
            <p class="subtitle">以命盘为背景线索，聚焦人格结构、内在动机、压力调节、关系模式与发展课题的深度心理分析。</p>
          </div>
          <aside class="seal">
            <small>报告对象</small>
            <strong>{html.escape(subject_name)}</strong>
            <dl>
              <dt>日主</dt><dd>{html.escape(day_master)}{html.escape(day_element)}{f' · {html.escape(polarity)}' if polarity else ''}</dd>
              <dt>月令</dt><dd>{html.escape(month_branch)}{f'（{html.escape(season)}）' if season else ''}</dd>
              <dt>生成</dt><dd>{generated}</dd>
            </dl>
          </aside>
        </div>
      </header>
      <section class="meta-strip">
        <div class="meta-card"><small>出生时间</small><strong>{html.escape(_fmt_dt(input_data['datetime']))}</strong></div>
        <div class="meta-card"><small>出生地</small><strong>{html.escape(place)}</strong></div>
        <div class="meta-card"><small>四柱</small><strong>{html.escape(bazi['text'])}</strong></div>
        <div class="meta-card"><small>当前大运</small><strong>{luck_card}</strong></div>
        <div class="meta-card"><small>当前流年</small><strong>{flow_card}</strong></div>
      </section>
      <section class="content">
        <div class="article">
          {toc}
          <div class="report-body">{report_html}</div>
        </div>
        {appendix}
        <div class="footer">本报告为文化命理与反思性心理分析，不构成临床诊断、心理测评、医疗、法律或投资建议，也不做确定性预测。命盘数据由 lunar-python 计算；带“启发式”标注的推导只作观察方向。生成时间：{generated}{version_note}。</div>
      </section>
    </article>
  </main>
  <aside class="term-popover" data-term-popover hidden role="dialog" aria-live="polite">
    <h4 data-term-title></h4>
    <p data-term-desc></p>
  </aside>
  <script>{script}</script>
</body>
</html>
"""
    return "\n".join(line.rstrip() for line in page.splitlines()) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--chart", required=True, help="Path to chart JSON generated by generate_bazi_chart.py")
    parser.add_argument("--markdown", required=True, help="Path to the Markdown report body")
    parser.add_argument("--output", required=True, help="Output HTML path")
    parser.add_argument("--name", default="未提供姓名", help="Subject name displayed in the report")
    parser.add_argument("--title", default="心理特征分析报告")
    args = parser.parse_args()

    chart = json.loads(Path(args.chart).read_text(encoding="utf-8"))
    chart["subject_name"] = args.name
    markdown = Path(args.markdown).read_text(encoding="utf-8")
    report_html = markdown_to_html(markdown)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_html(chart, report_html, args.title, markdown), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
