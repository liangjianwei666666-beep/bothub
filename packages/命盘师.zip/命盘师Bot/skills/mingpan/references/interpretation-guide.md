# BaZi Psychological Interpretation Guide

Use this after running `scripts/generate_bazi_chart.py`. The script output is the factual layer; this guide controls the professional psychological interpretation layer.

## Default Deliverable

Create a standalone HTML document by default. The user should be able to open the file directly in a browser without a dev server.

Use this flow:

1. Generate chart JSON.
2. Write the report body as Markdown. For full reports, also apply `professional-report-standard.md`.
3. Run `scripts/render_html_report.py` with the chart JSON, Markdown, and the user's name.
4. Return a concise final message linking to the generated HTML file.

HTML quality requirements:

- The main body is the psychological report; the chart appears only as a compact cover/metadata summary and a collapsed appendix.
- Keep the appendix collapsed by default: four-pillar table, element weights, ten gods, relations, time corrections, warnings, and luck tables.
- Use a polished long-form layout: cover, compact metadata strip, readable measure (about 800px), clear section dividers, restrained palette, print-friendly styling.
- In the appendix, make chart terms clickable with short plain-language explanations; leave the body text clean.
- Keep the report readable on mobile and desktop.
- Do not require external CSS, fonts, JavaScript, images, or network access. Inline JavaScript is acceptable for local interactions such as term explanations.

## Report Shape

The report is a psychological analysis that happens to be grounded in a BaZi chart. It is not a chart walkthrough.

- Default to second person ("你") when the subject is the reader; use third person when the user orders for someone else, and say whose report it is.
- A full report is roughly 3,000–6,000 Chinese characters, 10–13 top-level sections, 250–500 characters each.
- Every section should carry at least three of these five moves: **具体现象 → 心理机制 → 现实代价 → 调节方式 → 可验证信号**.
- Chart anchors are seasoning, not structure: at most one or two short clauses per section (e.g. "月令水旺、官星偏重"). Hidden stems, Na Yin, growth phases, and correction steps belong in the appendix.
- Prefer concrete scenes and behaviours over adjectives. A reader should be able to say "这说得中" or "这不像我" — both are useful.
- State the boundary once, in 方法与边界. Do not repeat disclaimer language in every section.

## Section Plan

Use these headings for a full report:

1. **报告摘要**
   - 6–8 bullets: core temperament, main strength, main cost, core tension, current developmental task, 2–3 high-leverage actions.
   - Each bullet should be specific enough to be disagreed with.

2. **核心人格结构**
   - Separate outward style from inner operating system, then name the central tension.
   - Explain how the tension protects the person and what it costs.

3. **动机与投入方式**
   - What activates sustained effort; what makes effort feel meaningless.
   - The difference between "difficult but autonomous" and "difficult and controlled".
   - One practical negotiation: how to turn vague assignments into concrete contracts.

4. **情绪调节与压力反应**
   - Write the pressure chain step by step; name early signals, visible behaviour, and recovery needs.
   - A compact table of 信号 / 外人看到的样子 / 更有效的处理 works well here.
   - Normalize recovery as maintenance, not reward.

5. **关系与亲密模式**
   - Needs (respect for judgment, autonomy), conflict style, withdrawal/repair cycle.
   - Translate the cycle into what a partner experiences, then give a repair script.

6. **沟通与冲突**
   - How the person's directness lands on others; the gap between intent and impact.
   - One or two concrete rephrasing examples, plus a timing rule.

7. **事业角色与工作方式**
   - Role design: structure, authority distance, collaboration density, output form, pace.
   - Distinguish "capability arena" from guaranteed outcome.
   - What environments quietly drain the person.

8. **金钱与资源心理**
   - Where security actually comes from (predictability, buffer, structure).
   - Decision style, over-collection of information, reversible vs irreversible choices.
   - Not financial advice.

9. **家庭印记与早期模式**
   - Mark the whole section as a hypothesis.
   - Offer two plausible compensation paths and a concrete way to confirm or disconfirm in real life.

10. **当前阶段的发展课题**
    - One or two sentences placing the current luck cycle and annual flow; no table.
    - Opportunity, risk, and recommended posture for the next 6–12 months.

11. **盲区与风险提醒**
    - 3–5 behavioural blind spots with the cost of each; non-clinical.
    - Include one line on when to seek professional support.

12. **接下来 30 天 / 90 天 / 一年**
    - Concrete, small, observable actions. No motivational slogans.

13. **可验证假设**
    - 3–5 "如果…那么…" statements with an observation window.
    - Say explicitly that lived experience outranks the report.

14. **方法与边界**
    - One short section: deterministic chart data, heuristic derivations, uncertainty, non-diagnostic nature.

## Quality Bar

- Be concrete: avoid generic phrases that fit everyone.
- Explain why: every important claim should point to a pillar, element, ten-god, luck cycle, or timing marker.
- Balance strengths and risks.
- Use Chinese metaphysics terms, but translate them into plain-language implications.
- Keep tone professional and grounded.
- Keep chart bookkeeping out of the body; the appendix already shows the data.
- Use psychologically precise but non-clinical language. Prefer "压力反应", "安全感策略", "依恋倾向", "边界", "自我调节", "内在批评", "补偿性努力", and "发展课题".
- Avoid labels such as depression, anxiety disorder, narcissism, trauma diagnosis, ADHD, or personality disorder unless the user explicitly asks for clinical education; even then, do not diagnose.

## Boundary Notes

- This is a cultural metaphysics and reflective psychology report, not objective prediction or clinical assessment.
- Do not provide psychiatric diagnosis, medical diagnosis, investment instruction, legal advice, or fatalistic certainty.
- For major life decisions, frame the reading as reflective context.
