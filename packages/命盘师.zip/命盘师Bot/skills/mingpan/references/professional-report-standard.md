# Professional Mingpan Report Standard

Use this standard for premium user-facing HTML reports. It upgrades the report from "interpretive reading" to a structured reflective profile.

## Mandatory Professional Sections

A full report is psychology-first. The chart is evidence; the reader is the subject.

1. **报告摘要**
   - 6–8 bullets.
   - Core temperament, main strength, main cost, core tension, current developmental task, and 2–3 high-leverage actions.
   - Every bullet must be specific enough to disagree with.

2. **核心人格结构**
   - Separate outward style from inner operating system; name the central tension.
   - Explain what the tension protects and what it costs.

3. **动机与投入方式**
   - What starts sustained effort, what makes it feel meaningless, what the person needs to negotiate up front.

4. **情绪调节与压力反应**
   - A concrete pressure chain (trigger → internal move → visible behaviour → recovery need).
   - One compact table of signals and better responses is enough; no chart tables.

5. **关系与亲密模式**
   - Needs, conflict style, withdrawal/repair cycle, partner fit.

6. **沟通与冲突**
   - Intent vs impact, one or two rephrasing examples, a timing rule.

7. **事业角色与工作方式**
   - Role design, authority distance, collaboration density, output form, pace — capability arena, not guaranteed outcome.

8. **金钱与资源心理**
   - Where security comes from, decision style, reversible vs irreversible choices. Not financial advice.

9. **家庭印记与早期模式**
   - Mark as hypothesis; offer two compensation paths and a way to confirm or disconfirm.

10. **当前阶段的发展课题**
    - One or two sentences for the current luck cycle and annual flow; opportunity, risk, posture.

11. **盲区与风险提醒**
    - 3–5 behavioural blind spots with costs; one line on when to seek professional support.

12. **行动方案**
    - 30-day, 90-day, and 12-month actions; small, observable, no slogans.

13. **可验证假设**
    - 3–5 "如果…那么…" statements with an observation window.

14. **方法与边界**
    - One short section: deterministic chart data, heuristic derivations, uncertainty, non-diagnostic nature. Do not repeat this language elsewhere.

## Depth Standard

- 10–13 substantive sections, 250–500 Chinese characters each; total roughly 3,000–6,000 characters.
- Each section must carry at least three of: 具体现象、心理机制、现实代价、调节方式、可验证信号.
- A section that only restates chart data is a defect: move that material to the appendix.
- Chart anchors: at most one or two short clauses per section. No hidden-stem, Na Yin, growth-phase, or correction walkthroughs in the body.
- The appendix carries the audit trail: four pillars, weights, ten gods, relations, corrections, warnings, luck tables.

## Evidence Rules

- Every major claim must reference at least one chart anchor, stated in one short clause: pillar, element, ten-god, relation, luck cycle, or true-solar-time correction.
- Use "evidence chain" language: "这不是单凭某一项判断，而是由 X + Y + Z 共同指向".
- Do not overuse single indicators. No major conclusion should rely on only one relation such as one clash or one ten-god.
- Quote only relations present in `bazi.relations`; do not add 暗合, 神煞, or school-specific combinations from memory.
- When a derived field drives a claim, name the field (`element_profile`, `day_master_strength`, `ten_god_stats`, `favorable_elements`) and label it as heuristic.
- Clearly mark uncertainty when:
  - birth time is near a two-hour boundary;
  - true solar time changes the hour pillar;
  - birthplace is approximate;
  - the report infers psychology from symbolic data rather than observed behavior.

## Tone Requirements

- Professional, warm, precise, non-fatalistic.
- Write like a senior reflective consultant, not like fortune-telling copy.
- Prefer terms such as:
  - 核心调节策略
  - 安全感结构
  - 压力反应链
  - 边界与修复
  - 角色设计
  - 发展任务
  - 行为实验
  - 可验证假设
- Avoid:
  - "必然", "一定", "命中注定", "大凶", "断定".
  - clinical diagnosis labels.
  - generic praise that could fit anyone.

## Length And Density

- Full reports should feel substantial: usually 3,000–6,000 Chinese characters, 10–13 sections.
- Use short paragraphs and subheadings; avoid walls of text.
- Include one concise summary list near the top, one action plan near the end, and 3–5 verifiable hypotheses.
- Make the report skimmable first, deep second.

## Close

End with a grounded note: the report is for self-observation and planning. Encourage the user to compare it with lived experience and seek qualified support for persistent mental health, medical, legal, or financial issues.
