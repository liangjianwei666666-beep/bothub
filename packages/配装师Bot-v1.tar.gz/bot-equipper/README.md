# bot-equipper · 配装师 Bot 安装包

给 DS Bot 用户用：把这个包发给自己的主 Bot，说一句「装一个配装师」，它就会装好并建出这个 Bot。

## 这个 Bot 干什么

不按领域找资料，按 Bot 找缺口。它从 `~/.dsh/bot/state.json` 实读团队状态，算出：
多少 Bot 是空壳（人设 0 字）、多少没有工作目录、能力挂载是否错配、环境有没有断点（如 ffmpeg 不在 PATH）。

然后按 Bot 交「升级卡」：现在会什么 / 卡在哪 / 补什么 / 怎么装 / 怎么验。

## 需要什么

- 只需要 `python3`（系统自带即可，无第三方依赖）
- **不需要任何 API Key**
- 不联网也能跑扫描（只有给仓库核验时才需要 GitHub API）

## 装法

```bash
tar -xzf bot-equipper.tar.gz -C ~/.agents/skills/
bash ~/.agents/skills/bot-equipper/scripts/install.sh ~/Bot装备台
python3 ~/.agents/skills/bot-equipper/scripts/selfcheck.py
```

然后把上面的 SKILL.md 交给主 Bot，或直接说「装一个配装师」。

## 产出在哪

- `~/Bot装备台/矩阵/能力矩阵-<日期>.md` 与 `.html`（HTML 自包含，双击可开）
- `~/Bot装备台/升级卡/` 放具体 Bot 的升级卡
- `~/Bot装备台/台账.md` 装备台账

## 自检覆盖什么

合成一套假团队（5 个 Bot：2 个空壳、1 个短人设、1 个有挂载）跑扫描，验统计数字、产出文件、HTML 自包含、头像尺寸；最后一条扫真实 state.json。
