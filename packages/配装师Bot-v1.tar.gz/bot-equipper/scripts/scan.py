#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""扫描任意 DS Bot 团队：读 state.json + Skill 目录，产出能力矩阵（MD + 自包含 HTML）。
用法: scan.py [--state PATH] [--skills PATH] [--out DIR]
不依赖第三方库，Python 3.8+。
"""
import argparse, json, os, re, sys, html, datetime

TRACKS = [
    ("视频与动画", ["视频", "动画", "短剧", "导演", "编剧", "口播", "科普片", "3D", "分镜"]),
    ("图像与设计", ["图", "设计", "表情包", "绘本", "插画"]),
    ("内容发布与会审", ["公众号", "发布", "审核", "运营", "圈子", "社媒", "主编", "主笔"]),
    ("教育学科", ["语文", "数学", "英语", "雅思", "题库", "外教", "学科", "学习"]),
    ("泛教育运营", ["创学营", "星球", "全维", "陪跑", "PPT"]),
    ("小工具与产品", ["工具", "产品", "coding", "调度", "工程师"]),
    ("咨询与命理", ["塔罗", "命盘", "易经", "心理", "教练", "人生"]),
    ("生活服务", ["租房", "外卖", "移居", "生活"]),
    ("情报与运营", ["情报", "雷达", "盯盘", "下载", "重建", "带货"]),
    ("创作与音频", ["歌手", "音乐", "声"]),
    ("组织与治理", ["Chief", "BR", "OPC", "HR", "ENFP", "接单", "木", "火", "土", "金", "水"]),
]

def classify(bot):
    hay = " ".join([bot.get("name") or "", bot.get("role") or "", (bot.get("workDir") or "")])
    for track, keys in TRACKS:
        for k in keys:
            if k and k in hay:
                return track
    return "未分类"

def load_state(path):
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    raw = d.get("bots") or d.get("agents") or {}
    bots = list(raw.values()) if isinstance(raw, dict) else list(raw)
    caps = (d.get("capabilities") or {}).get("items") or {}
    return bots, caps

def list_skills(path):
    if not os.path.isdir(path):
        return []
    return sorted(x for x in os.listdir(path)
                  if not x.startswith(".") and not x.endswith((".tar.gz", ".zip", ".md")))

def build(bots, caps, skills, generated_at):
    rows = []
    for b in bots:
        ins = (b.get("instructions") or "").strip()
        rows.append({
            "name": b.get("name") or "(无名)",
            "track": classify(b),
            "persona": len(ins),
            "shell": len(ins) == 0,
            "short": 0 < len(ins) < 300,
            "model": (b.get("model") or "").split("/")[-1] or "—",
            "dir": (b.get("workDir") or "").replace(os.path.expanduser("~"), "~"),
            "caps": list(b.get("capabilities") or []),
        })
    tracks = []
    for r in rows:
        if r["track"] not in tracks:
            tracks.append(r["track"])
    stats = {
        "bots": len(rows),
        "persona_ok": sum(1 for r in rows if not r["shell"]),
        "shell": sum(1 for r in rows if r["shell"]),
        "short": sum(1 for r in rows if r["short"]),
        "skills": len(skills),
        "caps": len(caps),
        "mounted": sum(1 for r in rows if r["caps"]),
        "nodir": sum(1 for r in rows if not r["dir"]),
    }
    return rows, tracks, stats

def md(rows, tracks, stats, caps, skills, generated_at):
    L = []; w = L.append
    w("# 团队能力矩阵（%s）" % generated_at)
    w("")
    w("- 生成工具：bot-equipper / scan.py")
    w("- 数据来源：state.json 实读 + Skill 目录清单")
    w("- 状态：数据已核验；归因与优先级为判断")
    w("")
    w("> 一句话结论：先看空壳，再看环境断点，最后才看缺什么新资源。")
    w("")
    w("## 全局数字")
    w("")
    w("| 指标 | 数值 |")
    w("|---|---|")
    w("| Bot 总数 | %d |" % stats["bots"])
    w("| 有人设 | %d |" % stats["persona_ok"])
    w("| **空壳（人设 0 字）** | **%d** |" % stats["shell"])
    w("| 人设偏短（<300 字） | %d |" % stats["short"])
    w("| 已装 Skill | %d |" % stats["skills"])
    w("| 注册能力项 | %d |" % stats["caps"])
    w("| 已挂载能力的 Bot | %d / %d |" % (stats["mounted"], stats["bots"]))
    w("| 无独立工作目录 | %d |" % stats["nodir"])
    w("")
    w("## 按赛道")
    w("")
    w("| 赛道 | Bot 数 | 空壳 | 已挂载 | Bot 名单 |")
    w("|---|---|---|---|---|")
    for t in tracks:
        rs = [r for r in rows if r["track"] == t]
        w("| %s | %d | %d | %d | %s |" % (
            t, len(rs), sum(1 for r in rs if r["shell"]),
            sum(1 for r in rs if r["caps"]),
            "、".join(r["name"] for r in rs[:8])))
    w("")
    shells = [r for r in rows if r["shell"]]
    w("## 空壳名单（优先补人设）")
    w("")
    if shells:
        for r in shells:
            w("- **%s**（%s）" % (r["name"], r["track"]))
    else:
        w("- 无空壳")
    w("")
    w("## 升级优先级建议")
    w("")
    w("1. **P0 补空壳人设**：%d 个 Bot 没有职责与边界，跑默认提示。" % stats["shell"])
    w("2. **P0 查环境断点**：确认 ffmpeg / node / python 是否在本机 PATH（`command -v ffmpeg`）。")
    w("3. **P1 清错挂**：%d 个 Bot 挂了能力项，其余 %d 个零挂载，检查是否挂错或该挂没挂。"
      % (stats["mounted"], stats["bots"] - stats["mounted"]))
    w("4. **P2 补工作目录**：%d 个 Bot 没有独立 workDir，产物会混在一起。" % stats["nodir"])
    w("")
    w("## 已注册能力项")
    w("")
    if caps:
        for k, v in caps.items():
            w("- `%s`（%s）：%s" % (k, v.get("kind") or "?", (v.get("description") or "")[:80]))
    else:
        w("- 无")
    w("")
    w("## 证据边界")
    w("")
    w("- 已核实：Bot 数量、人设字数、模型、工作目录、能力挂载、Skill 目录清单。")
    w("- 判断：赛道归类、优先级排序。")
    w("- 未验证：空壳是否真的导致行为退化（未做对照实验）；workDir 为空是否造成文件混乱。")
    w("")
    w("> Skill 目录是会话级注入的，「人设没提某个 Skill」不等于「用不了」，所以不计为缺口。")
    return "\n".join(L) + "\n"

CSS = """:root{--bg:#f7f7f4;--paper:#fff;--ink:#24332e;--muted:#68736d;--line:#d9e1dc;--accent:#2f4f45;--soft:#eef3ef}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.75 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}
.wrap{max-width:1080px;margin:0 auto;padding:26px 20px 60px}.tag{font:12px ui-monospace,Menlo,monospace;color:var(--accent);letter-spacing:.08em}
h1{font-size:27px;color:var(--accent);margin:8px 0 4px}h2{font-size:20px;margin:28px 0 10px;padding-top:12px;border-top:1px solid var(--line);color:var(--accent)}
.meta{color:var(--muted);font-size:13px}.doc{background:var(--paper);padding:30px 36px;box-shadow:0 1px 8px #24332e10;margin-top:18px}
code{background:var(--soft);padding:1px 5px;border-radius:3px;font-size:.92em}
blockquote{margin:16px 0;padding:10px 14px;border-left:3px solid var(--accent);background:var(--soft);color:#4d5d55}
table{border-collapse:collapse;width:100%;font-size:13px;margin:12px 0}th,td{border:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top}
th{background:var(--soft);color:var(--accent)}footer{color:var(--muted);font-size:12px;margin-top:20px}
@media(max-width:640px){.doc{padding:20px 16px}h1{font-size:23px}}"""

def md_to_html(md_text):
    out = []; i = 0; lines = md_text.splitlines()
    def inline(s):
        s = html.escape(s, quote=False)
        s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
        s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
        return s
    while i < len(lines):
        ln = lines[i]
        if not ln.strip():
            i += 1; continue
        if ln.startswith("|") and i + 1 < len(lines) and lines[i + 1].startswith("|---"):
            head = [c.strip() for c in ln.strip("|").split("|")]; i += 2; body = []
            while i < len(lines) and lines[i].startswith("|"):
                body.append([c.strip() for c in lines[i].strip("|").split("|")]); i += 1
            out.append("<table><thead><tr>" + "".join("<th>%s</th>" % inline(c) for c in head) +
                       "</tr></thead><tbody>" + "".join(
                           "<tr>" + "".join("<td>%s</td>" % inline(c) for c in r) + "</tr>" for r in body) +
                       "</tbody></table>")
            continue
        m = re.match(r"^(#{1,3})\s+(.*)$", ln)
        if m:
            out.append("<h%d>%s</h%d>" % (len(m.group(1)), inline(m.group(2)), len(m.group(1)))); i += 1; continue
        if ln.startswith("> "):
            buf = []
            while i < len(lines) and lines[i].startswith("> "):
                buf.append(inline(lines[i][2:])); i += 1
            out.append("<blockquote>%s</blockquote>" % "<br>".join(buf)); continue
        if re.match(r"^\d+\.\s+", ln):
            buf = []
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i]):
                buf.append("<li>%s</li>" % inline(re.sub(r"^\d+\.\s+", "", lines[i]))); i += 1
            out.append("<ol>%s</ol>" % "".join(buf)); continue
        if ln.startswith("- "):
            buf = []
            while i < len(lines) and lines[i].startswith("- "):
                buf.append("<li>%s</li>" % inline(lines[i][2:])); i += 1
            out.append("<ul>%s</ul>" % "".join(buf)); continue
        out.append("<p>%s</p>" % inline(ln)); i += 1
    return "\n".join(out)

def html_doc(body, generated_at):
    return ("<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>团队能力矩阵 %s</title><style>%s</style></head><body><div class=\"wrap\">"
            "<div class=\"tag\">BOT-EQUIPPER / CAPABILITY MATRIX</div>"
            "<h1>团队能力矩阵</h1><div class=\"meta\">生成时间：%s　·　数据源：state.json 实读 + Skill 目录</div>"
            "<div class=\"doc\">%s</div>"
            "<footer>本页为自包含单文件，可离线打开。数据反映生成时刻，Bot 变动后请重新扫描。</footer>"
            "</div></body></html>") % (generated_at, CSS, generated_at, body)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--state", default=os.path.expanduser("~/.dsh/bot/state.json"))
    ap.add_argument("--skills", default=os.path.expanduser("~/.agents/skills"))
    ap.add_argument("--out", default=os.path.expanduser("~/Bot装备台/矩阵"))
    a = ap.parse_args()
    if not os.path.exists(a.state):
        print("ERROR 找不到 state.json：%s" % a.state, file=sys.stderr); sys.exit(2)
    bots, caps = load_state(a.state)
    skills = list_skills(a.skills)
    generated_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    rows, tracks, stats = build(bots, caps, skills, generated_at)
    text = md(rows, tracks, stats, caps, skills, generated_at)
    os.makedirs(a.out, exist_ok=True)
    day = datetime.date.today().isoformat()
    p_md = os.path.join(a.out, "能力矩阵-%s.md" % day)
    p_html = os.path.join(a.out, "能力矩阵-%s.html" % day)
    with open(p_md, "w", encoding="utf-8") as f: f.write(text)
    with open(p_html, "w", encoding="utf-8") as f: f.write(html_doc(md_to_html(text), generated_at))
    print("BOTS=%d SHELL=%d SKILLS=%d MOUNTED=%d NODIR=%d" % (
        stats["bots"], stats["shell"], stats["skills"], stats["mounted"], stats["nodir"]))
    print("MD=%s" % p_md)
    print("HTML=%s" % p_html)

if __name__ == "__main__":
    main()
