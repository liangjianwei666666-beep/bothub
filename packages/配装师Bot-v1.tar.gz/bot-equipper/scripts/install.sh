#!/usr/bin/env bash
# 装配「配装师」Bot 的工作台。用法: install.sh [目标目录]
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-$HOME/Bot装备台}"
mkdir -p "$TARGET/矩阵" "$TARGET/升级卡"
cp "$SKILL_DIR/payload/头像.png" "$TARGET/头像.png"
[ -f "$TARGET/台账.md" ] || cp "$SKILL_DIR/templates/台账模板.md" "$TARGET/台账.md"
[ -f "$TARGET/升级卡模板.md" ] || cp "$SKILL_DIR/templates/升级卡模板.md" "$TARGET/升级卡模板.md"
echo "STEP 依赖检查"
command -v python3 >/dev/null 2>&1 || { echo "ERROR 缺 python3，请先安装"; exit 3; }
echo "  python3: $(python3 -V 2>&1)"
echo "STEP 首次扫描"
if [ -f "$HOME/.dsh/bot/state.json" ]; then
  python3 "$SKILL_DIR/scripts/scan.py" --out "$TARGET/矩阵" || echo "WARN 扫描失败（不影响装配，可稍后手跑）"
else
  echo "  SKIP 未找到 ~/.dsh/bot/state.json（可能尚未建过 Bot）"
fi
echo "STEP 环境断点检查"
for b in ffmpeg node; do
  if command -v "$b" >/dev/null 2>&1; then echo "  OK   $b -> $(command -v $b)"
  else echo "  WARN $b 不在 PATH（若团队有视频/前端岗，这会是批量断点）"; fi
done
echo "TARGET=$TARGET"
echo "DONE 装配完成"
