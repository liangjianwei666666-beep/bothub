#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""bot-equipper 自检：在临时目录用合成数据跑一遍扫描，不碰真实工作目录。"""
import json, os, re, struct, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCAN = os.path.join(HERE, "scan.py")
res = []

def ok(name, cond, extra=""):
    res.append(("PASS" if cond else "FAIL", name, extra))

def png_size(path):
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return struct.unpack(">II", head[16:24])

# 1 必需文件齐全
for rel in ("SKILL.md", "payload/头像.png", "templates/台账模板.md",
            "templates/升级卡模板.md", "scripts/scan.py", "scripts/install.sh"):
    ok("文件存在 %s" % rel, os.path.exists(os.path.join(ROOT, rel)))

# 2 头像尺寸
sz = png_size(os.path.join(ROOT, "payload", "头像.png"))
ok("头像为 256x256 PNG", sz == (256, 256), str(sz))

# 3 合成一个"别人家"的团队来扫
tmp = tempfile.mkdtemp(prefix="equip-check-")
state = {"version": 1, "bots": {}, "capabilities": {"items": {"demo-skill": {"kind": "skill", "description": "演示用"}}}}
def bot(name, ins, wd="", caps=None):
    return {"name": name, "role": "", "instructions": ins, "model": "x/y-model",
            "workDir": wd, "capabilities": caps or []}
state["bots"] = {
    "a": bot("导演甲", ""),
    "b": bot("剪辑乙", ""),
    "c": bot("语文丙", "你是语文助手，负责读写。你说话简短。"),
    "d": bot("雅思丁", "很长的人设" * 80, "/tmp/ielts", ["demo-skill"]),
    "e": bot("未知戊", "短人设"),
}
sp = os.path.join(tmp, "state.json")
json.dump(state, open(sp, "w"), ensure_ascii=False)
skdir = os.path.join(tmp, "skills"); os.makedirs(skdir)
for s in ("demo-one", "demo-two", "demo-three"): os.makedirs(os.path.join(skdir, s))
out = os.path.join(tmp, "out")
r = subprocess.run([sys.executable, SCAN, "--state", sp, "--skills", skdir, "--out", out],
                   capture_output=True, text=True)
ok("扫描退出码 0", r.returncode == 0, r.stderr[-200:])
stdout = r.stdout
m = re.search(r"BOTS=(\d+) SHELL=(\d+) SKILLS=(\d+) MOUNTED=(\d+) NODIR=(\d+)", stdout)
ok("输出统计行可解析", bool(m))
if m:
    bots, shell, skills, mounted, nodir = map(int, m.groups())
    ok("Bot 数正确 (5)", bots == 5, str(bots))
    ok("空壳数正确 (2)", shell == 2, str(shell))
    ok("Skill 数正确 (3)", skills == 3, str(skills))
    ok("挂载数正确 (1)", mounted == 1, str(mounted))
    ok("无目录数正确 (4)", nodir == 4, str(nodir))
mds = [f for f in os.listdir(out) if f.endswith(".md")] if os.path.isdir(out) else []
hts = [f for f in os.listdir(out) if f.endswith(".html")] if os.path.isdir(out) else []
ok("产出 Markdown", len(mds) == 1, str(mds))
ok("产出 HTML", len(hts) == 1, str(hts))
if mds:
    body = open(os.path.join(out, mds[0]), encoding="utf-8").read()
    ok("MD 含空壳名单", "空壳名单" in body and "导演甲" in body)
    ok("MD 未把 Skill 未提及当缺口", "不等于「用不了」" in body)
if hts:
    h = open(os.path.join(out, hts[0]), encoding="utf-8").read()
    ok("HTML 自包含", "<style>" in h and "<script" not in h and "http-equiv" not in h)
    ok("HTML 含表格", h.count("<table>") >= 1, str(h.count("<table>")))

# 4 真机扫描（有 state.json 就跑，没就跳过）
real = os.path.expanduser("~/.dsh/bot/state.json")
if os.path.exists(real):
    r2 = subprocess.run([sys.executable, SCAN, "--out", os.path.join(tmp, "real")],
                        capture_output=True, text=True)
    ok("真机 state.json 扫描成功", r2.returncode == 0, r2.stderr[-200:])
else:
    ok("真机 state.json 扫描（无文件则跳过）", True, "skipped")

fails = [x for x in res if x[0] == "FAIL"]
for status, name, extra in res:
    print("%s %s%s" % (status, name, ("  :: " + extra) if extra and status == "FAIL" else ""))
print("SELFTEST PASS %d / FAIL %d" % (len(res) - len(fails), len(fails)))
sys.exit(1 if fails else 0)
