#!/usr/bin/env bash
# 打成分发包：产出 ~/.agents/skills/bot-equipper.tar.gz
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(dirname "$SKILL_DIR")/bot-equipper.tar.gz"
cd "$(dirname "$SKILL_DIR")"
rm -f "$OUT"
tar -czf "$OUT" \
  --exclude='.DS_Store' --exclude='__pycache__' --exclude='*.pyc' \
  "$(basename "$SKILL_DIR")"
echo "PACKAGED=$OUT"
echo "SIZE=$(du -h "$OUT" | cut -f1)"
tar -tzf "$OUT" | sed 's/^/  /'
